package federation.moduleHello;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/federation/Federation/src/federation/hello.idl"
 * <li> <b>IDL Name</b>      ::moduleHello::hello
 * <li> <b>Repository Id</b> IDL:moduleHello/hello:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface hello {
  ...
};
 * </pre>
 */
public final class helloHolder implements org.omg.CORBA.portable.Streamable {
  public federation.moduleHello.hello value;

  public helloHolder () {
  }

  public helloHolder (final federation.moduleHello.hello _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = federation.moduleHello.helloHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    federation.moduleHello.helloHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return federation.moduleHello.helloHelper.type();
  }
}
