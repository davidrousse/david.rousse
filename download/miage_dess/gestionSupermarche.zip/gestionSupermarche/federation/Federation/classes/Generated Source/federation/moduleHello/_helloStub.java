package federation.moduleHello;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/federation/Federation/src/federation/hello.idl"
 * <li> <b>IDL Name</b>      ::moduleHello::hello
 * <li> <b>Repository Id</b> IDL:moduleHello/hello:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface hello {
  ...
};
 * </pre>
 */
public class _helloStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements hello {
  final public static java.lang.Class _opsClass = federation.moduleHello.helloOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:moduleHello/hello:1.0"
  };

  /**
   * <pre>
   *   string getMessage ();
   * </pre>
   */
  public java.lang.String getMessage () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("getMessage", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("getMessage", _opsClass);
        if (_so == null) {
          continue;
        }
        final federation.moduleHello.helloOperations _self = (federation.moduleHello.helloOperations)_so.servant;
        try {
          return _self.getMessage();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
