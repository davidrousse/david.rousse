package federation.moduleHello;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/federation/Federation/src/federation/hello.idl"
 * <li> <b>IDL Name</b>      ::moduleHello::hello
 * <li> <b>Repository Id</b> IDL:moduleHello/hello:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface hello {
  ...
};
 * </pre>
 */
public interface helloOperations {
  /**
   * <pre>
   *   string getMessage ();
   * </pre>
   */
  public java.lang.String getMessage ();

}
