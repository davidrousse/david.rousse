package federation.moduleHello;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/federation/Federation/src/federation/hello.idl"
 * <li> <b>IDL Name</b>      ::moduleHello::hello
 * <li> <b>Repository Id</b> IDL:moduleHello/hello:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface hello {
  ...
};
 * </pre>
 */
public class helloPOATie extends helloPOA {
  private federation.moduleHello.helloOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public helloPOATie (final federation.moduleHello.helloOperations _delegate) {
    this._delegate = _delegate;
  }

  public helloPOATie (final federation.moduleHello.helloOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public federation.moduleHello.helloOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final federation.moduleHello.helloOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   string getMessage ();
   * </pre>
   */
  public java.lang.String getMessage () {
    return this._delegate.getMessage();
  }

}
