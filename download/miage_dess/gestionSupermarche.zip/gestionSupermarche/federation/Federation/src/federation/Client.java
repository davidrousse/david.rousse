package federation;

import federation.moduleHello.*;
import federation.moduleHello.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class Client {
  public static void main(String args[]) {

    try {
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);
        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent("supermarche","designation");
        NamingContext desiCtx = NamingContextHelper.narrow(racineArbre.resolve(nom));

        for(int i=0;i<10;i++) {

          String nomObjet = new String("objet n�"+i);

          nom = new org.omg.CosNaming.NameComponent[1];
          nom[0] = new org.omg.CosNaming.NameComponent(nomObjet,"objet_metier");

          org.omg.CORBA.Object distant = desiCtx.resolve(nom);

          hello monObj = federation.moduleHello.helloHelper.narrow(distant);

          System.out.println(monObj.getMessage());
        }

      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }//fin du main
}