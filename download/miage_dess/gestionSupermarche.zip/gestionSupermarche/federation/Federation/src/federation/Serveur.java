package federation;

import federation.moduleHello.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class Serveur {

  public static void main(String[] args) {
    try {

      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      Federation utilFede = new Federation();
      utilFede.creerEspaceNom(racineObj,"federation","siege","supermarche");

      utilFede.ecrireIOR(orb,utilFede.recupererFederation(),args[0]);

      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };

      POA poa = rootPOA.create_POA("monPOA",rootPOA.the_POAManager(),policies);

      for(int i=0;i<10;i++) {

        String nomObjet = new String("objet n�"+i);

        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(nomObjet,"objet_metier");

        HelloImpl monServant = new HelloImpl(nomObjet);

        byte[] monId = nomObjet.getBytes();

        poa.activate_object_with_id(monId, monServant);

        utilFede.recupererContexteDesignation().rebind(nom,poa.servant_to_reference(monServant));

        System.out.println(poa.servant_to_reference(monServant) + " est pret.");
      }

      rootPOA.the_POAManager().activate();

      System.out.println("Contenu racine :");
      utilFede.parcourirRacine();

      System.out.println("Contenu federation :");
      utilFede.parcourirFederation();

      System.out.println("Contenu designation :");
      utilFede.parcourirDesignation();

      for(int i=0;i<10;i++) {

        String nomObjet = new String("objet n�"+i);

        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(nomObjet,"objet_metier");

        //utilFede.supprimerObjectContexteDesignation(nom);
        //System.out.println("Suppression de "+nomObjet);
      }

      //utilFede.supprimerFederation();
      //utilFede.supprimerContexteDesignation();

      System.out.println("Contenu designation :");
      utilFede.parcourirDesignation();

      System.out.println("Contenu federation :");
      utilFede.parcourirFederation();

      //utilFede.supprimerRacine();
      System.out.println("Contenu racine :");
      utilFede.parcourirRacine();

      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}