package federation;

import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import java.io.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class VisualiserContenuFederation {

  public static void main(String[] args) {
    try {

      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      Federation utilFede = new Federation();
      utilFede.creerEspaceNom(racineObj,args[1],args[0],args[2]);

      /**
       * Recuperation autre federation
       */
      String ligne;
      BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));


      // On attend des saisies de noms de fedeations
      System.out.println("Entrer la nom du fichier. Taper FIN pour quitter.");
      while(!(ligne = entree.readLine()).equals("FIN")) {
        NamingContext fedeDistante = utilFede.recupererFederationDistante(orb,ligne);

        Vector contenuDistant = utilFede.recupererContenuNamingContext(fedeDistante);
        System.out.println("Contenu federation "+ligne+" :");
        Enumeration parcours = contenuDistant.elements();
        while(parcours.hasMoreElements()) {
          NameComponent nc = (NameComponent)parcours.nextElement();
          System.out.println("Nom:"+nc.id+" - Type:"+nc.kind);
        }
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}