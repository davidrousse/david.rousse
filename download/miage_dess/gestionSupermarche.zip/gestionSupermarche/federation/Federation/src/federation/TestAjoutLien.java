package federation;

import federation.moduleHello.*;

import federation.moduleHello.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class TestAjoutLien {
  public static void main(String[] args) {
    try {

      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      Federation utilFede = new Federation();
      utilFede.creerEspaceNom(racineObj,"federation1","toulouse","supermarche1");

      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };

      POA poa = rootPOA.create_POA("monPOA",rootPOA.the_POAManager(),policies);

      for(int i=0;i<10;i++) {

        String nomObjet = new String("objet n�"+i);

        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(nomObjet,"objet_metier");

        HelloImpl monServant = new HelloImpl(nomObjet);

        byte[] monId = nomObjet.getBytes();

        poa.activate_object_with_id(monId, monServant);

        utilFede.recupererContexteDesignation().rebind(nom,poa.servant_to_reference(monServant));

        System.out.println(poa.servant_to_reference(monServant) + " est pret.");
      }

      /**
       * Recuperation autre federation
       */
      NamingContext fedeDistante = utilFede.recupererFederationDistante(orb,args[0]);

      System.out.println("Contenu federation distante :");
      utilFede.parcourirNamingContext(fedeDistante);

      System.out.println("Contenu federation locale avant copie :");
      utilFede.parcourirFederation();

      /**
       * Test copie federation
       */
      utilFede.copierNamingContext(fedeDistante);

      System.out.println("Contenu federation locale apres copie :");
      utilFede.parcourirFederation();

      System.out.println("Contenu federation distante avant mise � jour :");
      utilFede.parcourirNamingContext(fedeDistante);

      /**
       * Test mise � jour federation distante
       */
      utilFede.creerLien(fedeDistante,utilFede.recupererRacine(),"test","federation");

      System.out.println("Contenu federation distante apres mise � jour :");
      utilFede.parcourirNamingContext(fedeDistante);

      rootPOA.the_POAManager().activate();

      System.out.println("Contenu racine :");
      utilFede.parcourirRacine();

      /**
       * Test appel objet distant
       */
      for(int i=0;i<10;i++) {

        String nomObjet = new String("objet n�"+i);

        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[4];
        nom[0] = new org.omg.CosNaming.NameComponent("federation","federation");
        nom[1] = new org.omg.CosNaming.NameComponent("siege","federation");
        nom[2] = new org.omg.CosNaming.NameComponent("supermarche","designation");
        nom[3] = new org.omg.CosNaming.NameComponent(nomObjet,"objet_metier");

        // On recherche la r�f�rence
        org.omg.CORBA.Object distant = utilFede.recupererRacine().resolve(nom);

        //casting de l'objet CORBA au type adequat
        hello monObj = federation.moduleHello.helloHelper.narrow(distant);

        //appel methode
        System.out.println(monObj.getMessage());
      }


      System.out.println("Contenu designation :");
      utilFede.parcourirDesignation();

      for(int i=0;i<10;i++) {

        String nomObjet = new String("objet n�"+i);

        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(nomObjet,"objet_metier");

        utilFede.supprimerObjectContexteDesignation(nom);
        System.out.println("Suppression de "+nomObjet);
      }

      System.out.println("Contenu racine :");
      utilFede.parcourirRacine();

      /**
       * Test recuperation contenu d'un NamingContext
       */
      Vector contenuDistant = utilFede.recupererContenuNamingContext(fedeDistante);
      System.out.println("Contenu federation distante :");
      Enumeration parcours = contenuDistant.elements();
      while(parcours.hasMoreElements()) {
        NameComponent nc = (NameComponent)parcours.nextElement();
        System.out.println("Nom:"+nc.id+" - Type:"+nc.kind);
      }

      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}