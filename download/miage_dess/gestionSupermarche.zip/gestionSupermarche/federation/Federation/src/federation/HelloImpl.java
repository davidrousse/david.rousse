package federation;

import federation.moduleHello.*;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class HelloImpl extends helloPOA {

  private String _nom;

  public HelloImpl(String nom) {
    _nom = nom;
  }
  public String getMessage() {
    return _nom;
  }
}