package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public class GererProduitsPOATie extends GererProduitsPOA {
  private gererstocks.supermarche.GererProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererProduitsPOATie (final gererstocks.supermarche.GererProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererProduitsPOATie (final gererstocks.supermarche.GererProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererstocks.supermarche.GererProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererstocks.supermarche.GererProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws  gererstocks.supermarche.GererProduitsException {
    this._delegate.creer(codeBarre, designation, prixHT);
  }

  /**
   * <pre>
   *   void creerP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gererstocks.supermarche.Produit p) throws  gererstocks.supermarche.GererProduitsException {
    this._delegate.creerP(p);
  }

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws  gererstocks.supermarche.GererProduitsException {
    this._delegate.supprimer(codeBarre);
  }

  /**
   * <pre>
   *   void supprimerP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gererstocks.supermarche.Produit p) throws  gererstocks.supermarche.GererProduitsException {
    this._delegate.supprimerP(p);
  }

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws  gererstocks.supermarche.GererProduitsException {
    this._delegate.modifier(codeBarre, designation, prixHT);
  }

  /**
   * <pre>
   *   void modifierP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gererstocks.supermarche.Produit p) throws  gererstocks.supermarche.GererProduitsException {
    this._delegate.modifierP(p);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercher (in string codeBarre)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gererstocks.supermarche.GererProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercherP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercherP (gererstocks.supermarche.Produit p) throws  gererstocks.supermarche.GererProduitsException {
    return this._delegate.rechercherP(p);
  }

}
