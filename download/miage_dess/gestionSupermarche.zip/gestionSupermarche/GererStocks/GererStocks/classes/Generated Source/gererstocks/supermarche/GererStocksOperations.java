package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public interface GererStocksOperations {
  /**
   * <pre>
   *   readonly attribute gererstocks.supermarche.listeStocks listeS;
   * </pre>
   */
  public gererstocks.supermarche.Stock[] listeS ();

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   void creerS (in gererstocks.supermarche.Stock s)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gererstocks.supermarche.Stock s) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementerS (in gererstocks.supermarche.Stock s)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gererstocks.supermarche.Stock s) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementerS (in gererstocks.supermarche.Stock s)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gererstocks.supermarche.Stock s) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   gererstocks.supermarche.Stock rechercher (in string codeBarre)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public gererstocks.supermarche.Stock rechercher (java.lang.String codeBarre) throws gererstocks.supermarche.GererStocksException;

  /**
   * <pre>
   *   gererstocks.supermarche.Stock rechercherS (in gererstocks.supermarche.Stock s)
    raises (gererstocks.supermarche.GererStocksException);
   * </pre>
   */
  public gererstocks.supermarche.Stock rechercherS (gererstocks.supermarche.Stock s) throws gererstocks.supermarche.GererStocksException;

}
