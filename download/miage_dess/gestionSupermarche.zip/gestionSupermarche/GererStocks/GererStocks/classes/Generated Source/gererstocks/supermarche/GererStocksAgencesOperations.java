package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public interface GererStocksAgencesOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void creerS (in gererstocks.supermarche.Stock s, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gererstocks.supermarche.Stock s, 
                      java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementerS (in gererstocks.supermarche.Stock s, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gererstocks.supermarche.Stock s, 
                            java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementerS (in gererstocks.supermarche.Stock s, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gererstocks.supermarche.Stock s, 
                            java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gererstocks.supermarche.Stock rechercher (in string codeBarre,
                                            in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererstocks.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                   java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gererstocks.supermarche.Stock rechercherS (in gererstocks.supermarche.Stock s,
                                             in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererstocks.supermarche.Stock rechercherS (gererstocks.supermarche.Stock s, 
                                                    java.lang.String agence) throws gererstocks.supermarche.GererStocksAgencesException;

}
