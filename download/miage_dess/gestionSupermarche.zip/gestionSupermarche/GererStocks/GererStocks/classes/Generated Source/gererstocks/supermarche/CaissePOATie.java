package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public class CaissePOATie extends CaissePOA {
  private gererstocks.supermarche.CaisseOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public CaissePOATie (final gererstocks.supermarche.CaisseOperations _delegate) {
    this._delegate = _delegate;
  }

  public CaissePOATie (final gererstocks.supermarche.CaisseOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererstocks.supermarche.CaisseOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererstocks.supermarche.CaisseOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public double totalVentes () {
    return this._delegate.totalVentes();
  }

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public void totalVentes (double totalVentes) {
    this._delegate.totalVentes(totalVentes);
  }

  /**
   * <pre>
   *   readonly attribute string agence;
   * </pre>
   */
  public java.lang.String agence () {
    return this._delegate.agence();
  }

  /**
   * <pre>
   *   readonly attribute string caissier;
   * </pre>
   */
  public java.lang.String caissier () {
    return this._delegate.caissier();
  }

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws  gererstocks.supermarche.CaisseException {
    this._delegate.vendreS(codeBarre);
  }

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in long qte)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       int qte) throws  gererstocks.supermarche.CaisseException {
    this._delegate.vendreC(codeBarre, qte);
  }

  /**
   * <pre>
   *   void editerTicket ()
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void editerTicket () throws  gererstocks.supermarche.CaisseException {
    this._delegate.editerTicket();
  }

  /**
   * <pre>
   *   void connecter (in string login, in string password)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void connecter (java.lang.String login, 
                         java.lang.String password) throws  gererstocks.supermarche.CaisseException {
    this._delegate.connecter(login, password);
  }

  /**
   * <pre>
   *   void deconnecter (in string login)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login) throws  gererstocks.supermarche.CaisseException {
    this._delegate.deconnecter(login);
  }

}
