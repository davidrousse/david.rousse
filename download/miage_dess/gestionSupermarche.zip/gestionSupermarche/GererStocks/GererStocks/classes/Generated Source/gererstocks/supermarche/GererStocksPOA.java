package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public abstract class GererStocksPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, gererstocks.supermarche.GererStocksOperations {

  public gererstocks.supermarche.GererStocks _this () {
   return gererstocks.supermarche.GererStocksHelper.narrow(super._this_object());
  }

  public gererstocks.supermarche.GererStocks _this (org.omg.CORBA.ORB orb) {
    return gererstocks.supermarche.GererStocksHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererStocks:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_listeS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("creer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("creerS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("incrementer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("incrementerS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("decrementer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("decrementerS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
    _methods.put("rechercher", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 7));
    _methods.put("rechercherS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 8));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return gererstocks.supermarche.GererStocksPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (gererstocks.supermarche.GererStocksOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        gererstocks.supermarche.Stock[] _result = _self.listeS();
        _output = _handler.createReply();
        gererstocks.supermarche.listeStocksHelper.write(_output, _result);
        return _output;
      }
      case 1: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        _self.creer(codeBarre, qte);
        _output = _handler.createReply();
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 2: {
      try {
        gererstocks.supermarche.Stock s;
        s = gererstocks.supermarche.StockHelper.read(_input);
        _self.creerS(s);
        _output = _handler.createReply();
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 3: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        _self.incrementer(codeBarre, qte);
        _output = _handler.createReply();
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 4: {
      try {
        gererstocks.supermarche.Stock s;
        s = gererstocks.supermarche.StockHelper.read(_input);
        _self.incrementerS(s);
        _output = _handler.createReply();
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 5: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        _self.decrementer(codeBarre, qte);
        _output = _handler.createReply();
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 6: {
      try {
        gererstocks.supermarche.Stock s;
        s = gererstocks.supermarche.StockHelper.read(_input);
        _self.decrementerS(s);
        _output = _handler.createReply();
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 7: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        gererstocks.supermarche.Stock _result = _self.rechercher(codeBarre);
        _output = _handler.createReply();
        gererstocks.supermarche.StockHelper.write(_output, _result);
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 8: {
      try {
        gererstocks.supermarche.Stock s;
        s = gererstocks.supermarche.StockHelper.read(_input);
        gererstocks.supermarche.Stock _result = _self.rechercherS(s);
        _output = _handler.createReply();
        gererstocks.supermarche.StockHelper.write(_output, _result);
      }
      catch (gererstocks.supermarche.GererStocksException _exception) {
        _output = _handler.createExceptionReply();
        gererstocks.supermarche.GererStocksExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
