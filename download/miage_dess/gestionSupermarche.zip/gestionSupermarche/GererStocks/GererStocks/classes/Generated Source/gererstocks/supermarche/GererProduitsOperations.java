package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gererstocks.supermarche.Produit p) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gererstocks.supermarche.Produit p) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gererstocks.supermarche.Produit p) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercher (in string codeBarre)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercher (java.lang.String codeBarre) throws gererstocks.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercherP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.GererProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercherP (gererstocks.supermarche.Produit p) throws gererstocks.supermarche.GererProduitsException;

}
