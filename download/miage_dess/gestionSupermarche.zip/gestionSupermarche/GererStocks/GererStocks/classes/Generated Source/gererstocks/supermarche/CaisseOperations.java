package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public interface CaisseOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public double totalVentes ();

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public void totalVentes (double totalVentes);

  /**
   * <pre>
   *   readonly attribute string agence;
   * </pre>
   */
  public java.lang.String agence ();

  /**
   * <pre>
   *   readonly attribute string caissier;
   * </pre>
   */
  public java.lang.String caissier ();

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws gererstocks.supermarche.CaisseException;

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in long qte)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       int qte) throws gererstocks.supermarche.CaisseException;

  /**
   * <pre>
   *   void editerTicket ()
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void editerTicket () throws gererstocks.supermarche.CaisseException;

  /**
   * <pre>
   *   void connecter (in string login, in string password)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void connecter (java.lang.String login, 
                         java.lang.String password) throws gererstocks.supermarche.CaisseException;

  /**
   * <pre>
   *   void deconnecter (in string login)
    raises (gererstocks.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login) throws gererstocks.supermarche.CaisseException;

}
