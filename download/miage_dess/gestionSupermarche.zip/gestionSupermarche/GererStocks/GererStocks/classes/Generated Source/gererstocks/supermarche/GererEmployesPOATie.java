package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class GererEmployesPOATie extends GererEmployesPOA {
  private gererstocks.supermarche.GererEmployesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererEmployesPOATie (final gererstocks.supermarche.GererEmployesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererEmployesPOATie (final gererstocks.supermarche.GererEmployesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererstocks.supermarche.GererEmployesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererstocks.supermarche.GererEmployesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gererstocks.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gererstocks.supermarche.Employe[] listeE () {
    return this._delegate.listeE();
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  gererstocks.supermarche.GererEmployesException {
    this._delegate.creer(login, password, droit);
  }

  /**
   * <pre>
   *   void creerE (in gererstocks.supermarche.Employe e)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gererstocks.supermarche.Employe e) throws  gererstocks.supermarche.GererEmployesException {
    this._delegate.creerE(e);
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  gererstocks.supermarche.GererEmployesException {
    this._delegate.modifier(login, password, droit);
  }

  /**
   * <pre>
   *   void modifierE (in gererstocks.supermarche.Employe e)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gererstocks.supermarche.Employe e) throws  gererstocks.supermarche.GererEmployesException {
    this._delegate.modifierE(e);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  gererstocks.supermarche.GererEmployesException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   void supprimerE (in gererstocks.supermarche.Employe e)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gererstocks.supermarche.Employe e) throws  gererstocks.supermarche.GererEmployesException {
    this._delegate.supprimerE(e);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Employe rechercher (in string login)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public gererstocks.supermarche.Employe rechercher (java.lang.String login) throws  gererstocks.supermarche.GererEmployesException {
    return this._delegate.rechercher(login);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Employe rechercherE (in gererstocks.supermarche.Employe e)
    raises (gererstocks.supermarche.GererEmployesException);
   * </pre>
   */
  public gererstocks.supermarche.Employe rechercherE (gererstocks.supermarche.Employe e) throws  gererstocks.supermarche.GererEmployesException {
    return this._delegate.rechercherE(e);
  }

}
