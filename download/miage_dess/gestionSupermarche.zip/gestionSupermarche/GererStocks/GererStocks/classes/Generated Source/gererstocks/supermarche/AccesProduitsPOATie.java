package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public class AccesProduitsPOATie extends AccesProduitsPOA {
  private gererstocks.supermarche.AccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public AccesProduitsPOATie (final gererstocks.supermarche.AccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public AccesProduitsPOATie (final gererstocks.supermarche.AccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererstocks.supermarche.AccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererstocks.supermarche.AccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercher (in string codeBarre)
    raises (gererstocks.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gererstocks.supermarche.AccesProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercherP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercherP (gererstocks.supermarche.Produit p) throws  gererstocks.supermarche.AccesProduitsException {
    return this._delegate.rechercherP(p);
  }

}
