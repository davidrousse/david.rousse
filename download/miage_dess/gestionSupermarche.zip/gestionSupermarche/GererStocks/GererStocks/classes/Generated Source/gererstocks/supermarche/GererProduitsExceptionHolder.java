package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduitsException
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduitsException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererProduitsException {
  ...
};
 * </pre>
 */
public final class GererProduitsExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public gererstocks.supermarche.GererProduitsException value;

  public GererProduitsExceptionHolder () {
  }

  public GererProduitsExceptionHolder (final gererstocks.supermarche.GererProduitsException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gererstocks.supermarche.GererProduitsExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gererstocks.supermarche.GererProduitsExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gererstocks.supermarche.GererProduitsExceptionHelper.type();
  }
}
