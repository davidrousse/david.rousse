package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployesException
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployesException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererEmployesException {
  ...
};
 * </pre>
 */
public final class GererEmployesExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public gererstocks.supermarche.GererEmployesException value;

  public GererEmployesExceptionHolder () {
  }

  public GererEmployesExceptionHolder (final gererstocks.supermarche.GererEmployesException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gererstocks.supermarche.GererEmployesExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gererstocks.supermarche.GererEmployesExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gererstocks.supermarche.GererEmployesExceptionHelper.type();
  }
}
