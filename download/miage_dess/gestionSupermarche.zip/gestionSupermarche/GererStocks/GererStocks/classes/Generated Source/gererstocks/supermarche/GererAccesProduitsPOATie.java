package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public class GererAccesProduitsPOATie extends GererAccesProduitsPOA {
  private gererstocks.supermarche.GererAccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererAccesProduitsPOATie (final gererstocks.supermarche.GererAccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererAccesProduitsPOATie (final gererstocks.supermarche.GererAccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererstocks.supermarche.GererAccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererstocks.supermarche.GererAccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gererstocks.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public gererstocks.supermarche.AccesProduits[] listeAP () {
    return this._delegate.listeAP();
  }

  /**
   * <pre>
   *   gererstocks.supermarche.AccesProduits creer (in string agence)
    raises (gererstocks.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.AccesProduits creer (java.lang.String agence) throws  gererstocks.supermarche.GererAccesProduitsException {
    return this._delegate.creer(agence);
  }

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (gererstocks.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws  gererstocks.supermarche.GererAccesProduitsException {
    this._delegate.supprimer(agence);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.AccesProduits rechercher (in string agence)
    raises (gererstocks.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.AccesProduits rechercher (java.lang.String agence) throws  gererstocks.supermarche.GererAccesProduitsException {
    return this._delegate.rechercher(agence);
  }

}
