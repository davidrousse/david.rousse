package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercher (in string codeBarre)
    raises (gererstocks.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercher (java.lang.String codeBarre) throws gererstocks.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   gererstocks.supermarche.Produit rechercherP (in gererstocks.supermarche.Produit p)
    raises (gererstocks.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererstocks.supermarche.Produit rechercherP (gererstocks.supermarche.Produit p) throws gererstocks.supermarche.AccesProduitsException;

}
