package gererstocks.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/GererStocks/GererStocks/src/gererstocks/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public class GererStocksAgencesPOATie extends GererStocksAgencesPOA {
  private gererstocks.supermarche.GererStocksAgencesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksAgencesPOATie (final gererstocks.supermarche.GererStocksAgencesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksAgencesPOATie (final gererstocks.supermarche.GererStocksAgencesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererstocks.supermarche.GererStocksAgencesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererstocks.supermarche.GererStocksAgencesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    this._delegate.creer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void creerS (in gererstocks.supermarche.Stock s, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gererstocks.supermarche.Stock s, 
                      java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    this._delegate.creerS(s, agence);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    this._delegate.incrementer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void incrementerS (in gererstocks.supermarche.Stock s, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gererstocks.supermarche.Stock s, 
                            java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    this._delegate.incrementerS(s, agence);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    this._delegate.decrementer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void decrementerS (in gererstocks.supermarche.Stock s, in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gererstocks.supermarche.Stock s, 
                            java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    this._delegate.decrementerS(s, agence);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Stock rechercher (in string codeBarre,
                                            in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererstocks.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                   java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    return this._delegate.rechercher(codeBarre, agence);
  }

  /**
   * <pre>
   *   gererstocks.supermarche.Stock rechercherS (in gererstocks.supermarche.Stock s,
                                             in string agence)
    raises (gererstocks.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererstocks.supermarche.Stock rechercherS (gererstocks.supermarche.Stock s, 
                                                    java.lang.String agence) throws  gererstocks.supermarche.GererStocksAgencesException {
    return this._delegate.rechercherS(s, agence);
  }

}
