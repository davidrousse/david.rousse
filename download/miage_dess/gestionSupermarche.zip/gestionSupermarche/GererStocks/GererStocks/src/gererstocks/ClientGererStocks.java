package gererstocks;

import gererstocks.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ClientGererStocks {

  public static void main(String args[]) {

    try {
      // On intialise l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      // On construit le nom � chercher dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[1],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      // On recherche la r�f�rence aupr�s du naming service
      org.omg.CORBA.Object distant = racineArbre.resolve(nom);

      //casting de l'objet CORBA au type adequat
      GererStocks monObj = gererstocks.supermarche.GererStocksHelper.narrow(distant);

      // On appelle les methodes
      for(int i=1;i<50;i++) {
        try {
          monObj.creer((new Integer(i)).toString(),i);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          monObj.incrementer((new Integer(i)).toString(),10);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          monObj.decrementer((new Integer(i)).toString(),10);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
      }


      for(int i=50;i<100;i++) {
        Stock s = new Stock((new Integer(i)).toString(),i);
        try {
          monObj.creerS(s);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercherS(s)+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          s.qte=10;
          monObj.incrementerS(s);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercherS(s)+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          s.qte=10;
          monObj.decrementerS(s);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercherS(s)+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
      }

      for(int i=1000;i<1010;i++) {
        try {
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          monObj.incrementer((new Integer(i)).toString(),-10);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercherS(new Stock((new Integer(i)).toString(),0))+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          monObj.decrementer((new Integer(i)).toString(),-10);
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
        try {
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");
        }
        catch(gererstocks.supermarche.GererStocksException e) {
          System.out.println(e.toString());
        }
      }

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }//fin du main
}