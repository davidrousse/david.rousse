package gererstocks;

import gererstocks.supermarche.*;
import java.util.*;
import java.lang.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class GererStocksImpl extends GererStocksPOA {

  private Hashtable _listeS;

  public Stock[] listeS(){
  // retourne la liste des stocks
    Enumeration parcours = _listeS.elements();
    Stock[] listeStock = new Stock[_listeS.size()];;
    int i=0;
    while(parcours.hasMoreElements()) {
      listeStock[i] = (Stock)parcours.nextElement();
      i++;
    }
    return listeStock;
  }

  // constructeur
  public GererStocksImpl() {
    _listeS = new Hashtable();
  }

  public void creer (String codeBarre, int qte) throws gererstocks.supermarche.GererStocksException {
    // v�rifier que le stock pour ce code barre n'est pas d�j� cr��
    if (!_listeS.containsKey(codeBarre)){
      Integer q = new Integer(qte);
      _listeS.put(codeBarre,q);
      System.out.println("Cr�ation du stock reussie - Code barre : "+codeBarre);
    }
    else {
      System.out.println("Cr�ation du stock impossible - "+codeBarre+" existe deja.");
      throw new gererstocks.supermarche.GererStocksException ("Cr�ation du stock impossible - "+codeBarre+" existe deja.");
    }
  }

  public void creerS (Stock s) throws gererstocks.supermarche.GererStocksException {
    // v�rifier que le stock pour ce code barre n'est pas d�j� cr��
    if (!_listeS.containsKey(s.codeBarre)){
      Integer q = new Integer(s.qte);
      _listeS.put(s.codeBarre, q);
      System.out.println("Cr�ation du stock reussie - Code barre : "+s.codeBarre);
    }
    else
      throw new gererstocks.supermarche.GererStocksException ("Cr�ation du stock impossible - "+s.codeBarre+" existe deja.");
  }

  public void incrementer (String codeBarre, int qte) throws gererstocks.supermarche.GererStocksException {
    // v�rifier que le code barre existe
    if (_listeS.containsKey(codeBarre)){
        Integer q1 =  new Integer((_listeS.get(codeBarre).toString()));
        Integer q2 = new Integer(qte);
        Integer q = new Integer(q1.intValue() + q2.intValue());
        _listeS.put(codeBarre, q);
    }
    else
      throw new gererstocks.supermarche.GererStocksException ("Incrementation du stock impossible - "+codeBarre+" est inconnu.");
  }

  public void incrementerS (Stock s) throws gererstocks.supermarche.GererStocksException {
    // v�rifier que le code barre existe
    if (_listeS.containsKey(s.codeBarre)){
        Integer q1 =  new Integer((_listeS.get(s.codeBarre).toString()));
        Integer q2 = new Integer(s.qte);
        Integer q = new Integer(q1.intValue() + q2.intValue());
        _listeS.put(s.codeBarre, q);
    }
    else
      throw new gererstocks.supermarche.GererStocksException ("Incrementation du stock impossible - "+s.codeBarre+" est inconnu.");
  }

  public void decrementer (String codeBarre, int qte) throws gererstocks.supermarche.GererStocksException {
    // v�rifier que le code barre existe
    if (_listeS.containsKey(codeBarre)){
        Integer q1 =  new Integer((_listeS.get(codeBarre).toString()));
        Integer q2 = new Integer(qte);
        Integer q = new Integer (q1.intValue() - q2.intValue());
        _listeS.put(codeBarre, q);
    }
    else
      throw new gererstocks.supermarche.GererStocksException ("Decrementation du stock impossible - "+codeBarre+" est inconnu.");
  }

  public void decrementerS (Stock s) throws gererstocks.supermarche.GererStocksException {
  // v�rifier que le code barre existe
    if (_listeS.containsKey(s.codeBarre)){
        Integer q1 =  new Integer((_listeS.get(s.codeBarre).toString()));
        Integer q2 = new Integer(s.qte);
        Integer q = new Integer(q1.intValue() - q2.intValue());
        _listeS.put(s.codeBarre, q);
    }
    else
      throw new gererstocks.supermarche.GererStocksException ("Decrementation du stock impossible - "+s.codeBarre+" est inconnu.");
  }

  public Stock rechercher (String codeBarre) throws gererstocks.supermarche.GererStocksException {

     // v�rifier que le code barre existe
    if (_listeS.containsKey(codeBarre))
      return new Stock(codeBarre,((Integer)_listeS.get(codeBarre)).intValue());
    else
      throw new gererstocks.supermarche.GererStocksException ("Recherche du stock impossible - "+codeBarre+" est inconnu.");
  }

  public Stock rechercherS (Stock s) throws gererstocks.supermarche.GererStocksException {
   // v�rifier que le code barre existe
    if (_listeS.containsKey(s.codeBarre))
      return new Stock(s.codeBarre,((Integer)_listeS.get(s.codeBarre)).intValue());
    else
      throw new gererstocks.supermarche.GererStocksException ("Recherche du stock impossible - "+s.codeBarre+" est inconnu.");
  }
}