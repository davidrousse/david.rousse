package gereraccesproduits;

import gereraccesproduits.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ClientGererAccesProduits {

  public static void main(String args[]) {

    try {
	// On intialise l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
        org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

        //on r�cup�re ensuite la racine de l'arbre
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

        // On construit le nom � chercher dans l'annuaire
        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
        nom[0] = new org.omg.CosNaming.NameComponent(args[1],"designation");
        nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

        // On recherche la r�f�rence aupr�s du naming service
        org.omg.CORBA.Object distant = racineArbre.resolve(nom);

        //casting de l'objet CORBA au type adequat
	GererAccesProduits monObj = gereraccesproduits.supermarche.GererAccesProduitsHelper.narrow(distant);

        // On appelle les methodes
        for(int i=1;i<11;i++) {
          AccesProduits ap = monObj.creer("agence "+i);
          try {
            System.out.println("Resultat :\n"+ap.rechercher((new Integer(i)).toString())+"\n********\n");
          }
          catch(gereraccesproduits.supermarche.AccesProduitsException e) {
            System.out.println(e.toString());
          }

          try {
            System.out.println("Resultat :\n"+ap.rechercher((new Integer(i)).toString())+"\n********\n");
          }
          catch(gereraccesproduits.supermarche.AccesProduitsException e) {
            System.out.println(e.toString());
          }
          //monObj.supprimer("agence "+i);
          //System.out.println("Suppression agence "+i);
          //Test appel sur servant supprim�
          try{
            //System.out.println("Resultat test :\n"+ap.rechercher((new Integer(i)).toString())+"\n********\n");
          }
          catch(Exception e) {
            System.out.println("Appel impossible - "+e.toString());
          }
        }

        // autre test ...
        AccesProduits[] tabAP = monObj.listeAP();
        for(int i=0;i<tabAP.length;i++)
          System.out.println("Resultat :\n"+tabAP[i].rechercher((new Integer(i+1)).toString())+"\n********\n");

        try {
          System.out.println("Resultat :\n"+tabAP[1].rechercher((new Integer(9999999)).toString())+"\n********\n");
        }
        catch(gereraccesproduits.supermarche.AccesProduitsException e) {
          System.out.println(e.toString());
        }
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }//fin du main

}