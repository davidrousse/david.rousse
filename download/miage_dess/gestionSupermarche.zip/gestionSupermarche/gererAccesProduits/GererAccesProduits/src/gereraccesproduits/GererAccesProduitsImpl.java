package gereraccesproduits;

import gereraccesproduits.supermarche.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class GererAccesProduitsImpl extends GererAccesProduitsPOA {

  private Hashtable _liste;
  private String _nomFichier;

  public GererAccesProduitsImpl(String nomFichier) {
    _nomFichier = new String(nomFichier);
    _liste = new Hashtable();
  }
  public synchronized AccesProduits creer(String nomAgence) throws gereraccesproduits.supermarche.GererAccesProduitsException {

    // on verifie que l'agence n'est pas deja connectee
    AccesProduits obj = (AccesProduits) _liste.get(nomAgence);
    // si ce n'est pas le cas, on cree un AccesDonneesImpl
    if(obj == null) {

      // creation d'un servant
      AccesProduitsImpl objServant = new AccesProduitsImpl(nomAgence,_nomFichier);
      try {
        // activation de l'objet dans le POA par defaut
        obj = AccesProduitsHelper.narrow(_default_POA().servant_to_reference(objServant));
        // information de log
        System.out.println(_default_POA().servant_to_reference(objServant) + " est pret.");
      }
      catch (Exception e) {
        e.printStackTrace();
      }
      // ajout dans la liste des servants instancies
      _liste.put(nomAgence, obj);
    }
    // renvoie de l'objet demand�
    return obj;
  }
  public void supprimer(String nomAgence) throws gereraccesproduits.supermarche.GererAccesProduitsException {
    // fermetrue d'un AccesProduits
    AccesProduits obj = (AccesProduits) _liste.get(nomAgence);
    if (obj != null) {
      try{
        _default_POA().deactivate_object(_default_POA().reference_to_id(obj));
        _liste.remove(nomAgence);
        // information de log
        System.out.println("AccesProduit pour "+nomAgence+ " est arrete.");
      } catch (Exception e)
      {
        return;
      }
    } else {
      // l'objet n'existe pas
      return;
    }
    return;
  }
  public AccesProduits rechercher(String nomAgence) throws gereraccesproduits.supermarche.GererAccesProduitsException {
    return (AccesProduits)_liste.get(nomAgence);
  }

  public AccesProduits[] listeAP() {
    Enumeration parcours = _liste.elements();
    AccesProduits[] retour = new AccesProduits[_liste.size()];
    int i=0;
    while(parcours.hasMoreElements()) {
      retour[i] = (AccesProduits)parcours.nextElement();
      i++;
    }
    return retour;
  }
}