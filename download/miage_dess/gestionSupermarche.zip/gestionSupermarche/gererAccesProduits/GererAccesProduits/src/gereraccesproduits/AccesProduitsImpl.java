package gereraccesproduits;

import gereraccesproduits.supermarche.*;
import java.util.StringTokenizer;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class AccesProduitsImpl extends AccesProduitsPOA {

  private LectureDonnees _lecture;
  private String _nomObjet;

  public AccesProduitsImpl(String nomObjet,String nomFichier) {
    _lecture = new LectureDonnees(nomFichier);
    _nomObjet = new String(nomObjet);
    System.out.println("Creation de AccesProduits pour "+nomObjet);
  }

  public Produit rechercher(String codeBarre) throws gereraccesproduits.supermarche.AccesProduitsException {
    try {
      String ligne;
      ligne = _lecture.rechercher(codeBarre);
      StringTokenizer decouperLigne = new StringTokenizer(ligne,"\t");
      Produit retour = new Produit(decouperLigne.nextToken(),decouperLigne.nextToken(),(new Double(decouperLigne.nextToken())).doubleValue());
      return retour;
    }
    catch(Exception e) {
      _lecture.mettreAJour();
      System.out.println("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+codeBarre+" - Exception : "+e);
      throw new gereraccesproduits.supermarche.AccesProduitsException("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+codeBarre);
    }
  }

  public Produit rechercherP(Produit p) throws gereraccesproduits.supermarche.AccesProduitsException {
    try{
      StringTokenizer decouperLigne = new StringTokenizer(_lecture.rechercher(p.codeBarre),"\t");
      Produit retour = new Produit(decouperLigne.nextToken(),decouperLigne.nextToken(),(new Double(decouperLigne.nextToken())).doubleValue());

      return retour;
    }
    catch(Exception e) {
      _lecture.mettreAJour();
      System.out.println("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre+" - Exception : "+e);
      throw new gereraccesproduits.supermarche.AccesProduitsException("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre);
    }
  }
  public String nomObjet() {
    return _nomObjet;
  }
}