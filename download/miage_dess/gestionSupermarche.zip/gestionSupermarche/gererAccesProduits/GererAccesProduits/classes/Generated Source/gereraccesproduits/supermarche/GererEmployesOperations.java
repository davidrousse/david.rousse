package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployesOperations {
  /**
   * <pre>
   *   readonly attribute gereraccesproduits.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gereraccesproduits.supermarche.Employe[] listeE ();

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void creerE (in gereraccesproduits.supermarche.Employe e)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gereraccesproduits.supermarche.Employe e) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifierE (in gereraccesproduits.supermarche.Employe e)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gereraccesproduits.supermarche.Employe e) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimerE (in gereraccesproduits.supermarche.Employe e)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gereraccesproduits.supermarche.Employe e) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Employe rechercher (in string login)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Employe rechercher (java.lang.String login) throws gereraccesproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Employe rechercherE (in gereraccesproduits.supermarche.Employe e)
    raises (gereraccesproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Employe rechercherE (gereraccesproduits.supermarche.Employe e) throws gereraccesproduits.supermarche.GererEmployesException;

}
