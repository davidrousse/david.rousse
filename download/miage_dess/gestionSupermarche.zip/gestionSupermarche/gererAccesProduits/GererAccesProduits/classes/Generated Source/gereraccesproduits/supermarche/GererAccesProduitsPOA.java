package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public abstract class GererAccesProduitsPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, gereraccesproduits.supermarche.GererAccesProduitsOperations {

  public gereraccesproduits.supermarche.GererAccesProduits _this () {
   return gereraccesproduits.supermarche.GererAccesProduitsHelper.narrow(super._this_object());
  }

  public gereraccesproduits.supermarche.GererAccesProduits _this (org.omg.CORBA.ORB orb) {
    return gereraccesproduits.supermarche.GererAccesProduitsHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererAccesProduits:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_listeAP", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("creer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("supprimer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("rechercher", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return gereraccesproduits.supermarche.GererAccesProduitsPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (gereraccesproduits.supermarche.GererAccesProduitsOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        gereraccesproduits.supermarche.AccesProduits[] _result = _self.listeAP();
        _output = _handler.createReply();
        gereraccesproduits.supermarche.listeAccesProduitsHelper.write(_output, _result);
        return _output;
      }
      case 1: {
      try {
        java.lang.String agence;
        agence = _input.read_string();
        gereraccesproduits.supermarche.AccesProduits _result = _self.creer(agence);
        _output = _handler.createReply();
        gereraccesproduits.supermarche.AccesProduitsHelper.write(_output, _result);
      }
      catch (gereraccesproduits.supermarche.GererAccesProduitsException _exception) {
        _output = _handler.createExceptionReply();
        gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 2: {
      try {
        java.lang.String agence;
        agence = _input.read_string();
        _self.supprimer(agence);
        _output = _handler.createReply();
      }
      catch (gereraccesproduits.supermarche.GererAccesProduitsException _exception) {
        _output = _handler.createExceptionReply();
        gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 3: {
      try {
        java.lang.String agence;
        agence = _input.read_string();
        gereraccesproduits.supermarche.AccesProduits _result = _self.rechercher(agence);
        _output = _handler.createReply();
        gereraccesproduits.supermarche.AccesProduitsHelper.write(_output, _result);
      }
      catch (gereraccesproduits.supermarche.GererAccesProduitsException _exception) {
        _output = _handler.createExceptionReply();
        gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
