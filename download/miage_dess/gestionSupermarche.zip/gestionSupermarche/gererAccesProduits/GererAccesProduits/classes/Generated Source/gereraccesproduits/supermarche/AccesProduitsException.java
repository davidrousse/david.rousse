package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduitsException
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduitsException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception AccesProduitsException {
  ...
};
 * </pre>
 */
public final class AccesProduitsException extends org.omg.CORBA.UserException {
  
  public java.lang.String raison;

  public AccesProduitsException () {
    super(gereraccesproduits.supermarche.AccesProduitsExceptionHelper.id());
  }

  public AccesProduitsException (java.lang.String raison) {
    this();
    this.raison = raison;
  }

  public AccesProduitsException (java.lang.String _reason, java.lang.String raison) {
    super(gereraccesproduits.supermarche.AccesProduitsExceptionHelper.id() + ' ' + _reason);
    this.raison = raison;
  }

  public java.lang.String toString () {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("exception gereraccesproduits.supermarche.AccesProduitsException {");
    _ret.append("\n");
    _ret.append("java.lang.String raison=");
    _ret.append(raison != null?'\"' + raison + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;
    if (o instanceof gereraccesproduits.supermarche.AccesProduitsException) {
      final gereraccesproduits.supermarche.AccesProduitsException obj = (gereraccesproduits.supermarche.AccesProduitsException)o;
      boolean res = true;
      do {
        res = this.raison == obj.raison ||
         (this.raison != null && obj.raison != null && this.raison.equals(obj.raison));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
