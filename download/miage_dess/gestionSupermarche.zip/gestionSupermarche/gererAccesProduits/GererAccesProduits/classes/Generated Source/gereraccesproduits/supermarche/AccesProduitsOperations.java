package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Produit rechercher (in string codeBarre)
    raises (gereraccesproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Produit rechercher (java.lang.String codeBarre) throws gereraccesproduits.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Produit rechercherP (in gereraccesproduits.supermarche.Produit p)
    raises (gereraccesproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Produit rechercherP (gereraccesproduits.supermarche.Produit p) throws gereraccesproduits.supermarche.AccesProduitsException;

}
