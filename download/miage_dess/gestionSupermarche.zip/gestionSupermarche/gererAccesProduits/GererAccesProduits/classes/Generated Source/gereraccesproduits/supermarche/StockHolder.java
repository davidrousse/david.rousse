package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Stock
 * <li> <b>Repository Id</b> IDL:supermarche/Stock:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Stock {
  ...
};
 * </pre>
 */
public final class StockHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.Stock value;

  public StockHolder () {
  }

  public StockHolder (final gereraccesproduits.supermarche.Stock _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.StockHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.StockHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.StockHelper.type();
  }
}
