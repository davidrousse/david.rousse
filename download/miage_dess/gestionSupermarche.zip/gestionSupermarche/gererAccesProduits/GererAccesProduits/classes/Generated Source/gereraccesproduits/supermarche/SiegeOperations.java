package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public interface SiegeOperations {
  /**
   * <pre>
   *   readonly attribute gereraccesproduits.supermarche.listeAgences listeA;
   * </pre>
   */
  public java.lang.String[] listeA ();

  /**
   * <pre>
   *   void inscrire (in string agence)
    raises (gereraccesproduits.supermarche.SiegeException);
   * </pre>
   */
  public void inscrire (java.lang.String agence) throws gereraccesproduits.supermarche.SiegeException;

  /**
   * <pre>
   *   void desinscrire (in string agence)
    raises (gereraccesproduits.supermarche.SiegeException);
   * </pre>
   */
  public void desinscrire (java.lang.String agence) throws gereraccesproduits.supermarche.SiegeException;

}
