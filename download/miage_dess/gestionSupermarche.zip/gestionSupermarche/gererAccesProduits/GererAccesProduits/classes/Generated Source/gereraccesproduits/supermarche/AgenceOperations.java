package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public interface AgenceOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   readonly attribute gereraccesproduits.supermarche.listeCaisses listeC;
   * </pre>
   */
  public gereraccesproduits.supermarche.Caisse[] listeC ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge);

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public double TVA ();

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public void TVA (double TVA);

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws gereraccesproduits.supermarche.AgenceException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Caisse creer (in string login,
                                               in string agence,
                                               in string loginCaissier)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Caisse creer (java.lang.String login, 
                                                      java.lang.String agence, 
                                                      java.lang.String loginCaissier) throws gereraccesproduits.supermarche.AgenceException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gereraccesproduits.supermarche.AgenceException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Caisse rechercher (in string login)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Caisse rechercher (java.lang.String login) throws gereraccesproduits.supermarche.AgenceException;

}
