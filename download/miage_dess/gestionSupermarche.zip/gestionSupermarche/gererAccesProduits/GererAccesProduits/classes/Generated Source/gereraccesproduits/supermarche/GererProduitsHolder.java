package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public final class GererProduitsHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.GererProduits value;

  public GererProduitsHolder () {
  }

  public GererProduitsHolder (final gereraccesproduits.supermarche.GererProduits _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.GererProduitsHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.GererProduitsHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.GererProduitsHelper.type();
  }
}
