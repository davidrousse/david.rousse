package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public class _AgenceStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements Agence {
  final public static java.lang.Class _opsClass = gereraccesproduits.supermarche.AgenceOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Agence:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomObjet", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomObjet", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.nomObjet();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute gereraccesproduits.supermarche.listeCaisses listeC;
   * </pre>
   */
  public gereraccesproduits.supermarche.Caisse[] listeC () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereraccesproduits.supermarche.Caisse[] _result;
        try {
          _output = this._request("_get_listeC", true);
          _input = this._invoke(_output);
          _result = gereraccesproduits.supermarche.listeCaissesHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeC", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.listeC();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_marge", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_marge", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.marge();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_marge", true);
          _output.write_double((double)marge);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_marge", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          _self.marge(marge);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public double TVA () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_TVA", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_TVA", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.TVA();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public void TVA (double TVA) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_TVA", true);
          _output.write_double((double)TVA);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_TVA", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          _self.TVA(TVA);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws  gereraccesproduits.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereraccesproduits.supermarche.Produit _result;
        try {
          _output = this._request("recupererInfoProduit", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = gereraccesproduits.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereraccesproduits.supermarche.AgenceExceptionHelper.id())) {
            throw             gereraccesproduits.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("recupererInfoProduit", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.recupererInfoProduit(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Caisse creer (in string login,
                                               in string agence,
                                               in string loginCaissier)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Caisse creer (java.lang.String login, 
                                                      java.lang.String agence, 
                                                      java.lang.String loginCaissier) throws  gereraccesproduits.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereraccesproduits.supermarche.Caisse _result;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)login);
          _output.write_string((java.lang.String)agence);
          _output.write_string((java.lang.String)loginCaissier);
          _input = this._invoke(_output);
          _result = gereraccesproduits.supermarche.CaisseHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereraccesproduits.supermarche.AgenceExceptionHelper.id())) {
            throw             gereraccesproduits.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.creer(login, agence, loginCaissier);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  gereraccesproduits.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimer", true);
          _output.write_string((java.lang.String)login);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereraccesproduits.supermarche.AgenceExceptionHelper.id())) {
            throw             gereraccesproduits.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          _self.supprimer(login);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Caisse rechercher (in string login)
    raises (gereraccesproduits.supermarche.AgenceException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Caisse rechercher (java.lang.String login) throws  gereraccesproduits.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereraccesproduits.supermarche.Caisse _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)login);
          _input = this._invoke(_output);
          _result = gereraccesproduits.supermarche.CaisseHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereraccesproduits.supermarche.AgenceExceptionHelper.id())) {
            throw             gereraccesproduits.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereraccesproduits.supermarche.AgenceOperations _self = (gereraccesproduits.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.rechercher(login);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
