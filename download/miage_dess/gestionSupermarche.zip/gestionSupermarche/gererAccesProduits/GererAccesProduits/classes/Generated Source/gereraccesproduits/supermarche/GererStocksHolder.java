package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public final class GererStocksHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.GererStocks value;

  public GererStocksHolder () {
  }

  public GererStocksHolder (final gereraccesproduits.supermarche.GererStocks _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.GererStocksHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.GererStocksHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.GererStocksHelper.type();
  }
}
