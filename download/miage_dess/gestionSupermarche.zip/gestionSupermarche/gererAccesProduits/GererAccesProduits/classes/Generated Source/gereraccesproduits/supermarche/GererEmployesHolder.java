package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public final class GererEmployesHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.GererEmployes value;

  public GererEmployesHolder () {
  }

  public GererEmployesHolder (final gereraccesproduits.supermarche.GererEmployes _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.GererEmployesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.GererEmployesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.GererEmployesHelper.type();
  }
}
