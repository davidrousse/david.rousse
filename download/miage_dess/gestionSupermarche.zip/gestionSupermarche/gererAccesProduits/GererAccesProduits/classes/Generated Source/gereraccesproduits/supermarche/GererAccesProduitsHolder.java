package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public final class GererAccesProduitsHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.GererAccesProduits value;

  public GererAccesProduitsHolder () {
  }

  public GererAccesProduitsHolder (final gereraccesproduits.supermarche.GererAccesProduits _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.GererAccesProduitsHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.GererAccesProduitsHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.GererAccesProduitsHelper.type();
  }
}
