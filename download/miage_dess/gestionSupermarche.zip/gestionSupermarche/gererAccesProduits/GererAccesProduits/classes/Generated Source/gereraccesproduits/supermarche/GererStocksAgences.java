package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public interface GererStocksAgences extends com.inprise.vbroker.CORBA.Object, gereraccesproduits.supermarche.GererStocksAgencesOperations, org.omg.CORBA.portable.IDLEntity {
}
