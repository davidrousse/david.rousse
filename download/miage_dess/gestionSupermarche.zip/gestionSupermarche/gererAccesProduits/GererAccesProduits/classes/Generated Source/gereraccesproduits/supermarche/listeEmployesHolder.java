package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/listeEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgereraccesproduits.supermarche.Employe&gt listeEmployes;
 * </pre>
 */
public final class listeEmployesHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.Employe[] value;

  public listeEmployesHolder () {
  }

  public listeEmployesHolder (final gereraccesproduits.supermarche.Employe[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.listeEmployesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.listeEmployesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.listeEmployesHelper.type();
  }
}
