package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public interface GererStocksAgencesOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void creerS (in gereraccesproduits.supermarche.Stock s, in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gereraccesproduits.supermarche.Stock s, 
                      java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementerS (in gereraccesproduits.supermarche.Stock s,
                     in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gereraccesproduits.supermarche.Stock s, 
                            java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementerS (in gereraccesproduits.supermarche.Stock s,
                     in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gereraccesproduits.supermarche.Stock s, 
                            java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Stock rechercher (in string codeBarre,
                                                   in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                          java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Stock rechercherS (in gereraccesproduits.supermarche.Stock s,
                                                    in string agence)
    raises (gereraccesproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Stock rechercherS (gereraccesproduits.supermarche.Stock s, 
                                                           java.lang.String agence) throws gereraccesproduits.supermarche.GererStocksAgencesException;

}
