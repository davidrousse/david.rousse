package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public interface GererAccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute gereraccesproduits.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public gereraccesproduits.supermarche.AccesProduits[] listeAP ();

  /**
   * <pre>
   *   gereraccesproduits.supermarche.AccesProduits creer (in string agence)
    raises (gereraccesproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gereraccesproduits.supermarche.AccesProduits creer (java.lang.String agence) throws gereraccesproduits.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (gereraccesproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws gereraccesproduits.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.AccesProduits rechercher (in string agence)
    raises (gereraccesproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gereraccesproduits.supermarche.AccesProduits rechercher (java.lang.String agence) throws gereraccesproduits.supermarche.GererAccesProduitsException;

}
