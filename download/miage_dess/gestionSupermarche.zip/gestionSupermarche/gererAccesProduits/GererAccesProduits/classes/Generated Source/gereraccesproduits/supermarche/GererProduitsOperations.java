package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in gereraccesproduits.supermarche.Produit p)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gereraccesproduits.supermarche.Produit p) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in gereraccesproduits.supermarche.Produit p)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gereraccesproduits.supermarche.Produit p) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in gereraccesproduits.supermarche.Produit p)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gereraccesproduits.supermarche.Produit p) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Produit rechercher (in string codeBarre)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Produit rechercher (java.lang.String codeBarre) throws gereraccesproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gereraccesproduits.supermarche.Produit rechercherP (in gereraccesproduits.supermarche.Produit p)
    raises (gereraccesproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public gereraccesproduits.supermarche.Produit rechercherP (gereraccesproduits.supermarche.Produit p) throws gereraccesproduits.supermarche.GererProduitsException;

}
