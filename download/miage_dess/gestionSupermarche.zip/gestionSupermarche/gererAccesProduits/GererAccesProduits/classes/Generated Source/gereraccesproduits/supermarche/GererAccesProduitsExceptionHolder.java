package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduitsException
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduitsException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererAccesProduitsException {
  ...
};
 * </pre>
 */
public final class GererAccesProduitsExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public gereraccesproduits.supermarche.GererAccesProduitsException value;

  public GererAccesProduitsExceptionHolder () {
  }

  public GererAccesProduitsExceptionHolder (final gereraccesproduits.supermarche.GererAccesProduitsException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.type();
  }
}
