package gereraccesproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererAccesProduits/GererAccesProduits/src/gereraccesproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduitsException
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduitsException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererAccesProduitsException {
  ...
};
 * </pre>
 */
public final class GererAccesProduitsException extends org.omg.CORBA.UserException {
  
  public java.lang.String raison;

  public GererAccesProduitsException () {
    super(gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.id());
  }

  public GererAccesProduitsException (java.lang.String raison) {
    this();
    this.raison = raison;
  }

  public GererAccesProduitsException (java.lang.String _reason, java.lang.String raison) {
    super(gereraccesproduits.supermarche.GererAccesProduitsExceptionHelper.id() + ' ' + _reason);
    this.raison = raison;
  }

  public java.lang.String toString () {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("exception gereraccesproduits.supermarche.GererAccesProduitsException {");
    _ret.append("\n");
    _ret.append("java.lang.String raison=");
    _ret.append(raison != null?'\"' + raison + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;
    if (o instanceof gereraccesproduits.supermarche.GererAccesProduitsException) {
      final gereraccesproduits.supermarche.GererAccesProduitsException obj = (gereraccesproduits.supermarche.GererAccesProduitsException)o;
      boolean res = true;
      do {
        res = this.raison == obj.raison ||
         (this.raison != null && obj.raison != null && this.raison.equals(obj.raison));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
