package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksException
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererStocksException {
  ...
};
 * </pre>
 */
public final class GererStocksExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public siege.supermarche.GererStocksException value;

  public GererStocksExceptionHolder () {
  }

  public GererStocksExceptionHolder (final siege.supermarche.GererStocksException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = siege.supermarche.GererStocksExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    siege.supermarche.GererStocksExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return siege.supermarche.GererStocksExceptionHelper.type();
  }
}
