*********************************************
************       Contenu       ************
************   David ROUSSE,     ************
************   Cathy FRANCO et   ************
************   Laetitia SOULE    ************
*********************************************

Gestion de supermarche en CORBA. 

* Biblioth�ques n�cessaires:
Agences
GererEmployes
GererStocks
GererProduits
Visibroker (vbjorb.jar)

* Utilisation (exemple avec nomClasse suivie des parametres en ligne de commande) :

[osagent]
nameserv NameServiceSiege
nameserv NameServiceToulouse
nameserv NameServicePau
...
ServeurSiege Siege federation siege supermarche C:\gestionSupermarche\ior.txt

ServeurGererAccesProduits GererAccesProduits supermarche C:\gestionSupermarche\produits.txt

ServeurGererProduits GererProduits supermarche C:\gestionSupermarche\produits.txt

ServeurAgence AgenceToulouse federation toulouse supermarche C:\gestionSupermarche\ior.txt GererStocks GererEmployes

//lit les parametres specifiques � la caisse dans des message box
ServeurCaisse AgenceToulouse federation toulouse supermarche C:\gestionSupermarche\ior.txt GererStocks GererEmployes

ApplicationClienteSiege GererStocks GererProduits supermarche federation siege

//lit les parametres specifiques � la caisse dans des message box
ApplicationClienteCaisse GererStocks GererProduits supermarche federation siege

//lit les parametres specifiques � la caisse dans des message box
ApplicationClienteCaisse2 GererStocks GererProduits supermarche federation siege


Rq : en r�parti, remplacer le chemin du fichier ior.txt par le nom r�seau (UNC)

-- > Voir conception\conception.doc pour plus de d�tails 

***********************************************
* Date de cr�ation : 28/01/2002		      *
* Derni�re mise � jour : 28/01/2002           *
***********************************************
*        DESS MIAGe 2001/2002		      *
***********************************************
