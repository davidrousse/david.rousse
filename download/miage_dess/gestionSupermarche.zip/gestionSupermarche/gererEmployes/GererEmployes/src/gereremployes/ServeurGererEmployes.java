package gereremployes;

import gereremployes.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ServeurGererEmployes {

     public static void main(String[] args) {
    try {
      //verification des arguments
      //1� arg. = nom objet CORBA, 2� arg. = nom designation
      if(args.length!=2) {
        System.out.println(args.length+"Appel incorrect. Syntaxe : ServeurGererEmployes nomObj nomDesi");
        System.exit(0);
      }

      //intialisation de l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cup�re le rootPOA.
      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      //on construit le nom � enregistrer dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[1],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      //on va cr�er des politiques (policies)
      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };

      //cr�ation de son propre POA avec les politiques pr�c�dentes
      POA poa = rootPOA.create_POA("supermarchePOA",rootPOA.the_POAManager(),policies);

      //cr�ation du servant
      GererEmployesImpl monServant = new GererEmployesImpl();

      //donner un Object ID au servant
      byte[] monId = args[0].getBytes();

      //activer le servant avec l'ID dans le POA
      poa.activate_object_with_id(monId, monServant);

      //activer le POA manager
      rootPOA.the_POAManager().activate();

      //on enregistre l'objet dans l'annuaire
      racineArbre.rebind(nom,poa.servant_to_reference(monServant));

      //trace ecran
      System.out.println(poa.servant_to_reference(monServant) + " est pret.");

      //mse en attente de requete
      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  } //fin du main

}