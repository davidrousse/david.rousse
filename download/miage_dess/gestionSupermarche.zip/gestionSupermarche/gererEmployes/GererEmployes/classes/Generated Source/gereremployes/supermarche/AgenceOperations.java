package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public interface AgenceOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeCaisses listeC;
   * </pre>
   */
  public gereremployes.supermarche.Caisse[] listeC ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge);

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public double TVA ();

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public void TVA (double TVA);

  /**
   * <pre>
   *   gereremployes.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (gereremployes.supermarche.AgenceException);
   * </pre>
   */
  public gereremployes.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws gereremployes.supermarche.AgenceException;

  /**
   * <pre>
   *   gereremployes.supermarche.Caisse creer (in string login, in string agence,
                                          in string loginCaissier)
    raises (gereremployes.supermarche.AgenceException);
   * </pre>
   */
  public gereremployes.supermarche.Caisse creer (java.lang.String login, 
                                                 java.lang.String agence, 
                                                 java.lang.String loginCaissier) throws gereremployes.supermarche.AgenceException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereremployes.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gereremployes.supermarche.AgenceException;

  /**
   * <pre>
   *   gereremployes.supermarche.Caisse rechercher (in string login)
    raises (gereremployes.supermarche.AgenceException);
   * </pre>
   */
  public gereremployes.supermarche.Caisse rechercher (java.lang.String login) throws gereremployes.supermarche.AgenceException;

}
