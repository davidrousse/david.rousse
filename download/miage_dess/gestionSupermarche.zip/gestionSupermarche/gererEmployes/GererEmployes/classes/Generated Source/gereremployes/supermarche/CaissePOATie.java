package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public class CaissePOATie extends CaissePOA {
  private gereremployes.supermarche.CaisseOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public CaissePOATie (final gereremployes.supermarche.CaisseOperations _delegate) {
    this._delegate = _delegate;
  }

  public CaissePOATie (final gereremployes.supermarche.CaisseOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gereremployes.supermarche.CaisseOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gereremployes.supermarche.CaisseOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public double totalVentes () {
    return this._delegate.totalVentes();
  }

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public void totalVentes (double totalVentes) {
    this._delegate.totalVentes(totalVentes);
  }

  /**
   * <pre>
   *   readonly attribute string agence;
   * </pre>
   */
  public java.lang.String agence () {
    return this._delegate.agence();
  }

  /**
   * <pre>
   *   readonly attribute string caissier;
   * </pre>
   */
  public java.lang.String caissier () {
    return this._delegate.caissier();
  }

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (gereremployes.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws  gereremployes.supermarche.CaisseException {
    this._delegate.vendreS(codeBarre);
  }

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       int qte) throws  gereremployes.supermarche.CaisseException {
    this._delegate.vendreC(codeBarre, qte);
  }

  /**
   * <pre>
   *   void editerTicket ()
    raises (gereremployes.supermarche.CaisseException);
   * </pre>
   */
  public void editerTicket () throws  gereremployes.supermarche.CaisseException {
    this._delegate.editerTicket();
  }

  /**
   * <pre>
   *   void connecter (in string login, in string password)
    raises (gereremployes.supermarche.CaisseException);
   * </pre>
   */
  public void connecter (java.lang.String login, 
                         java.lang.String password) throws  gereremployes.supermarche.CaisseException {
    this._delegate.connecter(login, password);
  }

  /**
   * <pre>
   *   void deconnecter (in string login)
    raises (gereremployes.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login) throws  gereremployes.supermarche.CaisseException {
    this._delegate.deconnecter(login);
  }

}
