package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public interface GererStocksOperations {
  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeStocks listeS;
   * </pre>
   */
  public gereremployes.supermarche.Stock[] listeS ();

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   void creerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gereremployes.supermarche.Stock s) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gereremployes.supermarche.Stock s) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gereremployes.supermarche.Stock s) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercher (in string codeBarre)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercher (java.lang.String codeBarre) throws gereremployes.supermarche.GererStocksException;

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercherS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercherS (gereremployes.supermarche.Stock s) throws gereremployes.supermarche.GererStocksException;

}
