package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public class _GererStocksStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements GererStocks {
  final public static java.lang.Class _opsClass = gereremployes.supermarche.GererStocksOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererStocks:1.0"
  };

  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeStocks listeS;
   * </pre>
   */
  public gereremployes.supermarche.Stock[] listeS () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereremployes.supermarche.Stock[] _result;
        try {
          _output = this._request("_get_listeS", true);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.listeStocksHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          return _self.listeS();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.creer(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void creerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creerS", true);
          gereremployes.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.creerS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("incrementer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("incrementer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.incrementer(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void incrementerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("incrementerS", true);
          gereremployes.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("incrementerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.incrementerS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("decrementer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("decrementer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.decrementer(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void decrementerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("decrementerS", true);
          gereremployes.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("decrementerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.decrementerS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercher (in string codeBarre)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercher (java.lang.String codeBarre) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereremployes.supermarche.Stock _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.StockHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          return _self.rechercher(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercherS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercherS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereremployes.supermarche.Stock _result;
        try {
          _output = this._request("rechercherS", true);
          gereremployes.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.StockHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererStocksExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererStocksOperations _self = (gereremployes.supermarche.GererStocksOperations)_so.servant;
        try {
          return _self.rechercherS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
