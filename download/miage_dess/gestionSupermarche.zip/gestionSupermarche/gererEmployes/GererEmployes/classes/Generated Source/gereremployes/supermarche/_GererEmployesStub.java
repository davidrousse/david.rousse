package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class _GererEmployesStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements GererEmployes {
  final public static java.lang.Class _opsClass = gereremployes.supermarche.GererEmployesOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererEmployes:1.0"
  };

  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gereremployes.supermarche.Employe[] listeE () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereremployes.supermarche.Employe[] _result;
        try {
          _output = this._request("_get_listeE", true);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.listeEmployesHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeE", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          return _self.listeE();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)login);
          _output.write_string((java.lang.String)password);
          _output.write_string((java.lang.String)droit);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          _self.creer(login, password, droit);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void creerE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creerE", true);
          gereremployes.supermarche.EmployeHelper.write(_output, e);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creerE", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          _self.creerE(e);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("modifier", true);
          _output.write_string((java.lang.String)login);
          _output.write_string((java.lang.String)password);
          _output.write_string((java.lang.String)droit);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("modifier", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          _self.modifier(login, password, droit);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void modifierE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("modifierE", true);
          gereremployes.supermarche.EmployeHelper.write(_output, e);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("modifierE", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          _self.modifierE(e);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimer", true);
          _output.write_string((java.lang.String)login);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          _self.supprimer(login);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void supprimerE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimerE", true);
          gereremployes.supermarche.EmployeHelper.write(_output, e);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimerE", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          _self.supprimerE(e);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Employe rechercher (in string login)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public gereremployes.supermarche.Employe rechercher (java.lang.String login) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereremployes.supermarche.Employe _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)login);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.EmployeHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          return _self.rechercher(login);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Employe rechercherE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public gereremployes.supermarche.Employe rechercherE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gereremployes.supermarche.Employe _result;
        try {
          _output = this._request("rechercherE", true);
          gereremployes.supermarche.EmployeHelper.write(_output, e);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.EmployeHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.GererEmployesExceptionHelper.id())) {
            throw             gereremployes.supermarche.GererEmployesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherE", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.GererEmployesOperations _self = (gereremployes.supermarche.GererEmployesOperations)_so.servant;
        try {
          return _self.rechercherE(e);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
