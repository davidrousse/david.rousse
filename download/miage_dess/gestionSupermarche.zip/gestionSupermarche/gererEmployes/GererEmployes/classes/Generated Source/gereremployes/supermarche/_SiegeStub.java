package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public class _SiegeStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements Siege {
  final public static java.lang.Class _opsClass = gereremployes.supermarche.SiegeOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Siege:1.0"
  };

  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeAgences listeA;
   * </pre>
   */
  public java.lang.String[] listeA () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String[] _result;
        try {
          _output = this._request("_get_listeA", true);
          _input = this._invoke(_output);
          _result = gereremployes.supermarche.listeAgencesHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeA", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.SiegeOperations _self = (gereremployes.supermarche.SiegeOperations)_so.servant;
        try {
          return _self.listeA();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void inscrire (in string agence)
    raises (gereremployes.supermarche.SiegeException);
   * </pre>
   */
  public void inscrire (java.lang.String agence) throws  gereremployes.supermarche.SiegeException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("inscrire", true);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.SiegeExceptionHelper.id())) {
            throw             gereremployes.supermarche.SiegeExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("inscrire", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.SiegeOperations _self = (gereremployes.supermarche.SiegeOperations)_so.servant;
        try {
          _self.inscrire(agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void desinscrire (in string agence)
    raises (gereremployes.supermarche.SiegeException);
   * </pre>
   */
  public void desinscrire (java.lang.String agence) throws  gereremployes.supermarche.SiegeException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("desinscrire", true);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gereremployes.supermarche.SiegeExceptionHelper.id())) {
            throw             gereremployes.supermarche.SiegeExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("desinscrire", _opsClass);
        if (_so == null) {
          continue;
        }
        final gereremployes.supermarche.SiegeOperations _self = (gereremployes.supermarche.SiegeOperations)_so.servant;
        try {
          _self.desinscrire(agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
