package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeStocks
 * <li> <b>Repository Id</b> IDL:supermarche/listeStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgereremployes.supermarche.Stock&gt listeStocks;
 * </pre>
 */
public final class listeStocksHolder implements org.omg.CORBA.portable.Streamable {
  public gereremployes.supermarche.Stock[] value;

  public listeStocksHolder () {
  }

  public listeStocksHolder (final gereremployes.supermarche.Stock[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereremployes.supermarche.listeStocksHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereremployes.supermarche.listeStocksHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereremployes.supermarche.listeStocksHelper.type();
  }
}
