package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gereremployes.supermarche.Produit p) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gereremployes.supermarche.Produit p) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gereremployes.supermarche.Produit p) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercher (in string codeBarre)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercher (java.lang.String codeBarre) throws gereremployes.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercherP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercherP (gereremployes.supermarche.Produit p) throws gereremployes.supermarche.GererProduitsException;

}
