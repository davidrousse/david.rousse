package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercher (in string codeBarre)
    raises (gereremployes.supermarche.AccesProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercher (java.lang.String codeBarre) throws gereremployes.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercherP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.AccesProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercherP (gereremployes.supermarche.Produit p) throws gereremployes.supermarche.AccesProduitsException;

}
