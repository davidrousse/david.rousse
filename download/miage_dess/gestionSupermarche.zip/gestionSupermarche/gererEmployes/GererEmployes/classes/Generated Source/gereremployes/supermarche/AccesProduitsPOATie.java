package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public class AccesProduitsPOATie extends AccesProduitsPOA {
  private gereremployes.supermarche.AccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public AccesProduitsPOATie (final gereremployes.supermarche.AccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public AccesProduitsPOATie (final gereremployes.supermarche.AccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gereremployes.supermarche.AccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gereremployes.supermarche.AccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercher (in string codeBarre)
    raises (gereremployes.supermarche.AccesProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gereremployes.supermarche.AccesProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercherP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.AccesProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercherP (gereremployes.supermarche.Produit p) throws  gereremployes.supermarche.AccesProduitsException {
    return this._delegate.rechercherP(p);
  }

}
