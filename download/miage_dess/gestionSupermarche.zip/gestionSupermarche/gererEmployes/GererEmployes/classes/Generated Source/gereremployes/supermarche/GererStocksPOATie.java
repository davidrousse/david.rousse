package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public class GererStocksPOATie extends GererStocksPOA {
  private gereremployes.supermarche.GererStocksOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksPOATie (final gereremployes.supermarche.GererStocksOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksPOATie (final gereremployes.supermarche.GererStocksOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gereremployes.supermarche.GererStocksOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gereremployes.supermarche.GererStocksOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeStocks listeS;
   * </pre>
   */
  public gereremployes.supermarche.Stock[] listeS () {
    return this._delegate.listeS();
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws  gereremployes.supermarche.GererStocksException {
    this._delegate.creer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void creerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {
    this._delegate.creerS(s);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws  gereremployes.supermarche.GererStocksException {
    this._delegate.incrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void incrementerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {
    this._delegate.incrementerS(s);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws  gereremployes.supermarche.GererStocksException {
    this._delegate.decrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void decrementerS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {
    this._delegate.decrementerS(s);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercher (in string codeBarre)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercher (java.lang.String codeBarre) throws  gereremployes.supermarche.GererStocksException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercherS (in gereremployes.supermarche.Stock s)
    raises (gereremployes.supermarche.GererStocksException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercherS (gereremployes.supermarche.Stock s) throws  gereremployes.supermarche.GererStocksException {
    return this._delegate.rechercherS(s);
  }

}
