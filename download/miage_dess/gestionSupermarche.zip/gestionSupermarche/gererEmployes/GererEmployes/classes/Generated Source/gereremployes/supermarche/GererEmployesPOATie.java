package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class GererEmployesPOATie extends GererEmployesPOA {
  private gereremployes.supermarche.GererEmployesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererEmployesPOATie (final gereremployes.supermarche.GererEmployesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererEmployesPOATie (final gereremployes.supermarche.GererEmployesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gereremployes.supermarche.GererEmployesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gereremployes.supermarche.GererEmployesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gereremployes.supermarche.Employe[] listeE () {
    return this._delegate.listeE();
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  gereremployes.supermarche.GererEmployesException {
    this._delegate.creer(login, password, droit);
  }

  /**
   * <pre>
   *   void creerE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {
    this._delegate.creerE(e);
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  gereremployes.supermarche.GererEmployesException {
    this._delegate.modifier(login, password, droit);
  }

  /**
   * <pre>
   *   void modifierE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {
    this._delegate.modifierE(e);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  gereremployes.supermarche.GererEmployesException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   void supprimerE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {
    this._delegate.supprimerE(e);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Employe rechercher (in string login)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public gereremployes.supermarche.Employe rechercher (java.lang.String login) throws  gereremployes.supermarche.GererEmployesException {
    return this._delegate.rechercher(login);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Employe rechercherE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public gereremployes.supermarche.Employe rechercherE (gereremployes.supermarche.Employe e) throws  gereremployes.supermarche.GererEmployesException {
    return this._delegate.rechercherE(e);
  }

}
