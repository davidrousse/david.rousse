package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public class GererStocksAgencesPOATie extends GererStocksAgencesPOA {
  private gereremployes.supermarche.GererStocksAgencesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksAgencesPOATie (final gereremployes.supermarche.GererStocksAgencesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksAgencesPOATie (final gereremployes.supermarche.GererStocksAgencesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gereremployes.supermarche.GererStocksAgencesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gereremployes.supermarche.GererStocksAgencesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    this._delegate.creer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void creerS (in gereremployes.supermarche.Stock s, in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gereremployes.supermarche.Stock s, 
                      java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    this._delegate.creerS(s, agence);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    this._delegate.incrementer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void incrementerS (in gereremployes.supermarche.Stock s, in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gereremployes.supermarche.Stock s, 
                            java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    this._delegate.incrementerS(s, agence);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    this._delegate.decrementer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void decrementerS (in gereremployes.supermarche.Stock s, in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gereremployes.supermarche.Stock s, 
                            java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    this._delegate.decrementerS(s, agence);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercher (in string codeBarre,
                                              in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                     java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    return this._delegate.rechercher(codeBarre, agence);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Stock rechercherS (in gereremployes.supermarche.Stock s,
                                               in string agence)
    raises (gereremployes.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gereremployes.supermarche.Stock rechercherS (gereremployes.supermarche.Stock s, 
                                                      java.lang.String agence) throws  gereremployes.supermarche.GererStocksAgencesException {
    return this._delegate.rechercherS(s, agence);
  }

}
