package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public final class AgenceHolder implements org.omg.CORBA.portable.Streamable {
  public gereremployes.supermarche.Agence value;

  public AgenceHolder () {
  }

  public AgenceHolder (final gereremployes.supermarche.Agence _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereremployes.supermarche.AgenceHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereremployes.supermarche.AgenceHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereremployes.supermarche.AgenceHelper.type();
  }
}
