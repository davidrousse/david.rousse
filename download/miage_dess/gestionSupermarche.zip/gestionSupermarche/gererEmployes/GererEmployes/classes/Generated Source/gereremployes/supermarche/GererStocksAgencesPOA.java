package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public abstract class GererStocksAgencesPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, gereremployes.supermarche.GererStocksAgencesOperations {

  public gereremployes.supermarche.GererStocksAgences _this () {
   return gereremployes.supermarche.GererStocksAgencesHelper.narrow(super._this_object());
  }

  public gereremployes.supermarche.GererStocksAgences _this (org.omg.CORBA.ORB orb) {
    return gereremployes.supermarche.GererStocksAgencesHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererStocksAgences:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("creer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("creerS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("incrementer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("incrementerS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("decrementer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("decrementerS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("rechercher", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
    _methods.put("rechercherS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 7));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return gereremployes.supermarche.GererStocksAgencesPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (gereremployes.supermarche.GererStocksAgencesOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        java.lang.String agence;
        agence = _input.read_string();
        _self.creer(codeBarre, qte, agence);
        _output = _handler.createReply();
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 1: {
      try {
        gereremployes.supermarche.Stock s;
        s = gereremployes.supermarche.StockHelper.read(_input);
        java.lang.String agence;
        agence = _input.read_string();
        _self.creerS(s, agence);
        _output = _handler.createReply();
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 2: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        java.lang.String agence;
        agence = _input.read_string();
        _self.incrementer(codeBarre, qte, agence);
        _output = _handler.createReply();
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 3: {
      try {
        gereremployes.supermarche.Stock s;
        s = gereremployes.supermarche.StockHelper.read(_input);
        java.lang.String agence;
        agence = _input.read_string();
        _self.incrementerS(s, agence);
        _output = _handler.createReply();
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 4: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        java.lang.String agence;
        agence = _input.read_string();
        _self.decrementer(codeBarre, qte, agence);
        _output = _handler.createReply();
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 5: {
      try {
        gereremployes.supermarche.Stock s;
        s = gereremployes.supermarche.StockHelper.read(_input);
        java.lang.String agence;
        agence = _input.read_string();
        _self.decrementerS(s, agence);
        _output = _handler.createReply();
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 6: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        java.lang.String agence;
        agence = _input.read_string();
        gereremployes.supermarche.Stock _result = _self.rechercher(codeBarre, agence);
        _output = _handler.createReply();
        gereremployes.supermarche.StockHelper.write(_output, _result);
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 7: {
      try {
        gereremployes.supermarche.Stock s;
        s = gereremployes.supermarche.StockHelper.read(_input);
        java.lang.String agence;
        agence = _input.read_string();
        gereremployes.supermarche.Stock _result = _self.rechercherS(s, agence);
        _output = _handler.createReply();
        gereremployes.supermarche.StockHelper.write(_output, _result);
      }
      catch (gereremployes.supermarche.GererStocksAgencesException _exception) {
        _output = _handler.createExceptionReply();
        gereremployes.supermarche.GererStocksAgencesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
