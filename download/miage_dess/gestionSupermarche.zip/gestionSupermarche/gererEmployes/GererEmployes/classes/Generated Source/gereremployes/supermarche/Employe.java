package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Employe
 * <li> <b>Repository Id</b> IDL:supermarche/Employe:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Employe {
  ...
};
 * </pre>
 */
public final class Employe implements org.omg.CORBA.portable.IDLEntity {
  
  public java.lang.String login;
  
  public java.lang.String password;
  
  public java.lang.String droit;

  public Employe () {
  }

  public Employe (final java.lang.String login, 
                  final java.lang.String password, 
                  final java.lang.String droit) {
    this.login = login;
    this.password = password;
    this.droit = droit;
  }

  public java.lang.String toString() {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("struct gereremployes.supermarche.Employe {");
    _ret.append("\n");
    _ret.append("java.lang.String login=");
    _ret.append(login != null?'\"' + login + '\"':null);
    _ret.append(",\n");
    _ret.append("java.lang.String password=");
    _ret.append(password != null?'\"' + password + '\"':null);
    _ret.append(",\n");
    _ret.append("java.lang.String droit=");
    _ret.append(droit != null?'\"' + droit + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;

    if (o instanceof gereremployes.supermarche.Employe) {
      final gereremployes.supermarche.Employe obj = (gereremployes.supermarche.Employe)o;
      boolean res = true;
      do {
        res = this.login == obj.login ||
         (this.login != null && obj.login != null && this.login.equals(obj.login));
        if (!res) break;
        res = this.password == obj.password ||
         (this.password != null && obj.password != null && this.password.equals(obj.password));
        if (!res) break;
        res = this.droit == obj.droit ||
         (this.droit != null && obj.droit != null && this.droit.equals(obj.droit));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
