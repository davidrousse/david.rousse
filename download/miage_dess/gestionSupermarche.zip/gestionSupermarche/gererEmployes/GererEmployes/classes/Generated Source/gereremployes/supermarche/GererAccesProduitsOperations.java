package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public interface GererAccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public gereremployes.supermarche.AccesProduits[] listeAP ();

  /**
   * <pre>
   *   gereremployes.supermarche.AccesProduits creer (in string agence)
    raises (gereremployes.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.AccesProduits creer (java.lang.String agence) throws gereremployes.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (gereremployes.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws gereremployes.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   gereremployes.supermarche.AccesProduits rechercher (in string agence)
    raises (gereremployes.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.AccesProduits rechercher (java.lang.String agence) throws gereremployes.supermarche.GererAccesProduitsException;

}
