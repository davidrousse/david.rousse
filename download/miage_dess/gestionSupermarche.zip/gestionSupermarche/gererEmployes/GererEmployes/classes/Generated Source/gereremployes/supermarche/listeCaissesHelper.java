
package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeCaisses
 * <li> <b>Repository Id</b> IDL:supermarche/listeCaisses:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgereremployes.supermarche.Caisse&gt listeCaisses;
 * </pre>
 */
public final class listeCaissesHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static gereremployes.supermarche.Caisse[] read (final org.omg.CORBA.portable.InputStream _input) {
    gereremployes.supermarche.Caisse[] result;
    final int $length0 = _input.read_long();
    result = new gereremployes.supermarche.Caisse[$length0];
    for (int $counter1 = 0; $counter1 < $length0; $counter1++) {
      result[$counter1] = gereremployes.supermarche.CaisseHelper.read(_input);
    }
    return result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final gereremployes.supermarche.Caisse[] _vis_value) {
    _output.write_long(_vis_value.length);
    for (int $counter2 = 0;  $counter2 < _vis_value.length; $counter2++) {
      gereremployes.supermarche.CaisseHelper.write(_output, _vis_value[$counter2]);
    }
  }

  public static void insert (final org.omg.CORBA.Any any, final gereremployes.supermarche.Caisse[] _vis_value) {
    any.type(gereremployes.supermarche.listeCaissesHelper.type());
    any.insert_Streamable(new gereremployes.supermarche.listeCaissesHolder(_vis_value));
  }

  public static gereremployes.supermarche.Caisse[] extract (final org.omg.CORBA.Any any) {
    gereremployes.supermarche.Caisse[] _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      gereremployes.supermarche.listeCaissesHolder _vis_holder = new gereremployes.supermarche.listeCaissesHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    } else {
      _vis_value = gereremployes.supermarche.listeCaissesHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          org.omg.CORBA.TypeCode originalType = _orb().create_sequence_tc(0, gereremployes.supermarche.CaisseHelper.type());
          _type = _orb().create_alias_tc(id(), "listeCaisses", originalType);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/listeCaisses:1.0";
  }
}
