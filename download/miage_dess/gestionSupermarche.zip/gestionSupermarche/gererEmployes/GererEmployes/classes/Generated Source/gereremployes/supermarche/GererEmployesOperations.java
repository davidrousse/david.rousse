package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployesOperations {
  /**
   * <pre>
   *   readonly attribute gereremployes.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gereremployes.supermarche.Employe[] listeE ();

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void creerE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gereremployes.supermarche.Employe e) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifierE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gereremployes.supermarche.Employe e) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimerE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gereremployes.supermarche.Employe e) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gereremployes.supermarche.Employe rechercher (in string login)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public gereremployes.supermarche.Employe rechercher (java.lang.String login) throws gereremployes.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gereremployes.supermarche.Employe rechercherE (in gereremployes.supermarche.Employe e)
    raises (gereremployes.supermarche.GererEmployesException);
   * </pre>
   */
  public gereremployes.supermarche.Employe rechercherE (gereremployes.supermarche.Employe e) throws gereremployes.supermarche.GererEmployesException;

}
