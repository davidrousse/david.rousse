package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public final class AccesProduitsHolder implements org.omg.CORBA.portable.Streamable {
  public gereremployes.supermarche.AccesProduits value;

  public AccesProduitsHolder () {
  }

  public AccesProduitsHolder (final gereremployes.supermarche.AccesProduits _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gereremployes.supermarche.AccesProduitsHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gereremployes.supermarche.AccesProduitsHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gereremployes.supermarche.AccesProduitsHelper.type();
  }
}
