package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public class GererProduitsPOATie extends GererProduitsPOA {
  private gereremployes.supermarche.GererProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererProduitsPOATie (final gereremployes.supermarche.GererProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererProduitsPOATie (final gereremployes.supermarche.GererProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gereremployes.supermarche.GererProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gereremployes.supermarche.GererProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws  gereremployes.supermarche.GererProduitsException {
    this._delegate.creer(codeBarre, designation, prixHT);
  }

  /**
   * <pre>
   *   void creerP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gereremployes.supermarche.Produit p) throws  gereremployes.supermarche.GererProduitsException {
    this._delegate.creerP(p);
  }

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws  gereremployes.supermarche.GererProduitsException {
    this._delegate.supprimer(codeBarre);
  }

  /**
   * <pre>
   *   void supprimerP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gereremployes.supermarche.Produit p) throws  gereremployes.supermarche.GererProduitsException {
    this._delegate.supprimerP(p);
  }

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws  gereremployes.supermarche.GererProduitsException {
    this._delegate.modifier(codeBarre, designation, prixHT);
  }

  /**
   * <pre>
   *   void modifierP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gereremployes.supermarche.Produit p) throws  gereremployes.supermarche.GererProduitsException {
    this._delegate.modifierP(p);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercher (in string codeBarre)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gereremployes.supermarche.GererProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gereremployes.supermarche.Produit rechercherP (in gereremployes.supermarche.Produit p)
    raises (gereremployes.supermarche.GererProduitsException);
   * </pre>
   */
  public gereremployes.supermarche.Produit rechercherP (gereremployes.supermarche.Produit p) throws  gereremployes.supermarche.GererProduitsException {
    return this._delegate.rechercherP(p);
  }

}
