package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksException
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererStocksException {
  ...
};
 * </pre>
 */
public final class GererStocksExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public agences.supermarche.GererStocksException value;

  public GererStocksExceptionHolder () {
  }

  public GererStocksExceptionHolder (final agences.supermarche.GererStocksException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = agences.supermarche.GererStocksExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    agences.supermarche.GererStocksExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return agences.supermarche.GererStocksExceptionHelper.type();
  }
}
