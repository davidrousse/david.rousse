package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/listeAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltagences.supermarche.AccesProduits&gt listeAccesProduits;
 * </pre>
 */
public final class listeAccesProduitsHolder implements org.omg.CORBA.portable.Streamable {
  public agences.supermarche.AccesProduits[] value;

  public listeAccesProduitsHolder () {
  }

  public listeAccesProduitsHolder (final agences.supermarche.AccesProduits[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = agences.supermarche.listeAccesProduitsHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    agences.supermarche.listeAccesProduitsHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return agences.supermarche.listeAccesProduitsHelper.type();
  }
}
