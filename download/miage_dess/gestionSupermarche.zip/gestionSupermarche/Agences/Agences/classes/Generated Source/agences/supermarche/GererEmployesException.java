package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployesException
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployesException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererEmployesException {
  ...
};
 * </pre>
 */
public final class GererEmployesException extends org.omg.CORBA.UserException {
  
  public java.lang.String raison;

  public GererEmployesException () {
    super(agences.supermarche.GererEmployesExceptionHelper.id());
  }

  public GererEmployesException (java.lang.String raison) {
    this();
    this.raison = raison;
  }

  public GererEmployesException (java.lang.String _reason, java.lang.String raison) {
    super(agences.supermarche.GererEmployesExceptionHelper.id() + ' ' + _reason);
    this.raison = raison;
  }

  public java.lang.String toString () {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("exception agences.supermarche.GererEmployesException {");
    _ret.append("\n");
    _ret.append("java.lang.String raison=");
    _ret.append(raison != null?'\"' + raison + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;
    if (o instanceof agences.supermarche.GererEmployesException) {
      final agences.supermarche.GererEmployesException obj = (agences.supermarche.GererEmployesException)o;
      boolean res = true;
      do {
        res = this.raison == obj.raison ||
         (this.raison != null && obj.raison != null && this.raison.equals(obj.raison));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
