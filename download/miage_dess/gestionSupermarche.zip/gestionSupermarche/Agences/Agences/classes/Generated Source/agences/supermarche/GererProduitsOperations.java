package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (agences.supermarche.Produit p) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (agences.supermarche.Produit p) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (agences.supermarche.Produit p) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   agences.supermarche.Produit rechercher (in string codeBarre)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercher (java.lang.String codeBarre) throws agences.supermarche.GererProduitsException;

  /**
   * <pre>
   *   agences.supermarche.Produit rechercherP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercherP (agences.supermarche.Produit p) throws agences.supermarche.GererProduitsException;

}
