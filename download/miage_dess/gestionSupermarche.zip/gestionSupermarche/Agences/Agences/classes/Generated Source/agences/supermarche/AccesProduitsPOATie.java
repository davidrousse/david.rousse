package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public class AccesProduitsPOATie extends AccesProduitsPOA {
  private agences.supermarche.AccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public AccesProduitsPOATie (final agences.supermarche.AccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public AccesProduitsPOATie (final agences.supermarche.AccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public agences.supermarche.AccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final agences.supermarche.AccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   agences.supermarche.Produit rechercher (in string codeBarre)
    raises (agences.supermarche.AccesProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercher (java.lang.String codeBarre) throws  agences.supermarche.AccesProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   agences.supermarche.Produit rechercherP (in agences.supermarche.Produit p)
    raises (agences.supermarche.AccesProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercherP (agences.supermarche.Produit p) throws  agences.supermarche.AccesProduitsException {
    return this._delegate.rechercherP(p);
  }

}
