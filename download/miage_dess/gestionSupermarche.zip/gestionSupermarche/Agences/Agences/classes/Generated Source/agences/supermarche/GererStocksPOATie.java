package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public class GererStocksPOATie extends GererStocksPOA {
  private agences.supermarche.GererStocksOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksPOATie (final agences.supermarche.GererStocksOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksPOATie (final agences.supermarche.GererStocksOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public agences.supermarche.GererStocksOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final agences.supermarche.GererStocksOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeStocks listeS;
   * </pre>
   */
  public agences.supermarche.Stock[] listeS () {
    return this._delegate.listeS();
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws  agences.supermarche.GererStocksException {
    this._delegate.creer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void creerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {
    this._delegate.creerS(s);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws  agences.supermarche.GererStocksException {
    this._delegate.incrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void incrementerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {
    this._delegate.incrementerS(s);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws  agences.supermarche.GererStocksException {
    this._delegate.decrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void decrementerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {
    this._delegate.decrementerS(s);
  }

  /**
   * <pre>
   *   agences.supermarche.Stock rechercher (in string codeBarre)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public agences.supermarche.Stock rechercher (java.lang.String codeBarre) throws  agences.supermarche.GererStocksException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   agences.supermarche.Stock rechercherS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public agences.supermarche.Stock rechercherS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {
    return this._delegate.rechercherS(s);
  }

}
