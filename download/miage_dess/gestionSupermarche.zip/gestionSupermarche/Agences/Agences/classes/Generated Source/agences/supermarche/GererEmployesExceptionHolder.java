package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployesException
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployesException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererEmployesException {
  ...
};
 * </pre>
 */
public final class GererEmployesExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public agences.supermarche.GererEmployesException value;

  public GererEmployesExceptionHolder () {
  }

  public GererEmployesExceptionHolder (final agences.supermarche.GererEmployesException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = agences.supermarche.GererEmployesExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    agences.supermarche.GererEmployesExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return agences.supermarche.GererEmployesExceptionHelper.type();
  }
}
