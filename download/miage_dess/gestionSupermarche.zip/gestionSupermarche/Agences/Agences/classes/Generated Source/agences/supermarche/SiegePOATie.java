package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public class SiegePOATie extends SiegePOA {
  private agences.supermarche.SiegeOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public SiegePOATie (final agences.supermarche.SiegeOperations _delegate) {
    this._delegate = _delegate;
  }

  public SiegePOATie (final agences.supermarche.SiegeOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public agences.supermarche.SiegeOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final agences.supermarche.SiegeOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeAgences listeA;
   * </pre>
   */
  public java.lang.String[] listeA () {
    return this._delegate.listeA();
  }

  /**
   * <pre>
   *   void inscrire (in string agence)
    raises (agences.supermarche.SiegeException);
   * </pre>
   */
  public void inscrire (java.lang.String agence) throws  agences.supermarche.SiegeException {
    this._delegate.inscrire(agence);
  }

  /**
   * <pre>
   *   void desinscrire (in string agence)
    raises (agences.supermarche.SiegeException);
   * </pre>
   */
  public void desinscrire (java.lang.String agence) throws  agences.supermarche.SiegeException {
    this._delegate.desinscrire(agence);
  }

}
