package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::LigneTicket
 * <li> <b>Repository Id</b> IDL:supermarche/LigneTicket:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct LigneTicket {
  ...
};
 * </pre>
 */
public final class LigneTicket implements org.omg.CORBA.portable.IDLEntity {
  
  public java.lang.String codeBarre;
  
  public java.lang.String designation;
  
  public double prixTTC;
  
  public int qte;

  public LigneTicket () {
  }

  public LigneTicket (final java.lang.String codeBarre, 
                      final java.lang.String designation, 
                      final double prixTTC, 
                      final int qte) {
    this.codeBarre = codeBarre;
    this.designation = designation;
    this.prixTTC = prixTTC;
    this.qte = qte;
  }

  public java.lang.String toString() {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("struct agences.supermarche.LigneTicket {");
    _ret.append("\n");
    _ret.append("java.lang.String codeBarre=");
    _ret.append(codeBarre != null?'\"' + codeBarre + '\"':null);
    _ret.append(",\n");
    _ret.append("java.lang.String designation=");
    _ret.append(designation != null?'\"' + designation + '\"':null);
    _ret.append(",\n");
    _ret.append("double prixTTC=");
    _ret.append(prixTTC);
    _ret.append(",\n");
    _ret.append("int qte=");
    _ret.append(qte);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;

    if (o instanceof agences.supermarche.LigneTicket) {
      final agences.supermarche.LigneTicket obj = (agences.supermarche.LigneTicket)o;
      boolean res = true;
      do {
        res = this.codeBarre == obj.codeBarre ||
         (this.codeBarre != null && obj.codeBarre != null && this.codeBarre.equals(obj.codeBarre));
        if (!res) break;
        res = this.designation == obj.designation ||
         (this.designation != null && obj.designation != null && this.designation.equals(obj.designation));
        if (!res) break;
        res = this.prixTTC == obj.prixTTC;
        if (!res) break;
        res = this.qte == obj.qte;
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
