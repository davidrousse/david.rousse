package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployesOperations {
  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeEmployes listeE;
   * </pre>
   */
  public agences.supermarche.Employe[] listeE ();

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void creerE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (agences.supermarche.Employe e) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifierE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (agences.supermarche.Employe e) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimerE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (agences.supermarche.Employe e) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   agences.supermarche.Employe rechercher (in string login)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public agences.supermarche.Employe rechercher (java.lang.String login) throws agences.supermarche.GererEmployesException;

  /**
   * <pre>
   *   agences.supermarche.Employe rechercherE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public agences.supermarche.Employe rechercherE (agences.supermarche.Employe e) throws agences.supermarche.GererEmployesException;

}
