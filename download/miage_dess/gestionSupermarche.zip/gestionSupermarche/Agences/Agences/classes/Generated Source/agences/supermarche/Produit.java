package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Produit
 * <li> <b>Repository Id</b> IDL:supermarche/Produit:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Produit {
  ...
};
 * </pre>
 */
public final class Produit implements org.omg.CORBA.portable.IDLEntity {
  
  public java.lang.String codeBarre;
  
  public java.lang.String designation;
  
  public double prixHT;

  public Produit () {
  }

  public Produit (final java.lang.String codeBarre, 
                  final java.lang.String designation, 
                  final double prixHT) {
    this.codeBarre = codeBarre;
    this.designation = designation;
    this.prixHT = prixHT;
  }

  public java.lang.String toString() {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("struct agences.supermarche.Produit {");
    _ret.append("\n");
    _ret.append("java.lang.String codeBarre=");
    _ret.append(codeBarre != null?'\"' + codeBarre + '\"':null);
    _ret.append(",\n");
    _ret.append("java.lang.String designation=");
    _ret.append(designation != null?'\"' + designation + '\"':null);
    _ret.append(",\n");
    _ret.append("double prixHT=");
    _ret.append(prixHT);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;

    if (o instanceof agences.supermarche.Produit) {
      final agences.supermarche.Produit obj = (agences.supermarche.Produit)o;
      boolean res = true;
      do {
        res = this.codeBarre == obj.codeBarre ||
         (this.codeBarre != null && obj.codeBarre != null && this.codeBarre.equals(obj.codeBarre));
        if (!res) break;
        res = this.designation == obj.designation ||
         (this.designation != null && obj.designation != null && this.designation.equals(obj.designation));
        if (!res) break;
        res = this.prixHT == obj.prixHT;
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
