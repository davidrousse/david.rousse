package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public final class GererEmployesHolder implements org.omg.CORBA.portable.Streamable {
  public agences.supermarche.GererEmployes value;

  public GererEmployesHolder () {
  }

  public GererEmployesHolder (final agences.supermarche.GererEmployes _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = agences.supermarche.GererEmployesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    agences.supermarche.GererEmployesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return agences.supermarche.GererEmployesHelper.type();
  }
}
