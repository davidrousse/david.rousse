package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public class _GererStocksStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements GererStocks {
  final public static java.lang.Class _opsClass = agences.supermarche.GererStocksOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererStocks:1.0"
  };

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeStocks listeS;
   * </pre>
   */
  public agences.supermarche.Stock[] listeS () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Stock[] _result;
        try {
          _output = this._request("_get_listeS", true);
          _input = this._invoke(_output);
          _result = agences.supermarche.listeStocksHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeS", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          return _self.listeS();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.creer(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void creerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creerS", true);
          agences.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.creerS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("incrementer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("incrementer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.incrementer(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void incrementerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("incrementerS", true);
          agences.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("incrementerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.incrementerS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("decrementer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("decrementer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.decrementer(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void decrementerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("decrementerS", true);
          agences.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("decrementerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          _self.decrementerS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Stock rechercher (in string codeBarre)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public agences.supermarche.Stock rechercher (java.lang.String codeBarre) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Stock _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = agences.supermarche.StockHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          return _self.rechercher(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Stock rechercherS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public agences.supermarche.Stock rechercherS (agences.supermarche.Stock s) throws  agences.supermarche.GererStocksException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Stock _result;
        try {
          _output = this._request("rechercherS", true);
          agences.supermarche.StockHelper.write(_output, s);
          _input = this._invoke(_output);
          _result = agences.supermarche.StockHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererStocksExceptionHelper.id())) {
            throw             agences.supermarche.GererStocksExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherS", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererStocksOperations _self = (agences.supermarche.GererStocksOperations)_so.servant;
        try {
          return _self.rechercherS(s);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
