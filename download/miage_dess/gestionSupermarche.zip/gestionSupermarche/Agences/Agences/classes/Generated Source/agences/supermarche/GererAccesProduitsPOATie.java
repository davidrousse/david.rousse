package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public class GererAccesProduitsPOATie extends GererAccesProduitsPOA {
  private agences.supermarche.GererAccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererAccesProduitsPOATie (final agences.supermarche.GererAccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererAccesProduitsPOATie (final agences.supermarche.GererAccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public agences.supermarche.GererAccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final agences.supermarche.GererAccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public agences.supermarche.AccesProduits[] listeAP () {
    return this._delegate.listeAP();
  }

  /**
   * <pre>
   *   agences.supermarche.AccesProduits creer (in string agence)
    raises (agences.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public agences.supermarche.AccesProduits creer (java.lang.String agence) throws  agences.supermarche.GererAccesProduitsException {
    return this._delegate.creer(agence);
  }

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (agences.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws  agences.supermarche.GererAccesProduitsException {
    this._delegate.supprimer(agence);
  }

  /**
   * <pre>
   *   agences.supermarche.AccesProduits rechercher (in string agence)
    raises (agences.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public agences.supermarche.AccesProduits rechercher (java.lang.String agence) throws  agences.supermarche.GererAccesProduitsException {
    return this._delegate.rechercher(agence);
  }

}
