package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public abstract class SiegePOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, agences.supermarche.SiegeOperations {

  public agences.supermarche.Siege _this () {
   return agences.supermarche.SiegeHelper.narrow(super._this_object());
  }

  public agences.supermarche.Siege _this (org.omg.CORBA.ORB orb) {
    return agences.supermarche.SiegeHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Siege:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_listeA", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("inscrire", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("desinscrire", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return agences.supermarche.SiegePOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (agences.supermarche.SiegeOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        java.lang.String[] _result = _self.listeA();
        _output = _handler.createReply();
        agences.supermarche.listeAgencesHelper.write(_output, _result);
        return _output;
      }
      case 1: {
      try {
        java.lang.String agence;
        agence = _input.read_string();
        _self.inscrire(agence);
        _output = _handler.createReply();
      }
      catch (agences.supermarche.SiegeException _exception) {
        _output = _handler.createExceptionReply();
        agences.supermarche.SiegeExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 2: {
      try {
        java.lang.String agence;
        agence = _input.read_string();
        _self.desinscrire(agence);
        _output = _handler.createReply();
      }
      catch (agences.supermarche.SiegeException _exception) {
        _output = _handler.createExceptionReply();
        agences.supermarche.SiegeExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
