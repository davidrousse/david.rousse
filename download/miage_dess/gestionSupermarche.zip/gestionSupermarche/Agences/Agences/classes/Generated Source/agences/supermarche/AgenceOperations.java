package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public interface AgenceOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeCaisses listeC;
   * </pre>
   */
  public agences.supermarche.Caisse[] listeC ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge);

  /**
   * <pre>
   *   attribute double tva;
   * </pre>
   */
  public double tva ();

  /**
   * <pre>
   *   attribute double tva;
   * </pre>
   */
  public void tva (double tva);

  /**
   * <pre>
   *   agences.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws agences.supermarche.AgenceException;

  /**
   * <pre>
   *   agences.supermarche.Caisse creer (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Caisse creer (java.lang.String nomCaisse) throws agences.supermarche.AgenceException;

  /**
   * <pre>
   *   void supprimer (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String nomCaisse) throws agences.supermarche.AgenceException;

  /**
   * <pre>
   *   agences.supermarche.Caisse rechercher (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Caisse rechercher (java.lang.String nomCaisse) throws agences.supermarche.AgenceException;

  /**
   * <pre>
   *   void inscrire (in string nomCaisse, in agences.supermarche.Caisse refCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void inscrire (java.lang.String nomCaisse, 
                        agences.supermarche.Caisse refCaisse) throws agences.supermarche.AgenceException;

  /**
   * <pre>
   *   void desinscrire (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void desinscrire (java.lang.String nomCaisse) throws agences.supermarche.AgenceException;

}
