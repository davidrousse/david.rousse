package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public class _GererProduitsStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements GererProduits {
  final public static java.lang.Class _opsClass = agences.supermarche.GererProduitsOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererProduits:1.0"
  };

  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_string((java.lang.String)designation);
          _output.write_double((double)prixHT);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          _self.creer(codeBarre, designation, prixHT);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void creerP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (agences.supermarche.Produit p) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creerP", true);
          agences.supermarche.ProduitHelper.write(_output, p);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creerP", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          _self.creerP(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimer", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          _self.supprimer(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void supprimerP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (agences.supermarche.Produit p) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimerP", true);
          agences.supermarche.ProduitHelper.write(_output, p);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimerP", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          _self.supprimerP(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("modifier", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_string((java.lang.String)designation);
          _output.write_double((double)prixHT);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("modifier", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          _self.modifier(codeBarre, designation, prixHT);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void modifierP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (agences.supermarche.Produit p) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("modifierP", true);
          agences.supermarche.ProduitHelper.write(_output, p);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("modifierP", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          _self.modifierP(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Produit rechercher (in string codeBarre)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercher (java.lang.String codeBarre) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Produit _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = agences.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          return _self.rechercher(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Produit rechercherP (in agences.supermarche.Produit p)
    raises (agences.supermarche.GererProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercherP (agences.supermarche.Produit p) throws  agences.supermarche.GererProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Produit _result;
        try {
          _output = this._request("rechercherP", true);
          agences.supermarche.ProduitHelper.write(_output, p);
          _input = this._invoke(_output);
          _result = agences.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.GererProduitsExceptionHelper.id())) {
            throw             agences.supermarche.GererProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherP", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.GererProduitsOperations _self = (agences.supermarche.GererProduitsOperations)_so.servant;
        try {
          return _self.rechercherP(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
