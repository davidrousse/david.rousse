package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public interface CaisseOperations {
  /**
   * <pre>
   *   readonly attribute double totalVentes;
   * </pre>
   */
  public double totalVentes ();

  /**
   * <pre>
   *   readonly attribute double totalVentesCaissier;
   * </pre>
   */
  public double totalVentesCaissier ();

  /**
   * <pre>
   *   readonly attribute string nomAgence;
   * </pre>
   */
  public java.lang.String nomAgence ();

  /**
   * <pre>
   *   readonly attribute string nomCaissier;
   * </pre>
   */
  public java.lang.String nomCaissier ();

  /**
   * <pre>
   *   readonly attribute string nomCaisse;
   * </pre>
   */
  public java.lang.String nomCaisse ();

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws agences.supermarche.CaisseException;

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in long qte)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       int qte) throws agences.supermarche.CaisseException;

  /**
   * <pre>
   *   agences.supermarche.listeTickets editerTicket ()
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public agences.supermarche.LigneTicket[] editerTicket () throws agences.supermarche.CaisseException;

  /**
   * <pre>
   *   string connecter (in string login, in string password)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public java.lang.String connecter (java.lang.String login, 
                                     java.lang.String password) throws agences.supermarche.CaisseException;

  /**
   * <pre>
   *   void deconnecter (in string login, in string password)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login, 
                           java.lang.String password) throws agences.supermarche.CaisseException;

}
