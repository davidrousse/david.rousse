package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeTickets
 * <li> <b>Repository Id</b> IDL:supermarche/listeTickets:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltagences.supermarche.LigneTicket&gt listeTickets;
 * </pre>
 */
public final class listeTicketsHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static agences.supermarche.LigneTicket[] read (final org.omg.CORBA.portable.InputStream _input) {
    agences.supermarche.LigneTicket[] result;
    final int $length0 = _input.read_long();
    result = new agences.supermarche.LigneTicket[$length0];
    for (int $counter1 = 0; $counter1 < $length0; $counter1++) {
      result[$counter1] = agences.supermarche.LigneTicketHelper.read(_input);
    }
    return result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final agences.supermarche.LigneTicket[] _vis_value) {
    _output.write_long(_vis_value.length);
    for (int $counter2 = 0;  $counter2 < _vis_value.length; $counter2++) {
      agences.supermarche.LigneTicketHelper.write(_output, _vis_value[$counter2]);
    }
  }

  public static void insert (final org.omg.CORBA.Any any, final agences.supermarche.LigneTicket[] _vis_value) {
    any.type(agences.supermarche.listeTicketsHelper.type());
    any.insert_Streamable(new agences.supermarche.listeTicketsHolder(_vis_value));
  }

  public static agences.supermarche.LigneTicket[] extract (final org.omg.CORBA.Any any) {
    agences.supermarche.LigneTicket[] _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      agences.supermarche.listeTicketsHolder _vis_holder = new agences.supermarche.listeTicketsHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    } else {
      _vis_value = agences.supermarche.listeTicketsHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          org.omg.CORBA.TypeCode originalType = _orb().create_sequence_tc(0, agences.supermarche.LigneTicketHelper.type());
          _type = _orb().create_alias_tc(id(), "listeTickets", originalType);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/listeTickets:1.0";
  }
}
