package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public class _CaisseStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements Caisse {
  final public static java.lang.Class _opsClass = agences.supermarche.CaisseOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Caisse:1.0"
  };

  /**
   * <pre>
   *   readonly attribute double totalVentes;
   * </pre>
   */
  public double totalVentes () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_totalVentes", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_totalVentes", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.totalVentes();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute double totalVentesCaissier;
   * </pre>
   */
  public double totalVentesCaissier () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_totalVentesCaissier", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_totalVentesCaissier", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.totalVentesCaissier();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomAgence;
   * </pre>
   */
  public java.lang.String nomAgence () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomAgence", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomAgence", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.nomAgence();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomCaissier;
   * </pre>
   */
  public java.lang.String nomCaissier () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomCaissier", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomCaissier", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.nomCaissier();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomCaisse;
   * </pre>
   */
  public java.lang.String nomCaisse () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomCaisse", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomCaisse", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.nomCaisse();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws  agences.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("vendreS", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.CaisseExceptionHelper.id())) {
            throw             agences.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("vendreS", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          _self.vendreS(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in long qte)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       int qte) throws  agences.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("vendreC", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.CaisseExceptionHelper.id())) {
            throw             agences.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("vendreC", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          _self.vendreC(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   agences.supermarche.listeTickets editerTicket ()
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public agences.supermarche.LigneTicket[] editerTicket () throws  agences.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.LigneTicket[] _result;
        try {
          _output = this._request("editerTicket", true);
          _input = this._invoke(_output);
          _result = agences.supermarche.listeTicketsHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.CaisseExceptionHelper.id())) {
            throw             agences.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("editerTicket", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.editerTicket();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   string connecter (in string login, in string password)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public java.lang.String connecter (java.lang.String login, 
                                     java.lang.String password) throws  agences.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("connecter", true);
          _output.write_string((java.lang.String)login);
          _output.write_string((java.lang.String)password);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.CaisseExceptionHelper.id())) {
            throw             agences.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("connecter", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.connecter(login, password);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void deconnecter (in string login, in string password)
    raises (agences.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login, 
                           java.lang.String password) throws  agences.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("deconnecter", true);
          _output.write_string((java.lang.String)login);
          _output.write_string((java.lang.String)password);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.CaisseExceptionHelper.id())) {
            throw             agences.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("deconnecter", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.CaisseOperations _self = (agences.supermarche.CaisseOperations)_so.servant;
        try {
          _self.deconnecter(login, password);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
