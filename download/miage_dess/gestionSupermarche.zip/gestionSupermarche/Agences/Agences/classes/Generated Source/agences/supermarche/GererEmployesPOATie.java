package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class GererEmployesPOATie extends GererEmployesPOA {
  private agences.supermarche.GererEmployesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererEmployesPOATie (final agences.supermarche.GererEmployesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererEmployesPOATie (final agences.supermarche.GererEmployesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public agences.supermarche.GererEmployesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final agences.supermarche.GererEmployesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeEmployes listeE;
   * </pre>
   */
  public agences.supermarche.Employe[] listeE () {
    return this._delegate.listeE();
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  agences.supermarche.GererEmployesException {
    this._delegate.creer(login, password, droit);
  }

  /**
   * <pre>
   *   void creerE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (agences.supermarche.Employe e) throws  agences.supermarche.GererEmployesException {
    this._delegate.creerE(e);
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  agences.supermarche.GererEmployesException {
    this._delegate.modifier(login, password, droit);
  }

  /**
   * <pre>
   *   void modifierE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (agences.supermarche.Employe e) throws  agences.supermarche.GererEmployesException {
    this._delegate.modifierE(e);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  agences.supermarche.GererEmployesException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   void supprimerE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (agences.supermarche.Employe e) throws  agences.supermarche.GererEmployesException {
    this._delegate.supprimerE(e);
  }

  /**
   * <pre>
   *   agences.supermarche.Employe rechercher (in string login)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public agences.supermarche.Employe rechercher (java.lang.String login) throws  agences.supermarche.GererEmployesException {
    return this._delegate.rechercher(login);
  }

  /**
   * <pre>
   *   agences.supermarche.Employe rechercherE (in agences.supermarche.Employe e)
    raises (agences.supermarche.GererEmployesException);
   * </pre>
   */
  public agences.supermarche.Employe rechercherE (agences.supermarche.Employe e) throws  agences.supermarche.GererEmployesException {
    return this._delegate.rechercherE(e);
  }

}
