
package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeCaisses
 * <li> <b>Repository Id</b> IDL:supermarche/listeCaisses:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltagences.supermarche.Caisse&gt listeCaisses;
 * </pre>
 */
public final class listeCaissesHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static agences.supermarche.Caisse[] read (final org.omg.CORBA.portable.InputStream _input) {
    agences.supermarche.Caisse[] result;
    final int $length9 = _input.read_long();
    result = new agences.supermarche.Caisse[$length9];
    for (int $counter10 = 0; $counter10 < $length9; $counter10++) {
      result[$counter10] = agences.supermarche.CaisseHelper.read(_input);
    }
    return result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final agences.supermarche.Caisse[] _vis_value) {
    _output.write_long(_vis_value.length);
    for (int $counter11 = 0;  $counter11 < _vis_value.length; $counter11++) {
      agences.supermarche.CaisseHelper.write(_output, _vis_value[$counter11]);
    }
  }

  public static void insert (final org.omg.CORBA.Any any, final agences.supermarche.Caisse[] _vis_value) {
    any.type(agences.supermarche.listeCaissesHelper.type());
    any.insert_Streamable(new agences.supermarche.listeCaissesHolder(_vis_value));
  }

  public static agences.supermarche.Caisse[] extract (final org.omg.CORBA.Any any) {
    agences.supermarche.Caisse[] _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      agences.supermarche.listeCaissesHolder _vis_holder = new agences.supermarche.listeCaissesHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    } else {
      _vis_value = agences.supermarche.listeCaissesHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          org.omg.CORBA.TypeCode originalType = _orb().create_sequence_tc(0, agences.supermarche.CaisseHelper.type());
          _type = _orb().create_alias_tc(id(), "listeCaisses", originalType);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/listeCaisses:1.0";
  }
}
