package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::LigneTicket
 * <li> <b>Repository Id</b> IDL:supermarche/LigneTicket:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct LigneTicket {
  ...
};
 * </pre>
 */
public final class LigneTicketHolder implements org.omg.CORBA.portable.Streamable {
  public agences.supermarche.LigneTicket value;

  public LigneTicketHolder () {
  }

  public LigneTicketHolder (final agences.supermarche.LigneTicket _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = agences.supermarche.LigneTicketHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    agences.supermarche.LigneTicketHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return agences.supermarche.LigneTicketHelper.type();
  }
}
