package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public class _AgenceStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements Agence {
  final public static java.lang.Class _opsClass = agences.supermarche.AgenceOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Agence:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomObjet", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomObjet", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.nomObjet();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeCaisses listeC;
   * </pre>
   */
  public agences.supermarche.Caisse[] listeC () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Caisse[] _result;
        try {
          _output = this._request("_get_listeC", true);
          _input = this._invoke(_output);
          _result = agences.supermarche.listeCaissesHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeC", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.listeC();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_marge", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_marge", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.marge();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_marge", true);
          _output.write_double((double)marge);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_marge", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          _self.marge(marge);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   attribute double tva;
   * </pre>
   */
  public double tva () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_tva", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_tva", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.tva();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double tva;
   * </pre>
   */
  public void tva (double tva) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_tva", true);
          _output.write_double((double)tva);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_tva", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          _self.tva(tva);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws  agences.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Produit _result;
        try {
          _output = this._request("recupererInfoProduit", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = agences.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.AgenceExceptionHelper.id())) {
            throw             agences.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("recupererInfoProduit", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.recupererInfoProduit(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Caisse creer (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Caisse creer (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Caisse _result;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)nomCaisse);
          _input = this._invoke(_output);
          _result = agences.supermarche.CaisseHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.AgenceExceptionHelper.id())) {
            throw             agences.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.creer(nomCaisse);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void supprimer (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimer", true);
          _output.write_string((java.lang.String)nomCaisse);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.AgenceExceptionHelper.id())) {
            throw             agences.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimer", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          _self.supprimer(nomCaisse);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   agences.supermarche.Caisse rechercher (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Caisse rechercher (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        agences.supermarche.Caisse _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)nomCaisse);
          _input = this._invoke(_output);
          _result = agences.supermarche.CaisseHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.AgenceExceptionHelper.id())) {
            throw             agences.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          return _self.rechercher(nomCaisse);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void inscrire (in string nomCaisse, in agences.supermarche.Caisse refCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void inscrire (java.lang.String nomCaisse, 
                        agences.supermarche.Caisse refCaisse) throws  agences.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("inscrire", true);
          _output.write_string((java.lang.String)nomCaisse);
          agences.supermarche.CaisseHelper.write(_output, refCaisse);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.AgenceExceptionHelper.id())) {
            throw             agences.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("inscrire", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          _self.inscrire(nomCaisse, refCaisse);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void desinscrire (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void desinscrire (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("desinscrire", true);
          _output.write_string((java.lang.String)nomCaisse);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(agences.supermarche.AgenceExceptionHelper.id())) {
            throw             agences.supermarche.AgenceExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("desinscrire", _opsClass);
        if (_so == null) {
          continue;
        }
        final agences.supermarche.AgenceOperations _self = (agences.supermarche.AgenceOperations)_so.servant;
        try {
          _self.desinscrire(nomCaisse);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
