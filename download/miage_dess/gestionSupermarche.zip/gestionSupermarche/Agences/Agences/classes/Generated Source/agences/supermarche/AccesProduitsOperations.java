package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   agences.supermarche.Produit rechercher (in string codeBarre)
    raises (agences.supermarche.AccesProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercher (java.lang.String codeBarre) throws agences.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   agences.supermarche.Produit rechercherP (in agences.supermarche.Produit p)
    raises (agences.supermarche.AccesProduitsException);
   * </pre>
   */
  public agences.supermarche.Produit rechercherP (agences.supermarche.Produit p) throws agences.supermarche.AccesProduitsException;

}
