package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeTickets
 * <li> <b>Repository Id</b> IDL:supermarche/listeTickets:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltagences.supermarche.LigneTicket&gt listeTickets;
 * </pre>
 */
public final class listeTicketsHolder implements org.omg.CORBA.portable.Streamable {
  public agences.supermarche.LigneTicket[] value;

  public listeTicketsHolder () {
  }

  public listeTicketsHolder (final agences.supermarche.LigneTicket[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = agences.supermarche.listeTicketsHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    agences.supermarche.listeTicketsHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return agences.supermarche.listeTicketsHelper.type();
  }
}
