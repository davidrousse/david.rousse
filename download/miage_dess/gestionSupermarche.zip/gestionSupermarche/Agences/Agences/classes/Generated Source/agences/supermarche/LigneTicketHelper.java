package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::LigneTicket
 * <li> <b>Repository Id</b> IDL:supermarche/LigneTicket:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct LigneTicket {
  ...
};
 * </pre>
 */
public final class LigneTicketHelper {
  private static boolean _inited = false;
  private static boolean _initing = false;
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static agences.supermarche.LigneTicket read (final org.omg.CORBA.portable.InputStream _input) {
    final agences.supermarche.LigneTicket _result = new agences.supermarche.LigneTicket();
    _result.codeBarre = _input.read_string();
    _result.designation = _input.read_string();
    _result.prixTTC = _input.read_double();
    _result.qte = _input.read_long();
    return _result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final agences.supermarche.LigneTicket _vis_value) {
    _output.write_string((java.lang.String)_vis_value.codeBarre);
    _output.write_string((java.lang.String)_vis_value.designation);
    _output.write_double((double)_vis_value.prixTTC);
    _output.write_long((int)_vis_value.qte);
  }

  public static void insert (final org.omg.CORBA.Any any, final agences.supermarche.LigneTicket _vis_value) {
    any.insert_Streamable(new agences.supermarche.LigneTicketHolder(_vis_value));
  }

  public static agences.supermarche.LigneTicket extract (final org.omg.CORBA.Any any) {
    agences.supermarche.LigneTicket _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      agences.supermarche.LigneTicketHolder _vis_holder = new agences.supermarche.LigneTicketHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    }
    else {
      _vis_value = agences.supermarche.LigneTicketHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          if (_initializing) {
            return _orb().create_recursive_tc(id());
          }
          _initializing = true;
          final org.omg.CORBA.StructMember[] members = new org.omg.CORBA.StructMember[4];
          members[0] = new org.omg.CORBA.StructMember("codeBarre", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string), null);
          members[1] = new org.omg.CORBA.StructMember("designation", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string), null);
          members[2] = new org.omg.CORBA.StructMember("prixTTC", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_double), null);
          members[3] = new org.omg.CORBA.StructMember("qte", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_long), null);
          _type = _orb().create_struct_tc(id(), "LigneTicket", members);
          _initializing = false;
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/LigneTicket:1.0";
  }
}
