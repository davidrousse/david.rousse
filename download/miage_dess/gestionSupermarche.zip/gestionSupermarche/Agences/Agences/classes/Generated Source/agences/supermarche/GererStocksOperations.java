package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public interface GererStocksOperations {
  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeStocks listeS;
   * </pre>
   */
  public agences.supermarche.Stock[] listeS ();

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   void creerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (agences.supermarche.Stock s) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (agences.supermarche.Stock s) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementerS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (agences.supermarche.Stock s) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   agences.supermarche.Stock rechercher (in string codeBarre)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public agences.supermarche.Stock rechercher (java.lang.String codeBarre) throws agences.supermarche.GererStocksException;

  /**
   * <pre>
   *   agences.supermarche.Stock rechercherS (in agences.supermarche.Stock s)
    raises (agences.supermarche.GererStocksException);
   * </pre>
   */
  public agences.supermarche.Stock rechercherS (agences.supermarche.Stock s) throws agences.supermarche.GererStocksException;

}
