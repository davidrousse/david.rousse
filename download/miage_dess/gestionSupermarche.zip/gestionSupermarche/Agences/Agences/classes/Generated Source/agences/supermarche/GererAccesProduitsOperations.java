package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public interface GererAccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public agences.supermarche.AccesProduits[] listeAP ();

  /**
   * <pre>
   *   agences.supermarche.AccesProduits creer (in string agence)
    raises (agences.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public agences.supermarche.AccesProduits creer (java.lang.String agence) throws agences.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (agences.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws agences.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   agences.supermarche.AccesProduits rechercher (in string agence)
    raises (agences.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public agences.supermarche.AccesProduits rechercher (java.lang.String agence) throws agences.supermarche.GererAccesProduitsException;

}
