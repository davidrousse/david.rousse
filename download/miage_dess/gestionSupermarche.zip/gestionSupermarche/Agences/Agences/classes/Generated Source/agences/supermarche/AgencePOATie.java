package agences.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/Agences/Agences/src/agences/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public class AgencePOATie extends AgencePOA {
  private agences.supermarche.AgenceOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public AgencePOATie (final agences.supermarche.AgenceOperations _delegate) {
    this._delegate = _delegate;
  }

  public AgencePOATie (final agences.supermarche.AgenceOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public agences.supermarche.AgenceOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final agences.supermarche.AgenceOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   readonly attribute agences.supermarche.listeCaisses listeC;
   * </pre>
   */
  public agences.supermarche.Caisse[] listeC () {
    return this._delegate.listeC();
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge () {
    return this._delegate.marge();
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge) {
    this._delegate.marge(marge);
  }

  /**
   * <pre>
   *   attribute double tva;
   * </pre>
   */
  public double tva () {
    return this._delegate.tva();
  }

  /**
   * <pre>
   *   attribute double tva;
   * </pre>
   */
  public void tva (double tva) {
    this._delegate.tva(tva);
  }

  /**
   * <pre>
   *   agences.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws  agences.supermarche.AgenceException {
    return this._delegate.recupererInfoProduit(codeBarre);
  }

  /**
   * <pre>
   *   agences.supermarche.Caisse creer (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Caisse creer (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {
    return this._delegate.creer(nomCaisse);
  }

  /**
   * <pre>
   *   void supprimer (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {
    this._delegate.supprimer(nomCaisse);
  }

  /**
   * <pre>
   *   agences.supermarche.Caisse rechercher (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public agences.supermarche.Caisse rechercher (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {
    return this._delegate.rechercher(nomCaisse);
  }

  /**
   * <pre>
   *   void inscrire (in string nomCaisse, in agences.supermarche.Caisse refCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void inscrire (java.lang.String nomCaisse, 
                        agences.supermarche.Caisse refCaisse) throws  agences.supermarche.AgenceException {
    this._delegate.inscrire(nomCaisse, refCaisse);
  }

  /**
   * <pre>
   *   void desinscrire (in string nomCaisse)
    raises (agences.supermarche.AgenceException);
   * </pre>
   */
  public void desinscrire (java.lang.String nomCaisse) throws  agences.supermarche.AgenceException {
    this._delegate.desinscrire(nomCaisse);
  }

}
