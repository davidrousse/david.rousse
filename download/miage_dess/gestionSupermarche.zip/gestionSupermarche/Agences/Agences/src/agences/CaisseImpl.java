package agences;

import agences.supermarche.*;
import agences.*;
import gererstocks.supermarche.GererStocks;
import gererstocks.supermarche.GererStocksException;
import gererstocks.supermarche.Stock;
import gereremployes.supermarche.GererEmployes;
import gereremployes.supermarche.GererEmployesException;
import gereremployes.supermarche.Employe;
import java.util.*;

/**
 * Titre :
 * Description :
 * Copyright :    Copyright (c) 2002
 * Soci�t� :
 * @author
 * @version 1.0
 */

public class CaisseImpl extends CaissePOA {

  private String _nomCaissier;
  private String _nomAgence;
  private String _nomCaisse;
  private Vector _liste;
  private GererEmployes _iGererEmployes;
  private GererStocks _iGererStocks;
  private Agence _iAgence;
  private double _marge;
  private double _tva;
  private double _totalVentes;
  private double _totalVentesCaissier;

  public CaisseImpl(String agence, String caisse, GererEmployes pGererEmployes, Agence pAgence, GererStocks pGererStocks) {
    _nomAgence = agence;
    _nomCaisse = caisse;
    _liste = new Vector();
    _iGererEmployes = pGererEmployes;
    _iGererStocks = pGererStocks;
    _iAgence = pAgence;
    _totalVentes = 0.0;
    _totalVentesCaissier = 0.0;
    try {
      _tva = _iAgence.tva();
      _marge = _iAgence.marge();
    }
    catch(Exception e) {
      System.out.println("Impossible de se connecter a l'agence "+_nomAgence);
    }
  }

  public LigneTicket[] editerTicket() throws agences.supermarche.CaisseException {
    // retourne la liste des lignes tickets
    Enumeration parcours = _liste.elements();
    LigneTicket[] listeLigneTicket = new LigneTicket[_liste.size()];
    LigneTicket ticketCourant = null;
    int i=0;
    while(parcours.hasMoreElements()) {
      ticketCourant = (LigneTicket)parcours.nextElement();
      listeLigneTicket[i] = ticketCourant;
      _totalVentesCaissier += ticketCourant.prixTTC*ticketCourant.qte;
      try {
        _iGererStocks.decrementer(ticketCourant.codeBarre,ticketCourant.qte);
      }
      catch(GererStocksException e) {
        System.out.println("Impossible de mettre � jour le stock "+ticketCourant.codeBarre+" - "+e);
        throw new agences.supermarche.CaisseException("Impossible de mettre � jour le stock "+ticketCourant.codeBarre+" - "+e);
      }
      catch(Exception e) {
        System.out.println("Erreur inconnue ! - "+ticketCourant.codeBarre+" - "+e);
        throw new agences.supermarche.CaisseException("Erreur inconnue ! - "+ticketCourant.codeBarre+" - "+e);
      }
      i++;
    }
    _liste.removeAllElements();
    return listeLigneTicket;
  }

  public String nomCaissier() {
    return _nomCaissier;
  }
  public void vendreS(String codeBarre) throws agences.supermarche.CaisseException {
    //on recupere les info du produit
    try{
      Produit p = _iAgence.recupererInfoProduit(codeBarre);
      //on insere une ligne dans le ticket courant
      LigneTicket ligne = new LigneTicket(p.codeBarre,p.designation,p.prixHT*(1+_marge+_tva),1);
      _liste.addElement(ligne);
    }
    catch(agences.supermarche.AgenceException e) {
      System.out.println("Impossible de recuperer les informations du produit "+codeBarre+" - "+e);
      throw new CaisseException("Impossible de recuperer les informations du produit "+codeBarre);
    }
  }
  public void vendreC(String codeBarre, int qte) throws agences.supermarche.CaisseException {
    //on recupere les info du produit
    try{
      Produit p = _iAgence.recupererInfoProduit(codeBarre);
      //on insere une ligne dans le ticket courant
      LigneTicket ligne = new LigneTicket(p.codeBarre,p.designation,p.prixHT*(1+_marge+_tva),qte);
      _liste.addElement(ligne);
    }
    catch(agences.supermarche.AgenceException e) {
      System.out.println("Impossible de recuperer les informations du produit "+codeBarre+" - "+e);
      throw new CaisseException("Impossible de recuperer les informations du produit "+codeBarre);
    }
  }
  public void deconnecter(String login, String password) throws agences.supermarche.CaisseException {
    Employe e = null;
    try{
      //on verifie que c'est la bon caissier qui se deconnecte
      e = _iGererEmployes.rechercher(login);
    }
    catch(GererEmployesException ex) {
      System.out.println("Impossible de recuperer les informations de l'employe "+login+" - "+ex);
      throw new agences.supermarche.CaisseException("Impossible de recuperer les informations de l'employe "+login+"/"+password+" - "+ex);
    }
    catch(Exception ex) {
      System.out.println("Erreur lors de la deconnection ! "+login+"/"+password+" - "+ex);
      throw new agences.supermarche.CaisseException("Erreur lors de la deconnection ! "+login+"/"+password);
    }
    //on verifie le password
    if(e.password.equals(password)) {
      //maj du total de la caisse
      _totalVentes += _totalVentesCaissier;
      _totalVentesCaissier = 0.0;
    }
    else
      throw new agences.supermarche.CaisseException("Mot de passe incorrect. "+login+"/"+password);
  }
  public String nomAgence() {
    return _nomAgence;
  }
  public String nomCaisse() {
    return _nomCaisse;
  }
  public String connecter(String login, String password) throws agences.supermarche.CaisseException {
    Employe e = null;
    try{
      //on verifie le caissier qui se connecte
      e = _iGererEmployes.rechercher(login);
    }
    catch(GererEmployesException ex) {
      System.out.println("Impossible de recuperer les informations de l'employe "+login+"/"+password+" - "+ex);
      throw new agences.supermarche.CaisseException("Impossible de recuperer les informations de l'employe "+login+"/"+password+" - "+ex);
    }
    catch(Exception ex) {
      System.out.println("Erreur lors de la connection ! "+login+"/"+password+" - "+ex);
      throw new agences.supermarche.CaisseException("Erreur lors de la connection ! "+login+"/"+password);
    }
    //on verifie le password
    if(!(e.password.equals(password)))
      throw new agences.supermarche.CaisseException("Mot de passe incorrect. "+login+"/"+password);
    else
      _nomCaissier = login;

    return e.droit;
  }
  public double totalVentes() {
    return _totalVentes;
  }
  public double totalVentesCaissier() {
    return _totalVentesCaissier;
  }
}