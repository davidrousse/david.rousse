package agences;

import agences.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ClientAgenceTest {

  public static void main(String args[]) {

    try {
      // On intialise l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      // On construit le nom � chercher dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      // On recherche la r�f�rence aupr�s du naming service
      org.omg.CORBA.Object distant = racineArbre.resolve(nom);

      //casting de l'objet CORBA au type adequat
      Agence ap = agences.supermarche.AgenceHelper.narrow(distant);

      // On appelle les methodes
      ap.tva(0.196);
      ap.marge(0.01);
      System.out.println("Resultat nom Agence : "+ap.nomObjet());
      System.out.println("Resultat tva : "+ap.tva());
      System.out.println("Resultat marge : "+ap.marge());

      //test methode de Caisse
      Caisse c = ap.creer("caisse_test");
      try{
        c.connecter("david","?");
      }
      catch(CaisseException e) {
        System.out.println("Erreur appel Caisse n�1 - "+e.toString());
      }
      try{
        c.connecter("david","rousse");
      }
      catch(CaisseException e) {
        System.out.println("Erreur appel Caisse n�1 - "+e.toString());
      }
      try{
        c.vendreS("1");
        System.out.println("Vente simple OK");
      }
      catch(CaisseException e) {
        System.out.println("Erreur Vente simple - "+e.toString());
      }
      try{
        c.vendreC("1",2);
        System.out.println("Vente compliquee OK");
      }
      catch(CaisseException e) {
        System.out.println("Erreur Vente compliquee - "+e.toString());
      }
      System.out.println("Total ventes caissier : "+c.totalVentesCaissier());
      System.out.println("Total ventes caisse : "+c.totalVentes());
      try{
        LigneTicket[] t = c.editerTicket();
        for(int i=0;i<t.length;i++)
          System.out.println("Total ventes caissier : "+t[i].prixTTC);
      }
      catch(CaisseException e) {
        System.out.println("Erreur ticket - "+e.toString());
      }
      System.out.println("Total ventes caissier : "+c.totalVentesCaissier());
      System.out.println("Total ventes caisse : "+c.totalVentes());
      try{
        c.deconnecter("david","rousse");
      }
      catch(CaisseException e) {
        System.out.println("Erreur appel Caisse n�1 - "+e.toString());
      }
      System.out.println("Total ventes caissier : "+c.totalVentesCaissier());
      System.out.println("Total ventes caisse : "+c.totalVentes());

      for(int i=1;i<11;i++) {
        try{
          System.out.println("Resultat test :\n"+ap.recupererInfoProduit((new Integer(i)).toString())+"\n********\n");
        }
        catch(Exception e) {
          System.out.println("Appel impossible - "+e.toString());
        }
      }

      for(int i=1;i<11;i++) {
        String nomCaisse = new String("Caisse "+i);
        c = ap.creer(nomCaisse);
        try {
          System.out.println("Resultat :\n"+ap.rechercher(nomCaisse).nomAgence()+ap.rechercher(nomCaisse).nomCaisse()+"\n********\n");
        }
        catch(agences.supermarche.AgenceException e) {
          System.out.println(e.toString());
        }

        try {
          System.out.println("Resultat :\n"+ap.rechercher(nomCaisse)+"\n********\n");
        }
        catch(agences.supermarche.AgenceException e) {
          System.out.println(e.toString());
        }
        ap.supprimer(nomCaisse);
        System.out.println("Suppression "+nomCaisse);
        //Test appel sur servant supprim�
        try{
          System.out.println("Resultat test :\n"+ap.rechercher(nomCaisse)+"\n********\n");
        }
        catch(Exception e) {
          System.out.println("Appel impossible - "+e.toString());
        }
      }

      // autre test ...
      // On appelle les methodes
      for(int i=1;i<11;i++) {
        String nomCaisse = new String("Caisse "+i);
        c = ap.creer(nomCaisse);
      }

      Caisse[] tab = ap.listeC();
      for(int i=0;i<tab.length;i++) {
        String nomCaisse = new String("Caisse "+i);
        System.out.println("Resultat :\n"+tab[i].nomCaisse()+"\n********\n");
      }

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }//fin du main
}