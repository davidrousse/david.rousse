package agences;

import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import java.io.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class Federation {

  private static int _nbLiens=10;
  private String _nomFederationLocal;
  private String _nomFederationGene;
  private String _nomDesignation;
  private org.omg.CORBA.ORB _orb;
  private NamingContextExt _rootCtx;
  private NamingContext _desiCtx;
  private NamingContext _fedeCtx;

  public void creerEspaceNom(org.omg.CORBA.Object racineObj, String nomFederationGene, String nomFederationLocal, String nomDesignation) {
    _nomFederationLocal = nomFederationLocal;
    _nomDesignation = nomDesignation;
    _nomFederationGene = nomFederationGene;

    try {
      _rootCtx = NamingContextExtHelper.narrow(racineObj);

      //creation contexte de federation
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationGene,"federation");
      //lien rootCtx --> fedeCtx
      try{
        _fedeCtx = _rootCtx.bind_new_context(nom);
      }
      catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
        System.out.println("Le lien rootCtx-->"+_nomFederationGene+" existe deja - "+e.toString());
        //on recupere la reference du NamingContext fedeCtx
        nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationGene,"federation");
        _fedeCtx = org.omg.CosNaming.NamingContextHelper.narrow(_rootCtx.resolve(nom));
      }

      nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationLocal,"federation");
      //lien fedeCtx --> rootCtx
      try{
        _fedeCtx.bind_context(nom,_rootCtx);
      }
      catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
        System.out.println("Le lien "+_nomFederationLocal+"-->rootCtx existe deja - "+e.toString());
      }
      //creation contexte de designation
      nom[0] = new org.omg.CosNaming.NameComponent(_nomDesignation,"designation");
      //lien rootCtx --> desiCtx
      try{
        _desiCtx = _rootCtx.bind_new_context(nom);
      }
      catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
        System.out.println("Le lien rootCtx-->"+_nomDesignation+" existe deja - "+e.toString());
        nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(_nomDesignation,"designation");
        _desiCtx = org.omg.CosNaming.NamingContextHelper.narrow(_rootCtx.resolve(nom));
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void ecrireIOR(org.omg.CORBA.ORB orb, org.omg.CORBA.Object nomObjet, String nomFichier) {
    try {
      //ecriture IOR dans un fichier
      String ior = new String(orb.object_to_string(nomObjet));
      File fichier = new File(nomFichier);
      FileWriter fluxEcriture = new FileWriter(fichier);
      fluxEcriture.write(ior);
      fluxEcriture.flush();
      fluxEcriture.close();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public NamingContext recupererFederationSiege(org.omg.CORBA.ORB orb, String nomSource) {
  try{
      //recuperer la federation du siege
      File fichier;
      BufferedReader tamponLecture;
      fichier = new File(nomSource);
      tamponLecture = new BufferedReader(new FileReader(fichier));
      String ligneLue = tamponLecture.readLine();
      tamponLecture.close();

      return NamingContextHelper.narrow(orb.string_to_object(ligneLue));
    }
    catch (Exception e){
      System.out.println("Erreur recuperation federation du siege - "+e+" - Fichier IOR : "+nomSource);
      e.printStackTrace();
      return null;
    }
  }

  public NamingContextExt recupererRacine() {
    return _rootCtx;
  }

  public void creerLien(NamingContext source, NamingContext cible, String nomLien, String typeLien) {
  try{
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(nomLien,typeLien);

      //lien source --> cible
      source.bind_context(nom,cible);
    }
    catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
      System.out.println("Le lien vers "+nomLien+" existe deja - "+e.toString());
    }
    catch (Exception e){
      System.out.println("Erreur inconue ! - "+e);
    }
  }

  public NamingContext recupererFederation() {
    return _fedeCtx;
  }

  public NamingContext recupererContexteDesignation() {
    return _desiCtx;
  }

  public void supprimerObjectContexteDesignation(NameComponent[] nomObjet) {
    try{
      _desiCtx.unbind(nomObjet);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void supprimerRacine() {
    try{
      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();

      try{
      _rootCtx.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        return;
      }

      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++) {
        System.out.println("Suppression de nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(bList.value[i].binding_name[0].id,"federation");

        _rootCtx.unbind(nom);
      }

      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++) {

            org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
            nom[0] = new org.omg.CosNaming.NameComponent(bList.value[i].binding_name[0].id,"federation");

            _rootCtx.unbind(nom);

            System.out.println("Suppression de nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);
          }
        }
        //destruction iterateur
        bIterator.value.destroy();
      }

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void supprimerFederation() {
    try{
      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();

      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationGene,"federation");
      System.out.println("Suppression de nom:"+_nomFederationGene+" - Type:federation");

      _rootCtx.unbind(nom);

      try{
      _fedeCtx.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        _fedeCtx.destroy();
        return;
      }

      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++) {
        System.out.println("Suppression de nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

        nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(bList.value[i].binding_name[0].id,"federation");

        _fedeCtx.unbind(nom);
      }

      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++) {

            nom = new org.omg.CosNaming.NameComponent[1];
            nom[0] = new org.omg.CosNaming.NameComponent(bList.value[i].binding_name[0].id,"federation");

            _fedeCtx.unbind(nom);

            System.out.println("Suppression de nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);
          }
        }
        //destruction iterateur
        bIterator.value.destroy();
      }

      _fedeCtx.destroy();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void supprimerContexteDesignation() {
    try {
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(_nomDesignation,"designation");
      System.out.println("Suppression de nom:"+_nomDesignation+" - Type:designation");

      _rootCtx.unbind(nom);

      _desiCtx.destroy();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void parcourirRacine() {
    try {

      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();

      try{
        _rootCtx.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        System.out.println("Contexte vide");
        return;
      }
      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++)
        System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++)
            System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);
        }
        //destruction iterateur
        bIterator.value.destroy();
      }

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void parcourirFederation() {
    try {

      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();

      try{
        _fedeCtx.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        System.out.println("Contexte vide");
        return;
      }

      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++)
        System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++)
            System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);
        }
        //destruction iterateur
        bIterator.value.destroy();
      }

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void parcourirDesignation() {
    try {

      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();

      try {
        _desiCtx.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        System.out.println("Contexte vide");
        return;
      }

      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++)
        System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++)
            System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);
        }

        //destruction iterateur
        bIterator.value.destroy();
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void parcourirNamingContext(NamingContext nc) {
    try {

      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();

      try {
        nc.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        System.out.println("Contexte vide");
        return;
      }

      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++)
        System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++)
            System.out.println("Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);
        }

        //destruction iterateur
        bIterator.value.destroy();
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //copie le Naming Context pass� en parametre,
  //met a jour la federation du siege
  //met a jour les federations des autres agences
  public void copierNamingContext(NamingContext nc) {
    try {

      BindingIteratorHolder bIterator = new BindingIteratorHolder();
      BindingListHolder bList = new BindingListHolder();
      org.omg.CosNaming.NameComponent[] nom;
      NamingContext ctxDistant;
      NamingContext ctxFedeDistant;

      //on recuperer la liste des liens sortants du NamingContext � parcourir
      try {
        nc.list(_nbLiens,bList,bIterator);
      }
      catch (Exception e) {
        System.out.println("Contexte vide");
        return;
      }

      //parcours n premiers elements
      for(int i=0;i<bList.value.length;i++) {
        //on recupere la reference d'un NamingContext sortant
        nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(bList.value[i].binding_name[0].id,bList.value[i].binding_name[0].kind);
        ctxDistant = NamingContextHelper.narrow(nc.resolve(nom));
        try{
          //lien fedeCtx --> ctxDistant
          _fedeCtx.bind_context(nom,ctxDistant);
          System.out.println("Mise a jour federation locale agence - Creation lien vers Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

          //mise � jour federations agences ou siege
          //on recupere ici la reference de la federation pour le ctxDistant courant
          nom = new org.omg.CosNaming.NameComponent[1];
          nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationGene,"federation");
          ctxFedeDistant = NamingContextHelper.narrow(ctxDistant.resolve(nom));
          try{
            //nom a enregistrer (federation distante vers notre racine)
            nom = new org.omg.CosNaming.NameComponent[1];
            nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationLocal,"federation");
            //lien ctxFedeDistant --> _rootCtx
            ctxFedeDistant.bind_context(nom,_rootCtx);
            System.out.println("Mise a jour federation distante - Creation lien vers Nom:"+_nomFederationLocal+" - Type:federation");
          }
          catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
            System.out.println("Erreur mise a jour federation distante - Le lien vers "+_nomFederationLocal+" existe deja - "+e.toString());
          }
          catch(org.omg.CosNaming.NamingContextPackage.NotFound e) {
            System.out.println("Erreur mise a jour federation distante - Le lien vers "+bList.value[i].binding_name[0].id+" est inconnu - "+e.toString());
          }

        }
        catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
          System.out.println("Erreur mise a jour federation locale agence - Le lien vers "+bList.value[i].binding_name[0].id+" existe deja - "+e.toString());
        }
        catch(org.omg.CosNaming.NamingContextPackage.NotFound e) {
          System.out.println("Erreur mise a jour federation locale agence - Le lien vers "+bList.value[i].binding_name[0].id+" est inconnu - "+e.toString());
        }

      }
      //parcours iterateur si besoin
      if(bIterator.value!=null) {
        while(bIterator.value.next_n(_nbLiens,bList)) {
          for(int i=0;i<bList.value.length;i++) {
            nom = new org.omg.CosNaming.NameComponent[1];
            nom[0] = new org.omg.CosNaming.NameComponent(bList.value[i].binding_name[0].id,bList.value[i].binding_name[0].kind);
            ctxDistant = NamingContextHelper.narrow(nc.resolve(nom));
            try{
              //lien fedeCtx --> ctxDistant
              _fedeCtx.bind_context(nom,ctxDistant);
              System.out.println("Mise a jour federation locale agence - Creation lien vers Nom:"+bList.value[i].binding_name[0].id+" - Type:"+bList.value[i].binding_name[0].kind);

              //mise � jour federations agences ou siege
              nom = new org.omg.CosNaming.NameComponent[1];
              nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationGene,"federation");
              ctxFedeDistant = NamingContextHelper.narrow(ctxDistant.resolve(nom));
              try{
                //nom a enregistrer
                nom = new org.omg.CosNaming.NameComponent[1];
                nom[0] = new org.omg.CosNaming.NameComponent(_nomFederationLocal,"federation");
                //lien ctxFedeDistant --> _fedeCtx
                ctxFedeDistant.bind_context(nom,_fedeCtx);
                System.out.println("Mise a jour federation distante - Creation lien vers Nom:"+_nomFederationLocal+" - Type:federation");
              }
              catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
                System.out.println("Erreur mise a jour federation distante - Le lien vers "+_nomFederationLocal+" existe deja - "+e.toString());
              }
              catch(org.omg.CosNaming.NamingContextPackage.NotFound e) {
                System.out.println("Erreur mise a jour federation distante - Le lien vers "+bList.value[i].binding_name[0].id+" est inconnu - "+e.toString());
              }

            }
            catch(org.omg.CosNaming.NamingContextPackage.AlreadyBound e) {
              System.out.println("Erreur mise a jour federation locale agence - Le lien vers "+bList.value[i].binding_name[0].id+" existe deja - "+e.toString());
            }
          }
        }

        //destruction iterateur
        bIterator.value.destroy();
      }
    }
    catch (Exception e) {
      System.out.println("Erreur copie - Impossible de continuer - "+e);
    }
  }

}//fin classe