package agences;

import agences.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import gererstocks.GererStocksImpl;
import gereremployes.GererEmployesImpl;
import gereremployes.supermarche.GererEmployes;
import gereremployes.supermarche.GererEmployesException;
import gereremployes.supermarche.GererEmployesHelper;
import gererstocks.supermarche.GererStocks;
import gererstocks.supermarche.GererStocksException;
import gererstocks.supermarche.GererStocksHelper;
import javax.swing.*;
import java.util.*;

/**
 * Titre :
 * Description :
 * Copyright :    Copyright (c) 2002
 * Soci�t� :
 * @author
 * @version 1.0
 */

public class ServeurCaisse {

  public static void main(String[] args) {
    try {
      //verification des arguments (seuls certains servent pour la caisse ...
      // par ex., le fichier erst inutile !)
      //1� arg. = nom objet CORBA, 2� arg. = nom federation general
      //3� arg. = nom federation local, 4� arg. = nom designation
      //5� arg. = nom fichier IOR, 6� arg. = nom GererStocks
      //7� arg. = nom GererEmployes
      if(args.length!=7) {
        System.out.println("Appel incorrect. Syntaxe : ServeurCaisse nomObj nomFedeGene nomFedeLocal nomDesi nomFichierIOR nomGererStocks GererEmployes");
        System.exit(0);
      }

      String nomAgence =   JOptionPane.showInputDialog(
                           null,
                           "Entrez le nom de l'agence : " ,
                           "Gestion des caisses",
                           JOptionPane.QUESTION_MESSAGE);

      String nomCaisse =   JOptionPane.showInputDialog(
                           null,
                           "Entrez le nom de la caisse � cr�er : " ,
                           "Gestion des caisses",
                           JOptionPane.QUESTION_MESSAGE);

      System.getProperties().put("SVCnameroot","NameService"+nomAgence);

      //intialisation de l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cup�re le rootPOA.
      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      //on va cr�er des politiques (policies)
      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };

      //cr�ation de son propre POA avec les politiques pr�c�dentes
      POA poa = rootPOA.create_POA("supermarchePOA",rootPOA.the_POAManager(),policies);

      org.omg.CORBA.Object distant=null;

      //********************* recuperation de GererEmployes *******************
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent("GererEmployes","objet_metier");

      try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/"+"GererEmployes n'est pas accessible");
        System.exit(0);
      }

      //casting de l'objet CORBA au type adequat
      GererEmployes iGererEmployes = GererEmployesHelper.narrow(distant);

      //********************** recuperation de GererStocks *****************
      nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent("GererStocks","objet_metier");

      try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/"+"GererStocks n'est pas accessible");
        System.exit(0);
      }

      //casting de l'objet CORBA au type adequat
      GererStocks iGererStocks = GererStocksHelper.narrow(distant);

      //********************** recuperation de Agence *****************
      nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent("Agence"+nomAgence,"objet_metier");

      try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/Agence"+nomAgence+" n'est pas accessible");
        System.exit(0);
      }

      //casting de l'objet CORBA au type adequat
      Agence iAgence = agences.supermarche.AgenceHelper.narrow(distant);

      //******************* creation de CaisseImpl *****************
      //cr�ation du servant
      CaisseImpl monServant = new CaisseImpl(nomAgence,nomCaisse,iGererEmployes,iAgence,iGererStocks);

      //donner un Object ID au servant
      byte[] monId = nomCaisse.getBytes();

      //activer le servant avec l'ID dans le POA
      poa.activate_object_with_id(monId, monServant);

      //activer le POA manager
      rootPOA.the_POAManager().activate();

      //indique � l'agence que l'on s'est cree
      try{
        iAgence.inscrire(nomCaisse,CaisseHelper.narrow(poa.servant_to_reference(monServant)));
      }
      catch(AgenceException e) {
        System.out.println("Inscription impossible de la caisse "+nomCaisse+" sur l'agence "+nomAgence+" - "+e);
        System.exit(0);
      }

      //trace ecran
      System.out.println(poa.servant_to_reference(monServant) + " est pret.");

      //mse en attente de requete
      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  } //fin du main
}