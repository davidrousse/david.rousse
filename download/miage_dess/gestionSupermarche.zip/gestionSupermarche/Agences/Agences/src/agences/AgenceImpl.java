package agences;

import agences.supermarche.*;
import gererstocks.supermarche.GererStocks;
import gererstocks.supermarche.GererStocksException;
import gererstocks.supermarche.Stock;
import gereremployes.supermarche.GererEmployes;
import gereremployes.supermarche.GererEmployesException;
import java.util.*;

/**
 * Titre :
 * Description :
 * Copyright :    Copyright (c) 2002
 * Soci�t� :
 * @author
 * @version 1.0
 */

public class AgenceImpl extends AgencePOA {

  private Hashtable _liste;
  private String _nomAgence;
  private GererEmployes _iGererEmployes;
  private GererStocks _iGererStocks;
  private Agence _iAgence;
  private AccesProduits _iAccesProduits;
  private double _marge;
  private double _tva;
  private double _totalVentes;

  public synchronized Caisse creer(String nomCaisse) throws agences.supermarche.AgenceException {

    // on verifie que la caisse n'est pas deja creee
    Caisse obj = (Caisse) _liste.get(nomCaisse);
    // si ce n'est pas le cas, on cree un AccesDonneesImpl
    if(obj == null) {

      _iAgence = this._this();
      // creation d'un servant
      CaisseImpl objServant = new CaisseImpl(_nomAgence,nomCaisse,_iGererEmployes,_iAgence,_iGererStocks);
      try {
        // activation de l'objet dans le POA par defaut
        obj = CaisseHelper.narrow(_default_POA().servant_to_reference(objServant));
        // information de log
        System.out.println(_default_POA().servant_to_reference(objServant) + " est pret.");
      }
      catch (Exception e) {
        e.printStackTrace();
      }
      // ajout dans la liste des servants instancies
      _liste.put(nomCaisse, obj);
    }
    // renvoie de l'objet demand�
    return obj;
  }
  public void supprimer(String nomCaisse) throws agences.supermarche.AgenceException {
    Caisse obj = (Caisse) _liste.get(nomCaisse);
    if (obj != null) {
      try{
        _default_POA().deactivate_object(_default_POA().reference_to_id(obj));
        _liste.remove(nomCaisse);
        // information de log
        System.out.println("Caisse "+nomCaisse+" pour "+_nomAgence+ " est arretee.");
      }
      catch (Exception e)
      {
        return;
      }
    } else {
      // l'objet n'existe pas
      return;
    }
    return;
  }
  public Caisse rechercher(String nomCaisse) throws agences.supermarche.AgenceException {
    return (Caisse)_liste.get(nomCaisse);
  }

  public Caisse[] listeC() {
    Enumeration parcours = _liste.elements();
    Caisse[] retour = new Caisse[_liste.size()];
    int i=0;
    while(parcours.hasMoreElements()) {
      retour[i] = (Caisse)parcours.nextElement();
      i++;
    }
    return retour;
  }

  public AgenceImpl(String nomAgence, GererEmployes pGererEmployes, GererStocks pGererStocks, AccesProduits pAccesProduits) {
    _nomAgence = new String(nomAgence);
    _liste = new Hashtable();
    _iGererEmployes = pGererEmployes;
    _iGererStocks = pGererStocks;
    _iAccesProduits = pAccesProduits;
    _totalVentes = 0.0;
    _marge=0.01;
    _tva=0.196;

  }
  public void marge(double pMarge) {
    _marge = pMarge;
  }
  public Produit recupererInfoProduit(String codeBarre) throws agences.supermarche.AgenceException {
    //pour les besoins de la demo, on cree un stock pour la 1� vente
    try{
      _iGererStocks.rechercher(codeBarre);
    }
    catch(GererStocksException e) {
      //on cree un stock par defaut
      try{
        _iGererStocks.creer(codeBarre,10);
      }
      catch(GererStocksException ex) {
        System.out.println("Agence "+_nomAgence+ " : impossible de creer le stock (factice) du produit "+codeBarre+ " - "+ex);
      }
      catch(Exception ex) {
        System.out.println("Agence "+_nomAgence+ " : impossible de creer le stock (factice) du produit "+codeBarre+ " - "+ex);
      }
    }


    try {
      Produit p = _iAccesProduits.rechercher(codeBarre);
      return p;
    }
    catch(agences.supermarche.AccesProduitsException e) {
      System.out.println("Agence "+_nomAgence+ " : impossible de recuperer les informations du produit "+codeBarre+ " - "+e);
      throw new agences.supermarche.AgenceException("Agence "+_nomAgence+ " : impossible de recuperer les informations du produit "+codeBarre+ " - "+e);
    }
    catch(Exception e) {
      System.out.println("Agence "+_nomAgence+ " : impossible de recuperer les informations du produit "+codeBarre+ " - "+e);
      throw new agences.supermarche.AgenceException("Agence "+_nomAgence+ " : impossible de recuperer les informations du produit "+codeBarre+ " - "+e);
    }
  }
  public String nomObjet() {
    return _nomAgence;
  }
  public double marge() {
    return _marge;
  }
  public double tva() {
    return _tva;
  }
  public void tva(double pTva) {
    _tva = pTva;
  }
  //methodes pour la version 2
  public void inscrire(String nomCaisse, Caisse iCaisse) throws agences.supermarche.AgenceException {
    // on verifie que la caisse n'est pas deja connectee
    Caisse obj = (Caisse) _liste.get(nomCaisse);
    // si ce n'est pas le cas, on cree un AccesDonneesImpl
    if(obj == null) {
        //on inscrit
        _liste.put(nomCaisse,iCaisse);
        System.out.println(_nomAgence+" - Caisse "+nomCaisse+" inscrite");
    }
    else
        // on indique que la caisse est deja connectee
        throw new agences.supermarche.AgenceException(_nomAgence+" - Caisse "+nomCaisse+" deja connectee");
  }
  public void desinscrire(String nomCaisse) throws agences.supermarche.AgenceException {
    try{
      _liste.remove(nomCaisse);
      System.out.println(_nomAgence+" - Caisse "+nomCaisse+" desinscrite");
    }
    catch(Exception e) {
      // la caisse n'a pas ete trouvee
      throw new agences.supermarche.AgenceException(_nomAgence+" - Caisse "+nomCaisse+" non connectee");
    }
  }

}