package agences;

import agences.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import gererstocks.GererStocksImpl;
import gereremployes.GererEmployesImpl;
import gereremployes.supermarche.GererEmployes;
import gereremployes.supermarche.GererEmployesException;
import gereremployes.supermarche.GererEmployesHelper;


import gererstocks.supermarche.GererStocks;
import gererstocks.supermarche.GererStocksException;
import gererstocks.supermarche.GererStocksHelper;

import java.util.*;

/**
 * Titre :
 * Description :
 * Copyright :    Copyright (c) 2002
 * Soci�t� :
 * @author
 * @version 1.0
 */

public class ServeurAgence {

  public static void main(String[] args) {
    try {
      //verification des arguments
      //1� arg. = nom objet CORBA, 2� arg. = nom federation general
      //3� arg. = nom federation local, 4� arg. = nom designation
      //5� arg. = nom fichier IOR, 6� arg. = nom GererStocks
      //7� arg. = nom GererEmployes
      if(args.length!=7) {
        System.out.println("Appel incorrect. Syntaxe : ServeurAgence nomObj nomFedeGene nomFedeLocal nomDesi nomFichierIOR nomGererStocks GererEmployes");
        System.exit(0);
      }

      //intialisation de l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cup�re le rootPOA.
      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on cree l'arborescence federation plus designation dans le service de nommage
      Federation utilFede = new Federation();
      utilFede.creerEspaceNom(racineObj,args[1],args[2],args[3]);

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = utilFede.recupererRacine();

      //copie et mise � jour de toutes les federations existantes
      NamingContext fedeSiege = utilFede.recupererFederationSiege(orb,args[4]);
      utilFede.copierNamingContext(fedeSiege);

      //on r�cup�re ensuite la racine de l'arbre de designation
      NamingContext racineDesignation = utilFede.recupererContexteDesignation();

      //on va cr�er des politiques (policies)
      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };

      //cr�ation de son propre POA avec les politiques pr�c�dentes
      POA poa = rootPOA.create_POA("supermarchePOA",rootPOA.the_POAManager(),policies);

      org.omg.CORBA.Object distant=null;
/*
      //********************* recuperation de GererEmployes *******************
      nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent("GererEmployes","objet_metier");

      try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/"+"GererEmployes n'est pas accessible");
      }

      //casting de l'objet CORBA au type adequat
      GererEmployes iGererEmployes = agences.supermarche.GererEmployesHelper.narrow(distant);

      //********************** recuperation de GererStocks *****************
      nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent("GererStocks","objet_metier");

      try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/"+"GererStocks n'est pas accessible");
      }

      //casting de l'objet CORBA au type adequat
      GererStocks iGererStocks = agences.supermarche.GererStocksHelper.narrow(distant);
*/
      //********************** creation de GererEmployes *****************
      //on construit le nom � enregistrer dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(args[6],"objet_metier");

      //cr�ation du servant
      GererEmployesImpl monServantE = new GererEmployesImpl();

      //donner un Object ID au servant
      byte[] monIdE = args[6].getBytes();

      //activer le servant avec l'ID dans le POA
      poa.activate_object_with_id(monIdE, monServantE);

      //on enregistre l'objet dans l'annuaire
      racineDesignation.rebind(nom,poa.servant_to_reference(monServantE));

      //on recuperer une reference de GererStocks
      GererEmployes iGererEmployes = GererEmployesHelper.narrow(poa.servant_to_reference(monServantE));

      //trace ecran
      System.out.println(poa.servant_to_reference(monServantE) + " est pret.");

      //********************** creation de GererStocks *****************
      //on construit le nom � enregistrer dans l'annuaire
      nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(args[5],"objet_metier");

      //cr�ation du servant
      GererStocksImpl monServantGS = new GererStocksImpl();

      //donner un Object ID au servant
      byte[] monIdGS = args[5].getBytes();

      //activer le servant avec l'ID dans le POA
      poa.activate_object_with_id(monIdGS, monServantGS);

      //on enregistre l'objet dans l'annuaire
      racineDesignation.rebind(nom,poa.servant_to_reference(monServantGS));

      //on recuperer une reference de GererStocks
      //GererStocks iGererStocks = agences.supermarche.GererStocksHelper.narrow(poa.servant_to_reference(monServantGS));

      //trace ecran
      System.out.println(poa.servant_to_reference(monServantGS) + " est pret.");

      //on construit le nom � chercher dans l'annuaire
      nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[5],"objet_metier");

     try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/"+args[5]+" n'est pas accessible");
      }

      //casting de l'objet CORBA au type adequat
      GererStocks iGererStocks = GererStocksHelper.narrow(distant);

      //******************* recuperation de GererAccesProduits *****************
      nom = new org.omg.CosNaming.NameComponent[4];
      nom[0] = new org.omg.CosNaming.NameComponent(args[1],"federation");
      nom[1] = new org.omg.CosNaming.NameComponent("siege","federation");
      nom[2] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[3] = new org.omg.CosNaming.NameComponent("GererAccesProduits","objet_metier");

      try{
        // On recherche la r�f�rence
        distant = racineArbre.resolve(nom);
      }
      catch (Exception e) {
        System.out.println(args[3]+"/GererAccesProduits n'est pas accessible");
      }

      //casting de l'objet CORBA au type adequat
      GererAccesProduits iGererAccesProduits = GererAccesProduitsHelper.narrow(distant);

      //appel � la fabrique GererAccesProduits pour recuperer un interface de AccesProduits
      AccesProduits iAccesProduits = iGererAccesProduits.creer(args[0]);
      System.out.println("Connection fabrique "+iAccesProduits.nomObjet()+" OK");

      //******************* creation de AgenceImpl *****************
      //on construit le nom � enregistrer dans l'annuaire
      nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      //cr�ation du servant
      AgenceImpl monServant = new AgenceImpl(args[0],iGererEmployes,iGererStocks,iAccesProduits);

      //donner un Object ID au servant
      byte[] monId = args[0].getBytes();

      //activer le servant avec l'ID dans le POA
      poa.activate_object_with_id(monId, monServant);

      //activer le POA manager
      rootPOA.the_POAManager().activate();

      //on enregistre l'objet dans l'annuaire
      racineDesignation.rebind(nom,poa.servant_to_reference(monServant));

      //on affiche le contenu des contextes cr�es
      System.out.println("Contenu designation :");
      utilFede.parcourirDesignation();
      System.out.println("Contenu federation :");
      utilFede.parcourirFederation();
      System.out.println("Contenu racine :");
      utilFede.parcourirRacine();
      System.out.println("Contenu federation siege apres mise � jour :");
      utilFede.parcourirNamingContext(fedeSiege);

      //trace ecran
      System.out.println(poa.servant_to_reference(monServant) + " est pret.");

      //mse en attente de requete
      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  } //fin du main
}