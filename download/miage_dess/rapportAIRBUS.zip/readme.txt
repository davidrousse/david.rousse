*********************************************
************   Rapport de stage  ************
************    David ROUSSE     ************
************    Airbus France    ************
*********************************************

readme.txt : ce fichier

Tous les documents ci-dessous sont au format Microsoft Office 97.

rapportDR.doc : rapport de stage

slidesDR.pps : transparents

***********************************************
* Date de cr�ation : 25/03/2002		      *
* Derni�re mise � jour : 26/06/2002           *
***********************************************
* Stage David Rousse, DESS MIAGe 2001/2002    *
***********************************************
