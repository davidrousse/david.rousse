--TP BD Objet-Relationnel 
-- Marielle GISCLARD et David ROUSSE
-- insertions dans les tables
 
SET PAGESIZE 30;
SPOOL trace_insertQ9.sql;

DECLARE
	CURSOR parcours IS
	SELECT cau FROM auteurs;
BEGIN

-- insertion dans auteurs
INSERT INTO AUTEURS VALUES ('17S1','Moliere','Poquelin','Jean Batiste',
ENS_REF_OUVRAGES_TYPE(
	REF_OUVRAGES_TYPE(NULL,3),
	REF_OUVRAGES_TYPE(NULL,4),
	REF_OUVRAGES_TYPE(NULL,5),
	REF_OUVRAGES_TYPE(NULL,6)));
INSERT INTO AUTEURS VALUES ('17S2','Corneille','Corneille','Pierre',
ENS_REF_OUVRAGES_TYPE(
	REF_OUVRAGES_TYPE(NULL,1),
	REF_OUVRAGES_TYPE(NULL,2)));
INSERT INTO AUTEURS VALUES ('17S3','Voltaire','Arouet','Francois Marie',
ENS_REF_OUVRAGES_TYPE(REF_OUVRAGES_TYPE(NULL,7)));

-- insertion dans ouvrages
INSERT INTO OUVRAGES VALUES (1,'Horace',1640,'17S2',NULL,
	ENS_EXEMPLAIRES_TYPE(	EXEMPLAIRES_TYPE('E01'),
					EXEMPLAIRES_TYPE('E02')));

INSERT INTO OUVRAGES VALUES (2,'Androm�de',1650,'17S2',NULL,
ENS_EXEMPLAIRES_TYPE(	EXEMPLAIRES_TYPE('E03'),
				EXEMPLAIRES_TYPE('E04')));

INSERT INTO OUVRAGES VALUES (3,'Sganarelle',1661,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E05')));

INSERT INTO OUVRAGES VALUES (4,'Tartuffe',1664,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E06')));

INSERT INTO OUVRAGES VALUES (5,'L''avare',1668,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E07')));

INSERT INTO OUVRAGES VALUES (6,'Scapin',1672,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E08')));

INSERT INTO OUVRAGES VALUES (7,'Candide',1659,'17S3',NULL,
ENS_EXEMPLAIRES_TYPE(	EXEMPLAIRES_TYPE('E09'),
				EXEMPLAIRES_TYPE('E10'),
				EXEMPLAIRES_TYPE('E11')));

-- mise � jour synchronis�e des attributs r�f�rences de ouvrages
UPDATE ouvrages o
SET ref_cau = (	SELECT REF(a) 
			FROM AUTEURS a		
	WHERE a.cau = o.cau );

-- mise � jour synchronis�e des attributs r�f�rences de auteurs
FOR parcours_rec IN parcours LOOP
	UPDATE THE(	SELECT a.ref_ouvrages
			FROM auteurs a
			WHERE a.cau = parcours_rec.cau) e
 	SET e.ref_co = (	SELECT REF(o)
				FROM ouvrages o
				WHERE o.co = e.co);
END LOOP;

-- insertion dans abonnes
INSERT INTO ABONNES 
VALUES (1,'P','Alain','Terrieur',10,'Rue Dedans',31000,'Toulouse',	
	ENS_EMPRUNTS_TYPE(
		EMPRUNTS_TYPE('E02','01-NOV-2001'),		
		EMPRUNTS_TYPE('E04','01-NOV-2001'),		
		EMPRUNTS_TYPE('E05','02-NOV-2001'),			
		EMPRUNTS_TYPE('E06','03-NOV-2001')));


INSERT INTO ABONNES VALUES (2,'P','Alain','Verse',22,'Avenue de l''endroit',31400,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E01','01-NOV-2001')));

INSERT INTO ABONNES VALUES (3,'N','Marc','Assein',1,'place des Ardennes',31000,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E03','03-NOV-2001')));

INSERT INTO ABONNES VALUES (4,'N','Hillary','Varien',7,'Avenue des pas doues',31300,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E10','02-NOV-2001'),			
EMPRUNTS_TYPE('E11','01-NOV-2001')));

INSERT INTO ABONNES VALUES (5,'N','Melusine','Enfaillite',1,'Rue du depot',31000,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E09','04-NOV-2001')));


END;
/
SHOW ERRORS;

SPOOL OFF;




