-- TP BD Objet-Relationnel
-- Marielle GISCLARD et David ROUSSE

-- Q4 : implementations de la partie dynamique

-------------------------------------------------
-- methode dispo de exemplaires
-------------------------------------------------
CREATE OR REPLACE TYPE BODY exemplaires_type AS MEMBER FUNCTION dispo RETURN VARCHAR2 IS 

	retour VARCHAR2(20);
	nb INTEGER;
	cumul INTEGER;
	BEGIN

		cumul := 0;

		FOR aa IN (SELECT * FROM abonnes) LOOP
			SELECT COUNT(*) INTO nb
			FROM THE(SELECT a.emprunts FROM abonnes a WHERE a.cab = aa.cab ) e
			WHERE e.ne = self.ne;
			cumul := cumul + nb;
		END LOOP;

		IF (cumul>0) THEN
			retour := 'Non disponible';
		ELSE
			retour := 'Disponible';
		END IF;
	
		RETURN retour;		
				
	END dispo;

END;
/

SHOW ERRORS;

SELECT ex.ne, ex.co, ex.dispo() 
FROM exemplaires ex;