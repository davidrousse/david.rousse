--TP BD Objet-Relationnel 
-- Marielle GISCLARD et David ROUSSE
-- insertions dans les tables
 
SET PAGESIZE 30;
SPOOL trace_insertQ8.sql;
DELETE FROM ABONNES;
DELETE FROM OUVRAGES;
DELETE FROM AUTEURS;

BEGIN

-- insertion dans auteurs
INSERT INTO AUTEURS VALUES ('17S1','Moliere','Poquelin','Jean Batiste');
INSERT INTO AUTEURS VALUES ('17S2','Corneille','Corneille','Pierre');
INSERT INTO AUTEURS VALUES ('17S3','Voltaire','Arouet','Francois Marie');


-- insertion dans ouvrages
INSERT INTO OUVRAGES VALUES (1,'Horace',1640,'17S2',NULL,
	ENS_EXEMPLAIRES_TYPE(	EXEMPLAIRES_TYPE('E01'),
					EXEMPLAIRES_TYPE('E02')));

INSERT INTO OUVRAGES VALUES (2,'Androm�de',1650,'17S2',NULL,
ENS_EXEMPLAIRES_TYPE(	EXEMPLAIRES_TYPE('E03'),
				EXEMPLAIRES_TYPE('E04')));

INSERT INTO OUVRAGES VALUES (3,'Sganarelle',1661,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E05')));

INSERT INTO OUVRAGES VALUES (4,'Tartuffe',1664,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E06')));

INSERT INTO OUVRAGES VALUES (5,'L''avare',1668,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E07')));

INSERT INTO OUVRAGES VALUES (6,'Scapin',1672,'17S1',NULL,
ENS_EXEMPLAIRES_TYPE(EXEMPLAIRES_TYPE('E08')));

INSERT INTO OUVRAGES VALUES (7,'Candide',1659,'17S3',NULL,
ENS_EXEMPLAIRES_TYPE(	EXEMPLAIRES_TYPE('E09'),
				EXEMPLAIRES_TYPE('E10'),
				EXEMPLAIRES_TYPE('E11')));

-- mise � jour synchronis�e des attributs r�f�rences de ouvrages
UPDATE ouvrages o
SET ref_cau = (	SELECT REF(a) 
			FROM AUTEURS a		
	WHERE a.cau = o.cau );

-- insertion dans abonnes
INSERT INTO ABONNES 
VALUES (1,'P','Alain','Terrieur',10,'Rue Dedans',31000,'Toulouse',	
	ENS_EMPRUNTS_TYPE(
		EMPRUNTS_TYPE('E02','01-NOV-2001'),		
		EMPRUNTS_TYPE('E04','01-NOV-2001'),		
		EMPRUNTS_TYPE('E05','02-NOV-2001'),			
		EMPRUNTS_TYPE('E06','03-NOV-2001')));


INSERT INTO ABONNES VALUES (2,'P','Alain','Verse',22,'Avenue de l''endroit',31400,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E01','01-NOV-2001')));

INSERT INTO ABONNES VALUES (3,'N','Marc','Assein',1,'place des Ardennes',31000,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E03','03-NOV-2001')));

INSERT INTO ABONNES VALUES (4,'N','Hillary','Varien',7,'Avenue des pas doues',31300,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E10','02-NOV-2001'),			
EMPRUNTS_TYPE('E11','01-NOV-2001')));

INSERT INTO ABONNES VALUES (5,'N','Melusine','Enfaillite',1,'Rue du depot',31000,'Toulouse',			
ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE('E09','04-NOV-2001')));


END;
/
SHOW ERRORS

-- verification du resultat
SELECT * FROM AUTEURS;
SELECT * FROM OUVRAGES;
SELECT aa.cab, e.ne, e.ref_ne
FROM abonnes a, THE(	SELECT aa.emprunts
		  		FROM abonnes aa
 				WHERE aa.cab = a.cab) e;

SPOOL OFF;




