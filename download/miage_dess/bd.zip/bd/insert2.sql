-- TP BD Objet-Relationnel
-- Marielle GISCLARD et David ROUSSE

-- Q4 : insertions dans les tables


SET PAGESIZE 30;
SPOOL trace_insert.sql;

DELETE FROM ABONNES;
DELETE FROM EXEMPLAIRES;
DELETE FROM OUVRAGES;
DELETE FROM AUTEURS;

DECLARE 

	CURSOR parcours IS
	SELECT cab FROM abonnes;

BEGIN

-- insertion dans auteurs
INSERT INTO AUTEURS VALUES ('17S1','Moliere','Poquelin','Jean Batiste');
INSERT INTO AUTEURS VALUES ('17S2','Corneille','Corneille','Pierre');
INSERT INTO AUTEURS VALUES ('17S3','Voltaire','Arouet','Francois Marie');

-- insertion dans ouvrages
INSERT INTO OUVRAGES VALUES (1,'Horace',1640,'17S2',NULL);
INSERT INTO OUVRAGES VALUES (2,'Androm�de',1650,'17S2',NULL);
INSERT INTO OUVRAGES VALUES (3,'Sganarelle',1661,'17S1',NULL);
INSERT INTO OUVRAGES VALUES (4,'Tartuffe',1664,'17S1',NULL);
INSERT INTO OUVRAGES VALUES (5,'L''avare',1668,'17S1',NULL);
INSERT INTO OUVRAGES VALUES (6,'Scapin',1672,'17S1',NULL);
INSERT INTO OUVRAGES VALUES (7,'Candide',1659,'17S3',NULL);

-- mise � jour synchronis�e des attributes r�f�rences de ouvrages
UPDATE ouvrages o
SET ref_cau = (	SELECT REF(a) 
			FROM AUTEURS a
			WHERE a.cau = o.cau );

-- insertion dans exemplaires
INSERT INTO EXEMPLAIRES VALUES ('E01',1,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E02',1,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E03',2,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E04',2,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E05',3,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E06',4,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E07',5,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E08',6,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E09',7,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E10',7,NULL);
INSERT INTO EXEMPLAIRES VALUES ('E11',7,NULL);

-- mise � jour des attributes r�f�rences de exemplaires
UPDATE exemplaires e
SET ref_co = (	SELECT REF(o) 
			FROM OUVRAGES o
			WHERE e.co = o.co );


-- insertion dans abonnes
INSERT INTO ABONNES VALUES (1,'P','Alain','Terrieur',10,'Rue Dedans',31000,'Toulouse',
					ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE(NULL,'E02','01-NOV-2001'),
								EMPRUNTS_TYPE(NULL,'E04','01-NOV-2001'),
								EMPRUNTS_TYPE(NULL,'E05','02-NOV-2001'),
								EMPRUNTS_TYPE(NULL,'E06','03-NOV-2001')));

INSERT INTO ABONNES VALUES (2,'P','Alain','Verse',22,'Avenue de l''endroit',31400,'Toulouse',
					ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE(NULL,'E01','01-NOV-2001')));

INSERT INTO ABONNES VALUES (3,'N','Marc','Assein',1,'place des Ardennes',31000,'Toulouse',
					ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE(NULL,'E03','03-NOV-2001')));

INSERT INTO ABONNES VALUES (4,'N','Hillary','Varien',7,'Avenue des pas doues',31300,'Toulouse',
					ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE(NULL,'E10','02-NOV-2001'),
								EMPRUNTS_TYPE(NULL,'E11','01-NOV-2001')));

INSERT INTO ABONNES VALUES (5,'N','Melusine','Enfaillite',1,'Rue du depot',31000,'Toulouse',
					ENS_EMPRUNTS_TYPE(EMPRUNTS_TYPE(NULL,'E09','04-NOV-2001')));


-- mise � jour des attributes r�f�rences de abonnes
FOR parcours_rec IN parcours LOOP
	UPDATE THE(	SELECT a.emprunts
			FROM abonnes a
			WHERE a.cab = parcours_rec.cab) emp
	SET emp.ref_ne = (SELECT REF(ex) 
				FROM exemplaires ex
				WHERE ex.ne = emp.ne );
END LOOP;


END;
/

SHOW ERRORS

-- verification du resultat
SELECT * FROM ABONNES;
SELECT * FROM AUTEURS;
SELECT * FROM OUVRAGES;
SELECT * FROM EXEMPLAIRES;

SPOOL OFF;

-- Q4 bis : reconstitution des tables relationnelles

SET PAGESIZE 30;
SPOOL trace_tables.sql;

PROMPT '--- Auteurs ---';
SELECT * FROM auteurs;

PROMPT '--- Ouvrages ---';
SELECT co, titre, an, cau FROM ouvrages;

PROMPT '--- Exemplaires ---';
SELECT ne, co FROM exemplaires;

PROMPT '--- Abonnes ---';
SELECT cab, type, nom_ab, num, lib, cp, ville
FROM abonnes;

PROMPT '--- Emprunts ---';
SELECT aa.cab, e.ne, e.de, e.dr
FROM abonnes aa, THE(	SELECT a.emprunts
		  	FROM abonnes a
			WHERE a.cab = aa.cab) e;

SPOOL OFF;




