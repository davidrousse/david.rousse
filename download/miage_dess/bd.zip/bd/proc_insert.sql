-- TP BD Objet-Relationnel
-- Marielle GISCLARD et David ROUSSE

-- Q5 : programme d'enregistrement d'un emprunt

SET PAGESIZE 30;
PROMPT 'Fichier sortie :'
ACCEPT ficsortie
SPOOL &ficsortie.log;

-- cr�ation de la table COMPTE_RENDU (sans contraintes)
DROP TABLE COMPTE_RENDU;
CREATE TABLE COMPTE_RENDU
(
	LIGNE_COMPTE_RENDU VARCHAR(80)
);

PROMPT 'Entrez le nom de l''abonn�:'
ACCEPT NomAbonne

PROMPT 'Entrez le pr�nom de l''abonn�:'
ACCEPT PrenomAbonne

PROMPT 'Entrez le code de l''ouvrage � emprunter:'
ACCEPT CodeOuvrage

-- d�but du bloc PL/SQL
DECLARE	

	message COMPTE_RENDU.LIGNE_COMPTE_RENDU%TYPE;
	code_abonne ABONNES.CAB%TYPE;
	code_ouvrage OUVRAGES.CO%TYPE;
	numero_exemplaire EXEMPLAIRES.NE%TYPE;
	etape_verif INTEGER;
	nombre_emprunt INTEGER;
	trouve BOOLEAN;
	disponibilite VARCHAR2(20);
	NO_EXEMPLAIRE_AVAILABLE EXCEPTION;
	NO_DATA_FOUND EXCEPTION;
	PRAGMA EXCEPTION_INIT(NO_DATA_FOUND,+100);

BEGIN	
	-- on tente de recuperer le code de l''abonn�
	etape_verif := 1;
	SELECT cab INTO code_abonne FROM abonnes WHERE nom_ab = '&NomAbonne' AND prenom_ab = '&PrenomAbonne';

	-- on tente de recuperer le code de l''ouvrage
	etape_verif := 2;
	SELECT co INTO code_ouvrage FROM ouvrages WHERE co = '&CodeOuvrage';
	
	-- on teste la disponibilit� de l''ouvrage
	trouve := true;
	FOR ex IN (SELECT * FROM exemplaires WHERE co = '&CodeOuvrage') LOOP 
		IF trouve THEN
			select e.dispo() into disponibilite from exemplaires e where e.ne = ex.ne;
			IF disponibilite = 'Disponible' THEN
				trouve := true;
				numero_exemplaire := ex.ne;
			END IF;
		END IF;
	END LOOP;
	IF trouve = false THEN
		RAISE NO_EXEMPLAIRE_AVAILABLE;
	END IF ;

	-- on verifie le nombre d''emprunts pour l''abonne
	FOR a IN (SELECT * FROM abonnes WHERE cab = code_abonne) LOOP
		SELECT COUNT(*) INTO nombre_emprunt
		FROM THE(SELECT aa.emprunts FROM abonnes aa WHERE a.cab = aa.cab);
	END LOOP;

	-- si l'abonne a 4 emprunts, il ne peut plus emprunter
	IF (nombre_emprunt<4) THEN
		INSERT INTO THE(SELECT a.emprunts FROM abonnes a WHERE a.cab = code_abonne) VALUES(NULL,numero_exemplaire,SYSDATE);

		UPDATE THE(SELECT a.emprunts FROM abonnes a WHERE a.cab = code_abonne) emp
		SET emp.ref_ne = (SELECT REF(ex) FROM exemplaires ex where ex.ne = numero_exemplaire);

		MESSAGE := 'Emprunt de l''exemplaire '||numero_exemplaire||' de l''ouvrage &CodeOuvrage enregistr� pour l''abonn� &NomAbonne &PrenomAbonne';
		INSERT INTO COMPTE_RENDU VALUES (MESSAGE);		
	ELSE
		MESSAGE := 'Emprunt impossible. L''abonne &NomAbonne &PrenomAbonne a deja emprunt� 4 exemplaires';
		INSERT INTO COMPTE_RENDU VALUES (MESSAGE);
	END IF;
	
	MESSAGE := 'Transaction terminee';
	INSERT INTO COMPTE_RENDU VALUES (MESSAGE);
	
	COMMIT;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		ROLLBACK;
		IF etape_verif = 1 THEN
			INSERT INTO COMPTE_RENDU VALUES ('Abonn� inconnu.');
		ELSIF etape_verif = 2 THEN
			INSERT INTO COMPTE_RENDU VALUES ('Ouvrage inconnu.');
		END IF;
	WHEN NO_EXEMPLAIRE_AVAILABLE THEN
		ROLLBACK;
		INSERT INTO COMPTE_RENDU VALUES ('Ouvrage indisponible.');
	WHEN OTHERS THEN
		ROLLBACK;
		MESSAGE:=SUBSTR(SQLERRM,1,80);
		INSERT INTO COMPTE_RENDU VALUES (MESSAGE);		
END;
/

-- fin du bloc PL/SQL
SHOW ERRORS;

SELECT * FROM COMPTE_RENDU;
