-- TP BD Objet-Relationnel
-- Marielle GISCLARD et David ROUSSE

-- Q4 : implementations de la partie dynamique

SET PAGESIZE 30;
SPOOL trace_dyna.log;

-------------------------------------------------
-- methode dr de emprunts
-------------------------------------------------
CREATE OR REPLACE TYPE BODY emprunts_type AS MEMBER FUNCTION dr RETURN DATE IS 

	retour DATE;

	BEGIN

		FOR a IN (SELECT * FROM abonnes) LOOP

			FOR e IN (SELECT * FROM THE(SELECT aa.emprunts FROM abonnes aa WHERE a.cab = aa.cab)) LOOP
				
				IF (e.ne = self.ne) THEN 
					IF (a.type = 'N') THEN
						retour := e.de + 15;
					ELSE
						retour := e.de + 20;
					END IF;
		
					RETURN retour;		
				END IF;

			END LOOP;

		END LOOP;

		-- par defaut, on retourne la date systeme
		RETURN SYSDATE;		
				
	END dr;

END;
/

SHOW ERRORS;

SELECT a.cab, a.type, e.ne, e.de, e.dr() 
FROM abonnes a, THE(	SELECT a.emprunts
				FROM abonnes aa
				WHERE a.cab = aa.cab) e;
/

