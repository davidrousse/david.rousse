-- TP BD Objet-Relationnel
-- Marielle GISCLARD et David ROUSSE

-- Q9 : specifications des types et des tables
spool trace_specQ9.log;

DROP TABLE abonnes;
DROP TYPE abonnes_type;
DROP TYPE ens_emprunts_type;
DROP TYPE emprunts_type;
DROP TABLE ouvrages;
DROP TYPE ouvrages_type;
DROP TYPE ens_exemplaires_type;
DROP TYPE exemplaires_type;
DROP TABLE exemplaires;
DROP TABLE auteurs;
DROP TYPE ens_ref_ouvrages_type;
DROP TYPE ref_ouvrages_type;
DROP TYPE auteurs_type;

-------------------------------------------------
-- auteurs
-------------------------------------------------

CREATE OR REPLACE TYPE ouvrages_type;
/
show errors;
CREATE OR REPLACE TYPE ref_ouvrages_type AS OBJECT (
	ref_co REF ouvrages_type,
	co NUMBER(2)
);
/
show errors;

CREATE OR REPLACE TYPE ens_ref_ouvrages_type AS TABLE OF ref_ouvrages_type;
/
show errors;

CREATE OR REPLACE TYPE auteurs_type AS OBJECT (
	cau VARCHAR2(4),
	nom_u VARCHAR2(30),
	nom_au VARCHAR2(30),
	prenom_au VARCHAR2(30),
	ref_ouvrages ens_ref_ouvrages_type 
);
/
show errors;

CREATE TABLE auteurs OF auteurs_type (
	CONSTRAINT pk_auteurs PRIMARY KEY(cau))
	NESTED TABLE ref_ouvrages STORE AS tab_ref_ouvrages;
	
/

-------------------------------------------------
-- ouvrages et exemplaires
-------------------------------------------------

-- exemplaires_type
CREATE OR REPLACE TYPE exemplaires_type AS OBJECT (
	ne VARCHAR(5),
	MEMBER FUNCTION dispo RETURN BOOLEAN,
	PRAGMA RESTRICT_REFERENCES(dispo,WNDS,WNPS)
)
/
-- ens_exemplaires_type
CREATE OR REPLACE TYPE ens_exemplaires_type AS TABLE OF exemplaires_type;
/
-- ouvrages_type
CREATE OR REPLACE TYPE ouvrages_type AS OBJECT (
	co NUMBER(2),
	titre VARCHAR2(30),
	an NUMBER(4),
	cau VARCHAR2(4),
	ref_cau REF auteurs_type,
	exemplaires ens_exemplaires_type
)
/
-- table ouvrages
CREATE TABLE ouvrages OF ouvrages_type (
	CONSTRAINT pk_ouvrages PRIMARY KEY(co))
	NESTED TABLE exemplaires STORE AS tab_exemplaires;
/


-------------------------------------------------
-- emprunts et abonnes
-------------------------------------------------
-- emprunts_type
CREATE OR REPLACE TYPE emprunts_type AS OBJECT (
	ref_ne REF exemplaires_type,
	ne VARCHAR(5),
	de DATE,
	MEMBER FUNCTION dr RETURN DATE,
	PRAGMA RESTRICT_REFERENCES(dr,WNDS,WNPS)
)
/
-- ens_emprunts_type
CREATE OR REPLACE TYPE ens_emprunts_type AS VARRAY(4) OF emprunts_type;
/
-- abonnes_type
CREATE OR REPLACE TYPE abonnes_type AS OBJECT (
	cab NUMBER(2),
	type VARCHAR2(1),
	prenom_ab VARCHAR2(30),
	nom_ab VARCHAR2(30),
	num NUMBER(3),
	lib VARCHAR2(30),
	cp NUMBER(5),
	ville VARCHAR2(30),
	emprunts ens_emprunts_type
)
/
-- table abonnes
CREATE TABLE abonnes OF abonnes_type (
	CONSTRAINT pk_abonnes PRIMARY KEY(cab))





select type_name from user_types;
desc auteurs;
desc ouvrages;
desc tab_exemplaires;
desc abonnes;
desc tab_emprunts;

select * from auteurs;
select * from ouvrages;
select * from abonnes;

spool off
