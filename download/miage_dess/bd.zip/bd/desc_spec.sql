spool desc_trace_spec.log

select type_name from user_types;
desc auteurs;
desc ouvrages;
desc exemplaires;
desc abonnes;
desc tab_emprunts;

select * from auteurs;
select * from ouvrages;
select * from exemplaires;
select * from abonnes;

spool off