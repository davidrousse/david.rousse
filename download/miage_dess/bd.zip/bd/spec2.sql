-- TP BD Objet-Relationnel
-- Marielle GISCLARD et David ROUSSE

-- Q3 : specifications des types et des tables

DROP TABLE abonnes;
DROP TYPE abonnes_type;
DROP TYPE ens_emprunts_type;
DROP TYPE emprunts_type;
DROP TABLE exemplaires;
DROP TYPE exemplaires_type;
DROP TABLE ouvrages;
DROP TYPE ouvrages_type;
DROP TABLE auteurs;
DROP TYPE auteurs_type;
/

-------------------------------------------------
-- auteurs
-------------------------------------------------
CREATE OR REPLACE TYPE auteurs_type AS OBJECT (
	cau VARCHAR2(4),
	nom_u VARCHAR2(30),
	nom_au VARCHAR2(30),
	prenom_au VARCHAR2(30)
);
/
CREATE TABLE auteurs OF auteurs_type (
	CONSTRAINT pk_auteurs PRIMARY KEY(cau));

/

-------------------------------------------------
-- ouvrages
-------------------------------------------------
CREATE OR REPLACE TYPE ouvrages_type AS OBJECT (
	co NUMBER(2),
	titre VARCHAR2(30),
	an NUMBER(4),
	cau VARCHAR2(4),
	ref_cau REF auteurs_type
)
/
CREATE TABLE ouvrages OF ouvrages_type (
	CONSTRAINT pk_ouvrages PRIMARY KEY(co))
/

-------------------------------------------------
-- exemplaires
-------------------------------------------------
CREATE OR REPLACE TYPE exemplaires_type AS OBJECT (
	ne VARCHAR(5),
	co NUMBER(2),
	ref_co REF ouvrages_type,
	MEMBER FUNCTION dispo RETURN VARCHAR2,
	PRAGMA RESTRICT_REFERENCES(dispo,WNDS,WNPS)
)
/
CREATE TABLE exemplaires OF exemplaires_type (
	CONSTRAINT pk_exemplaires PRIMARY KEY(ne))
/

-------------------------------------------------
-- emprunts et abonnes
-------------------------------------------------
-- emprunts_type
CREATE OR REPLACE TYPE emprunts_type AS OBJECT (
	ref_ne REF exemplaires_type,
	ne VARCHAR(5),
	de DATE,
	-- methode relative a la question Q5, donne la date de retour prevue
	MEMBER FUNCTION dr RETURN DATE,
	PRAGMA RESTRICT_REFERENCES(dr,WNDS,WNPS)
)
/
-- ens_emprunts_type
CREATE OR REPLACE TYPE ens_emprunts_type AS TABLE OF emprunts_type;
/
-- abonnes_type
CREATE OR REPLACE TYPE abonnes_type AS OBJECT (
	cab NUMBER(2),
	type VARCHAR2(1),
	prenom_ab VARCHAR2(30),
	nom_ab VARCHAR2(30),
	num NUMBER(3),
	lib VARCHAR2(30),
	cp NUMBER(5),
	ville VARCHAR2(30),
	emprunts ens_emprunts_type
)
/
-- table abonnes
CREATE TABLE abonnes OF abonnes_type (
	CONSTRAINT pk_abonnes PRIMARY KEY(cab))
	NESTED TABLE emprunts STORE AS tab_emprunts;
/

SHOW ERRORS;