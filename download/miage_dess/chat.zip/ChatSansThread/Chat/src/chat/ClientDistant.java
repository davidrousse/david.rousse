package chat;

/**
 * Title:        Chat en RMI version 1 sans threads
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public interface ClientDistant extends java.rmi.Remote {
    public void msg(Message m) throws java.rmi.RemoteException;
}