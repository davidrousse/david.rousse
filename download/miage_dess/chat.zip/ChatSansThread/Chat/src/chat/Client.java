package chat;

/**
 * Title:        Chat en RMI version 1 sans threads
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.awt.*;
import java.awt.event.*;

public class Client extends Frame implements ActionListener {

  private TextField saisie;
  private TextArea affichage;
  private Button boutonEnvoi;
  private Button boutonStop;
  private Panel boutonPanel;
  private ServeurChat serveurDistant;
  private String nom;

  public Client(String nomClient, String nomServeur) {

    super("Chat en RMI (version 1)");
    try {
      //construction IHM
      saisie = new TextField();
      affichage = new TextArea();
      affichage.setEditable(false);
      this.setLayout(new BorderLayout());
      this.add("North",affichage);
      this.add("Center",saisie);
      saisie.addActionListener(this);
      boutonPanel = new Panel();
      boutonEnvoi = new Button("Envoyer");
      boutonStop = new Button("Quitter");
      boutonPanel.add(boutonEnvoi);
      boutonEnvoi.addActionListener(this);
      boutonPanel.add(boutonStop);
      boutonStop.addActionListener(this);
      this.add("South",boutonPanel);
      this.pack();
      this.show();

      //initialisation des attributs
      nom = nomClient;

      //cr�ation d'un objet d'implantation pour l'interface ClientDistant
      new ClientDistantImpl(nom, affichage);
      affichage.append("\nLe client "+nom+" est pret ...");

      //recuperation de la reference du proxy
      serveurDistant = (ServeurChat) Naming.lookup(nomServeur);
      //connexion au serveur
      serveurDistant.connect(nom);
      affichage.append("\nTapez vos phrases en terminant par FIN :");
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }

  public void actionPerformed(ActionEvent e) {
    try {

      //Appuie sur le bouton Envoi ou sur la touche Entr�e
      if((e.getSource() == boutonEnvoi) || (e.getSource() == saisie)) {

        //recuperation du texte saisie
        String ligne = saisie.getText();

        if(!ligne.equals("FIN")){
          serveurDistant.msg(new Message(nom+" : "+ligne));
        }
        else {
          serveurDistant.disconnect(nom);
          serveurDistant = null;
          affichage.append("\nLe client "+nom+" s'est d�-connecte ...");
        }
        saisie.setText("");
      }

      //Appui sur le bouton Stop
      if(e.getSource() == boutonStop) {
        serveurDistant.disconnect(nom);
        System.exit(0);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      //v�rification des arguments
      if(args[0].equals("") || args[1].equals("")) {
        System.out.println("Appel incorrect.");
        System.out.println("Syntaxe : Client nomClient nomServeur");
        System.exit(0);
      }

      new Client(args[0],args[1]);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

}