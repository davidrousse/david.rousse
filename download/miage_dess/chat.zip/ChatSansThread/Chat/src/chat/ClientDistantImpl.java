package chat;

/**
 * Title:        Chat en RMI version 1 sans threads
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.awt.TextArea;

public class ClientDistantImpl extends UnicastRemoteObject implements ClientDistant {

  private TextArea sortie;

  public ClientDistantImpl(String nomClient, TextArea canalSortie) throws java.rmi.RemoteException  {
    super();
    try
    {
      //enregistrement de la RMI Registry
      System.setSecurityManager(new RMISecurityManager());
      Naming.rebind(nomClient, this);
      sortie = canalSortie;
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void msg(Message m) throws java.rmi.RemoteException {
    try
    {
      sortie.append("\n"+m.toString());
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }


}