package chat;

/**
 * Title:
 *    Chat en RMI version 1 sans threads
 * Description:* Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L 1& D
 * @version 1.0
 */

public interface ServeurChat extends ClientDistant {

    public void connect(String url) throws java.rmi.RemoteException;
    public void disconnect(String url) throws java.rmi.RemoteException;
}
