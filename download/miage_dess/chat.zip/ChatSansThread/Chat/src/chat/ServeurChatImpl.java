package chat;

/**
 * Title:        Chat en RMI version 1 sans threads
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.io.*;

public class ServeurChatImpl extends UnicastRemoteObject implements ServeurChat {

  private Hashtable lesClients;

  public ServeurChatImpl() throws RemoteException {
    super();
    lesClients = new Hashtable();
  }

  public void connect(String url) throws RemoteException {
    try
    {
      if(!lesClients.containsKey(url))
      {
        ClientDistant client = (ClientDistant)Naming.lookup(url);
        lesClients.put(url,client);
        System.out.println("Le client "+url+" s'est connecte.");
      }
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }

  public void disconnect(String url) throws RemoteException {
    try
    {
      if(lesClients.containsKey(url)) {
        lesClients.remove(url);
        System.out.println("Le client "+url+" s'est deconnecte.");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void msg(Message m) throws RemoteException {
    try {

        Enumeration parcours = lesClients.elements();

        while(parcours.hasMoreElements()){
          ((ClientDistant)parcours.nextElement()).msg(m);
        }

      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
  }

  public static void main(String[] args) {

    try {
      System.setSecurityManager(new RMISecurityManager());
      ServeurChatImpl obj = new ServeurChatImpl();
      Naming.rebind(args[0], obj);
      System.out.println("Le serveur "+args[0]+" est pret ...");
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}