*********************************************
************       Contenu       ************
************   David ROUSSE et   ************
************   Laetitia SOULE    ************
*********************************************

Chat en RMI :

-- > Voir ChatRMI.ppt pour plus de d�tails 
ainsi que les fichiers readme.txt dans chaque r�pertoire 
.\src de chaque version.

***********************************************
* Date de cr�ation : 23/11/2001		      *
* Derni�re mise � jour : 29/11/2001           *
***********************************************
*        DESS MIAGe 2001/2002		      *
***********************************************
