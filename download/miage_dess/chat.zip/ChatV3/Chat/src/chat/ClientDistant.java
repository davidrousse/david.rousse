package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public interface ClientDistant extends java.rmi.Remote {
    public void connect(String url) throws java.rmi.RemoteException;
    public void disconnect(String url) throws java.rmi.RemoteException;
    public void msg(Message m) throws java.rmi.RemoteException;
}