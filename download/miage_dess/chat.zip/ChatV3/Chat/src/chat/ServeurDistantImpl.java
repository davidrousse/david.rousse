package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.io.*;

public class ServeurDistantImpl extends UnicastRemoteObject implements ServeurDistant {

  private Vector lesClients;

  public ServeurDistantImpl() throws RemoteException {

    super();
    lesClients = new Vector();
  }

  public String register(String url) throws java.rmi.RemoteException {
    try
    {
      String retour = null;

      //on verifie que le client n'est pas deja connect�
      if(!lesClients.contains(url))
      {
        String pere = new String("");

        //si il y a au moins un client deja present, il devient pere de this
        if(!lesClients.isEmpty()){
          pere = (String) lesClients.lastElement();
          ClientDistant proxyPere = (ClientDistant) Naming.lookup(pere);
          //on previent le pere qu'il a un fils
          proxyPere.connect(url);
        }
        //on ajoute le fils dans la liste du serveur
        lesClients.addElement(url);
        //on renvoie au fils le nom de son pere
        retour = new String(pere);
        System.out.println("Le client "+url+" s'est enregistre ...");
      }
      return retour;
    }
    catch(Exception e)
    {
      e.printStackTrace();
      return null;
    }
  }

  public void unRegister(String url) throws java.rmi.RemoteException {
    try
    {
        int index = lesClients.indexOf(url);

        //un client situ� en milieu de liste
        if(index != 0 && index != (lesClients.size()-1))
        {
          String urlPere = (String) lesClients.get(index-1);
          String urlFils = (String) lesClients.get(index+1);

          ClientDistant proxyPere = (ClientDistant) Naming.lookup(urlPere);
          proxyPere.disconnect(url);
          proxyPere.connect(urlFils);

          ClientDistant proxyFils = (ClientDistant) Naming.lookup(urlFils);
          proxyFils.disconnect(url);
          proxyFils.connect(urlPere);

          lesClients.remove(url);
        }
        //le dernier client se deconnecte
        else if(index == 0 && index == (lesClients.size()-1)){
           lesClients.remove(url);
        }
        //le premier client se deconnecte mais il en reste d'autres
        else if(index == 0){
           String urlFils = (String) lesClients.get(index+1);
           ClientDistant proxyFils = (ClientDistant) Naming.lookup(urlFils);
           proxyFils.disconnect(url);
           lesClients.remove(url);
        }
        //le dernier client se deconnecte
        else if(index == (lesClients.size()-1))
        {
            String urlPere = (String) lesClients.get(index-1);
            ClientDistant proxyPere = (ClientDistant) Naming.lookup(urlPere);
            proxyPere.disconnect(url);
            lesClients.remove(url);
        }
        System.out.println("Le client "+url+" s'est des-enregistre ...");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      System.setSecurityManager(new RMISecurityManager());
      ServeurDistantImpl obj = new ServeurDistantImpl();
      Naming.rebind(args[0], obj);
      System.out.println("Le serveur "+args[0]+" est pret ...");
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}