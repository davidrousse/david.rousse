package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.awt.TextArea;

public class ClientDistantImpl extends UnicastRemoteObject implements ClientDistant {

  private Hashtable lesClients;
  private ServeurDistant serveurDistant;
  private ClientDistant client;
  private int numeroDernierMessageRecu = -1;
  private TextArea affichage;

  public ClientDistantImpl(String nomClient, ServeurDistant proxyServeur, TextArea affich) throws java.rmi.RemoteException  {
    super();
    try
    {
      System.setSecurityManager(new RMISecurityManager());
      Naming.rebind(nomClient, this);
      affichage = affich;
      serveurDistant = proxyServeur;
      lesClients = new Hashtable();
      String pere = serveurDistant.register(nomClient);

      if (!pere.equals(""))
      {
        client = (ClientDistant)Naming.lookup(pere);
        lesClients.put(pere,client);
      }

    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void connect(String url) throws RemoteException {
    try
    {
      if(!lesClients.containsKey(url))
      {
        ClientDistant client = (ClientDistant)Naming.lookup(url);
        lesClients.put(url,client);
        affichage.append("\nLe client "+url+" est connecte ...");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void disconnect(String url) throws RemoteException {
    try
    {
      if(lesClients.containsKey(url)) {
        lesClients.remove(url);
        affichage.append("\nLe client "+url+" est deconnecte ...");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void msg(Message m) throws RemoteException {
    try {

        Enumeration parcours = lesClients.elements();
        ClientDistant client;
        int numeroMsg = m.getNumeroMessage();
        String emetteur = m.getEmetteur();

        if(numeroMsg!=numeroDernierMessageRecu) {

          affichage.append("\n"+emetteur.toString()+">"+m.toString());
          numeroDernierMessageRecu = numeroMsg;

          while(parcours.hasMoreElements())
          {
            client = (ClientDistant)parcours.nextElement();
            client.msg(m);
          }
        }
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
  }
}