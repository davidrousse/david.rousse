package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.net.InetAddress;
import java.awt.*;
import java.awt.event.*;

public class Client extends Frame implements ActionListener {

  private TextField saisie;
  private TextArea affichage;
  private Button boutonEnvoi;
  private Button boutonStop;
  private Panel boutonPanel;
  private String nom;
  private ClientDistant client;
  private ServeurDistant serveur;

  public Client(String nomClient, String nomServeur) {
    super("Chat en RMI (version 3)");
    try {
      //construction IHM
      saisie = new TextField();
      affichage = new TextArea();
      affichage.setEditable(false);
      this.setLayout(new BorderLayout());
      this.add("North",affichage);
      this.add("Center",saisie);
      saisie.addActionListener(this);
      boutonPanel = new Panel();
      boutonEnvoi = new Button("Envoyer");
      boutonStop = new Button("Quitter");
      boutonPanel.add(boutonEnvoi);
      boutonEnvoi.addActionListener(this);
      boutonPanel.add(boutonStop);
      boutonStop.addActionListener(this);
      this.add("South",boutonPanel);
      this.pack();
      this.show();

      serveur = (ServeurDistant)Naming.lookup(nomServeur);

      new ClientDistantImpl(nomClient, serveur, affichage);
      affichage.append("\nLe client "+nomClient+" est connecte � "+nomServeur+" ...");

      nom = new String(nomClient);
      client = (ClientDistant)Naming.lookup(nomClient);
      //serveur = (ServeurDistant)Naming.lookup(nomServeur);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void actionPerformed(ActionEvent e) {
    try {
      if((e.getSource() == boutonEnvoi) || (e.getSource() == saisie)) {
        String ligne = saisie.getText();
        if(!ligne.equals("FIN")){
          client.msg(new Message(ligne, nom));
        }
        else {
          serveur.unRegister(nom);
          affichage.append("\nLe client "+nom+" s'est d�connecte ...");
          System.exit(0);
        }
        saisie.setText("");
      }

      if(e.getSource() == boutonStop) {
        serveur.unRegister(nom);
        System.exit(0);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      new Client(args[0],args[1]);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

}