package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class Message implements java.io.Serializable {

  private String m;
  private String e;

  public Message(String pm, String pe) {
    m = new String(pm);
    e = new String(pe);
  }

  public int getNumeroMessage() {
    return m.hashCode();
  }

  public String getEmetteur() {
    return e.toString();
  }

  public String toString() {
    return m.toString();
  }
}