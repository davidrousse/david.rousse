*********************************************
************       Contenu       ************
************   David et Laetitia ************
*********************************************

Chat en RMI version 1 :
 - version client/Serveur
 - gestion d'un thread chez le client
 - saisie des parametres applicatifs 
 dans une boite de dialogue


***********************************************
* Date de cr�ation : 23/11/2001		      *
* Derni�re mise � jour : 23/11/2001           *
***********************************************
*        DESS MIAGe 2001/2002		      *
***********************************************
