package chat;

/**
 * Title:        Chat en RMI version 1
 * Description:  Chat en RMI version client/serveur
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia & David
 * @version 1.0
 */

public interface ClientDistant extends java.rmi.Remote {
    public void msg(Message m) throws java.rmi.RemoteException;
}