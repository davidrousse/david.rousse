package chat;

/**
 * Title:        Chat en RMI version 1
 * Description:  Chat en RMI version client/serveur
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia & David
 * @version 1.0
 */

public class Message implements java.io.Serializable {

  private String m;

  public Message(String pm) {
    m = new String(pm);
  }

  public String toString() {
    return m;
  }
}