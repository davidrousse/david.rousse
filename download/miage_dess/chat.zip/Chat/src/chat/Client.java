package chat;

/**
 * Title:        Chat en RMI version 1
 * Description:  Chat en RMI version client/serveur
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia & David
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.io.*;
import java.net.InetAddress;
import javax.swing.*;

public class Client {

  public static void main(String[] args) {

    try {

      String adresseIP = InetAddress.getLocalHost().toString();

      String nomPersonne = JOptionPane.showInputDialog("Entrer votre nom :");
      String nomServeur = JOptionPane.showInputDialog("Entrer le nom du serveur de chat : ");

      new ClientDistantImpl(adresseIP+nomPersonne);
      ServeurChat serveurDistant = (ServeurChat)Naming.lookup(adresseIP+nomServeur);
      System.out.println("Le client "+adresseIP+"/"+nomPersonne+" est pret ...");

      dialoguer(adresseIP, nomPersonne, nomServeur, serveurDistant);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public static void dialoguer(String adresseIP, String nomPersonne, String nomServeur, ServeurChat serveur) {
    try {

      String ligne;
      BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));

      serveur.connect(adresseIP+nomPersonne);
      System.out.println("Le client "+adresseIP+"/"+nomPersonne+" est connecte a "+adresseIP+"/"+nomServeur+" ...");

      System.out.println("Taper FIN pour quitter ...");
      while(!(ligne = entree.readLine()).equals("FIN")) {
        serveur.msg(new Message(nomPersonne+">"+ligne));
      }

      serveur.disconnect(adresseIP+nomPersonne);
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }
}