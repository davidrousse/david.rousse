package chat;

/**
 * Title:        Chat en RMI version 1
 * Description:  Chat en RMI version client/serveur
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia & David
 * @version 1.0
 */

public interface ServeurChat extends ClientDistant {
    public void connect(String url) throws java.rmi.RemoteException;
    public void disconnect(String url) throws java.rmi.RemoteException;
}