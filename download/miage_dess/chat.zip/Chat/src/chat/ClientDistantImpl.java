package chat;

/**
 * Title:        Chat en RMI version 1
 * Description:  Chat en RMI version client/serveur
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia & David
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

public class ClientDistantImpl extends UnicastRemoteObject implements ClientDistant, Runnable {

  private Message messageRecu;
  private Thread threadInterne;
  private boolean enService;

  public ClientDistantImpl(String nomClient) throws RemoteException {
    super();
    try
    {
      System.setSecurityManager(new RMISecurityManager());
      Naming.rebind(nomClient, this);
      this.lancer();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public synchronized void lancer() {
    if(!enService) {
      threadInterne = new Thread(this);
      threadInterne.start();
      enService = true;
    }
  }

  public synchronized void arreter() {
    if(enService) {
      threadInterne = null;
      enService = false;
    }
  }

  public boolean isAlive() {
    return enService;
  }

  public void run() {
      try {

    while(enService) {

	while(messageRecu != null && !(messageRecu.toString().equals("FIN"))) {
          System.out.println(messageRecu.toString());
          messageRecu = null;
        }
        //fin de la communication
        //this.arreter();
        //break;

    }
      }
      catch(Exception e) {
        e.printStackTrace();
      }

  }

  public void msg(Message m) throws RemoteException {
    try
    {
      messageRecu = new Message(m.toString());
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
}