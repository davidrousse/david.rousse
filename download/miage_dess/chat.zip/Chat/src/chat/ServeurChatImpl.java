package chat;

/**
 * Title:        Chat en RMI version 1
 * Description:  Chat en RMI version client/serveur
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia & David
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.io.*;
import java.net.InetAddress;

public class ServeurChatImpl extends UnicastRemoteObject implements ServeurChat {

  private Hashtable lesClients;

  public ServeurChatImpl() throws RemoteException {
    super();
    lesClients = new Hashtable();
  }

  public void connect(String url) throws RemoteException {
    if(!lesClients.containsKey(url))
    {
      try
      {
        ClientDistant client = (ClientDistant)Naming.lookup(url);
        lesClients.put(url,client);
        System.out.println("Connexion de "+url+" realisee.");
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
    }
  }

  public void disconnect(String url) throws RemoteException {
    if(lesClients.containsKey(url)) {
      lesClients.remove(url);
      System.out.println("Deconnexion de "+url+" realisee.");
    }
  }

  public void msg(Message m) throws RemoteException {
    try {

        Enumeration parcours = lesClients.elements();

        while(parcours.hasMoreElements())
        {
          ((ClientDistant)parcours.nextElement()).msg(m);
        }

      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
  }

  public static void main(String[] args) {

    try {
      System.setSecurityManager(new RMISecurityManager());
      String adresseIP = InetAddress.getLocalHost().toString();
      ServeurChatImpl obj = new ServeurChatImpl();
      Naming.rebind(adresseIP+args[0], obj);
      System.out.println("Le serveur "+adresseIP+"/"+args[0]+" est pret ...");
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}