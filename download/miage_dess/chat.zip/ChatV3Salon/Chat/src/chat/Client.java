package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.net.InetAddress;
import java.awt.*;
import java.awt.event.*;

public class Client extends Frame implements ActionListener {

  private TextField saisie;
  private TextArea affichage;
  private Button boutonEnvoi;
  private Button boutonStop;
  private Panel boutonPanel;
  private String nomC;
  private String nomS;
  private ClientDistant client;
  private ServeurDistant serveur;

  public Client(String nomClient, String nomServeur, String nomSalon) {
    super("Chat en RMI (version 3 - Salon)");
    try {
      //construction IHM
      saisie = new TextField("Taper votre message ici ...");
      affichage = new TextArea();
      affichage.setEditable(false);
      this.setLayout(new BorderLayout());
      this.add("North",affichage);
      this.add("Center",saisie);
      saisie.addActionListener(this);
      boutonPanel = new Panel();
      boutonEnvoi = new Button("Envoyer");
      boutonStop = new Button("Quitter");
      boutonPanel.add(boutonEnvoi);
      boutonEnvoi.addActionListener(this);
      boutonPanel.add(boutonStop);
      boutonStop.addActionListener(this);
      this.add("South",boutonPanel);
      this.pack();
      this.show();

      serveur = (ServeurDistant)Naming.lookup(nomServeur);

      //creation de l'objet serveur "cote client"
      new ClientDistantImpl(nomClient, serveur, affichage, nomSalon);
      affichage.append("\nLe client "+nomClient+" est connecte � "+nomServeur+" ... (salon "+nomSalon+")");

      //recuperation du proxy de notre "objet serveur"
      nomC = new String(nomClient);
      nomS = new String(nomSalon);
      client = (ClientDistant)Naming.lookup(nomClient);

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void actionPerformed(ActionEvent e) {
    try {
      if((e.getSource() == boutonEnvoi) || (e.getSource() == saisie)) {
        String ligne = saisie.getText();
        if(!ligne.equals("FIN")){
          client.msg(new Message(ligne, nomC));
        }
        else {
          serveur.unRegister(nomC, nomS);
          affichage.append("\nLe client "+nomC+" s'est d�connecte ...");
          System.exit(0);
        }
        saisie.setText("");
      }

      if(e.getSource() == boutonStop) {
        serveur.unRegister(nomC, nomS);
        System.exit(0);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      //v�rification des arguments.
      //1� arg = Nom client, 2� arg = Nom serveur, [3� arg = Nom salon]
      if(args[0].equals("") || args[1].equals("")) {
        System.out.println("Appel incorrect.");
        System.out.println("Syntaxe : Client nomClient nomServeur [nomSalon]");
        System.exit(0);
      }

      String salon;
      if(!args[2].equals(""))
        salon = new String(args[2]);
      else
        salon = new String("");

      new Client(args[0],args[1], salon);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

}