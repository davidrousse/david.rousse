package chat;

import java.rmi.RemoteException;

/**
 * Title:        Chat en RMI (version 3)
 * Description:  Chat en RMI
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class ClientDejaPresentException extends RemoteException {

  private String _client;

  public ClientDejaPresentException(String nomClient) {
    _client = nomClient;
  }

  public String toString() {
    return "Le nom "+_client+" est deja utilise.";
  }
}