package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.awt.TextArea;
import java.io.*;

public class ClientDistantImpl extends UnicastRemoteObject implements ClientDistant {

  private Hashtable lesClients;
  private ServeurDistant serveurDistant;
  private ClientDistant client;
  private int numeroDernierMessageRecu = -1;
  private TextArea affichage;

  public ClientDistantImpl(String nomClient, ServeurDistant proxyServeur, TextArea affich, String nomSalon) throws java.rmi.RemoteException {
    super();
    try
    {
      //enregistrement de l'implantation
      System.setSecurityManager(new RMISecurityManager());
      Naming.rebind(nomClient, this);

      //initialisation des variables
      affichage = affich;
      serveurDistant = proxyServeur;
      lesClients = new Hashtable();

      //connection au serveur
      String pere = serveurDistant.register(nomClient, nomSalon);

      if (!pere.equals("-1")){
        //recuperation du proxy du pere
        if (!pere.equals(nomClient)){
          client = (ClientDistant)Naming.lookup(pere);
          lesClients.put(pere,client);
        }
        else {
          //le register a echou� ... On indique au client l'erreur et on sort
          BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));
          System.out.println("Connexion refusee : le client "+nomClient+" existe deja !");
          System.out.println("Le programme va se terminer. Appuyer sur ENTREE pour quitter ... ");
          entree.readLine();
          System.exit(0);
        }
      }

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void connect(String url) throws RemoteException {
    try
    {
      if(!lesClients.containsKey(url))
      {
        ClientDistant client = (ClientDistant)Naming.lookup(url);
        lesClients.put(url,client);
        affichage.append("\nLe client "+url+" est connecte ...");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void disconnect(String url) throws RemoteException {
    try
    {
      if(lesClients.containsKey(url)) {
        lesClients.remove(url);
        affichage.append("\nLe client "+url+" est deconnecte ...");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void msg(Message m) throws RemoteException {
    try {

        Enumeration parcours = lesClients.elements();
        ClientDistant client;
        int numeroMsg = m.getNumeroMessage();
        String emetteur = m.getEmetteur();

        if(numeroMsg!=numeroDernierMessageRecu) {

          affichage.append("\n"+emetteur.toString()+">"+m.toString());
          numeroDernierMessageRecu = numeroMsg;

          while(parcours.hasMoreElements())
          {
            client = (ClientDistant)parcours.nextElement();
            client.msg(m);
          }
        }
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
  }
}