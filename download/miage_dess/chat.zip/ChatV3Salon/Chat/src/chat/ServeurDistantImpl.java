package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.io.*;

public class ServeurDistantImpl extends UnicastRemoteObject implements ServeurDistant {

  private Hashtable lesSalons;

  public ServeurDistantImpl(String nomSalonDeBase) throws RemoteException {

    super();
    lesSalons = new Hashtable();
  }

  public String register(String url, String salon) throws java.rmi.RemoteException {
    try
    {
      String retour = null;
      String pere;
      Vector lesClients;

      //on verifie que le salon existe
      if(!lesSalons.containsKey(salon)) {
        //le salon n'existe pas, on le cree
        lesClients = new Vector();
      }
      else {
        //on recupere les clients deja presents dans le salon
        lesClients = (Vector)lesSalons.get(salon);
      }

      //on verifie que le client n'est pas deja connect�
      if(!lesClients.contains(url)){
        pere = new String("-1");

        //si il y a au moins un client deja present, il devient pere de this
        if(!lesClients.isEmpty()){
          pere = (String) lesClients.lastElement();
          ClientDistant proxyPere = (ClientDistant) Naming.lookup(pere);
          //on previent le pere qu'il a un fils
          proxyPere.connect(url);
        }
        //on ajoute le fils dans la liste du serveur pour le salon
        lesClients.addElement(url);
        lesSalons.put(salon, lesClients);
        //on renvoie au fils le nom de son pere
        retour = new String(pere);
        System.out.println("Le client "+url+" s'est enregistre dans le salon "+salon+"...");
      }
      else {
        //le nom est deja utilis�
        System.out.println("Connexion refusee : le client "+url+" existe deja !");
        retour = new String(url);
      }

      return retour;

    }
    catch(Exception e){
      e.printStackTrace();
      return null;
    }
  }

  public void unRegister(String url, String salon) throws java.rmi.RemoteException {
    try
    {
        Vector lesClients;
        int index;

        //on verifie que le salon existe
        if(lesSalons.containsKey(salon)) {
          //on recupere les clients du salon
          lesClients = (Vector)lesSalons.get(salon);

          //on recupere la position du client � deconnecter
          index = lesClients.indexOf(url);

          //un client situ� en milieu de liste
          if(index != 0 && index != (lesClients.size()-1))
          {
            String urlPere = (String) lesClients.get(index-1);
            String urlFils = (String) lesClients.get(index+1);

            ClientDistant proxyPere = (ClientDistant) Naming.lookup(urlPere);
            proxyPere.disconnect(url);
            proxyPere.connect(urlFils);

            ClientDistant proxyFils = (ClientDistant) Naming.lookup(urlFils);
            proxyFils.disconnect(url);
            proxyFils.connect(urlPere);

            lesClients.remove(url);
          }
          //le dernier client se deconnecte
          else if(index == 0 && index == (lesClients.size()-1)){
             lesClients.remove(url);
          }
          //le premier client se deconnecte mais il en reste d'autres
          else if(index == 0){
             String urlFils = (String) lesClients.get(index+1);
             ClientDistant proxyFils = (ClientDistant) Naming.lookup(urlFils);
             proxyFils.disconnect(url);
             lesClients.remove(url);
          }
          //le dernier client se deconnecte
          else if(index == (lesClients.size()-1))
          {
              String urlPere = (String) lesClients.get(index-1);
              ClientDistant proxyPere = (ClientDistant) Naming.lookup(urlPere);
              proxyPere.disconnect(url);
              lesClients.remove(url);
          }

          //on reecrit le vecteur modifie
          lesSalons.put(salon, lesClients);

          System.out.println("Le client "+url+" s'est des-enregistre du salon "+salon+"...");
        }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      //v�rification des arguments.
      //1� arg = Nom serveur, 2� arg = Nom salon de base
      if(args[0].equals("") || args[1].equals("")) {
        System.out.println("Appel incorrect.");
        System.out.println("Syntaxe : ServeurDistantImpl nomServeur nomSalonDeBase");
        System.exit(0);
      }
      System.setSecurityManager(new RMISecurityManager());
      ServeurDistantImpl obj = new ServeurDistantImpl(args[1]);
      Naming.rebind(args[0], obj);
      System.out.println("Le serveur "+args[0]+" est pret ... ");
      System.out.println("Le salon de base est "+args[1]+" ... ");
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}