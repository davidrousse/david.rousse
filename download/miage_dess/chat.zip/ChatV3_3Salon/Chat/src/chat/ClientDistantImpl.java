package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.awt.*;
import java.io.*;
import javax.swing.*;

public class ClientDistantImpl extends UnicastRemoteObject implements ClientDistant {

  private Hashtable lesClients;
  private ServeurDistant serveurDistant;
  private ClientDistant client;
  private int numeroDernierMessageRecu;
  private ClientIHM ihm;
  private Hashtable lesSalons;
  private String salonCourant;
  private String nomClientChat;

  public ClientDistantImpl(String nomClient, ServeurDistant proxyServeur,
          String nomSalon, ClientIHM ihmC) throws java.rmi.RemoteException {
    super();
    try
    {
      //enregistrement de l'implantation
      System.setSecurityManager(new RMISecurityManager());
      Naming.rebind(nomClient, this);

      //initialisation des variables
      numeroDernierMessageRecu = -1;
      ihm = ihmC;
      serveurDistant = proxyServeur;
      lesClients = new Hashtable();
      salonCourant = nomSalon;
      nomClientChat = nomClient;

      //connection au serveur
      String pere = serveurDistant.register(nomClient, nomSalon);

      if (!pere.equals("-1")){
        //recuperation du proxy du pere
        if (!pere.equals(nomClient)){
          client = (ClientDistant)Naming.lookup(pere);
          lesClients.put(pere,client);
        }
        else {
          //le register a echou� ... On indique au client l'erreur et on sort
          BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));
          System.out.println("Connexion refusee : le client "+nomClient+" existe deja !");
          System.out.println("Le programme va se terminer. Appuyer sur ENTREE pour quitter ... ");
          entree.readLine();
          System.exit(0);
        }
      }

      //recuperation de la liste des salons disponibles et des participants deja presents
      PeerList listeRetour = serveurDistant.getAvailableAreas();
      lesSalons = listeRetour.getList();
      //chargement des donnes recues dans l'IHM
      chargerListes();

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void connect(String url) throws RemoteException {
    try
    {
      if(!lesClients.containsKey(url))
      {
        ClientDistant client = (ClientDistant)Naming.lookup(url);
        lesClients.put(url,client);
        ihm.affichage.append("\nLe client "+url+" est connecte ...");

        //mise a jour de l'IHM
        ihm.listeParticipants.add(url);
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void disconnect(String url) throws RemoteException {
    try
    {
      if(lesClients.containsKey(url)) {
        lesClients.remove(url);
        ihm.affichage.append("\nLe client "+url+" est deconnecte ...");

        //mise a jour de l'IHM
        ihm.listeParticipants.remove(url);
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void msg(Message m) throws RemoteException {
    try {

        Enumeration parcours = lesClients.elements();
        ClientDistant client;
        int numeroMsg = m.getNumeroMessage();
        String emetteur = m.getEmetteur();

        if(numeroMsg!=numeroDernierMessageRecu) {

          ihm.affichage.append("\n"+emetteur.toString()+">"+m.toString());

          numeroDernierMessageRecu = numeroMsg;

          while(parcours.hasMoreElements())
          {
            client = (ClientDistant)parcours.nextElement();
            client.msg(m);
          }
        }
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
  }

  public String createSaloon(String name) throws java.rmi.RemoteException {
    try{
      //on quitter le salon courant
      serveurDistant.unRegister(nomClientChat, salonCourant);

      //on s'enregistre dans le nouveau salon que l'on cree en meme temps
      salonCourant = name;

      serveurDistant.register(nomClientChat, salonCourant);

      ihm.affichage.append("\nLe client "+nomClientChat+" est connecte � "+salonCourant);

      //recuperation de la liste des salons disponibles et des participants deja presents
      PeerList listeRetour = serveurDistant.getAvailableAreas();
      lesSalons = listeRetour.getList();

      //maj des donnes recues dans l'IHM
      ihm.listeSalon.add(salonCourant);

      //on vide les donnes deja presentes
      ihm.listeParticipants.removeAll();

      //on recupere les participants du salon du client
      Vector lesClients = (Vector)lesSalons.get(salonCourant);

      //on va parcourir la liste des clients de ce salon
      Enumeration parcours = lesClients.elements();
      while(parcours.hasMoreElements())
        //on ajoute un client de ce salon a l'IHM
        ihm.listeParticipants.add(parcours.nextElement().toString());


      return salonCourant;
    }
    catch(Exception e){
      e.printStackTrace();
      return salonCourant;
    }
  }

  public String changeSaloon(String previous, String next) throws java.rmi.RemoteException {
    try{
      String retour = previous; //en cas d'erreur, on renvoie le salon existant

      //deconnexion du salon actuel
      serveurDistant.unRegister(nomClientChat, previous);

      //connexion dans le nouveau salon
      String pere = serveurDistant.register(nomClientChat, next);

      if (!pere.equals("-1")){
        //recuperation du proxy du pere
        if (!pere.equals(nomClientChat)){
          client = (ClientDistant)Naming.lookup(pere);
          lesClients.put(pere,client);
          //le register a echou� ... on retourne le precedent salon
          JOptionPane.showMessageDialog(null,"L'enregidtrement dans le salon "+next+" a ehou�."+
          "Le salon courant reste "+previous,"Erreur Chat RMI", JOptionPane.ERROR_MESSAGE);

        }
        else {
          //le register a echou� ... on retourne le precedent salon
          JOptionPane.showMessageDialog(null,"L'enregistrement dans le salon "+next+" a ehou�."+" Le salon courant reste "+previous,"Erreur Chat RMI", JOptionPane.ERROR_MESSAGE);

          return retour;
        }
      }

      //le salon courant a � present chang�
      salonCourant = next;
      retour = salonCourant;

      //mise a jour de l'IHM
      chargerListes();

      return retour;
    }
    catch(Exception e){
      e.printStackTrace();
      return salonCourant;
    }
  }

  //methodes utilitaires privees
  private void chargerListes() {
    try {
      Enumeration parcours = lesSalons.keys();

      //on vide les donnes deja presentes
      ihm.listeSalon.removeAll();
      ihm.listeParticipants.removeAll();

      //on parcours les salons
      while(parcours.hasMoreElements()){
        //on recupere le nom d'un salon
        String valeurCle = (String)parcours.nextElement();
        //on ajoute le salon courant dans l'IHM
        ihm.listeSalon.add(valeurCle);
      }

      //on recupere les participants du salon du client
      Vector lesClients = (Vector)lesSalons.get(salonCourant);

      //on va parcourir la liste des clients de ce salon
      parcours = lesClients.elements();
      while(parcours.hasMoreElements())
        //on ajoute un client de ce salon a l'IHM
        ihm.listeParticipants.add(parcours.nextElement().toString());
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }


}