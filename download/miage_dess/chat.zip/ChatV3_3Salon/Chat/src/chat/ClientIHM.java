package chat;

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.net.InetAddress;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title:        Chat en RMI (version 3)
 * Description:  Chat en RMI
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class ClientIHM  extends Frame {

  //attributs pour IHM
  ScrollPane scrollPane1 = new ScrollPane();
  TextArea affichage = new TextArea();
  List listeSalon = new List();
  List listeParticipants = new List();
  TextField saisie = new TextField();
  Panel boutonPanel = new Panel();
  Button boutonEnvoi = new Button();
  Button boutonStop = new Button();
  Button boutonSalon = new Button();

  //attributs applicatifs
  private String nomC;
  private String nomS;
  private String nomSrv;
  private ClientDistant client;
  private ServeurDistant serveur;

  public ClientIHM(String nomClient, String nomServeur, String nomSalon) {
    try {
      //creation de l'IHM
      jbInit();

      //initialisation des attributs
      nomC = new String(nomClient);
      nomS = new String(nomSalon);
      nomSrv = new String(nomServeur);

      serveur = (ServeurDistant)Naming.lookup(nomServeur);

      //creation de l'objet serveur "cote client"
      new ClientDistantImpl(nomClient, serveur, nomSalon, this);
      affichage.append("\nLe client "+nomClient+" est connecte � "+nomServeur);

      //recuperation du proxy de notre "objet serveur"
      client = (ClientDistant)Naming.lookup(nomClient);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.setTitle("Chat en RMI (version 3.3 - Salon)");
    this.setResizable(false);
    this.setLayout(new BorderLayout());

    saisie.setText("Taper votre message ici ...");
    saisie.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        saisie_actionPerformed(e);
      }
    });
    boutonPanel.setLayout(new FlowLayout());
    boutonEnvoi.setLabel("Envoyer");
    boutonEnvoi.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        boutonEnvoi_actionPerformed(e);
      }
    });
    boutonSalon.setLabel("Cr�er salon");
    boutonSalon.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        boutonSalon_actionPerformed(e);
      }
    });
    boutonStop.setLabel("Quitter");
    boutonStop.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        boutonStop_actionPerformed(e);
      }
    });
    affichage.setEditable(false);
    this.setLayout(new BorderLayout());
    this.add("North",affichage);
    this.add("Center",saisie);
    this.add("West",listeSalon);
    this.add("East",listeParticipants);
    boutonPanel.add(boutonEnvoi);
    boutonPanel.add(boutonSalon);
    boutonPanel.add(boutonStop);
    this.add("South",boutonPanel);
    this.pack();
    this.show();
  }

  void boutonEnvoi_actionPerformed(ActionEvent e) {
    try {
      String ligne = saisie.getText();
      if(!ligne.equals("FIN")){
        client.msg(new Message(ligne, nomC));
      }
      saisie.setText("");
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void boutonStop_actionPerformed(ActionEvent e) {
    try{
      serveur.unRegister(nomC, nomS);
      System.exit(0);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void saisie_actionPerformed(ActionEvent e) {
    try {
      String ligne = saisie.getText();
      if(!ligne.equals("FIN")){
        client.msg(new Message(ligne, nomC));
      }
      else {
        serveur.unRegister(nomC, nomS);
        System.exit(0);
      }
      saisie.setText("");
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  //void listeSalon_actionPerformed(ActionEvent e) {
    //lorsque l'utilisateur change de salon, on appele changeSalon si besoin
    //try {
      //String nomSelectionne = listeSalon.getSelectedItem().toString();

      //if(!nomSelectionne.equals("")) {
        //on regarde si l'utilisateur a change de saon
        //if(!nomSelectionne.equals(nomS)) {
          //le salon a chang�
          //nomS = client.changeSaloon(nomS, nomSelectionne);
        //}
      //}
    //}
    //catch(Exception ex) {
      //ex.printStackTrace();
    //}
  //}

  void boutonSalon_actionPerformed(ActionEvent e) {
    try {
      String nomNouveauSalon;

      nomNouveauSalon = JOptionPane.showInputDialog("Entrer le nom du salon :");

      //v�rification du nom
      if(nomNouveauSalon.equals("") || nomNouveauSalon.equals(nomS)) {
        JOptionPane.showMessageDialog(null,"Nom de salon incorrect. "
                  ,"Erreur Chat RMI", JOptionPane.WARNING_MESSAGE);
      }
      else {
        //le salon a chang�
        nomS = client.createSaloon(nomNouveauSalon);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  //main du client
  public static void main(String[] args) {

    try {
      //saisie du nom du client et du serveur � contacter
      String nomPersonne;
      BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));
      System.out.println("Entrez votre nom : ");
      nomPersonne = entree.readLine();

      //v�rification des saisies
      if(nomPersonne.equals("") || args[0].equals("")) {
        System.out.println("Appel incorrect.");
        System.out.println("Vous devez donner votre nom et le nom du serveur a contacter.");
        System.exit(0);
      }

      //on se connecte au salon par defaut
      String salon = new String("Salon principal");

      new ClientIHM(nomPersonne, args[0], salon);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }//fin du main

}//fin classe