package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.util.*;

public class PeerList implements java.io.Serializable {

  private Hashtable lesSalons;

  public PeerList(Hashtable liste) {
    lesSalons = liste;
  }

  public Hashtable getList() {
    return lesSalons;
  }
}