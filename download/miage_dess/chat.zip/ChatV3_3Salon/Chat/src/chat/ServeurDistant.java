package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public interface ServeurDistant extends java.rmi.Remote {
    public String register(String url, String salon) throws java.rmi.RemoteException;
    public void unRegister(String url, String salon) throws java.rmi.RemoteException;
    public PeerList getAvailableAreas() throws java.rmi.RemoteException;
}