*********************************************
************       Contenu       ************
************   David et Laetitia ************
*********************************************

Chat en RMI version 3.3 :
 - version Peer to Peer avec une liste chain�e
 - IHM avec Swing
 - Salon 	
 - Informations sur les participants, 
   les salons dispo ...

***********************************************
* Date de cr�ation : 23/11/2001		      *
* Derni�re mise � jour : 29/11/2001           *
***********************************************
*        DESS MIAGe 2001/2002		      *
***********************************************
