package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.util.*;

public class PeerList implements java.io.Serializable {

  public Vector lesClients;

  public PeerList(Vector liste) {
    lesClients = new Vector(liste);
  }

  public PeerList getPeerList() {
    return this;
  }
}