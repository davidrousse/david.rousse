package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

public class ClientDistantImpl extends UnicastRemoteObject implements ClientDistant {

  private Hashtable lesClients;
  private ServeurChat serveurDistant;
  private ClientDistant clientLocal;

  public ClientDistantImpl(String nomClient, String nomServeur, ServeurChat serveurProxy) throws java.rmi.RemoteException  {
    super();
    try
    {
      PeerList listeClientsConnectes;
      Enumeration parcours;
      ClientDistant client;
      String nom;

      lesClients = new Hashtable();
      serveurDistant = serveurProxy;

      System.setSecurityManager(new RMISecurityManager());

      Naming.rebind(nomClient, this);

      listeClientsConnectes = serveurDistant.register(nomClient);
      parcours = listeClientsConnectes.getPeerList().lesClients.elements();
      while(parcours.hasMoreElements()){
        nom = (String)(parcours.nextElement());
        client = (ClientDistant)Naming.lookup(nom);
        lesClients.put(nom,client);
        client.connect(nomClient);
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void connect(String url) throws RemoteException {
    try
    {
      if(!lesClients.containsKey(url))
      {
        ClientDistant client = (ClientDistant)Naming.lookup(url);
        lesClients.put(url,client);
        System.out.println("Le client "+url+" est connecte ...");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void disconnect(String url) throws RemoteException {
    try {
      if(lesClients.containsKey(url)) {
        lesClients.remove(url);
        System.out.println("Le client "+url+" est de-connecte ...");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void msg(Message m) throws RemoteException {
    try {

        System.out.println(m.toString());
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }

  public void msgAuxClients(Message m) throws RemoteException {
    try {

        Enumeration parcours = lesClients.elements();
        ClientDistant client;

        while(parcours.hasMoreElements()){
          client = (ClientDistant)parcours.nextElement();
          client.msg(m);
        }
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }
}