package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public interface ServeurChat extends java.rmi.Remote {
    public PeerList register(String url) throws java.rmi.RemoteException;
    public void unRegister(String url) throws java.rmi.RemoteException;
}