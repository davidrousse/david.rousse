package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;

public class Client {

  public Client() {
  }

  public static void main(String[] args) {

    try {

      ServeurChat serveurDistant = (ServeurChat) Naming.lookup(args[1]);

      new ClientDistantImpl(args[0], args[1], serveurDistant);
      System.out.println("Le client "+args[0]+" est connecte � "+args[1]+" ...");

      ClientDistant client = (ClientDistant)Naming.lookup(args[0]);
      BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));
      String ligne;
      while(!(ligne=entree.readLine()).equals("FIN")){
        client.msgAuxClients(new Message(args[0]+">"+ligne));
      }
      serveurDistant.unRegister(args[0]);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

}