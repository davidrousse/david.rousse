package chat;

/**
 * Title:        Chat en peer to peer
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.io.*;

public class ServeurChatImpl extends UnicastRemoteObject implements ServeurChat {

  private Vector lesClients;

  public ServeurChatImpl() throws RemoteException {

    super();
    lesClients = new Vector();
  }

  public PeerList register(String url) throws java.rmi.RemoteException {
    try
    {
      PeerList retour = null;
      if(!lesClients.contains(url))
      {
        lesClients.addElement(url);
        retour = new PeerList(lesClients);
        System.out.println("Le client "+url+" s'est enregistre ...");
      }
      return retour;
    }
    catch(Exception e)
    {
      e.printStackTrace();
      return null;
    }
  }

  public void unRegister(String url) throws java.rmi.RemoteException {
    try
    {
        ClientDistant client;
        String nomClient;
        Enumeration parcours = lesClients.elements();

        while(parcours.hasMoreElements())
        {
          nomClient = (String)parcours.nextElement();
          client = (ClientDistant)Naming.lookup(nomClient);
          client.disconnect(url);
        }

        lesClients.removeElement(url);

        System.out.println("Le client "+url+" s'est des-enregistre ...");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      System.setSecurityManager(new RMISecurityManager());
      ServeurChatImpl obj = new ServeurChatImpl();
      Naming.rebind(args[0], obj);
      System.out.println("Le serveur "+args[0]+" est pret ...");
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}