package talkcorba;

/**
 * Title:        Un talk en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia et David
 * @version 1.0
 */

public class TalkImpl extends talkcorba.talkCORBA.talkPOA {

  private String _nom;

  public TalkImpl(java.lang.String nom) {
    super();
    _nom = new String(nom);
  }

  public java.lang.String nom (){
    return _nom;
  }

  public void envoi_message (java.lang.String message) {
    System.out.println("Reception : "+message);
  }
}