package talkcorba;

/**
 * Title:        Un talk en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author Laetitia et David
 * @version 1.0
 */

import org.omg.CosNaming.*;
import com.inprise.vbroker.orb.*;
import java.io.*;

public class Client {

  public static talkcorba.talkCORBA.talk monTalk;

  public static void main(String args[]) {

    try {
        String ligne;
        BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));

	// On intialise l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        /**
         * On r�cupere en premier lieu la r�f�rence initiale du service de nommage
         * c'est � dire la r�f�rence initalie dont le nom est NameService
         */
        org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");
        /**
         * On r�cup�re ensuite la racine de l'arbre de d�signation: l'annuaire est
         * hierarchis� en cat�gorie et sous-cat�gories,
         * le tout formant l'arbre (ou graphe) de d�signation.
         */
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

        // On construit le nom � chercher dans l'annuaire
        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        // On recherche la r�f�rence aupr�s du naming service
        org.omg.CORBA.Object distantTalk = racineArbre.resolve(nom);

        //casting de l'objet CORBA au type talk
	monTalk = talkcorba.talkCORBA.talkHelper.narrow(distantTalk);

        // On attend des saisie
        System.out.println("Entrer votre texte. Taper FIN pour quitter.");
        while(!(ligne = entree.readLine()).equals("FIN")) {
          monTalk.envoi_message(ligne);
        }

      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }//fin du main
} // fin de Client