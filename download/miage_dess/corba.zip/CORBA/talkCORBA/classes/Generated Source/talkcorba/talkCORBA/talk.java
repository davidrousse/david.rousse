package talkcorba.talkCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "G:/Documents and Settings/King/jbproject/talkCORBA/src/talkcorba/talk.idl"
 * <li> <b>IDL Name</b>      ::talkCORBA::talk
 * <li> <b>Repository Id</b> IDL:talkCORBA/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public interface talk extends com.inprise.vbroker.CORBA.Object, talkcorba.talkCORBA.talkOperations, org.omg.CORBA.portable.IDLEntity {
}
