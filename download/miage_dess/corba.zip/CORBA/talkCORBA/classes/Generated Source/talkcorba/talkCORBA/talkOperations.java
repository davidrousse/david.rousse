package talkcorba.talkCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "G:/Documents and Settings/King/jbproject/talkCORBA/src/talkcorba/talk.idl"
 * <li> <b>IDL Name</b>      ::talkCORBA::talk
 * <li> <b>Repository Id</b> IDL:talkCORBA/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public interface talkOperations {
  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom ();

  /**
   * <pre>
   *   void envoi_message (in string message);
   * </pre>
   */
  public void envoi_message (java.lang.String message);

}
