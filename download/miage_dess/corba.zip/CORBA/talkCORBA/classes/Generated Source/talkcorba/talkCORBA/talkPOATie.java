package talkcorba.talkCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "G:/Documents and Settings/King/jbproject/talkCORBA/src/talkcorba/talk.idl"
 * <li> <b>IDL Name</b>      ::talkCORBA::talk
 * <li> <b>Repository Id</b> IDL:talkCORBA/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public class talkPOATie extends talkPOA {
  private talkcorba.talkCORBA.talkOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public talkPOATie (final talkcorba.talkCORBA.talkOperations _delegate) {
    this._delegate = _delegate;
  }

  public talkPOATie (final talkcorba.talkCORBA.talkOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public talkcorba.talkCORBA.talkOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final talkcorba.talkCORBA.talkOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {
    return this._delegate.nom();
  }

  /**
   * <pre>
   *   void envoi_message (in string message);
   * </pre>
   */
  public void envoi_message (java.lang.String message) {
    this._delegate.envoi_message(message);
  }

}
