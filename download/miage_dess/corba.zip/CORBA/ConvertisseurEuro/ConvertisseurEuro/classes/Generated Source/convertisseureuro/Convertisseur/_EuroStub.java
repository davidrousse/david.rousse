package convertisseureuro.Convertisseur;


/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/ConvertisseurEuro/ConvertisseurEuro/src/convertisseureuro/Convertisseur.idl"
 * <li> <b>IDL Name</b>      ::Convertisseur::Euro
 * <li> <b>Repository Id</b> IDL:Convertisseur/Euro:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Euro {
  ...
};
 * </pre>
 */
public class _EuroStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements Euro {
  final public static java.lang.Class _opsClass = convertisseureuro.Convertisseur.EuroOperations.class;


  public java.lang.String[] _ids () {
    return __ids;
  }


  private static java.lang.String[] __ids = {
    "IDL:Convertisseur/Euro:1.0"
  };


  /**
     * <pre>
   *   attribute double taux;
   * </pre>
   */
  public double taux () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_taux", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_taux", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          return _self.taux();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
     * <pre>
   *   attribute double taux;
   * </pre>
   */
  public void taux (double taux) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_taux", true);
          _output.write_double((double)taux);
          _input = this._invoke(_output);
                  }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_taux", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          _self.taux(taux);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
     * <pre>
   *   attribute string devise;
   * </pre>
   */
  public java.lang.String devise () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_devise", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_devise", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          return _self.devise();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
     * <pre>
   *   attribute string devise;
   * </pre>
   */
  public void devise (java.lang.String devise) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_devise", true);
          _output.write_string((java.lang.String)devise);
          _input = this._invoke(_output);
                  }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_devise", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          _self.devise(devise);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
     * <pre>
   *   void start ();
   * </pre>
   */
  public void start () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("start", true);
          _input = this._invoke(_output);
                  }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("start", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          _self.start();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
     * <pre>
   *   double toEuro (in double devise);
   * </pre>
   */
  public double toEuro (double devise) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("toEuro", true);
          _output.write_double((double)devise);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("toEuro", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          return _self.toEuro(devise);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
     * <pre>
   *   double toDevise (in double euro);
   * </pre>
   */
  public double toDevise (double euro) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("toDevise", true);
          _output.write_double((double)euro);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("toDevise", _opsClass);
        if (_so == null) {
          continue;
        }
        final convertisseureuro.Convertisseur.EuroOperations _self = (convertisseureuro.Convertisseur.EuroOperations)_so.servant;
        try {
          return _self.toDevise(euro);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
