package convertisseureuro.Convertisseur;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/ConvertisseurEuro/ConvertisseurEuro/src/convertisseureuro/Convertisseur.idl"
 * <li> <b>IDL Name</b>      ::Convertisseur::Euro
 * <li> <b>Repository Id</b> IDL:Convertisseur/Euro:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Euro {
  ...
};
 * </pre>
 */
public abstract class EuroPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, convertisseureuro.Convertisseur.EuroOperations {

  public convertisseureuro.Convertisseur.Euro _this () {
   return convertisseureuro.Convertisseur.EuroHelper.narrow(super._this_object());
  }

  public convertisseureuro.Convertisseur.Euro _this (org.omg.CORBA.ORB orb) {
    return convertisseureuro.Convertisseur.EuroHelper.narrow(super._this_object(orb));
  }



  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }


  private static java.lang.String[] __ids = {
    "IDL:Convertisseur/Euro:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_taux", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("_set_taux", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("_get_devise", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("_set_devise", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("start", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("toEuro", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("toDevise", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
  }


  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return convertisseureuro.Convertisseur.EuroPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }


  public static org.omg.CORBA.portable.OutputStream _invoke (convertisseureuro.Convertisseur.EuroOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        double _result = _self.taux();
        _output = _handler.createReply();
        _output.write_double((double)_result);
        return _output;
      }
      case 1: {
        double taux;
        taux = _input.read_double();
        _self.taux(taux);
        _output = _handler.createReply();
        return _output;
      }
      case 2: {
        java.lang.String _result = _self.devise();
        _output = _handler.createReply();
        _output.write_string((java.lang.String)_result);
        return _output;
      }
      case 3: {
        java.lang.String devise;
        devise = _input.read_string();
        _self.devise(devise);
        _output = _handler.createReply();
        return _output;
      }
      case 4: {
        _self.start();
        _output = _handler.createReply();
        return _output;
      }
      case 5: {
        double devise;
        devise = _input.read_double();
        double _result = _self.toEuro(devise);
        _output = _handler.createReply();
        _output.write_double((double)_result);
        return _output;
      }
      case 6: {
        double euro;
        euro = _input.read_double();
        double _result = _self.toDevise(euro);
        _output = _handler.createReply();
        _output.write_double((double)_result);
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
