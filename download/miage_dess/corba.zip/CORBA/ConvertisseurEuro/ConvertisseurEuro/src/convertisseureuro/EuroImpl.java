package convertisseureuro;

import convertisseureuro.Convertisseur.*;


/**
 * Title:        Convertisseur Euro
 * Description:  Convertisseur Euros-Francs en CORBA
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

public class EuroImpl extends convertisseureuro.Convertisseur.EuroPOA  {

  // construction des objets
  public EuroImpl(java.lang.String name) {
    super();
    _taux=6.55695;
    _devise="Francs";

  }
  public EuroImpl() {
    super();
    _taux=6.55695;
    _devise="Francs";

  }

  // taux de conversion
  private double _taux;

  public void start() {

      }

  public void taux(double taux) {
    System.out.println(taux);
      _taux=taux;
  }
  public double taux() {
    return _taux;
  }

  // devise utilis�e
  private String _devise;

  public void devise(java.lang.String devise) {
      _devise=devise;
  }
  public java.lang.String devise() {
      return _devise;
  }

  // impl�mentation des op�rations de conversion
  public double toEuro(double devise) {
    return devise / _taux;
  }
  public double toDevise(double euro) {
    return euro * _taux;
  }
}