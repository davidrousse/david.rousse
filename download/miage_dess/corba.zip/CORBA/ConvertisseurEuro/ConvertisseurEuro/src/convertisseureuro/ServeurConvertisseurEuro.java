package convertisseureuro;

import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import com.inprise.vbroker.orb.*;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValue;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValueHelper;

/**
 * Title:        Convertisseur Euro
 * Description:  Convertisseur Euros-Francs en CORBA
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

public class ServeurConvertisseurEuro {

public static void main(String[] args) {
try {
	//intialisation de l'orb
        org.omg.CORBA.ORB orb = com.inprise.vbroker.orb.ORB.init(args,null);

        //r�f�rences initiales
        String [] ids = orb.list_initial_services();
        System.out.println("*** Liste des r�f�rences disponibles :");
        for(int i=0;i<ids.length;i++)
          System.out.println(ids[i]);
        System.out.println("***");

        // r�cup�ration du rootPOA
        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
        //POA rootPOA = null;
        //org.omg.CORBA.Object obj = orb.resolve_initial_references("RootPOA");
        //rootPOA = org.omg.PortableServer.POAHelper.narrow(obj);

      org.omg.CORBA.Any any = orb.create_any();
      BindSupportPolicyValueHelper.insert(any, BindSupportPolicyValue.BY_INSTANCE);
      org.omg.CORBA.Policy bsPolicy = orb.create_policy(com.inprise.vbroker.PortableServerExt.BIND_SUPPORT_POLICY_TYPE.value, any);


        // Cr�ation de politiques pour un POA persistent
        org.omg.CORBA.Policy[] policies = {rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT),bsPolicy};

        // Cr�ation de son propre POA avec les politiques pr�c�dentes
        POA poa = rootPOA.create_POA("monEuro_POA",rootPOA.the_POAManager(),policies);

        //r�cup�ration du naming service
        //NamingContext root=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));
        //obj = null;
        //org.omg.CosNaming.NamingContext naming = null;
        //try {
          //obj = orb.resolve_initial_references("NameService");
          //naming = org.omg.CosNaming.NamingContextHelper.narrow(obj);
        //}
        //catch(org.omg.CORBA.ORBPackage.InvalidName nom) {
          //System.out.println("Impossible de r�soudre NameService");
          //System.exit(0);
        //}
        //if(naming == null) {
          //System.out.println("NameService indisponible");
          //System.exit(0);
        //}

        //construction du nom � enregistrer
        //org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
        //nameToFind[0] = new org.omg.CosNaming.NameComponent(args[0],"");
        //nameToFind[0] = new org.omg.CosNaming.NameComponent();
        //nameToFind[0].id = "Euro";
        //nameToFind[0].kind = "";

        //Cr�ation du servant
        EuroImpl monEuro = new EuroImpl();

        // Donner un ID au servant
        //byte[] monEuroId = args[0].getBytes();
        byte[] monEuroId = "Euro".getBytes();

        // Activer le servant avec l'ID dans le POA
        poa.activate_object_with_id(monEuroId, monEuro);

        // Activer le POA manager
        rootPOA.the_POAManager().activate();

        //enregistrement dans le service de nommage
        //naming.rebind(nameToFind,rootPOA.servant_to_reference(monEuro));
        //naming.bind(nameToFind,monEuro);

        System.out.println(poa.servant_to_reference(monEuro) + " est pret.");

        // Mise en attente de requete
        orb.run();
    }
	catch (Exception e) {e.printStackTrace();
	}
}
}