import java.util.Properties;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.*;



class InterfaceFrame extends JFrame
   implements DocumentListener, ActionListener
{  public InterfaceFrame()
   {  setTitle("Convertisseur �");
      setSize(350, 250);
      addWindowListener(new WindowAdapter()
      {  public void windowClosing(WindowEvent e)
         {  System.exit(0);
         }
      } );

      //placer le logo euro comme icone de fen�tre
      Toolkit tk = Toolkit.getDefaultToolkit();
      Image img = tk.getImage("\\euro\\euro_logo.gif");
      setIconImage(img);

      this.setResizable(false);



      contentPane = getContentPane();

      //Insertion d'un menu
      JMenuBar menuBar = new JMenuBar();
      setJMenuBar(menuBar);
      JMenu menu = new JMenu("Fichier");
      menu.setMnemonic('F');
      itemQuitter = new JMenuItem("Quitter");
      itemQuitter.addActionListener(this);
      menu.add(itemQuitter);
      menuBar.add(menu);

      JMenu aide = new JMenu("Aide");
      aide.setMnemonic('A');
      itemAPropos = new JMenuItem("A Propos");
      itemAPropos.addActionListener(this);
      aide.add(itemAPropos);
      menuBar.add(aide);

      //Insertion d'un cadre
      Border bordureParam = BorderFactory.createEtchedBorder();
      Border titreBordureParam = BorderFactory.createTitledBorder(bordureParam,"Param�tres");

      JPanel p = new JPanel();
      devise = new JTextField(ClientConvertisseurEuro2.monEuro.devise(), 10);
      p.add(new JLabel("Devise"));
      p.add(devise);
      devise.getDocument().addDocumentListener(this);

      taux = new DoubleTextField(ClientConvertisseurEuro2.monEuro.taux(), 8);
      p.add(new JLabel("Taux"));
      p.add(taux);
      taux.getDocument().addDocumentListener(this);
      p.setBorder(titreBordureParam);
      contentPane.add(p, "South");

      p2 = new FonctionnementPanel();
      contentPane.add(p2,"Center");

   }

   public void actionPerformed(ActionEvent evt)
   {
   java.lang.Object source = evt.getSource();
   if (source==itemQuitter)
      System.exit(0);
    else if (source==itemAPropos)
        {if (dialogue==null)
          dialogue= new AProposDialogue(this);
          dialogue.show();
          repaint();
          }

    }


   public void insertUpdate(DocumentEvent e)
   {
   ClientConvertisseurEuro2.monEuro.devise(devise.getText());
   ClientConvertisseurEuro2.monEuro.taux(taux.getValue());
   p2.toDevise.setText("Vers "+ClientConvertisseurEuro2.monEuro.devise());

   }
   public void removeUpdate(DocumentEvent e)
   {
   ClientConvertisseurEuro2.monEuro.devise(devise.getText());
   ClientConvertisseurEuro2.monEuro.taux(taux.getValue());
   p2.toDevise.setText("Vers "+ClientConvertisseurEuro2.monEuro.devise());
   }
   public void changedUpdate(DocumentEvent e)
   {
   }



   private DoubleTextField taux;
   private JTextField devise;
   private java.awt.Container contentPane;
   private FonctionnementPanel p2;
   private AProposDialogue dialogue;
   private JMenuItem itemQuitter, itemAPropos;

}

class AProposDialogue extends JDialog
{
public AProposDialogue(JFrame parent)
{
super(parent, "A propos du convertisseur Euro",true);
 Box b = Box.createVerticalBox();
      b.add(Box.createGlue());
      b.add(new JLabel("Convertisseur Euro 1.0"));
      b.add(new JLabel("Par Yann STEFF Copyright 2000"));
      b.add(Box.createGlue());
      getContentPane().add(b, "Center");

      JPanel p2 = new JPanel();
      JButton ok = new JButton("Ok");
      p2.add(ok);
      getContentPane().add(p2, "South");

      ok.addActionListener(new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            { setVisible(false);

            }
         } );

      setSize(250, 150);
   }
}



class FonctionnementPanel extends JPanel
   implements ActionListener, DocumentListener
{  public FonctionnementPanel()
   {  somme = new DoubleTextField(0, 8);
      add(new JLabel("Somme"));
      add(somme);
      somme.getDocument().addDocumentListener(this);

      toEuro=new JButton("Vers Euro");
      toDevise=new JButton("Vers "+ClientConvertisseurEuro2.monEuro.devise());


      resultat = new DoubleTextField(0, 8);
      add(new JLabel("Resultat"));
      add(resultat);
      resultat.getDocument().addDocumentListener(this);

      add(toEuro);
      add(toDevise);

      toEuro.addActionListener(this);
      toDevise.addActionListener(this);
   }


   public void insertUpdate(DocumentEvent e)
   {
   }
   public void removeUpdate(DocumentEvent e)
   {
   }
   public void changedUpdate(DocumentEvent e)
   {
   }

   public void actionPerformed(ActionEvent evt)
   {  java.lang.Object source = evt.getSource();
      if (source == toEuro)
      {Double temp = new Double(ClientConvertisseurEuro2.monEuro.toEuro(somme.getValue()));
      resultat.setText(temp.toString());}
      else if (source == toDevise) {Double temp = new Double(ClientConvertisseurEuro2.monEuro.toDevise(somme.getValue()));
      resultat.setText(temp.toString());}
   }

   private JButton toEuro;
   public JButton toDevise;
   private DoubleTextField somme;
   private DoubleTextField resultat;
}




class DoubleTextDocument extends PlainDocument
{  public void insertString(int offs, String str,
      AttributeSet a)
      throws BadLocationException
   {  if (str == null) return;
      String oldString = getText(0, getLength());
      String newString = oldString.substring(0, offs)
         + str + oldString.substring(offs);
      try
      {  Double.parseDouble(newString + "0");
         super.insertString(offs, str, a);
      }
      catch(NumberFormatException e)
      {
      }
   }
}

class DoubleTextField extends JTextField
{  public DoubleTextField(double defval, int size)
   {  super("" + defval, size);
   }

   protected Document createDefaultModel()
   {  return new DoubleTextDocument();
   }

   public boolean isValid()
   {  try
      {  Double.parseDouble(getText());
         return true;
      }
      catch(NumberFormatException e)
      {  return false;
      }
   }

   public double getValue()
   {  try
      {  return Double.parseDouble(getText());
      }
      catch(NumberFormatException e)
      {  return 0;
      }
   }
}

public class ClientConvertisseurEuro2 {
public static Convertisseur.Euro monEuro;

public static void main(String args[]) {
org.omg.CosNaming.NamingContext root;
try {
	//intialisation de l'orb
        ORB orb = ORB.init(args,null);

        //r�cup�ration du naming service
        root=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));

        //construction du nom � rechercher
        org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
        nameToFind[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        //recherche aupr�s du naming service
        org.omg.CORBA.Object distantEuro = root.resolve(nameToFind);

        //casting de l'objet CORBA au type convertisseur euro
	monEuro = Convertisseur.EuroHelper.narrow(distantEuro);

        //appel de l'interface graphique windows
        JFrame frame = new InterfaceFrame();
        frame.show();

	}
	catch (Exception e) {e.printStackTrace();}
}//fin du main

}

