//import java.util.Properties;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
//import org.omg.CORBA.*;
//import java.util.*;

public class ServeurConvertisseurEuro {

public static void main(String[] args) {
try {
	//intialisation de l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        // r�cup�ration du POA
        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

        // Cr�ation de politiques pour un POA persistent
        org.omg.CORBA.Policy[] policies = {rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)};

        // Cr�ation de son propre POA avec les politiques pr�c�dentes
        POA poa = rootPOA.create_POA("monEuro_POA",rootPOA.the_POAManager(),policies);

        //r�cup�ration du naming service
        NamingContext root=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));


        //construction du nom � enregistrer
        org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
        nameToFind[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        //Cr�ation du servant
        EuroImpl monEuro = new EuroImpl();

        // Donner un ID au servant
        byte[] monEuroId = args[0].getBytes();

        // Activer le servant avec l'ID dans le POA
        poa.activate_object_with_id(monEuroId, monEuro);

        // Activer le POA manager
        rootPOA.the_POAManager().activate();

        //enregistrement dans le service de nommage
        root.rebind(nameToFind,poa.servant_to_reference(monEuro));

        System.out.println(poa.servant_to_reference(monEuro) + " is ready.");

        // Mise en attente de requete
        orb.run();


	//for(;;);
    }
	catch (Exception e) {e.printStackTrace();
	}
}
}