package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::annuaire
 * <li> <b>Repository Id</b> IDL:appliTest/annuaire:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface annuaire {
  ...
};
 * </pre>
 */
public interface annuaire extends com.inprise.vbroker.CORBA.Object, testidl.appliTest.annuaireOperations, org.omg.CORBA.portable.IDLEntity {
}
