package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::annuaire
 * <li> <b>Repository Id</b> IDL:appliTest/annuaire:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface annuaire {
  ...
};
 * </pre>
 */
public final class annuaireHolder implements org.omg.CORBA.portable.Streamable {
  public testidl.appliTest.annuaire value;

  public annuaireHolder () {
  }

  public annuaireHolder (final testidl.appliTest.annuaire _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = testidl.appliTest.annuaireHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    testidl.appliTest.annuaireHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return testidl.appliTest.annuaireHelper.type();
  }
}
