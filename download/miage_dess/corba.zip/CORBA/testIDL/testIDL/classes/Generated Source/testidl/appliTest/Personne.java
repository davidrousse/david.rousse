package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::Personne
 * <li> <b>Repository Id</b> IDL:appliTest/Personne:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Personne {
  ...
};
 * </pre>
 */
public final class Personne implements org.omg.CORBA.portable.IDLEntity {
  
  public int numero;
  
  public java.lang.String nom;

  public Personne () {
  }

  public Personne (final int numero, 
                   final java.lang.String nom) {
    this.numero = numero;
    this.nom = nom;
  }

  public java.lang.String toString() {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("struct testidl.appliTest.Personne {");
    _ret.append("\n");
    _ret.append("int numero=");
    _ret.append(numero);
    _ret.append(",\n");
    _ret.append("java.lang.String nom=");
    _ret.append(nom != null?'\"' + nom + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;

    if (o instanceof testidl.appliTest.Personne) {
      final testidl.appliTest.Personne obj = (testidl.appliTest.Personne)o;
      boolean res = true;
      do {
        res = this.numero == obj.numero;
        if (!res) break;
        res = this.nom == obj.nom ||
         (this.nom != null && obj.nom != null && this.nom.equals(obj.nom));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
