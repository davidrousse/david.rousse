package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::annuaire
 * <li> <b>Repository Id</b> IDL:appliTest/annuaire:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface annuaire {
  ...
};
 * </pre>
 */
public interface annuaireOperations {
  /**
   * <pre>
   *   attribute testidl.appliTest.lesPersonnes pers;
   * </pre>
   */
  public testidl.appliTest.Personne[] pers ();

  /**
   * <pre>
   *   attribute testidl.appliTest.lesPersonnes pers;
   * </pre>
   */
  public void pers (testidl.appliTest.Personne[] pers);

  /**
   * <pre>
   *   void ajouter (in testidl.appliTest.Personne p);
   * </pre>
   */
  public void ajouter (testidl.appliTest.Personne p);

  /**
   * <pre>
   *   void supprimer (in testidl.appliTest.Personne p);
   * </pre>
   */
  public void supprimer (testidl.appliTest.Personne p);

  /**
   * <pre>
   *   testidl.appliTest.lesPersonnes recuperer ();
   * </pre>
   */
  public testidl.appliTest.Personne[] recuperer ();

}
