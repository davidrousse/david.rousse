package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::annuaire
 * <li> <b>Repository Id</b> IDL:appliTest/annuaire:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface annuaire {
  ...
};
 * </pre>
 */
public class _annuaireStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements annuaire {
  final public static java.lang.Class _opsClass = testidl.appliTest.annuaireOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:appliTest/annuaire:1.0"
  };

  /**
   * <pre>
   *   attribute testidl.appliTest.lesPersonnes pers;
   * </pre>
   */
  public testidl.appliTest.Personne[] pers () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        testidl.appliTest.Personne[] _result;
        try {
          _output = this._request("_get_pers", true);
          _input = this._invoke(_output);
          _result = testidl.appliTest.lesPersonnesHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_pers", _opsClass);
        if (_so == null) {
          continue;
        }
        final testidl.appliTest.annuaireOperations _self = (testidl.appliTest.annuaireOperations)_so.servant;
        try {
          return _self.pers();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute testidl.appliTest.lesPersonnes pers;
   * </pre>
   */
  public void pers (testidl.appliTest.Personne[] pers) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_pers", true);
          testidl.appliTest.lesPersonnesHelper.write(_output, pers);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_pers", _opsClass);
        if (_so == null) {
          continue;
        }
        final testidl.appliTest.annuaireOperations _self = (testidl.appliTest.annuaireOperations)_so.servant;
        try {
          _self.pers(pers);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void ajouter (in testidl.appliTest.Personne p);
   * </pre>
   */
  public void ajouter (testidl.appliTest.Personne p) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("ajouter", true);
          testidl.appliTest.PersonneHelper.write(_output, p);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("ajouter", _opsClass);
        if (_so == null) {
          continue;
        }
        final testidl.appliTest.annuaireOperations _self = (testidl.appliTest.annuaireOperations)_so.servant;
        try {
          _self.ajouter(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void supprimer (in testidl.appliTest.Personne p);
   * </pre>
   */
  public void supprimer (testidl.appliTest.Personne p) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimer", true);
          testidl.appliTest.PersonneHelper.write(_output, p);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimer", _opsClass);
        if (_so == null) {
          continue;
        }
        final testidl.appliTest.annuaireOperations _self = (testidl.appliTest.annuaireOperations)_so.servant;
        try {
          _self.supprimer(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   testidl.appliTest.lesPersonnes recuperer ();
   * </pre>
   */
  public testidl.appliTest.Personne[] recuperer () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        testidl.appliTest.Personne[] _result;
        try {
          _output = this._request("recuperer", true);
          _input = this._invoke(_output);
          _result = testidl.appliTest.lesPersonnesHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("recuperer", _opsClass);
        if (_so == null) {
          continue;
        }
        final testidl.appliTest.annuaireOperations _self = (testidl.appliTest.annuaireOperations)_so.servant;
        try {
          return _self.recuperer();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
