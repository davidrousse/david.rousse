package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::annuaire
 * <li> <b>Repository Id</b> IDL:appliTest/annuaire:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface annuaire {
  ...
};
 * </pre>
 */
public class annuairePOATie extends annuairePOA {
  private testidl.appliTest.annuaireOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public annuairePOATie (final testidl.appliTest.annuaireOperations _delegate) {
    this._delegate = _delegate;
  }

  public annuairePOATie (final testidl.appliTest.annuaireOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public testidl.appliTest.annuaireOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final testidl.appliTest.annuaireOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   attribute testidl.appliTest.lesPersonnes pers;
   * </pre>
   */
  public testidl.appliTest.Personne[] pers () {
    return this._delegate.pers();
  }

  /**
   * <pre>
   *   attribute testidl.appliTest.lesPersonnes pers;
   * </pre>
   */
  public void pers (testidl.appliTest.Personne[] pers) {
    this._delegate.pers(pers);
  }

  /**
   * <pre>
   *   void ajouter (in testidl.appliTest.Personne p);
   * </pre>
   */
  public void ajouter (testidl.appliTest.Personne p) {
    this._delegate.ajouter(p);
  }

  /**
   * <pre>
   *   void supprimer (in testidl.appliTest.Personne p);
   * </pre>
   */
  public void supprimer (testidl.appliTest.Personne p) {
    this._delegate.supprimer(p);
  }

  /**
   * <pre>
   *   testidl.appliTest.lesPersonnes recuperer ();
   * </pre>
   */
  public testidl.appliTest.Personne[] recuperer () {
    return this._delegate.recuperer();
  }

}
