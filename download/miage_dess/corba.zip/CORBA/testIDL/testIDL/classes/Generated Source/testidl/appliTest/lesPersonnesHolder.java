package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::lesPersonnes
 * <li> <b>Repository Id</b> IDL:appliTest/lesPersonnes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&lttestidl.appliTest.Personne&gt lesPersonnes;
 * </pre>
 */
public final class lesPersonnesHolder implements org.omg.CORBA.portable.Streamable {
  public testidl.appliTest.Personne[] value;

  public lesPersonnesHolder () {
  }

  public lesPersonnesHolder (final testidl.appliTest.Personne[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = testidl.appliTest.lesPersonnesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    testidl.appliTest.lesPersonnesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return testidl.appliTest.lesPersonnesHelper.type();
  }
}
