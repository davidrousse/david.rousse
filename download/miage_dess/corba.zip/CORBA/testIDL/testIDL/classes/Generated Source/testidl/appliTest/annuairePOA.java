package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::annuaire
 * <li> <b>Repository Id</b> IDL:appliTest/annuaire:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface annuaire {
  ...
};
 * </pre>
 */
public abstract class annuairePOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, testidl.appliTest.annuaireOperations {

  public testidl.appliTest.annuaire _this () {
   return testidl.appliTest.annuaireHelper.narrow(super._this_object());
  }

  public testidl.appliTest.annuaire _this (org.omg.CORBA.ORB orb) {
    return testidl.appliTest.annuaireHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:appliTest/annuaire:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_pers", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("_set_pers", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("ajouter", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("supprimer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("recuperer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return testidl.appliTest.annuairePOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (testidl.appliTest.annuaireOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        testidl.appliTest.Personne[] _result = _self.pers();
        _output = _handler.createReply();
        testidl.appliTest.lesPersonnesHelper.write(_output, _result);
        return _output;
      }
      case 1: {
        testidl.appliTest.Personne[] pers;
        pers = testidl.appliTest.lesPersonnesHelper.read(_input);
        _self.pers(pers);
        _output = _handler.createReply();
        return _output;
      }
      case 2: {
        testidl.appliTest.Personne p;
        p = testidl.appliTest.PersonneHelper.read(_input);
        _self.ajouter(p);
        _output = _handler.createReply();
        return _output;
      }
      case 3: {
        testidl.appliTest.Personne p;
        p = testidl.appliTest.PersonneHelper.read(_input);
        _self.supprimer(p);
        _output = _handler.createReply();
        return _output;
      }
      case 4: {
        testidl.appliTest.Personne[] _result = _self.recuperer();
        _output = _handler.createReply();
        testidl.appliTest.lesPersonnesHelper.write(_output, _result);
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
