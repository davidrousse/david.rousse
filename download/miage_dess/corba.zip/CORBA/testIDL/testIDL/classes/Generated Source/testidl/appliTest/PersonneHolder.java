package testidl.appliTest;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/testIDL/testIDL/src/testidl/test.idl"
 * <li> <b>IDL Name</b>      ::appliTest::Personne
 * <li> <b>Repository Id</b> IDL:appliTest/Personne:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Personne {
  ...
};
 * </pre>
 */
public final class PersonneHolder implements org.omg.CORBA.portable.Streamable {
  public testidl.appliTest.Personne value;

  public PersonneHolder () {
  }

  public PersonneHolder (final testidl.appliTest.Personne _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = testidl.appliTest.PersonneHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    testidl.appliTest.PersonneHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return testidl.appliTest.PersonneHelper.type();
  }
}
