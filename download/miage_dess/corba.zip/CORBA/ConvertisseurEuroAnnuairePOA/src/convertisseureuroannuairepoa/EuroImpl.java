package convertisseureuroannuairepoa;

/**
 * Title:        Convertisseur Euro - Franc
 * Description:  Convertisseur Euro - Franc utilisant le service d'annuaire interop�rable (CosNaming) et un POA personnalis�
 *
 * On remarque que dans l'approche POA,
 * le servant h�rite du squelette EuroPOA, EuroPOA implante EuroOperations
 * et herite de org.omg.PortableServer.Servant (on voit donc que le servant n'a
 *  pas de lien avec l'interface Euro donc avec la r�f�rence de celle-ci).
 * Dans l'approche BOA,
 * l'objet d'implantation h�rite du squelette _EuroImplBase,
 * _EuroImplBase implante Euro et h�rite de org.omg.CORBA.portable.ObjectImpl
 * qui implante org.omg.CORBA.Object
 *
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

public class EuroImpl extends convertisseureuroannuairepoa.Convertisseur.EuroPOA {

  // construction des objets
  public EuroImpl(java.lang.String name) {
    super();
    _taux=6.55695;
    _devise="Francs";

  }
  public EuroImpl() {
    super();
    _taux=6.55695;
    _devise="Francs";
  }

  // taux de conversion
  private double _taux;

  public void start() {

      }

  public void taux(double taux) {
    System.out.println(taux);
      _taux=taux;
  }
  public double taux() {
    return _taux;
  }

  // devise utilis�e
  private String _devise;

  public void devise(java.lang.String devise) {
      _devise=devise;
  }
  public java.lang.String devise() {
      return _devise;
  }

  // impl�mentation des op�rations de conversion
  public double toEuro(double devise) {
    return devise / _taux;
  }
  public double toDevise(double euro) {
    return euro * _taux;
  }
}