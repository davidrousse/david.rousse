package convertisseureuroannuairepoa;

import java.util.Properties;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.*;

/**
 * Title:        Convertisseur Euro - Franc
 * Description:  Convertisseur Euro - Franc utilisant le service d'annuaire interop�rable (CosNaming) et un POA personnalis�
 *
 * Attention, pour lancer le client, 2 mani�res :
 *  - en mode ligne de commande, taper vbj -DSVCnameroot=NameService Client
 *  - sous JBuilder, ajouter dans l'onglet Run du menu Project Properties
 *  la valeur -DSVCnameroot=NameService � VM Parameters
 *
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

class InterfaceFrame extends JFrame
   implements DocumentListener, ActionListener
{  public InterfaceFrame()
   {  setTitle("Convertisseur �");
      setSize(350, 250);
      addWindowListener(new WindowAdapter()
      {  public void windowClosing(WindowEvent e)
         {  System.exit(0);
         }
      } );

      //placer le logo euro comme icone de fen�tre
      Toolkit tk = Toolkit.getDefaultToolkit();


      this.setResizable(false);



      contentPane = getContentPane();

      //Insertion d'un menu
      JMenuBar menuBar = new JMenuBar();
      setJMenuBar(menuBar);
      JMenu menu = new JMenu("Fichier");
      menu.setMnemonic('F');
      itemQuitter = new JMenuItem("Quitter");
      itemQuitter.addActionListener(this);
      menu.add(itemQuitter);
      menuBar.add(menu);

      JMenu aide = new JMenu("Aide");
      aide.setMnemonic('A');
      itemAPropos = new JMenuItem("A Propos");
      itemAPropos.addActionListener(this);
      aide.add(itemAPropos);
      menuBar.add(aide);

      //Insertion d'un cadre
      Border bordureParam = BorderFactory.createEtchedBorder();
      Border titreBordureParam = BorderFactory.createTitledBorder(bordureParam,"Param�tres");

      JPanel p = new JPanel();
      devise = new JTextField(Client.monEuro.devise(), 10);
      p.add(new JLabel("Devise"));
      p.add(devise);
      devise.getDocument().addDocumentListener(this);

      taux = new DoubleTextField(Client.monEuro.taux(), 8);
      p.add(new JLabel("Taux"));
      p.add(taux);
      taux.getDocument().addDocumentListener(this);
      p.setBorder(titreBordureParam);
      contentPane.add(p, "South");

      p2 = new FonctionnementPanel();
      contentPane.add(p2,"Center");

   }

   public void actionPerformed(ActionEvent evt)
   {
   java.lang.Object source = evt.getSource();
   if (source==itemQuitter)
      System.exit(0);
    else if (source==itemAPropos)
        {if (dialogue==null)
          dialogue= new AProposDialogue(this);
          dialogue.show();
          repaint();
          }

    }


   public void insertUpdate(DocumentEvent e)
   {
   Client.monEuro.devise(devise.getText());
   Client.monEuro.taux(taux.getValue());
   p2.toDevise.setText("Vers "+Client.monEuro.devise());

   }
   public void removeUpdate(DocumentEvent e)
   {
   Client.monEuro.devise(devise.getText());
   Client.monEuro.taux(taux.getValue());
   p2.toDevise.setText("Vers "+Client.monEuro.devise());
   }
   public void changedUpdate(DocumentEvent e)
   {
   }



   private DoubleTextField taux;
   private JTextField devise;
   private java.awt.Container contentPane;
   private FonctionnementPanel p2;
   private AProposDialogue dialogue;
   private JMenuItem itemQuitter, itemAPropos;

}

class AProposDialogue extends JDialog
{
public AProposDialogue(JFrame parent)
{
super(parent, "A propos du convertisseur Euro",true);
 Box b = Box.createVerticalBox();
      b.add(Box.createGlue());
      b.add(new JLabel("Convertisseur Euro 1.0"));
      b.add(new JLabel("Par Yann STEFF Copyright 2000"));
      b.add(Box.createGlue());
      getContentPane().add(b, "Center");

      JPanel p2 = new JPanel();
      JButton ok = new JButton("Ok");
      p2.add(ok);
      getContentPane().add(p2, "South");

      ok.addActionListener(new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            { setVisible(false);

            }
         } );

      setSize(250, 150);
   }
}



class FonctionnementPanel extends JPanel
   implements ActionListener, DocumentListener
{  public FonctionnementPanel()
   {  somme = new DoubleTextField(0, 8);
      add(new JLabel("Somme"));
      add(somme);
      somme.getDocument().addDocumentListener(this);

      toEuro=new JButton("Vers Euro");
      toDevise=new JButton("Vers "+Client.monEuro.devise());


      resultat = new DoubleTextField(0, 8);
      add(new JLabel("Resultat"));
      add(resultat);
      resultat.getDocument().addDocumentListener(this);

      add(toEuro);
      add(toDevise);

      toEuro.addActionListener(this);
      toDevise.addActionListener(this);
   }


   public void insertUpdate(DocumentEvent e)
   {
   }
   public void removeUpdate(DocumentEvent e)
   {
   }
   public void changedUpdate(DocumentEvent e)
   {
   }

   public void actionPerformed(ActionEvent evt)
   {  java.lang.Object source = evt.getSource();
      if (source == toEuro)
      {Double temp = new Double(Client.monEuro.toEuro(somme.getValue()));
      resultat.setText(temp.toString());}
      else if (source == toDevise) {Double temp = new Double(Client.monEuro.toDevise(somme.getValue()));
      resultat.setText(temp.toString());}
   }

   private JButton toEuro;
   public JButton toDevise;
   private DoubleTextField somme;
   private DoubleTextField resultat;
}




class DoubleTextDocument extends PlainDocument
{  public void insertString(int offs, String str,
      AttributeSet a)
      throws BadLocationException
   {  if (str == null) return;
      String oldString = getText(0, getLength());
      String newString = oldString.substring(0, offs)
         + str + oldString.substring(offs);
      try
      {  Double.parseDouble(newString + "0");
         super.insertString(offs, str, a);
      }
      catch(NumberFormatException e)
      {
      }
   }
}

class DoubleTextField extends JTextField
{  public DoubleTextField(double defval, int size)
   {  super("" + defval, size);
   }

   protected Document createDefaultModel()
   {  return new DoubleTextDocument();
   }

   public boolean isValid()
   {  try
      {  Double.parseDouble(getText());
         return true;
      }
      catch(NumberFormatException e)
      {  return false;
      }
   }

   public double getValue()
   {  try
      {  return Double.parseDouble(getText());
      }
      catch(NumberFormatException e)
      {  return 0;
      }
   }
}

public class Client {

  public static convertisseureuroannuairepoa.Convertisseur.Euro monEuro;

  public static void main(String args[]) {

    try {
	// On intialise l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        /**
         * On r�cupere en premier lieu la r�f�rence initiale du service de nommage
         * c'est � dire la r�f�rence initalie dont le nom est NameService
         */
        org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");
        /**
         * On r�cup�re ensuite la racine de l'arbre de d�signation: l'annuaire est
         * hierarchis� en cat�gorie et sous-cat�gories,
         * le tout formant l'arbre (ou graphe) de d�signation.
         */
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

        // On construit le nom � chercher dans l'annuaire
        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent("ConvertisseurEuro","");

        // On recherche la r�f�rence aupr�s du naming service
        org.omg.CORBA.Object distantEuro = racineArbre.resolve(nom);

        //casting de l'objet CORBA au type convertisseur euro
	monEuro = convertisseureuroannuairepoa.Convertisseur.EuroHelper.narrow(distantEuro);

        // On appelle l'interface graphique
        JFrame frame = new InterfaceFrame();
        frame.show();

      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }//fin du main
} // fin de Client