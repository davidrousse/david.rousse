package convertisseureuroannuairepoa;

import convertisseureuroannuairepoa.Convertisseur.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import com.inprise.vbroker.orb.*;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValue;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValueHelper;


/**
 * Title:        Convertisseur Euro - Franc
 * Description:  Convertisseur Euro - Franc utilisant le service d'annuaire interop�rable (CosNaming) et un POA personnalis�
 * Le service d'annuaire permet de mettre en correspondance un nom et
 * un r�f�rence d'objets.
 * Le POA est un adaptateur d'objets portable c'est � dire que
 * son fonctionnement sera identique sur diff�rentes impl�mntations de CORBA
 * (car il est mieux sp�cifier que la BOA).
 * De plus, la POA introduit (ou modifie) les notions de :
 * - servant (entit� qui implente une interface IDL)
 * - serveur (entit� qui loge un ensemble de servants)
 * - r�f�rences d'objets (vue cliente d'une interface IDL)
 * - ...
 *
 * Attention, pour lancer le serveur, 2 mani�res :
 *  - en mode ligne de commande, taper vbj -DSVCnameroot=NameService Server  &
 *  - sous JBuilder, ajouter dans l'onglet Run du menu Project Properties
 *  la valeur -DSVCnameroot=NameService � VM Parameters
 *
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

public class Serveur {

  public static void main(String[] args) {
    try {
      //intialisation de l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      /**
       * On peut afficher pour info. les r�f�rences initiales c'est � dire
       * les noms correspondant aux r�f�rences initiales support�es
       * par d�faut par l'ORB :
       * String [] ids = orb.list_initial_services();
       * System.out.println("*** Liste des r�f�rences disponibles :");
       * for(int i=0;i<ids.length;i++)
       *    System.out.println(ids[i]);
       * System.out.println("***");
       */
        String [] ids = orb.list_initial_services();
        System.out.println("*** Liste des r�f�rences disponibles :");
        for(int i=0;i<ids.length;i++)
           System.out.println(ids[i]);
        System.out.println("***");
      /**
       *  On ne doit plus initialiser le BOA ...
       * com.inprise.vbroker.CORBA.BOA boa = ((com.inprise.vbroker.CORBA.ORB)orb).BOA_init();
       * ... mais on r�cup�re le rootPOA.
       * Le rootPOA est le seul POA qui existe par d�faut sur le serveur.
       * On pourra ensuite cr�er des POA fils dont on param�trera les politiques
       * pour qu'ils g�rent un ensemble de servants comme on le d�sire.
       */
      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      /**
       * On r�cupere en premier lieu la r�f�rence initiale du service de nommage
       * c'est � dire la r�f�rence initalie dont le nom est NameService
       */
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");
      /**
       * On r�cup�re ensuite la racine de l'arbre de d�signation: l'annuaire est
       * hierarchis� en cat�gorie et sous-cat�gories,
       * le tout formant l'arbre (ou graphe) de d�signation.
       */
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      /**
       * On construit le nom � enregistrer dans l'annuaire
       */
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent("ConvertisseurEuro","");

      /**
       *  On va cr�er des regles ou politiques (policies) pour utiliser avec
       *  un POA personnel.
       *  Pour notre POA, on choisit la valeur PERSISTENT pour la r�gle Lifespan
       *  Cette r�gle permet de rendre les r�f�rences d'objets persistantes (si
       *  on relance le serveur, le servant aura la meme reference).
       *  Le rootPOA ne supporte que des objets TRANSIENT alors que l'on
       * a besoin d'objets PERSISTENT donc on va cr�er un POA avec
       * une politique persistante ...
       * ... Cr�ation de politiques pour un POA PERSISTENT
       */
/*      org.omg.CORBA.Any any = orb.create_any();
      BindSupportPolicyValueHelper.insert(any, BindSupportPolicyValue.BY_INSTANCE);
      org.omg.CORBA.Policy bsPolicy = orb.create_policy(com.inprise.vbroker.PortableServerExt.BIND_SUPPORT_POLICY_TYPE.value, any);
      org.omg.CORBA.Policy[] policies = {rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT),bsPolicy}; */
      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };
      /**
       * Cr�ation de son propre POA avec les politiques pr�c�dentes et avec
       * le meme POA Manager que son pere, en l'occurrence le RootPOA.
       */
      POA poa = rootPOA.create_POA("monPOA",rootPOA.the_POAManager(),policies);

      /**
       *  Avec un BOA, un servant est un objet CORBA.
       *  Avec un POA, un servant et un objet sont distincts.
       *  Ainsi, on dissosie la notion d'objet d'implantation servant)
       *  de la notion de r�f. d'obj. A pr�sent, on peut asocier plusieurs
       *  r�f. d'obj. au m�me servant. Les lcients pour leurs parts croiront
       *  s'adresser � des obj distincts.
       *
       *
       *  Au lieu de cr�er un objet CORBA et d'appeler obj_is_ready
       *  pour l'activer, on cr�e un servant et on active ce servant
       *  avec un ID sur notre POA. Si l'on ne veut pas donner son propre ID
       *  au servant, on peut ecrire directement :
       *  byte[] monEuroId = null;
       *  monEuroId = rootPOA.activate_object(moneuro);
       *
       *  ... Cr�ation du servant
       */
      EuroImpl monEuroServant = new EuroImpl();

      /**
       * Donner un Object ID en convertissant "Euro" en un tableau d'octets
       */
      byte[] monEuroId = "Euro".getBytes();

      /**
       * Activer le servant avec l'ID dans le POA
       */
      poa.activate_object_with_id(monEuroId, monEuroServant);

      /**
       * Cette �tape n'a pas d'�quivalent avec le BOA.
       * Le root POA et notre POA personnel doivent �tre manag�s
       * par un gestionnaire de POA, le POA manager. Ce gestionnaire peut
       * g�rer simultan�ment plusieurs POA dont il controle
       * l'�tat de traitement (empilation des requetes, desactivation, ...).
       *
       * ... Activer le POA manager (passage de l'�tat Inactif � l'�tat Actif)
       */
      rootPOA.the_POAManager().activate();

      /**
       * On enregistre l'objet dans l'annuaire
       * (ou on modifie la liaison d'objet d�j� exsitante graca � rebind() )
       *
       * On aurait pu utiliser la ligne
       * ((NamingContext)racineArbre).bind(racineArbre.to_name("ConvertisseurEuro"), poa.servant_to_reference(monEuroServant));
       * pour enregistrer le serveur mais si on relance la serveur une 2� fois,
       * l'exception AlreadyBound est lev�e car la liaison existe d�j�.
       */
      racineArbre.rebind(nom,poa.servant_to_reference(monEuroServant));


      /**
       * On affiche un trace � l'�cran de la r�f�rence d'objet
       * associ�e au servant monEuro. On aurait pu utilser la m�thode
       * poa.id_to_reference(monEuroId) pour obtenir le meme resultat.
       */
      System.out.println(poa.servant_to_reference(monEuroServant) + " est pret.");


      /**
       * On n'utilise plus boa.impl_is_ready(); mais orb.run()
       * pour attendre les requetes ...
       *
       * ...Mise en attente de requete
       */
      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  } //fin du main

} //fin de la classe (du serveur)