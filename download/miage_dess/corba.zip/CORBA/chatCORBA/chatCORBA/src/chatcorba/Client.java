package chatcorba;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextExtPackage.*;
import java.lang.*;
import org.omg.PortableServer.*;
import com.inprise.vbroker.orb.*;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValue;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValueHelper;
import java.io.*;

/**
 * Title:        Chat en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class Client {

  private static chatcorba.chatCORBA.chatServeur monServeur;


  public static void main(String args[]) {

    try {
        String ligne;
        BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));

	// On intialise l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        /**
         * On r�cupere en premier lieu la r�f�rence initiale du service de nommage
         * c'est � dire la r�f�rence initalie dont le nom est NameService
         */
        org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");
        /**
         * On r�cup�re ensuite la racine de l'arbre de d�signation: l'annuaire est
         * hierarchis� en cat�gorie et sous-cat�gories,
         * le tout formant l'arbre (ou graphe) de d�signation.
         */
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

        // On construit le nom � chercher dans l'annuaire
        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        // On recherche la r�f�rence aupr�s du naming service
        org.omg.CORBA.Object objectDistant = racineArbre.resolve(nom);

        //casting de l'objet CORBA au type chatServeur
	monServeur = chatcorba.chatCORBA.chatServeurHelper.narrow(objectDistant);


        //connexion au serveur
        monServeur.connecter(args[1]);

        // On attend des saisie
        System.out.println("Entrer votre texte. Taper FIN pour quitter.");
        while(!(ligne = entree.readLine()).equals("FIN")) {
          monServeur.envoyer_message(args[1]+">"+ligne);
        }

        try{
          monServeur.deconnecter(args[1]);
        }catch(Exception e){
          e.printStackTrace();
        }
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }//fin du main
}