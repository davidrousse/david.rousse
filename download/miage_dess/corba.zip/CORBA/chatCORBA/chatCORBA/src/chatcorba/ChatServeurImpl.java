package chatcorba;

import chatcorba.chatCORBA.*;
import java.util.*;
import org.omg.CosNaming.*;
import com.inprise.vbroker.orb.*;
/**
 * Title:        Chat en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

import org.omg.CosNaming.*;

public class ChatServeurImpl extends chatServeurPOA {

  private String _nom;
  private Hashtable _lesClients;
  private NamingContextExt _racineArbre;

  public ChatServeurImpl(String nom, NamingContextExt racineArbre) {
    super();
    _nom = new String(nom);
    _lesClients = new Hashtable();
    _racineArbre = racineArbre;

  }

  public void deconnecter(String nom) {
    chatClient representantLocal = (chatClient) _lesClients.get(nom);
    representantLocal.arreter();
    _lesClients.remove(nom);


  }

  public void connecter(String nom) {

    try{

      if (!_lesClients.containsKey(nom))
      {
        // On construit le nom � chercher dans l'annuaire
          org.omg.CosNaming.NameComponent [] chatNom = new org.omg.CosNaming.NameComponent[1];
          chatNom[0] = new org.omg.CosNaming.NameComponent(nom,"");

          // On recherche la r�f�rence aupr�s du naming service
          org.omg.CORBA.Object objetDistant = _racineArbre.resolve(chatNom);

          //casting de l'objet CORBA au type chatClient
          chatClient chatDistant = chatcorba.chatCORBA.chatClientHelper.narrow(objetDistant);
          _lesClients.put(nom,chatDistant);
          System.out.println("Le client "+nom+" s'est enregistr�!");
      }

    }catch(Exception e){
      e.printStackTrace();
    }
  }

  public String nom() {
     return _nom;
  }

  public void envoyer_message(String message) {

    try{

      for(Enumeration enum = _lesClients.keys();enum.hasMoreElements();)
      {
        chatClient representantLocal = (chatClient) _lesClients.get((enum.nextElement()).toString());
        representantLocal.afficher_message(message);

      }

    }catch(Exception e){
      e.printStackTrace();
    }
  }
}