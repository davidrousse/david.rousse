package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatServeur
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatServeur:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatServeur {
  ...
};
 * </pre>
 */
public final class chatServeurHolder implements org.omg.CORBA.portable.Streamable {
  public chatcorba.chatCORBA.chatServeur value;

  public chatServeurHolder () {
  }

  public chatServeurHolder (final chatcorba.chatCORBA.chatServeur _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = chatcorba.chatCORBA.chatServeurHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    chatcorba.chatCORBA.chatServeurHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return chatcorba.chatCORBA.chatServeurHelper.type();
  }
}
