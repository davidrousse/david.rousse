package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatClient
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatClient:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatClient {
  ...
};
 * </pre>
 */
public final class chatClientHolder implements org.omg.CORBA.portable.Streamable {
  public chatcorba.chatCORBA.chatClient value;

  public chatClientHolder () {
  }

  public chatClientHolder (final chatcorba.chatCORBA.chatClient _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = chatcorba.chatCORBA.chatClientHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    chatcorba.chatCORBA.chatClientHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return chatcorba.chatCORBA.chatClientHelper.type();
  }
}
