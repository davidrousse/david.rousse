package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatClient
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatClient:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatClient {
  ...
};
 * </pre>
 */
public class chatClientPOATie extends chatClientPOA {
  private chatcorba.chatCORBA.chatClientOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public chatClientPOATie (final chatcorba.chatCORBA.chatClientOperations _delegate) {
    this._delegate = _delegate;
  }

  public chatClientPOATie (final chatcorba.chatCORBA.chatClientOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public chatcorba.chatCORBA.chatClientOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final chatcorba.chatCORBA.chatClientOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {
    return this._delegate.nom();
  }

  /**
   * <pre>
   *   void afficher_message (in string message);
   * </pre>
   */
  public void afficher_message (java.lang.String message) {
    this._delegate.afficher_message(message);
  }

  /**
   * <pre>
   *   void arreter ();
   * </pre>
   */
  public void arreter () {
    this._delegate.arreter();
  }

}
