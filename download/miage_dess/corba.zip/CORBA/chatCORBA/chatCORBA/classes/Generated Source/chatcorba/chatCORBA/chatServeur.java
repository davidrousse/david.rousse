package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatServeur
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatServeur:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatServeur {
  ...
};
 * </pre>
 */
public interface chatServeur extends com.inprise.vbroker.CORBA.Object, chatcorba.chatCORBA.chatServeurOperations, org.omg.CORBA.portable.IDLEntity {
}
