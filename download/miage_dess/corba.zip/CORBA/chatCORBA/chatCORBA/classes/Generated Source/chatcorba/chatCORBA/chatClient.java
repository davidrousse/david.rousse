package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatClient
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatClient:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatClient {
  ...
};
 * </pre>
 */
public interface chatClient extends com.inprise.vbroker.CORBA.Object, chatcorba.chatCORBA.chatClientOperations, org.omg.CORBA.portable.IDLEntity {
}
