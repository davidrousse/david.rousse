package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatServeur
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatServeur:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatServeur {
  ...
};
 * </pre>
 */
public class _chatServeurStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements chatServeur {
  final public static java.lang.Class _opsClass = chatcorba.chatCORBA.chatServeurOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:chatCORBA/chatServeur:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nom", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nom", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatServeurOperations _self = (chatcorba.chatCORBA.chatServeurOperations)_so.servant;
        try {
          return _self.nom();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void envoyer_message (in string message);
   * </pre>
   */
  public void envoyer_message (java.lang.String message) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("envoyer_message", true);
          _output.write_string((java.lang.String)message);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("envoyer_message", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatServeurOperations _self = (chatcorba.chatCORBA.chatServeurOperations)_so.servant;
        try {
          _self.envoyer_message(message);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void connecter (in string nom);
   * </pre>
   */
  public void connecter (java.lang.String nom) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("connecter", true);
          _output.write_string((java.lang.String)nom);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("connecter", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatServeurOperations _self = (chatcorba.chatCORBA.chatServeurOperations)_so.servant;
        try {
          _self.connecter(nom);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void deconnecter (in string nom);
   * </pre>
   */
  public void deconnecter (java.lang.String nom) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("deconnecter", true);
          _output.write_string((java.lang.String)nom);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("deconnecter", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatServeurOperations _self = (chatcorba.chatCORBA.chatServeurOperations)_so.servant;
        try {
          _self.deconnecter(nom);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
