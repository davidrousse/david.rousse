package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatClient
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatClient:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatClient {
  ...
};
 * </pre>
 */
public interface chatClientOperations {
  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom ();

  /**
   * <pre>
   *   void afficher_message (in string message);
   * </pre>
   */
  public void afficher_message (java.lang.String message);

  /**
   * <pre>
   *   void arreter ();
   * </pre>
   */
  public void arreter ();

}
