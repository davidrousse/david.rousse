package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBA/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatServeur
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatServeur:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatServeur {
  ...
};
 * </pre>
 */
public abstract class chatServeurPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, chatcorba.chatCORBA.chatServeurOperations {

  public chatcorba.chatCORBA.chatServeur _this () {
   return chatcorba.chatCORBA.chatServeurHelper.narrow(super._this_object());
  }

  public chatcorba.chatCORBA.chatServeur _this (org.omg.CORBA.ORB orb) {
    return chatcorba.chatCORBA.chatServeurHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:chatCORBA/chatServeur:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_nom", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("envoyer_message", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("connecter", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("deconnecter", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return chatcorba.chatCORBA.chatServeurPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (chatcorba.chatCORBA.chatServeurOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        java.lang.String _result = _self.nom();
        _output = _handler.createReply();
        _output.write_string((java.lang.String)_result);
        return _output;
      }
      case 1: {
        java.lang.String message;
        message = _input.read_string();
        _self.envoyer_message(message);
        _output = _handler.createReply();
        return _output;
      }
      case 2: {
        java.lang.String nom;
        nom = _input.read_string();
        _self.connecter(nom);
        _output = _handler.createReply();
        return _output;
      }
      case 3: {
        java.lang.String nom;
        nom = _input.read_string();
        _self.deconnecter(nom);
        _output = _handler.createReply();
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
