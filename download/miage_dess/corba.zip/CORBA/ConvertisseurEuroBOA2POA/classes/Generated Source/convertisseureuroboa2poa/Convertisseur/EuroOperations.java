package convertisseureuroboa2poa.Convertisseur;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/ConvertisseurEuroBOA2POA/src/convertisseureuroboa2poa/ConvertisseurEuro.idl"
 * <li> <b>IDL Name</b>      ::Convertisseur::Euro
 * <li> <b>Repository Id</b> IDL:Convertisseur/Euro:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Euro {
  ...
};
 * </pre>
 */
public interface EuroOperations {
  /**
   * <pre>
   *   attribute double taux;
   * </pre>
   */
  public double taux ();

  /**
   * <pre>
   *   attribute double taux;
   * </pre>
   */
  public void taux (double taux);

  /**
   * <pre>
   *   attribute string devise;
   * </pre>
   */
  public java.lang.String devise ();

  /**
   * <pre>
   *   attribute string devise;
   * </pre>
   */
  public void devise (java.lang.String devise);

  /**
   * <pre>
   *   void start ();
   * </pre>
   */
  public void start ();

  /**
   * <pre>
   *   double toEuro (in double devise);
   * </pre>
   */
  public double toEuro (double devise);

  /**
   * <pre>
   *   double toDevise (in double euro);
   * </pre>
   */
  public double toDevise (double euro);

}
