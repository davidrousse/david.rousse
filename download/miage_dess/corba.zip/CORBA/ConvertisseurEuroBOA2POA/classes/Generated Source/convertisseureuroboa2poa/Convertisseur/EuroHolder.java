package convertisseureuroboa2poa.Convertisseur;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/ConvertisseurEuroBOA2POA/src/convertisseureuroboa2poa/ConvertisseurEuro.idl"
 * <li> <b>IDL Name</b>      ::Convertisseur::Euro
 * <li> <b>Repository Id</b> IDL:Convertisseur/Euro:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Euro {
  ...
};
 * </pre>
 */
public final class EuroHolder implements org.omg.CORBA.portable.Streamable {
  public convertisseureuroboa2poa.Convertisseur.Euro value;

  public EuroHolder () {
  }

  public EuroHolder (final convertisseureuroboa2poa.Convertisseur.Euro _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = convertisseureuroboa2poa.Convertisseur.EuroHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    convertisseureuroboa2poa.Convertisseur.EuroHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return convertisseureuroboa2poa.Convertisseur.EuroHelper.type();
  }
}
