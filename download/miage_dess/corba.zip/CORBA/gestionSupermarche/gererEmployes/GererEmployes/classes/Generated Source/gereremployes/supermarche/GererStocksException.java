package gereremployes.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/gestionSupermarche/gererEmployes/GererEmployes/src/gereremployes/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksException
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererStocksException {
  ...
};
 * </pre>
 */
public final class GererStocksException extends org.omg.CORBA.UserException {
  
  public java.lang.String raison;

  public GererStocksException () {
    super(gereremployes.supermarche.GererStocksExceptionHelper.id());
  }

  public GererStocksException (java.lang.String raison) {
    this();
    this.raison = raison;
  }

  public GererStocksException (java.lang.String _reason, java.lang.String raison) {
    super(gereremployes.supermarche.GererStocksExceptionHelper.id() + ' ' + _reason);
    this.raison = raison;
  }

  public java.lang.String toString () {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("exception gereremployes.supermarche.GererStocksException {");
    _ret.append("\n");
    _ret.append("java.lang.String raison=");
    _ret.append(raison != null?'\"' + raison + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;
    if (o instanceof gereremployes.supermarche.GererStocksException) {
      final gereremployes.supermarche.GererStocksException obj = (gereremployes.supermarche.GererStocksException)o;
      boolean res = true;
      do {
        res = this.raison == obj.raison ||
         (this.raison != null && obj.raison != null && this.raison.equals(obj.raison));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
