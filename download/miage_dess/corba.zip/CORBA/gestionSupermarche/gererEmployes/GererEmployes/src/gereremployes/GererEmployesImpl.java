package gereremployes;

import gereremployes.supermarche.*;
import java.util.*;
import java.lang.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class GererEmployesImpl extends GererEmployesPOA{

    Hashtable _listeE;

    public Employe[] listeE()
    {
      // retourne la liste des employes
       Enumeration parcours = _listeE.elements();
       Employe[] listeEmployes = new Employe[_listeE.size()];;
       int i=0;

       while(parcours.hasMoreElements()) {
         listeEmployes[i] = (Employe)parcours.nextElement();
         i++;
       }

       return listeEmployes;
    }

    //contructeur
    public GererEmployesImpl()
    {
      _listeE = new Hashtable();

      //par defaut, on cree trois caissiers et un gerant d'agence
      Employe empl  = new Employe("david","rousse","Caissier");
      _listeE.put("david",empl);
      empl  = new Employe("gerant","miage","Gerant");
      _listeE.put("gerant",empl);
      empl  = new Employe("cathy","franco","Caissier");
      _listeE.put("cathy",empl);
      empl  = new Employe("laetitia","soulie","Caissier");
      _listeE.put("laetitia",empl);
    }

    //cr�ation d'un employ� � partir d'unlogin, d'un password et de droits
    public void creer(String login, String password, String droit) throws gereremployes.supermarche.GererEmployesException{
	if ( !_listeE.containsKey(login)){
	  Employe empl  = new Employe(login,password,droit);
	  _listeE.put(login,empl);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Cr�ation de l'employe impossible");
	}
    }

    //Cr�ation d'un employ� � partir d'un employ�
    public void creerE(Employe e) throws gereremployes.supermarche.GererEmployesException{
	if ( !_listeE.containsKey(e.login)){ //employe pas encore cree
	  _listeE.put(e.login,e);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Cr�ation de l'employe impossible!");
	}
    }

    //Modification d'un employ� � partir de son login
    public void modifier(String login, String password, String droit) throws gereremployes.supermarche.GererEmployesException{
	if(_listeE.containsKey(login)){ //employe existant
	  Employe e = new Employe(login,password,droit);
      	  _listeE.put(login,e);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Modification de l'employe impossible");
	}
    }

    //Modification d'un employ� � partir d'un employ�
    public void modifierE(Employe e) throws gereremployes.supermarche.GererEmployesException{
	if(_listeE.containsKey(e.login)){ //employe existant
	  _listeE.put(e.login,e);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Modification de l'employe impossible");;
	}
    }

    //Suppression d'un employ� � partir de son login
    public void supprimer(String login) throws gereremployes.supermarche.GererEmployesException{
        if(_listeE.containsKey(login)){ //employe existant
	    _listeE.remove(login);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Suppression impossible, l'employe est inexistant!");
	}
    }

    //Suppression d'un employ� � partir d'un employ�
    public void supprimerE(Employe e) throws gereremployes.supermarche.GererEmployesException{
      if(_listeE.containsKey(e.login)){ //employe existant
	  _listeE.remove(e.login);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Suppression impossible, l'employe est inexistant!");
	}
    }

    //Recherche d'un employ� � partir du login
    public Employe rechercher (String login) throws gereremployes.supermarche.GererEmployesException{
        if(_listeE.containsKey(login)){ //employe existant

	  return new Employe(login,((Employe)_listeE.get(login)).password,((Employe)_listeE.get(login)).droit);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Recherche impossible, l'employe est inexistant!");
	}
    }

    //Recherche de l'employ� � partir d'un employ�
    public Employe rechercherE (Employe e) throws gereremployes.supermarche.GererEmployesException{
        if(_listeE.containsKey(e.login)){ //employe existant
	  return new Employe(e.login,((Employe)_listeE.get(e.login)).password,((Employe)_listeE.get(e.login)).droit);
	}else{
	  throw new gereremployes.supermarche.GererEmployesException("Recherche impossible, l'employe est inexistant!");
	}
    }

  }
