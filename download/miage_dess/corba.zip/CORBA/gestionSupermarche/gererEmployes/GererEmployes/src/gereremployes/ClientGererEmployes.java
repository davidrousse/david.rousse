package gereremployes;

import gereremployes.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ClientGererEmployes {

  public static void main(String args[]) {

    try {
      // On intialise l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      // On construit le nom � chercher dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[1],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      // On recherche la r�f�rence aupr�s du naming service
      org.omg.CORBA.Object distant = racineArbre.resolve(nom);

      //casting de l'objet CORBA au type adequat
      GererEmployes monObj = gereremployes.supermarche.GererEmployesHelper.narrow(distant);

      try{
        monObj.rechercher("david");
         }
        catch(gereremployes.supermarche.GererEmployesException e) {
          System.out.println(e.toString());
          e.printStackTrace();
        }

      try{
        monObj.creer("david","d","tous");
        monObj.creer("cathy","c","tous");
        monObj.creer("laeti","l","tous");
         }
        catch(gereremployes.supermarche.GererEmployesException e) {
          System.out.println(e.toString());
          e.printStackTrace();
        }

        try{
          System.out.println("Test de la recherche avec login en param");
          System.out.println("Employe"+(monObj.rechercher("david")));
          System.out.println("Employe"+(monObj.rechercher("cathy")));
          System.out.println("Employe"+(monObj.rechercher("laeti")));
         }
        catch(gereremployes.supermarche.GererEmployesException e) {
          System.out.println(e.toString());
        }
        try{

          Employe e = new Employe();
          e = monObj.rechercher("david");
          System.out.println("Test de recherche avec employe en param");
          System.out.println("Employe"+(monObj.rechercherE(e)));
         }
        catch(gereremployes.supermarche.GererEmployesException e) {
          System.out.println(e.toString());
        }
        try{

          monObj.modifier("david","david","aucun");
          System.out.println("Employe"+(monObj.rechercher("david")));
         }
        catch(gereremployes.supermarche.GererEmployesException e) {
          System.out.println(e.toString());
        }
        try{
          monObj.supprimer("laeti");
         }
        catch(gereremployes.supermarche.GererEmployesException e) {
          System.out.println(e.toString());
        }
        Employe [] tabEmpl = monObj.listeE();
        for(int i = 0; i<tabEmpl.length;i++)
            System.out.println("Employe =>"+tabEmpl[i]);
  }
    catch (Exception e) {
      e.printStackTrace();
    }
  }//fin du main

}