package persistancedonnees;

/**
 * Title:        Classe d'acc�s aux donn�es
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class TestClientEcritureDonnees {

  public static void main(String args[]) {
    try {
      EcritureDonnees ecriture = new EcritureDonnees(args[0]);
      LectureDonnees lecture = new LectureDonnees(args[0]);
      int i=0, iDebut=1501, nombre=100;

      //test ecriture
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++) {
          String valeur = new Integer(i).toString();
          ecriture.inserer(i+"\tProduit\t"+i+"\t"+(new Float(valeur)));
          System.out.println("Insertion de ["+(new Integer(i)).toString()+"] OK");
        }
      }
      catch(NullPointerException e) {
        System.out.println("Non insere : "+i);
      }

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}