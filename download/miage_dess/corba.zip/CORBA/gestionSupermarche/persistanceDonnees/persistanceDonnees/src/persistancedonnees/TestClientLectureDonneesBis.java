package persistancedonnees;

/**
 * Title:        Classe d'acc�s aux donn�es
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class TestClientLectureDonneesBis {

  public static void main(String args[]) {
    try {
      LectureDonnees lecture = new LectureDonnees(args[0]);
      int i=0, iDebut=1, nombre=150;

      //test lecture
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++)
          System.out.println(lecture.rechercher((new Integer(i)).toString()));
      }
      catch(NullPointerException e) {
        System.out.println("Non trouv� : "+i);
      }

      lecture.fermerSource();

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}