package persistancedonnees;

/**
 * Title:        Classe d'acc�s aux donn�es
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

import java.io.*;
import java.util.StringTokenizer;

public class EcritureDonnees {

  private String nomSource;
  private File fichier;

  public EcritureDonnees(String source) {
    try {
      nomSource = source;
      fichier = new File (nomSource);
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }

  synchronized public void mettreAJour(String cle, String nouvelleValeur) {
    try {
      // recuperation de la taille du fichier ouvert
      int taille = (int)fichier.length();

      // variable pour lire le nom de caracteres lus dans le fichier
      int chars_lus = 0;

      //flux de lecture
      FileReader in = new FileReader(fichier);

      //tampon de lecture
      BufferedReader tampon = new BufferedReader(in);

      //chaine � ecrire
      String texte = new String();
      String ligneLue = new String();
      StringTokenizer decouperLigne;
      String cleLue;

      //lecture du flux
      while(tampon.ready()) {
        ligneLue = tampon.readLine();
        if(!ligneLue.equalsIgnoreCase("")) {
          decouperLigne = new StringTokenizer(ligneLue,"\t");
          cleLue = decouperLigne.nextToken();
          if(!cleLue.equalsIgnoreCase(cle))
            texte = texte + "\n"+ ligneLue;
          else
            texte = texte + "\n"+ nouvelleValeur;
        }
      }
      tampon.close();

      //flux de sortie
      FileWriter out = new FileWriter(fichier);

      //ecriture
      out.write(texte);

      //fermeture flux
      out.close();
    }
    catch (Exception e){
      System.out.println("Erreur mise a jour "+cle);
      e.printStackTrace();
    }
  }

  synchronized public void supprimer(String cle) {
    try {
      // recuperation de la taille du fichier ouvert
      int taille = (int)fichier.length();

      // variable pour lire le nom de caracteres lus dans le fichier
      int chars_lus = 0;

      //flux de lecture
      FileReader in = new FileReader(fichier);

      //tampon de lecture
      BufferedReader tampon = new BufferedReader(in);

      //chaine � ecrire
      String texte = new String();
      String ligneLue = new String();

      //lecture du flux
      while(tampon.ready()) {
        ligneLue = tampon.readLine();
        if(!ligneLue.startsWith(cle))
          texte = texte + "\n"+ ligneLue;
      }
      tampon.close();

      //flux de sortie
      FileWriter out = new FileWriter(fichier);

      //ecriture
      out.write(texte);

      //fermeture flux
      out.close();
    }
    catch (Exception e){
      System.out.println("Erreur suppression "+cle);
      e.printStackTrace();
    }
  }

  synchronized public void inserer(String valeur) {
    try {
      // recuperation de la taille du fichier ouvert
      int taille = (int)fichier.length();

      // variable pour lire le nom de caracteres lus dans le fichier
      int chars_lus = 0;

      //flux de lecture
      FileReader in = new FileReader(fichier);

      //tampon
      char[] tampon = new char[taille];

      //lecture du flux
      while(in.ready()) {
        chars_lus += in.read(tampon, chars_lus, taille - chars_lus);
      }
      in.close();

      //chaine � ecrire
      String texte = new String(tampon, 0, chars_lus);

      //flux de sortie
      FileWriter out = new FileWriter(fichier);

      //ajout de la donnee
      texte = texte + "\n" + valeur;

      //ecriture
      out.write(texte);

      //fermeture flux
      out.close();
    }
    catch (Exception e){
      System.out.println("Erreur insertion "+valeur);
      e.printStackTrace();
    }
  }
}