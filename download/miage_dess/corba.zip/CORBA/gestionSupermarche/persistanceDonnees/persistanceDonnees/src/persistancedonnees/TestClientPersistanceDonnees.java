package persistancedonnees;

/**
 * Title:        Classe d'acc�s aux donn�es
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class TestClientPersistanceDonnees {

  public static void main(String args[]) {
    try {
      EcritureDonnees ecriture = new EcritureDonnees(args[0]);
      LectureDonnees lecture = new LectureDonnees(args[0]);
      int i=0, iDebut=1, nombre=10;

      //test ecriture
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++) {
          String valeur = new Integer(i).toString();
          ecriture.inserer(i+"\tProduit\t"+i+"\t"+(new Float(valeur)));
          System.out.println("Insertion de ["+(new Integer(i)).toString()+"] OK");
        }
      }
      catch(NullPointerException e) {
        System.out.println("Non insere : "+i);
      }

      //test lecture apres insertion
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++)
          System.out.println(lecture.rechercher((new Integer(i)).toString()));
      }
      catch(NullPointerException e) {
        System.out.println("Non trouv� : "+i);
      }

      //test mise � jour
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++) {
          ecriture.mettreAJour((new Integer(i)).toString(),"0\tGod\t0,00");
          System.out.println(lecture.rechercher((new Integer(0)).toString()));
        }
      }
      catch(NullPointerException e) {
        System.out.println("Non maj : "+i);
      }

      //test supprimer
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++) {
          String valeur = new Integer(i).toString();
          ecriture.supprimer((new Integer(i)).toString());
          System.out.println("Suppression de ["+(new Integer(i)).toString()+"] OK");
        }
      }
      catch(NullPointerException e) {
        System.out.println("Non supprime : "+i);
      }

      //test ecriture apres suppression
      try{
        for(i=iDebut;i<iDebut+2*nombre;i++) {
          String valeur = new Integer(i).toString();
          ecriture.inserer(i+"\tProduit\t"+i+"\t"+(new Float(valeur)));
          System.out.println("Insertion de ["+(new Integer(i)).toString()+"] OK");
        }
      }
      catch(NullPointerException e) {
        System.out.println("Non insere : "+i);
      }

      lecture.fermerSource();

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}