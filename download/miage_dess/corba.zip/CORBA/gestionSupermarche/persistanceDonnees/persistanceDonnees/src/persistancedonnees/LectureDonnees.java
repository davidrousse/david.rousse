package persistancedonnees;

/**
 * Title:        Classe d'acc�s aux donn�es
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

import java.io.*;

public class LectureDonnees {

  private String nomSource;
  private BufferedReader tampon;
  private File fichier;
  private BufferedReader tamponLecture;


  public LectureDonnees(String source) {
    try
    {
      nomSource = source;
      fichier = new File(nomSource);
      tamponLecture = new BufferedReader(new FileReader(fichier));
    }
    catch (Exception e){
      System.out.println("Erreur ouverture fichier "+source);
      e.printStackTrace();
    }
  }

  public void fermerSource()  {
    try {
      //fermeture tampon lecture
      tamponLecture.close();
    }
    catch (IOException e){
      System.out.println("Erreur fermeture fichier "+nomSource);
      e.printStackTrace();
    }
  }

  public String rechercher(String cle) throws IOException{
    try
    {
      //tamponLecture = new BufferedReader(new FileReader(fichier));

      String ligneLue;
      while(!(ligneLue = tamponLecture.readLine()).startsWith(cle));

      return ligneLue;
    }
    catch (IOException e){
      System.out.println("Erreur recherche : valeur de cle "+cle);
      e.printStackTrace();
      return "erreur";
    }
  }
}