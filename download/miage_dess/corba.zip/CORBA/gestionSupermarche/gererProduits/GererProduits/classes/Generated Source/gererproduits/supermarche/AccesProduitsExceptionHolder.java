package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduitsException
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduitsException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception AccesProduitsException {
  ...
};
 * </pre>
 */
public final class AccesProduitsExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public gererproduits.supermarche.AccesProduitsException value;

  public AccesProduitsExceptionHolder () {
  }

  public AccesProduitsExceptionHolder (final gererproduits.supermarche.AccesProduitsException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gererproduits.supermarche.AccesProduitsExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gererproduits.supermarche.AccesProduitsExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gererproduits.supermarche.AccesProduitsExceptionHelper.type();
  }
}
