package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployesOperations {
  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gererproduits.supermarche.Employe[] listeE ();

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void creerE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gererproduits.supermarche.Employe e) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifierE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gererproduits.supermarche.Employe e) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimerE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gererproduits.supermarche.Employe e) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gererproduits.supermarche.Employe rechercher (in string login)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public gererproduits.supermarche.Employe rechercher (java.lang.String login) throws gererproduits.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gererproduits.supermarche.Employe rechercherE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public gererproduits.supermarche.Employe rechercherE (gererproduits.supermarche.Employe e) throws gererproduits.supermarche.GererEmployesException;

}
