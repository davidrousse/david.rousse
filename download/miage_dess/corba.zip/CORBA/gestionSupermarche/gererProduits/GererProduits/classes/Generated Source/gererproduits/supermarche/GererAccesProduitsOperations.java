package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public interface GererAccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public gererproduits.supermarche.AccesProduits[] listeAP ();

  /**
   * <pre>
   *   gererproduits.supermarche.AccesProduits creer (in string agence)
    raises (gererproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.AccesProduits creer (java.lang.String agence) throws gererproduits.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (gererproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws gererproduits.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   gererproduits.supermarche.AccesProduits rechercher (in string agence)
    raises (gererproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.AccesProduits rechercher (java.lang.String agence) throws gererproduits.supermarche.GererAccesProduitsException;

}
