package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public class AccesProduitsPOATie extends AccesProduitsPOA {
  private gererproduits.supermarche.AccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public AccesProduitsPOATie (final gererproduits.supermarche.AccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public AccesProduitsPOATie (final gererproduits.supermarche.AccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererproduits.supermarche.AccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererproduits.supermarche.AccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercher (in string codeBarre)
    raises (gererproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gererproduits.supermarche.AccesProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercherP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercherP (gererproduits.supermarche.Produit p) throws  gererproduits.supermarche.AccesProduitsException {
    return this._delegate.rechercherP(p);
  }

}
