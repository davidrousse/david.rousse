
package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/listeAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgererproduits.supermarche.AccesProduits&gt listeAccesProduits;
 * </pre>
 */
public final class listeAccesProduitsHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static gererproduits.supermarche.AccesProduits[] read (final org.omg.CORBA.portable.InputStream _input) {
    gererproduits.supermarche.AccesProduits[] result;
    final int $length12 = _input.read_long();
    result = new gererproduits.supermarche.AccesProduits[$length12];
    for (int $counter13 = 0; $counter13 < $length12; $counter13++) {
      result[$counter13] = gererproduits.supermarche.AccesProduitsHelper.read(_input);
    }
    return result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final gererproduits.supermarche.AccesProduits[] _vis_value) {
    _output.write_long(_vis_value.length);
    for (int $counter14 = 0;  $counter14 < _vis_value.length; $counter14++) {
      gererproduits.supermarche.AccesProduitsHelper.write(_output, _vis_value[$counter14]);
    }
  }

  public static void insert (final org.omg.CORBA.Any any, final gererproduits.supermarche.AccesProduits[] _vis_value) {
    any.type(gererproduits.supermarche.listeAccesProduitsHelper.type());
    any.insert_Streamable(new gererproduits.supermarche.listeAccesProduitsHolder(_vis_value));
  }

  public static gererproduits.supermarche.AccesProduits[] extract (final org.omg.CORBA.Any any) {
    gererproduits.supermarche.AccesProduits[] _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      gererproduits.supermarche.listeAccesProduitsHolder _vis_holder = new gererproduits.supermarche.listeAccesProduitsHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    } else {
      _vis_value = gererproduits.supermarche.listeAccesProduitsHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          org.omg.CORBA.TypeCode originalType = _orb().create_sequence_tc(0, gererproduits.supermarche.AccesProduitsHelper.type());
          _type = _orb().create_alias_tc(id(), "listeAccesProduits", originalType);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/listeAccesProduits:1.0";
  }
}
