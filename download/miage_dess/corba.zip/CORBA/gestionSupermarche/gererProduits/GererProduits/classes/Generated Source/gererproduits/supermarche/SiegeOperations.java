package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public interface SiegeOperations {
  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeAgences listeA;
   * </pre>
   */
  public java.lang.String[] listeA ();

  /**
   * <pre>
   *   void inscrire (in string agence)
    raises (gererproduits.supermarche.SiegeException);
   * </pre>
   */
  public void inscrire (java.lang.String agence) throws gererproduits.supermarche.SiegeException;

  /**
   * <pre>
   *   void desinscrire (in string agence)
    raises (gererproduits.supermarche.SiegeException);
   * </pre>
   */
  public void desinscrire (java.lang.String agence) throws gererproduits.supermarche.SiegeException;

}
