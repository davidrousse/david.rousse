package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployes extends com.inprise.vbroker.CORBA.Object, gererproduits.supermarche.GererEmployesOperations, org.omg.CORBA.portable.IDLEntity {
}
