package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercher (in string codeBarre)
    raises (gererproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercher (java.lang.String codeBarre) throws gererproduits.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercherP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercherP (gererproduits.supermarche.Produit p) throws gererproduits.supermarche.AccesProduitsException;

}
