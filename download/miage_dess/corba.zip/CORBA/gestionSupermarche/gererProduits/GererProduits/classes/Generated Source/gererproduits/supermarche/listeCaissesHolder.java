package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeCaisses
 * <li> <b>Repository Id</b> IDL:supermarche/listeCaisses:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgererproduits.supermarche.Caisse&gt listeCaisses;
 * </pre>
 */
public final class listeCaissesHolder implements org.omg.CORBA.portable.Streamable {
  public gererproduits.supermarche.Caisse[] value;

  public listeCaissesHolder () {
  }

  public listeCaissesHolder (final gererproduits.supermarche.Caisse[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gererproduits.supermarche.listeCaissesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gererproduits.supermarche.listeCaissesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gererproduits.supermarche.listeCaissesHelper.type();
  }
}
