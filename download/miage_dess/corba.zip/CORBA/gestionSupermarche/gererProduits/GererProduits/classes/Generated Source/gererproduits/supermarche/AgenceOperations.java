package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public interface AgenceOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeCaisses listeC;
   * </pre>
   */
  public gererproduits.supermarche.Caisse[] listeC ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge);

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public double TVA ();

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public void TVA (double TVA);

  /**
   * <pre>
   *   gererproduits.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (gererproduits.supermarche.AgenceException);
   * </pre>
   */
  public gererproduits.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws gererproduits.supermarche.AgenceException;

  /**
   * <pre>
   *   gererproduits.supermarche.Caisse creer (in string login, in string agence,
                                          in string loginCaissier)
    raises (gererproduits.supermarche.AgenceException);
   * </pre>
   */
  public gererproduits.supermarche.Caisse creer (java.lang.String login, 
                                                 java.lang.String agence, 
                                                 java.lang.String loginCaissier) throws gererproduits.supermarche.AgenceException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gererproduits.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gererproduits.supermarche.AgenceException;

  /**
   * <pre>
   *   gererproduits.supermarche.Caisse rechercher (in string login)
    raises (gererproduits.supermarche.AgenceException);
   * </pre>
   */
  public gererproduits.supermarche.Caisse rechercher (java.lang.String login) throws gererproduits.supermarche.AgenceException;

}
