package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public class GererAccesProduitsPOATie extends GererAccesProduitsPOA {
  private gererproduits.supermarche.GererAccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererAccesProduitsPOATie (final gererproduits.supermarche.GererAccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererAccesProduitsPOATie (final gererproduits.supermarche.GererAccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererproduits.supermarche.GererAccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererproduits.supermarche.GererAccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public gererproduits.supermarche.AccesProduits[] listeAP () {
    return this._delegate.listeAP();
  }

  /**
   * <pre>
   *   gererproduits.supermarche.AccesProduits creer (in string agence)
    raises (gererproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.AccesProduits creer (java.lang.String agence) throws  gererproduits.supermarche.GererAccesProduitsException {
    return this._delegate.creer(agence);
  }

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (gererproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws  gererproduits.supermarche.GererAccesProduitsException {
    this._delegate.supprimer(agence);
  }

  /**
   * <pre>
   *   gererproduits.supermarche.AccesProduits rechercher (in string agence)
    raises (gererproduits.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.AccesProduits rechercher (java.lang.String agence) throws  gererproduits.supermarche.GererAccesProduitsException {
    return this._delegate.rechercher(agence);
  }

}
