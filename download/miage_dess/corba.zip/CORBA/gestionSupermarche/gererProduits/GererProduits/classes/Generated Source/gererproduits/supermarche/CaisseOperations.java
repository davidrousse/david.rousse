package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public interface CaisseOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public double totalVentes ();

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public void totalVentes (double totalVentes);

  /**
   * <pre>
   *   readonly attribute string agence;
   * </pre>
   */
  public java.lang.String agence ();

  /**
   * <pre>
   *   readonly attribute string caissier;
   * </pre>
   */
  public java.lang.String caissier ();

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (gererproduits.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws gererproduits.supermarche.CaisseException;

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       int qte) throws gererproduits.supermarche.CaisseException;

  /**
   * <pre>
   *   void editerTicket ()
    raises (gererproduits.supermarche.CaisseException);
   * </pre>
   */
  public void editerTicket () throws gererproduits.supermarche.CaisseException;

  /**
   * <pre>
   *   void connecter (in string login, in string password)
    raises (gererproduits.supermarche.CaisseException);
   * </pre>
   */
  public void connecter (java.lang.String login, 
                         java.lang.String password) throws gererproduits.supermarche.CaisseException;

  /**
   * <pre>
   *   void deconnecter (in string login)
    raises (gererproduits.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login) throws gererproduits.supermarche.CaisseException;

}
