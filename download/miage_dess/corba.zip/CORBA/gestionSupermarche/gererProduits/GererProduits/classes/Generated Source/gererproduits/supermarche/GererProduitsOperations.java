package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gererproduits.supermarche.Produit p) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gererproduits.supermarche.Produit p) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gererproduits.supermarche.Produit p) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercher (in string codeBarre)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercher (java.lang.String codeBarre) throws gererproduits.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercherP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.GererProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercherP (gererproduits.supermarche.Produit p) throws gererproduits.supermarche.GererProduitsException;

}
