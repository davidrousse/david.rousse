package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public final class AgenceHolder implements org.omg.CORBA.portable.Streamable {
  public gererproduits.supermarche.Agence value;

  public AgenceHolder () {
  }

  public AgenceHolder (final gererproduits.supermarche.Agence _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gererproduits.supermarche.AgenceHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gererproduits.supermarche.AgenceHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gererproduits.supermarche.AgenceHelper.type();
  }
}
