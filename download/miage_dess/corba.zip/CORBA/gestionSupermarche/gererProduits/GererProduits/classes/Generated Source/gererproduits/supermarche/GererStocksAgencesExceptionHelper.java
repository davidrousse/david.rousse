package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgencesException
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgencesException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererStocksAgencesException {
  ...
};
 * </pre>
 */
public final class GererStocksAgencesExceptionHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static gererproduits.supermarche.GererStocksAgencesException read (final org.omg.CORBA.portable.InputStream _input) {
    if (!_input.read_string().equals(id())) {
      throw new org.omg.CORBA.MARSHAL("Mismatched repository id");
    }
    final gererproduits.supermarche.GererStocksAgencesException _result = new gererproduits.supermarche.GererStocksAgencesException();
    _result.raison = _input.read_string();
    return _result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final gererproduits.supermarche.GererStocksAgencesException _vis_value) {
    _output.write_string(id());
    _output.write_string((java.lang.String)_vis_value.raison);
  }

  public static void insert (final org.omg.CORBA.Any any, final gererproduits.supermarche.GererStocksAgencesException _vis_value) {
    any.insert_Streamable(new gererproduits.supermarche.GererStocksAgencesExceptionHolder(_vis_value));
  }

  public static gererproduits.supermarche.GererStocksAgencesException extract (final org.omg.CORBA.Any any) {
    gererproduits.supermarche.GererStocksAgencesException _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      gererproduits.supermarche.GererStocksAgencesExceptionHolder _vis_holder = new gererproduits.supermarche.GererStocksAgencesExceptionHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    }
    else {
      _vis_value = gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          final org.omg.CORBA.StructMember[] members = new org.omg.CORBA.StructMember[1];
          members[0] = new org.omg.CORBA.StructMember("raison", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string), null);
          _type = _orb().create_exception_tc(id(), "GererStocksAgencesException", members);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/GererStocksAgencesException:1.0";
  }
}
