package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public class GererStocksPOATie extends GererStocksPOA {
  private gererproduits.supermarche.GererStocksOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksPOATie (final gererproduits.supermarche.GererStocksOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksPOATie (final gererproduits.supermarche.GererStocksOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererproduits.supermarche.GererStocksOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererproduits.supermarche.GererStocksOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeStocks listeS;
   * </pre>
   */
  public gererproduits.supermarche.Stock[] listeS () {
    return this._delegate.listeS();
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws  gererproduits.supermarche.GererStocksException {
    this._delegate.creer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void creerS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gererproduits.supermarche.Stock s) throws  gererproduits.supermarche.GererStocksException {
    this._delegate.creerS(s);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws  gererproduits.supermarche.GererStocksException {
    this._delegate.incrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void incrementerS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gererproduits.supermarche.Stock s) throws  gererproduits.supermarche.GererStocksException {
    this._delegate.incrementerS(s);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws  gererproduits.supermarche.GererStocksException {
    this._delegate.decrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void decrementerS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gererproduits.supermarche.Stock s) throws  gererproduits.supermarche.GererStocksException {
    this._delegate.decrementerS(s);
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercher (in string codeBarre)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercher (java.lang.String codeBarre) throws  gererproduits.supermarche.GererStocksException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercherS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercherS (gererproduits.supermarche.Stock s) throws  gererproduits.supermarche.GererStocksException {
    return this._delegate.rechercherS(s);
  }

}
