package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::SiegeException
 * <li> <b>Repository Id</b> IDL:supermarche/SiegeException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception SiegeException {
  ...
};
 * </pre>
 */
public final class SiegeException extends org.omg.CORBA.UserException {
  
  public java.lang.String raison;

  public SiegeException () {
    super(gererproduits.supermarche.SiegeExceptionHelper.id());
  }

  public SiegeException (java.lang.String raison) {
    this();
    this.raison = raison;
  }

  public SiegeException (java.lang.String _reason, java.lang.String raison) {
    super(gererproduits.supermarche.SiegeExceptionHelper.id() + ' ' + _reason);
    this.raison = raison;
  }

  public java.lang.String toString () {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("exception gererproduits.supermarche.SiegeException {");
    _ret.append("\n");
    _ret.append("java.lang.String raison=");
    _ret.append(raison != null?'\"' + raison + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;
    if (o instanceof gererproduits.supermarche.SiegeException) {
      final gererproduits.supermarche.SiegeException obj = (gererproduits.supermarche.SiegeException)o;
      boolean res = true;
      do {
        res = this.raison == obj.raison ||
         (this.raison != null && obj.raison != null && this.raison.equals(obj.raison));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
