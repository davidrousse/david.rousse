package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/listeEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgererproduits.supermarche.Employe&gt listeEmployes;
 * </pre>
 */
public final class listeEmployesHolder implements org.omg.CORBA.portable.Streamable {
  public gererproduits.supermarche.Employe[] value;

  public listeEmployesHolder () {
  }

  public listeEmployesHolder (final gererproduits.supermarche.Employe[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gererproduits.supermarche.listeEmployesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gererproduits.supermarche.listeEmployesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gererproduits.supermarche.listeEmployesHelper.type();
  }
}
