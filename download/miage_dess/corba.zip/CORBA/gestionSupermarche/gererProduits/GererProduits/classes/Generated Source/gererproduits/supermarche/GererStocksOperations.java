package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public interface GererStocksOperations {
  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeStocks listeS;
   * </pre>
   */
  public gererproduits.supermarche.Stock[] listeS ();

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   void creerS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gererproduits.supermarche.Stock s) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementerS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gererproduits.supermarche.Stock s) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementerS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gererproduits.supermarche.Stock s) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercher (in string codeBarre)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercher (java.lang.String codeBarre) throws gererproduits.supermarche.GererStocksException;

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercherS (in gererproduits.supermarche.Stock s)
    raises (gererproduits.supermarche.GererStocksException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercherS (gererproduits.supermarche.Stock s) throws gererproduits.supermarche.GererStocksException;

}
