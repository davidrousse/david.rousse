package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public class _GererStocksAgencesStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements GererStocksAgences {
  final public static java.lang.Class _opsClass = gererproduits.supermarche.GererStocksAgencesOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererStocksAgences:1.0"
  };

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          _self.creer(codeBarre, qte, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void creerS (in gererproduits.supermarche.Stock s, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gererproduits.supermarche.Stock s, 
                      java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("creerS", true);
          gererproduits.supermarche.StockHelper.write(_output, s);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          _self.creerS(s, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("incrementer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("incrementer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          _self.incrementer(codeBarre, qte, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void incrementerS (in gererproduits.supermarche.Stock s, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gererproduits.supermarche.Stock s, 
                            java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("incrementerS", true);
          gererproduits.supermarche.StockHelper.write(_output, s);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("incrementerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          _self.incrementerS(s, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("decrementer", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_long((int)qte);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("decrementer", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          _self.decrementer(codeBarre, qte, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void decrementerS (in gererproduits.supermarche.Stock s, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gererproduits.supermarche.Stock s, 
                            java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("decrementerS", true);
          gererproduits.supermarche.StockHelper.write(_output, s);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("decrementerS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          _self.decrementerS(s, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercher (in string codeBarre,
                                              in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                     java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gererproduits.supermarche.Stock _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
          _result = gererproduits.supermarche.StockHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          return _self.rechercher(codeBarre, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercherS (in gererproduits.supermarche.Stock s,
                                               in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercherS (gererproduits.supermarche.Stock s, 
                                                      java.lang.String agence) throws  gererproduits.supermarche.GererStocksAgencesException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gererproduits.supermarche.Stock _result;
        try {
          _output = this._request("rechercherS", true);
          gererproduits.supermarche.StockHelper.write(_output, s);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
          _result = gererproduits.supermarche.StockHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.GererStocksAgencesExceptionHelper.id())) {
            throw             gererproduits.supermarche.GererStocksAgencesExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.GererStocksAgencesOperations _self = (gererproduits.supermarche.GererStocksAgencesOperations)_so.servant;
        try {
          return _self.rechercherS(s, agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
