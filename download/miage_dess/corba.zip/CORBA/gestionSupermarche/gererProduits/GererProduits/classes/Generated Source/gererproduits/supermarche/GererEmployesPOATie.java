package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class GererEmployesPOATie extends GererEmployesPOA {
  private gererproduits.supermarche.GererEmployesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererEmployesPOATie (final gererproduits.supermarche.GererEmployesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererEmployesPOATie (final gererproduits.supermarche.GererEmployesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gererproduits.supermarche.GererEmployesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gererproduits.supermarche.GererEmployesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gererproduits.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gererproduits.supermarche.Employe[] listeE () {
    return this._delegate.listeE();
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  gererproduits.supermarche.GererEmployesException {
    this._delegate.creer(login, password, droit);
  }

  /**
   * <pre>
   *   void creerE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gererproduits.supermarche.Employe e) throws  gererproduits.supermarche.GererEmployesException {
    this._delegate.creerE(e);
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  gererproduits.supermarche.GererEmployesException {
    this._delegate.modifier(login, password, droit);
  }

  /**
   * <pre>
   *   void modifierE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gererproduits.supermarche.Employe e) throws  gererproduits.supermarche.GererEmployesException {
    this._delegate.modifierE(e);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  gererproduits.supermarche.GererEmployesException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   void supprimerE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gererproduits.supermarche.Employe e) throws  gererproduits.supermarche.GererEmployesException {
    this._delegate.supprimerE(e);
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Employe rechercher (in string login)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public gererproduits.supermarche.Employe rechercher (java.lang.String login) throws  gererproduits.supermarche.GererEmployesException {
    return this._delegate.rechercher(login);
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Employe rechercherE (in gererproduits.supermarche.Employe e)
    raises (gererproduits.supermarche.GererEmployesException);
   * </pre>
   */
  public gererproduits.supermarche.Employe rechercherE (gererproduits.supermarche.Employe e) throws  gererproduits.supermarche.GererEmployesException {
    return this._delegate.rechercherE(e);
  }

}
