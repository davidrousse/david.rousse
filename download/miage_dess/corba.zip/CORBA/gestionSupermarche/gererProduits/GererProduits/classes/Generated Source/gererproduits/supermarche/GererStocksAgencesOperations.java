package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public interface GererStocksAgencesOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void creerS (in gererproduits.supermarche.Stock s, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gererproduits.supermarche.Stock s, 
                      java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementerS (in gererproduits.supermarche.Stock s, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gererproduits.supermarche.Stock s, 
                            java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementerS (in gererproduits.supermarche.Stock s, in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gererproduits.supermarche.Stock s, 
                            java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercher (in string codeBarre,
                                              in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                     java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gererproduits.supermarche.Stock rechercherS (in gererproduits.supermarche.Stock s,
                                               in string agence)
    raises (gererproduits.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gererproduits.supermarche.Stock rechercherS (gererproduits.supermarche.Stock s, 
                                                      java.lang.String agence) throws gererproduits.supermarche.GererStocksAgencesException;

}
