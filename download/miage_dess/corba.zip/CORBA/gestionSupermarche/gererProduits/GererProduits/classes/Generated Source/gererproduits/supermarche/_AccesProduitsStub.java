package gererproduits.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gererProduits/GererProduits/src/gererproduits/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public class _AccesProduitsStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements AccesProduits {
  final public static java.lang.Class _opsClass = gererproduits.supermarche.AccesProduitsOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/AccesProduits:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomObjet", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomObjet", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.AccesProduitsOperations _self = (gererproduits.supermarche.AccesProduitsOperations)_so.servant;
        try {
          return _self.nomObjet();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercher (in string codeBarre)
    raises (gererproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gererproduits.supermarche.AccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gererproduits.supermarche.Produit _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = gererproduits.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.AccesProduitsExceptionHelper.id())) {
            throw             gererproduits.supermarche.AccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.AccesProduitsOperations _self = (gererproduits.supermarche.AccesProduitsOperations)_so.servant;
        try {
          return _self.rechercher(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   gererproduits.supermarche.Produit rechercherP (in gererproduits.supermarche.Produit p)
    raises (gererproduits.supermarche.AccesProduitsException);
   * </pre>
   */
  public gererproduits.supermarche.Produit rechercherP (gererproduits.supermarche.Produit p) throws  gererproduits.supermarche.AccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        gererproduits.supermarche.Produit _result;
        try {
          _output = this._request("rechercherP", true);
          gererproduits.supermarche.ProduitHelper.write(_output, p);
          _input = this._invoke(_output);
          _result = gererproduits.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gererproduits.supermarche.AccesProduitsExceptionHelper.id())) {
            throw             gererproduits.supermarche.AccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherP", _opsClass);
        if (_so == null) {
          continue;
        }
        final gererproduits.supermarche.AccesProduitsOperations _self = (gererproduits.supermarche.AccesProduitsOperations)_so.servant;
        try {
          return _self.rechercherP(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
