package gererproduits;

import gererproduits.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ClientGererProduits {

  public static void main(String args[]) {

    try {
      // On intialise l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      // On construit le nom � chercher dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[1],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      // On recherche la r�f�rence aupr�s du naming service
      org.omg.CORBA.Object distant = racineArbre.resolve(nom);

      //casting de l'objet CORBA au type adequat
      GererProduits monObj = gererproduits.supermarche.GererProduitsHelper.narrow(distant);

      // On appelle les methodes
      for(int i=1;i<50;i++) {
        String produit = new String("Produit "+i);
        double prix=i;
        try {
          //monObj.creer((new Integer(i)).toString(),produit,prix);
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");
          //monObj.modifier((new Integer(i)).toString(),produit,prix+10.0);
          System.out.println("Resultat :\n"+monObj.rechercher((new Integer(i)).toString())+"\n********\n");

        }
        catch(gererproduits.supermarche.GererProduitsException e) {
          System.out.println(e.toString());
        }
      }

      for(int i=51;i<100;i++) {
        String produit = new String("Produit "+i);
        double prix=i;
        try {
          Produit p = new Produit((new Integer(i)).toString(),produit,prix);
          //monObj.creerP(p);
          System.out.println("Resultat :\n"+monObj.rechercherP(p)+"\n********\n");
          p.prixHT+=10.0;
          //monObj.modifierP(p);
          System.out.println("Resultat :\n"+monObj.rechercherP(p)+"\n********\n");
        }
        catch(gererproduits.supermarche.GererProduitsException e) {
          System.out.println(e.toString());
        }

      }


    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }//fin du main
}