package gererproduits;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

import java.io.*;

public class LectureDonnees {

  private String nomSource;
  private File fichier;
  private BufferedReader tamponLecture;


  public LectureDonnees(String source) {
    try
    {
      nomSource = source;
      fichier = new File(nomSource);
    }
    catch (Exception e){
      System.out.println("Erreur ouverture fichier "+source);
      e.printStackTrace();
    }
  }

  public void mettreAJour() {
    try
    {
      tamponLecture.close();
      fichier = new File(nomSource);
    }
    catch (Exception e){
      System.out.println("Erreur mise a jour fichier "+nomSource);
      e.printStackTrace();
    }
  }
  public void fermerSource()  {
    try {
      //fermeture tampon lecture
      tamponLecture.close();
    }
    catch (IOException e){
      System.out.println("Erreur fermeture fichier "+nomSource);
      e.printStackTrace();
    }
  }

  public String rechercher(String cle) throws IOException {
      String ligneLue;

      tamponLecture = new BufferedReader(new FileReader(fichier));
      while(!(ligneLue = tamponLecture.readLine()).startsWith(cle));

      return ligneLue;
  }
}