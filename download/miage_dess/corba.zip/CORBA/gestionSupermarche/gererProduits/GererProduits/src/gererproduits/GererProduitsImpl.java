package gererproduits;

import gererproduits.supermarche.*;
import java.util.StringTokenizer;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class GererProduitsImpl extends GererProduitsPOA {

  private String _nomObjet;
  private String _nomFichier;

  public GererProduitsImpl(String nomObjet,String nomFichier) {
    _nomFichier = new String(nomFichier);
    _nomObjet = new String(nomObjet);
  }
  public void supprimerP(Produit p) throws gererproduits.supermarche.GererProduitsException {
    try {
      EcritureDonnees ecriture = new EcritureDonnees(_nomFichier);
      ecriture.supprimer(p.codeBarre);
      System.out.println(_nomObjet+" - Suppression de ["+p.codeBarre+"] OK");
    }
    catch(Exception e) {
      System.out.println("Erreur suppression dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre+" - Exception : "+e);
      throw new gererproduits.supermarche.GererProduitsException("Erreur suppression dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre);
    }
  }
  public void modifier(String codeBarre, String designation, double prixHT) throws gererproduits.supermarche.GererProduitsException {
    try{
      EcritureDonnees ecriture = new EcritureDonnees(_nomFichier);
      ecriture.mettreAJour(codeBarre,codeBarre+"\t"+designation+"\t"+prixHT);
      System.out.println(_nomObjet+" - Modification de ["+codeBarre+"] OK");
    }
    catch(Exception e) {
      System.out.println("Erreur modification dans "+_nomObjet+" : valeur de codeBarre "+codeBarre+" - Exception : "+e);
      throw new gererproduits.supermarche.GererProduitsException("Erreur modification dans "+_nomObjet+" : valeur de codeBarre "+codeBarre);
    }
  }
  public void supprimer(String codeBarre) throws gererproduits.supermarche.GererProduitsException {
    try{
      EcritureDonnees ecriture = new EcritureDonnees(_nomFichier);
      ecriture.supprimer(codeBarre);
      System.out.println(_nomObjet+" - Suppression de ["+codeBarre+"] OK");
    }
    catch(Exception e) {
      System.out.println("Erreur suppression dans "+_nomObjet+" : valeur de codeBarre "+codeBarre+" - Exception : "+e);
      throw new gererproduits.supermarche.GererProduitsException("Erreur suppression dans "+_nomObjet+" : valeur de codeBarre "+codeBarre);
    }
  }
  public Produit rechercher(String codeBarre) throws gererproduits.supermarche.GererProduitsException {
    try {
      String ligne;
      LectureDonnees lecture = new LectureDonnees(_nomFichier);
      ligne = lecture.rechercher(codeBarre);
      StringTokenizer decouperLigne = new StringTokenizer(ligne,"\t");
      Produit retour = new Produit(decouperLigne.nextToken(),decouperLigne.nextToken(),(new Double(decouperLigne.nextToken())).doubleValue());
      lecture.fermerSource();
      return retour;
    }
    catch(Exception e) {
      System.out.println("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+codeBarre+" - Exception : "+e);
      throw new gererproduits.supermarche.GererProduitsException("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+codeBarre);
    }
  }
  public void modifierP(Produit p) throws gererproduits.supermarche.GererProduitsException {
    try{
      EcritureDonnees ecriture = new EcritureDonnees(_nomFichier);
      ecriture.mettreAJour(p.codeBarre,p.codeBarre+"\t"+p.designation+"\t"+p.prixHT);
      System.out.println(_nomObjet+" - Modification de ["+p.codeBarre+"] OK");
    }
    catch(Exception e) {
      System.out.println("Erreur modification dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre+" - Exception : "+e);
      throw new gererproduits.supermarche.GererProduitsException("Erreur modification dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre);
    }
  }
  public Produit rechercherP(Produit p) throws gererproduits.supermarche.GererProduitsException {
    try{
      LectureDonnees lecture = new LectureDonnees(_nomFichier);
      StringTokenizer decouperLigne = new StringTokenizer(lecture.rechercher(p.codeBarre),"\t");
      Produit retour = new Produit(decouperLigne.nextToken(),decouperLigne.nextToken(),(new Double(decouperLigne.nextToken())).doubleValue());
      lecture.fermerSource();
      return retour;
    }
    catch(Exception e) {
      System.out.println("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre+" - Exception : "+e);
      throw new gererproduits.supermarche.GererProduitsException("Erreur recherche dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre);
    }
  }
  public void creer(String codeBarre, String designation, double prixHT) throws gererproduits.supermarche.GererProduitsException {
    try{
      EcritureDonnees ecriture = new EcritureDonnees(_nomFichier);
      ecriture.inserer(codeBarre+"\t"+designation+"\t"+prixHT);
      System.out.println(_nomObjet+" - Insertion de ["+codeBarre+"] OK");
    }
    catch(Exception e) {
      System.out.println("Erreur insertion dans "+_nomObjet+" : valeur de codeBarre "+codeBarre+" - Exception : "+e.toString());
      throw new gererproduits.supermarche.GererProduitsException("Erreur insertion dans "+_nomObjet+" : valeur de codeBarre "+codeBarre+" - Exception : "+e.toString());
    }
  }
  public void creerP(Produit p) throws gererproduits.supermarche.GererProduitsException {
    try{
      EcritureDonnees ecriture = new EcritureDonnees(_nomFichier);
      ecriture.inserer(p.codeBarre+"\t"+p.designation+"\t"+p.prixHT);
      System.out.println(_nomObjet+" - Insertion de ["+p.codeBarre+"] OK");
    }
    catch(Exception e) {
      System.out.println("Erreur creation dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre+" - Exception : "+e.toString());
      throw new gererproduits.supermarche.GererProduitsException("Erreur creation dans "+_nomObjet+" : valeur de codeBarre "+p.codeBarre+" - Exception : "+e.toString());
    }

  }
}