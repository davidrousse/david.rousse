package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Produit rechercher (in string codeBarre)
    raises (gestionsupermarche.supermarche.AccesProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Produit rechercher (java.lang.String codeBarre) throws gestionsupermarche.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Produit rechercherP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.AccesProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Produit rechercherP (gestionsupermarche.supermarche.Produit p) throws gestionsupermarche.supermarche.AccesProduitsException;

}
