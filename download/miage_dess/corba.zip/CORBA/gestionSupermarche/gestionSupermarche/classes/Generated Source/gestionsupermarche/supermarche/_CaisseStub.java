package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public class _CaisseStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements Caisse {
  final public static java.lang.Class _opsClass = gestionsupermarche.supermarche.CaisseOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Caisse:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomObjet", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomObjet", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.nomObjet();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public double totalVentes () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        double _result;
        try {
          _output = this._request("_get_totalVentes", true);
          _input = this._invoke(_output);
          _result = _input.read_double();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_totalVentes", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.totalVentes();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   attribute double totalVentes;
   * </pre>
   */
  public void totalVentes (double totalVentes) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("_set_totalVentes", true);
          _output.write_double((double)totalVentes);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_set_totalVentes", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          _self.totalVentes(totalVentes);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   readonly attribute string agence;
   * </pre>
   */
  public java.lang.String agence () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_agence", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_agence", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.agence();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   readonly attribute string caissier;
   * </pre>
   */
  public java.lang.String caissier () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_caissier", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_caissier", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          return _self.caissier();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void vendreS (in string codeBarre)
    raises (gestionsupermarche.supermarche.CaisseException);
   * </pre>
   */
  public void vendreS (java.lang.String codeBarre) throws  gestionsupermarche.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("vendreS", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gestionsupermarche.supermarche.CaisseExceptionHelper.id())) {
            throw             gestionsupermarche.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("vendreS", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          _self.vendreS(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void vendreC (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.CaisseException);
   * </pre>
   */
  public void vendreC (java.lang.String codeBarre, 
                       short qte) throws  gestionsupermarche.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("vendreC", true);
          _output.write_string((java.lang.String)codeBarre);
          _output.write_short((short)qte);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gestionsupermarche.supermarche.CaisseExceptionHelper.id())) {
            throw             gestionsupermarche.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("vendreC", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          _self.vendreC(codeBarre, qte);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void editerTicket ()
    raises (gestionsupermarche.supermarche.CaisseException);
   * </pre>
   */
  public void editerTicket () throws  gestionsupermarche.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("editerTicket", true);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gestionsupermarche.supermarche.CaisseExceptionHelper.id())) {
            throw             gestionsupermarche.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("editerTicket", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          _self.editerTicket();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void connecter (in string login, in string password)
    raises (gestionsupermarche.supermarche.CaisseException);
   * </pre>
   */
  public void connecter (java.lang.String login, 
                         java.lang.String password) throws  gestionsupermarche.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("connecter", true);
          _output.write_string((java.lang.String)login);
          _output.write_string((java.lang.String)password);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gestionsupermarche.supermarche.CaisseExceptionHelper.id())) {
            throw             gestionsupermarche.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("connecter", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          _self.connecter(login, password);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void deconnecter (in string login)
    raises (gestionsupermarche.supermarche.CaisseException);
   * </pre>
   */
  public void deconnecter (java.lang.String login) throws  gestionsupermarche.supermarche.CaisseException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("deconnecter", true);
          _output.write_string((java.lang.String)login);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(gestionsupermarche.supermarche.CaisseExceptionHelper.id())) {
            throw             gestionsupermarche.supermarche.CaisseExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("deconnecter", _opsClass);
        if (_so == null) {
          continue;
        }
        final gestionsupermarche.supermarche.CaisseOperations _self = (gestionsupermarche.supermarche.CaisseOperations)_so.servant;
        try {
          _self.deconnecter(login);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
