package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class GererEmployesPOATie extends GererEmployesPOA {
  private gestionsupermarche.supermarche.GererEmployesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererEmployesPOATie (final gestionsupermarche.supermarche.GererEmployesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererEmployesPOATie (final gestionsupermarche.supermarche.GererEmployesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gestionsupermarche.supermarche.GererEmployesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gestionsupermarche.supermarche.GererEmployesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gestionsupermarche.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gestionsupermarche.supermarche.Employe[] listeE () {
    return this._delegate.listeE();
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  gestionsupermarche.supermarche.GererEmployesException {
    this._delegate.creer(login, password, droit);
  }

  /**
   * <pre>
   *   void creerE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gestionsupermarche.supermarche.Employe e) throws  gestionsupermarche.supermarche.GererEmployesException {
    this._delegate.creerE(e);
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  gestionsupermarche.supermarche.GererEmployesException {
    this._delegate.modifier(login, password, droit);
  }

  /**
   * <pre>
   *   void modifierE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gestionsupermarche.supermarche.Employe e) throws  gestionsupermarche.supermarche.GererEmployesException {
    this._delegate.modifierE(e);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  gestionsupermarche.supermarche.GererEmployesException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   void supprimerE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gestionsupermarche.supermarche.Employe e) throws  gestionsupermarche.supermarche.GererEmployesException {
    this._delegate.supprimerE(e);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Employe rechercher (in string login)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Employe rechercher (java.lang.String login) throws  gestionsupermarche.supermarche.GererEmployesException {
    return this._delegate.rechercher(login);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Employe rechercherE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Employe rechercherE (gestionsupermarche.supermarche.Employe e) throws  gestionsupermarche.supermarche.GererEmployesException {
    return this._delegate.rechercherE(e);
  }

}
