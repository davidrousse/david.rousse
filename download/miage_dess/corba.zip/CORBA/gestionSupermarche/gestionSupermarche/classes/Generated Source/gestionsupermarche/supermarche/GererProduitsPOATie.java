package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public class GererProduitsPOATie extends GererProduitsPOA {
  private gestionsupermarche.supermarche.GererProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererProduitsPOATie (final gestionsupermarche.supermarche.GererProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererProduitsPOATie (final gestionsupermarche.supermarche.GererProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gestionsupermarche.supermarche.GererProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gestionsupermarche.supermarche.GererProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws  gestionsupermarche.supermarche.GererProduitsException {
    this._delegate.creer(codeBarre, designation, prixHT);
  }

  /**
   * <pre>
   *   void creerP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gestionsupermarche.supermarche.Produit p) throws  gestionsupermarche.supermarche.GererProduitsException {
    this._delegate.creerP(p);
  }

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws  gestionsupermarche.supermarche.GererProduitsException {
    this._delegate.supprimer(codeBarre);
  }

  /**
   * <pre>
   *   void supprimerP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gestionsupermarche.supermarche.Produit p) throws  gestionsupermarche.supermarche.GererProduitsException {
    this._delegate.supprimerP(p);
  }

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws  gestionsupermarche.supermarche.GererProduitsException {
    this._delegate.modifier(codeBarre, designation, prixHT);
  }

  /**
   * <pre>
   *   void modifierP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gestionsupermarche.supermarche.Produit p) throws  gestionsupermarche.supermarche.GererProduitsException {
    this._delegate.modifierP(p);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Produit rechercher (in string codeBarre)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Produit rechercher (java.lang.String codeBarre) throws  gestionsupermarche.supermarche.GererProduitsException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Produit rechercherP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Produit rechercherP (gestionsupermarche.supermarche.Produit p) throws  gestionsupermarche.supermarche.GererProduitsException {
    return this._delegate.rechercherP(p);
  }

}
