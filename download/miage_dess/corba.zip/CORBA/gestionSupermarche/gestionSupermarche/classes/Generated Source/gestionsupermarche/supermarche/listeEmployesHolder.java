package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/listeEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgestionsupermarche.supermarche.Employe&gt listeEmployes;
 * </pre>
 */
public final class listeEmployesHolder implements org.omg.CORBA.portable.Streamable {
  public gestionsupermarche.supermarche.Employe[] value;

  public listeEmployesHolder () {
  }

  public listeEmployesHolder (final gestionsupermarche.supermarche.Employe[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gestionsupermarche.supermarche.listeEmployesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gestionsupermarche.supermarche.listeEmployesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gestionsupermarche.supermarche.listeEmployesHelper.type();
  }
}
