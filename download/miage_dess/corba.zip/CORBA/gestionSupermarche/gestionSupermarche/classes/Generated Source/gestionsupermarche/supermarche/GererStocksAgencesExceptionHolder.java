package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgencesException
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgencesException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception GererStocksAgencesException {
  ...
};
 * </pre>
 */
public final class GererStocksAgencesExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public gestionsupermarche.supermarche.GererStocksAgencesException value;

  public GererStocksAgencesExceptionHolder () {
  }

  public GererStocksAgencesExceptionHolder (final gestionsupermarche.supermarche.GererStocksAgencesException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gestionsupermarche.supermarche.GererStocksAgencesExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gestionsupermarche.supermarche.GererStocksAgencesExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gestionsupermarche.supermarche.GererStocksAgencesExceptionHelper.type();
  }
}
