package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public class GererStocksPOATie extends GererStocksPOA {
  private gestionsupermarche.supermarche.GererStocksOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksPOATie (final gestionsupermarche.supermarche.GererStocksOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksPOATie (final gestionsupermarche.supermarche.GererStocksOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gestionsupermarche.supermarche.GererStocksOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gestionsupermarche.supermarche.GererStocksOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute gestionsupermarche.supermarche.listeStocks listeS;
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock[] listeS () {
    return this._delegate.listeS();
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     short qte) throws  gestionsupermarche.supermarche.GererStocksException {
    this._delegate.creer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void creerS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gestionsupermarche.supermarche.Stock s) throws  gestionsupermarche.supermarche.GererStocksException {
    this._delegate.creerS(s);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           short qte) throws  gestionsupermarche.supermarche.GererStocksException {
    this._delegate.incrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void incrementerS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gestionsupermarche.supermarche.Stock s) throws  gestionsupermarche.supermarche.GererStocksException {
    this._delegate.incrementerS(s);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           short qte) throws  gestionsupermarche.supermarche.GererStocksException {
    this._delegate.decrementer(codeBarre, qte);
  }

  /**
   * <pre>
   *   void decrementerS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gestionsupermarche.supermarche.Stock s) throws  gestionsupermarche.supermarche.GererStocksException {
    this._delegate.decrementerS(s);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercher (in string codeBarre)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercher (java.lang.String codeBarre) throws  gestionsupermarche.supermarche.GererStocksException {
    return this._delegate.rechercher(codeBarre);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercherS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercherS (gestionsupermarche.supermarche.Stock s) throws  gestionsupermarche.supermarche.GererStocksException {
    return this._delegate.rechercherS(s);
  }

}
