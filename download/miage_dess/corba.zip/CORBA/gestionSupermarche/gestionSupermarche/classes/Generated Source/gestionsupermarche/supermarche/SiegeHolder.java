package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public final class SiegeHolder implements org.omg.CORBA.portable.Streamable {
  public gestionsupermarche.supermarche.Siege value;

  public SiegeHolder () {
  }

  public SiegeHolder (final gestionsupermarche.supermarche.Siege _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gestionsupermarche.supermarche.SiegeHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gestionsupermarche.supermarche.SiegeHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gestionsupermarche.supermarche.SiegeHelper.type();
  }
}
