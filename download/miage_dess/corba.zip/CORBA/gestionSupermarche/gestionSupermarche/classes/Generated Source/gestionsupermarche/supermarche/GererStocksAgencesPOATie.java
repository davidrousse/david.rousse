package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public class GererStocksAgencesPOATie extends GererStocksAgencesPOA {
  private gestionsupermarche.supermarche.GererStocksAgencesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererStocksAgencesPOATie (final gestionsupermarche.supermarche.GererStocksAgencesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererStocksAgencesPOATie (final gestionsupermarche.supermarche.GererStocksAgencesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public gestionsupermarche.supermarche.GererStocksAgencesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final gestionsupermarche.supermarche.GererStocksAgencesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void creer (in string codeBarre, in short qte, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     short qte, 
                     java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    this._delegate.creer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void creerS (in gestionsupermarche.supermarche.Stock s, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gestionsupermarche.supermarche.Stock s, 
                      java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    this._delegate.creerS(s, agence);
  }

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in short qte, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           short qte, 
                           java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    this._delegate.incrementer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void incrementerS (in gestionsupermarche.supermarche.Stock s,
                     in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gestionsupermarche.supermarche.Stock s, 
                            java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    this._delegate.incrementerS(s, agence);
  }

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in short qte, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           short qte, 
                           java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    this._delegate.decrementer(codeBarre, qte, agence);
  }

  /**
   * <pre>
   *   void decrementerS (in gestionsupermarche.supermarche.Stock s,
                     in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gestionsupermarche.supermarche.Stock s, 
                            java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    this._delegate.decrementerS(s, agence);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercher (in string codeBarre,
                                                   in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                          java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    return this._delegate.rechercher(codeBarre, agence);
  }

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercherS (in gestionsupermarche.supermarche.Stock s,
                                                    in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercherS (gestionsupermarche.supermarche.Stock s, 
                                                           java.lang.String agence) throws  gestionsupermarche.supermarche.GererStocksAgencesException {
    return this._delegate.rechercherS(s, agence);
  }

}
