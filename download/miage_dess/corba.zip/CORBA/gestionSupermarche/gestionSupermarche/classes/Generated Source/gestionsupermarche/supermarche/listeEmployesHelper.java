
package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/listeEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgestionsupermarche.supermarche.Employe&gt listeEmployes;
 * </pre>
 */
public final class listeEmployesHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static gestionsupermarche.supermarche.Employe[] read (final org.omg.CORBA.portable.InputStream _input) {
    gestionsupermarche.supermarche.Employe[] result;
    final int $length6 = _input.read_long();
    result = new gestionsupermarche.supermarche.Employe[$length6];
    for (int $counter7 = 0; $counter7 < $length6; $counter7++) {
      result[$counter7] = gestionsupermarche.supermarche.EmployeHelper.read(_input);
    }
    return result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final gestionsupermarche.supermarche.Employe[] _vis_value) {
    _output.write_long(_vis_value.length);
    for (int $counter8 = 0;  $counter8 < _vis_value.length; $counter8++) {
      gestionsupermarche.supermarche.EmployeHelper.write(_output, _vis_value[$counter8]);
    }
  }

  public static void insert (final org.omg.CORBA.Any any, final gestionsupermarche.supermarche.Employe[] _vis_value) {
    any.type(gestionsupermarche.supermarche.listeEmployesHelper.type());
    any.insert_Streamable(new gestionsupermarche.supermarche.listeEmployesHolder(_vis_value));
  }

  public static gestionsupermarche.supermarche.Employe[] extract (final org.omg.CORBA.Any any) {
    gestionsupermarche.supermarche.Employe[] _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      gestionsupermarche.supermarche.listeEmployesHolder _vis_holder = new gestionsupermarche.supermarche.listeEmployesHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    } else {
      _vis_value = gestionsupermarche.supermarche.listeEmployesHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          org.omg.CORBA.TypeCode originalType = _orb().create_sequence_tc(0, gestionsupermarche.supermarche.EmployeHelper.type());
          _type = _orb().create_alias_tc(id(), "listeEmployes", originalType);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/listeEmployes:1.0";
  }
}
