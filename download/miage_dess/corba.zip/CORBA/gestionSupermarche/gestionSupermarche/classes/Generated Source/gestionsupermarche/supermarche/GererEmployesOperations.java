package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployesOperations {
  /**
   * <pre>
   *   readonly attribute gestionsupermarche.supermarche.listeEmployes listeE;
   * </pre>
   */
  public gestionsupermarche.supermarche.Employe[] listeE ();

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void creerE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (gestionsupermarche.supermarche.Employe e) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifierE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (gestionsupermarche.supermarche.Employe e) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimerE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (gestionsupermarche.supermarche.Employe e) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Employe rechercher (in string login)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Employe rechercher (java.lang.String login) throws gestionsupermarche.supermarche.GererEmployesException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Employe rechercherE (in gestionsupermarche.supermarche.Employe e)
    raises (gestionsupermarche.supermarche.GererEmployesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Employe rechercherE (gestionsupermarche.supermarche.Employe e) throws gestionsupermarche.supermarche.GererEmployesException;

}
