package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AgenceException
 * <li> <b>Repository Id</b> IDL:supermarche/AgenceException:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * exception AgenceException {
  ...
};
 * </pre>
 */
public final class AgenceExceptionHolder implements org.omg.CORBA.portable.Streamable {
  public gestionsupermarche.supermarche.AgenceException value;

  public AgenceExceptionHolder () {
  }

  public AgenceExceptionHolder (final gestionsupermarche.supermarche.AgenceException _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gestionsupermarche.supermarche.AgenceExceptionHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gestionsupermarche.supermarche.AgenceExceptionHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gestionsupermarche.supermarche.AgenceExceptionHelper.type();
  }
}
