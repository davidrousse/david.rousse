package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public final class GererStocksAgencesHolder implements org.omg.CORBA.portable.Streamable {
  public gestionsupermarche.supermarche.GererStocksAgences value;

  public GererStocksAgencesHolder () {
  }

  public GererStocksAgencesHolder (final gestionsupermarche.supermarche.GererStocksAgences _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gestionsupermarche.supermarche.GererStocksAgencesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gestionsupermarche.supermarche.GererStocksAgencesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gestionsupermarche.supermarche.GererStocksAgencesHelper.type();
  }
}
