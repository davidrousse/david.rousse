package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public interface Caisse extends com.inprise.vbroker.CORBA.Object, gestionsupermarche.supermarche.CaisseOperations, org.omg.CORBA.portable.IDLEntity {
}
