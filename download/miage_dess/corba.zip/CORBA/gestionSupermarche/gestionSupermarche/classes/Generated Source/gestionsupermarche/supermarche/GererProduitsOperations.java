package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (gestionsupermarche.supermarche.Produit p) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (gestionsupermarche.supermarche.Produit p) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (gestionsupermarche.supermarche.Produit p) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Produit rechercher (in string codeBarre)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Produit rechercher (java.lang.String codeBarre) throws gestionsupermarche.supermarche.GererProduitsException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Produit rechercherP (in gestionsupermarche.supermarche.Produit p)
    raises (gestionsupermarche.supermarche.GererProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Produit rechercherP (gestionsupermarche.supermarche.Produit p) throws gestionsupermarche.supermarche.GererProduitsException;

}
