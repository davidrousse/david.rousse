package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public interface GererStocksAgencesOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in short qte, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     short qte, 
                     java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void creerS (in gestionsupermarche.supermarche.Stock s, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (gestionsupermarche.supermarche.Stock s, 
                      java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in short qte, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           short qte, 
                           java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementerS (in gestionsupermarche.supermarche.Stock s,
                     in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (gestionsupermarche.supermarche.Stock s, 
                            java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in short qte, in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           short qte, 
                           java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementerS (in gestionsupermarche.supermarche.Stock s,
                     in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (gestionsupermarche.supermarche.Stock s, 
                            java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercher (in string codeBarre,
                                                   in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                                          java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercherS (in gestionsupermarche.supermarche.Stock s,
                                                    in string agence)
    raises (gestionsupermarche.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercherS (gestionsupermarche.supermarche.Stock s, 
                                                           java.lang.String agence) throws gestionsupermarche.supermarche.GererStocksAgencesException;

}
