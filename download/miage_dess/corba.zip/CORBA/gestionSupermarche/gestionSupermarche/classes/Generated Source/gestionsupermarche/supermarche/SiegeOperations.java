package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Siege
 * <li> <b>Repository Id</b> IDL:supermarche/Siege:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Siege {
  ...
};
 * </pre>
 */
public interface SiegeOperations {
  /**
   * <pre>
   *   void inscrire (in string agence)
    raises (gestionsupermarche.supermarche.SiegeException);
   * </pre>
   */
  public void inscrire (java.lang.String agence) throws gestionsupermarche.supermarche.SiegeException;

  /**
   * <pre>
   *   void desinscrire (in string agence)
    raises (gestionsupermarche.supermarche.SiegeException);
   * </pre>
   */
  public void desinscrire (java.lang.String agence) throws gestionsupermarche.supermarche.SiegeException;

}
