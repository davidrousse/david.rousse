package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public interface GererStocksOperations {
  /**
   * <pre>
   *   readonly attribute gestionsupermarche.supermarche.listeStocks listeS;
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock[] listeS ();

  /**
   * <pre>
   *   void creer (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     short qte) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   void creerS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (gestionsupermarche.supermarche.Stock s) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           short qte) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementerS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (gestionsupermarche.supermarche.Stock s) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in short qte)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           short qte) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementerS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (gestionsupermarche.supermarche.Stock s) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercher (in string codeBarre)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercher (java.lang.String codeBarre) throws gestionsupermarche.supermarche.GererStocksException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.Stock rechercherS (in gestionsupermarche.supermarche.Stock s)
    raises (gestionsupermarche.supermarche.GererStocksException);
   * </pre>
   */
  public gestionsupermarche.supermarche.Stock rechercherS (gestionsupermarche.supermarche.Stock s) throws gestionsupermarche.supermarche.GererStocksException;

}
