package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public interface GererAccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute gestionsupermarche.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public gestionsupermarche.supermarche.AccesProduits[] listeAP ();

  /**
   * <pre>
   *   gestionsupermarche.supermarche.AccesProduits creer (in string agence)
    raises (gestionsupermarche.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.AccesProduits creer (java.lang.String agence) throws gestionsupermarche.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (gestionsupermarche.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws gestionsupermarche.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   gestionsupermarche.supermarche.AccesProduits rechercher (in string agence)
    raises (gestionsupermarche.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public gestionsupermarche.supermarche.AccesProduits rechercher (java.lang.String agence) throws gestionsupermarche.supermarche.GererAccesProduitsException;

}
