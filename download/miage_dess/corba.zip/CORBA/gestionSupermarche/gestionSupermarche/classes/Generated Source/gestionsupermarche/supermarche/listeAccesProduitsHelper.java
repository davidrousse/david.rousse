
package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/listeAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgestionsupermarche.supermarche.AccesProduits&gt listeAccesProduits;
 * </pre>
 */
public final class listeAccesProduitsHelper {
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static gestionsupermarche.supermarche.AccesProduits[] read (final org.omg.CORBA.portable.InputStream _input) {
    gestionsupermarche.supermarche.AccesProduits[] result;
    final int $length9 = _input.read_long();
    result = new gestionsupermarche.supermarche.AccesProduits[$length9];
    for (int $counter10 = 0; $counter10 < $length9; $counter10++) {
      result[$counter10] = gestionsupermarche.supermarche.AccesProduitsHelper.read(_input);
    }
    return result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final gestionsupermarche.supermarche.AccesProduits[] _vis_value) {
    _output.write_long(_vis_value.length);
    for (int $counter11 = 0;  $counter11 < _vis_value.length; $counter11++) {
      gestionsupermarche.supermarche.AccesProduitsHelper.write(_output, _vis_value[$counter11]);
    }
  }

  public static void insert (final org.omg.CORBA.Any any, final gestionsupermarche.supermarche.AccesProduits[] _vis_value) {
    any.type(gestionsupermarche.supermarche.listeAccesProduitsHelper.type());
    any.insert_Streamable(new gestionsupermarche.supermarche.listeAccesProduitsHolder(_vis_value));
  }

  public static gestionsupermarche.supermarche.AccesProduits[] extract (final org.omg.CORBA.Any any) {
    gestionsupermarche.supermarche.AccesProduits[] _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      gestionsupermarche.supermarche.listeAccesProduitsHolder _vis_holder = new gestionsupermarche.supermarche.listeAccesProduitsHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    } else {
      _vis_value = gestionsupermarche.supermarche.listeAccesProduitsHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          org.omg.CORBA.TypeCode originalType = _orb().create_sequence_tc(0, gestionsupermarche.supermarche.AccesProduitsHelper.type());
          _type = _orb().create_alias_tc(id(), "listeAccesProduits", originalType);
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/listeAccesProduits:1.0";
  }
}
