package gestionsupermarche.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/gestionSupermarche/src/gestionsupermarche/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/listeAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltgestionsupermarche.supermarche.AccesProduits&gt listeAccesProduits;
 * </pre>
 */
public final class listeAccesProduitsHolder implements org.omg.CORBA.portable.Streamable {
  public gestionsupermarche.supermarche.AccesProduits[] value;

  public listeAccesProduitsHolder () {
  }

  public listeAccesProduitsHolder (final gestionsupermarche.supermarche.AccesProduits[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = gestionsupermarche.supermarche.listeAccesProduitsHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    gestionsupermarche.supermarche.listeAccesProduitsHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return gestionsupermarche.supermarche.listeAccesProduitsHelper.type();
  }
}
