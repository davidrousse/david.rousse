package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public class _AccesProduitsStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements AccesProduits {
  final public static java.lang.Class _opsClass = siege.supermarche.AccesProduitsOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/AccesProduits:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nomObjet", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nomObjet", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.AccesProduitsOperations _self = (siege.supermarche.AccesProduitsOperations)_so.servant;
        try {
          return _self.nomObjet();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   siege.supermarche.Produit rechercher (in string codeBarre)
    raises (siege.supermarche.AccesProduitsException);
   * </pre>
   */
  public siege.supermarche.Produit rechercher (java.lang.String codeBarre) throws  siege.supermarche.AccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        siege.supermarche.Produit _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)codeBarre);
          _input = this._invoke(_output);
          _result = siege.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(siege.supermarche.AccesProduitsExceptionHelper.id())) {
            throw             siege.supermarche.AccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.AccesProduitsOperations _self = (siege.supermarche.AccesProduitsOperations)_so.servant;
        try {
          return _self.rechercher(codeBarre);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   siege.supermarche.Produit rechercherP (in siege.supermarche.Produit p)
    raises (siege.supermarche.AccesProduitsException);
   * </pre>
   */
  public siege.supermarche.Produit rechercherP (siege.supermarche.Produit p) throws  siege.supermarche.AccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        siege.supermarche.Produit _result;
        try {
          _output = this._request("rechercherP", true);
          siege.supermarche.ProduitHelper.write(_output, p);
          _input = this._invoke(_output);
          _result = siege.supermarche.ProduitHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(siege.supermarche.AccesProduitsExceptionHelper.id())) {
            throw             siege.supermarche.AccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercherP", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.AccesProduitsOperations _self = (siege.supermarche.AccesProduitsOperations)_so.servant;
        try {
          return _self.rechercherP(p);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
