package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeAgences
 * <li> <b>Repository Id</b> IDL:supermarche/listeAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltstring&gt listeAgences;
 * </pre>
 */
public final class listeAgencesHolder implements org.omg.CORBA.portable.Streamable {
  public java.lang.String[] value;

  public listeAgencesHolder () {
  }

  public listeAgencesHolder (final java.lang.String[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = siege.supermarche.listeAgencesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    siege.supermarche.listeAgencesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return siege.supermarche.listeAgencesHelper.type();
  }
}
