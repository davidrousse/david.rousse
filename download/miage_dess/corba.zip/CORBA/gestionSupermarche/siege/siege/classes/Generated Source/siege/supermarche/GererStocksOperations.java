package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocks
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocks {
  ...
};
 * </pre>
 */
public interface GererStocksOperations {
  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeStocks listeS;
   * </pre>
   */
  public siege.supermarche.Stock[] listeS ();

  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   void creerS (in siege.supermarche.Stock s)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public void creerS (siege.supermarche.Stock s) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   void incrementerS (in siege.supermarche.Stock s)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public void incrementerS (siege.supermarche.Stock s) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   void decrementerS (in siege.supermarche.Stock s)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public void decrementerS (siege.supermarche.Stock s) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   siege.supermarche.Stock rechercher (in string codeBarre)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public siege.supermarche.Stock rechercher (java.lang.String codeBarre) throws siege.supermarche.GererStocksException;

  /**
   * <pre>
   *   siege.supermarche.Stock rechercherS (in siege.supermarche.Stock s)
    raises (siege.supermarche.GererStocksException);
   * </pre>
   */
  public siege.supermarche.Stock rechercherS (siege.supermarche.Stock s) throws siege.supermarche.GererStocksException;

}
