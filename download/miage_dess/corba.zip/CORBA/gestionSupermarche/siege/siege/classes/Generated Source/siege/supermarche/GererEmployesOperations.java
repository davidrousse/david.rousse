package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public interface GererEmployesOperations {
  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeEmployes listeE;
   * </pre>
   */
  public siege.supermarche.Employe[] listeE ();

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void creerE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (siege.supermarche.Employe e) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void modifierE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (siege.supermarche.Employe e) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   void supprimerE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (siege.supermarche.Employe e) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   siege.supermarche.Employe rechercher (in string login)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public siege.supermarche.Employe rechercher (java.lang.String login) throws siege.supermarche.GererEmployesException;

  /**
   * <pre>
   *   siege.supermarche.Employe rechercherE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public siege.supermarche.Employe rechercherE (siege.supermarche.Employe e) throws siege.supermarche.GererEmployesException;

}
