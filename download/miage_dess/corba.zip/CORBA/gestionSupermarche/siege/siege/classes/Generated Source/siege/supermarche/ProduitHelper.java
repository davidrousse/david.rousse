package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Produit
 * <li> <b>Repository Id</b> IDL:supermarche/Produit:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Produit {
  ...
};
 * </pre>
 */
public final class ProduitHelper {
  private static boolean _inited = false;
  private static boolean _initing = false;
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static siege.supermarche.Produit read (final org.omg.CORBA.portable.InputStream _input) {
    final siege.supermarche.Produit _result = new siege.supermarche.Produit();
    _result.codeBarre = _input.read_string();
    _result.designation = _input.read_string();
    _result.prixHT = _input.read_double();
    return _result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final siege.supermarche.Produit _vis_value) {
    _output.write_string((java.lang.String)_vis_value.codeBarre);
    _output.write_string((java.lang.String)_vis_value.designation);
    _output.write_double((double)_vis_value.prixHT);
  }

  public static void insert (final org.omg.CORBA.Any any, final siege.supermarche.Produit _vis_value) {
    any.insert_Streamable(new siege.supermarche.ProduitHolder(_vis_value));
  }

  public static siege.supermarche.Produit extract (final org.omg.CORBA.Any any) {
    siege.supermarche.Produit _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      siege.supermarche.ProduitHolder _vis_holder = new siege.supermarche.ProduitHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    }
    else {
      _vis_value = siege.supermarche.ProduitHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          if (_initializing) {
            return _orb().create_recursive_tc(id());
          }
          _initializing = true;
          final org.omg.CORBA.StructMember[] members = new org.omg.CORBA.StructMember[3];
          members[0] = new org.omg.CORBA.StructMember("codeBarre", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string), null);
          members[1] = new org.omg.CORBA.StructMember("designation", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string), null);
          members[2] = new org.omg.CORBA.StructMember("prixHT", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_double), null);
          _type = _orb().create_struct_tc(id(), "Produit", members);
          _initializing = false;
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/Produit:1.0";
  }
}
