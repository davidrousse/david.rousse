package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public abstract class GererProduitsPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, siege.supermarche.GererProduitsOperations {

  public siege.supermarche.GererProduits _this () {
   return siege.supermarche.GererProduitsHelper.narrow(super._this_object());
  }

  public siege.supermarche.GererProduits _this (org.omg.CORBA.ORB orb) {
    return siege.supermarche.GererProduitsHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererProduits:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("creer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("creerP", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("supprimer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("supprimerP", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("modifier", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("modifierP", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("rechercher", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
    _methods.put("rechercherP", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 7));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return siege.supermarche.GererProduitsPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (siege.supermarche.GererProduitsOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        java.lang.String designation;
        designation = _input.read_string();
        double prixHT;
        prixHT = _input.read_double();
        _self.creer(codeBarre, designation, prixHT);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 1: {
      try {
        siege.supermarche.Produit p;
        p = siege.supermarche.ProduitHelper.read(_input);
        _self.creerP(p);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 2: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        _self.supprimer(codeBarre);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 3: {
      try {
        siege.supermarche.Produit p;
        p = siege.supermarche.ProduitHelper.read(_input);
        _self.supprimerP(p);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 4: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        java.lang.String designation;
        designation = _input.read_string();
        double prixHT;
        prixHT = _input.read_double();
        _self.modifier(codeBarre, designation, prixHT);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 5: {
      try {
        siege.supermarche.Produit p;
        p = siege.supermarche.ProduitHelper.read(_input);
        _self.modifierP(p);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 6: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        siege.supermarche.Produit _result = _self.rechercher(codeBarre);
        _output = _handler.createReply();
        siege.supermarche.ProduitHelper.write(_output, _result);
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 7: {
      try {
        siege.supermarche.Produit p;
        p = siege.supermarche.ProduitHelper.read(_input);
        siege.supermarche.Produit _result = _self.rechercherP(p);
        _output = _handler.createReply();
        siege.supermarche.ProduitHelper.write(_output, _result);
      }
      catch (siege.supermarche.GererProduitsException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererProduitsExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
