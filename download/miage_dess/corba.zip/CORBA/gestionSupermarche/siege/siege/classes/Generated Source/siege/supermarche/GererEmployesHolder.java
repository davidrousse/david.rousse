package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public final class GererEmployesHolder implements org.omg.CORBA.portable.Streamable {
  public siege.supermarche.GererEmployes value;

  public GererEmployesHolder () {
  }

  public GererEmployesHolder (final siege.supermarche.GererEmployes _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = siege.supermarche.GererEmployesHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    siege.supermarche.GererEmployesHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return siege.supermarche.GererEmployesHelper.type();
  }
}
