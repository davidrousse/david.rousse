package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererStocksAgences
 * <li> <b>Repository Id</b> IDL:supermarche/GererStocksAgences:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererStocksAgences {
  ...
};
 * </pre>
 */
public interface GererStocksAgencesOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in long qte, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     int qte, 
                     java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void creerS (in siege.supermarche.Stock s, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void creerS (siege.supermarche.Stock s, 
                      java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementer (in string codeBarre, in long qte, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void incrementerS (in siege.supermarche.Stock s, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void incrementerS (siege.supermarche.Stock s, 
                            java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementer (in string codeBarre, in long qte, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementer (java.lang.String codeBarre, 
                           int qte, 
                           java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   void decrementerS (in siege.supermarche.Stock s, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public void decrementerS (siege.supermarche.Stock s, 
                            java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   siege.supermarche.Stock rechercher (in string codeBarre, in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public siege.supermarche.Stock rechercher (java.lang.String codeBarre, 
                                             java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

  /**
   * <pre>
   *   siege.supermarche.Stock rechercherS (in siege.supermarche.Stock s,
                                       in string agence)
    raises (siege.supermarche.GererStocksAgencesException);
   * </pre>
   */
  public siege.supermarche.Stock rechercherS (siege.supermarche.Stock s, 
                                              java.lang.String agence) throws siege.supermarche.GererStocksAgencesException;

}
