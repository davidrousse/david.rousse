package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Stock
 * <li> <b>Repository Id</b> IDL:supermarche/Stock:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Stock {
  ...
};
 * </pre>
 */
public final class Stock implements org.omg.CORBA.portable.IDLEntity {
  
  public java.lang.String codeBarre;
  
  public int qte;

  public Stock () {
  }

  public Stock (final java.lang.String codeBarre, 
                final int qte) {
    this.codeBarre = codeBarre;
    this.qte = qte;
  }

  public java.lang.String toString() {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("struct siege.supermarche.Stock {");
    _ret.append("\n");
    _ret.append("java.lang.String codeBarre=");
    _ret.append(codeBarre != null?'\"' + codeBarre + '\"':null);
    _ret.append(",\n");
    _ret.append("int qte=");
    _ret.append(qte);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;

    if (o instanceof siege.supermarche.Stock) {
      final siege.supermarche.Stock obj = (siege.supermarche.Stock)o;
      boolean res = true;
      do {
        res = this.codeBarre == obj.codeBarre ||
         (this.codeBarre != null && obj.codeBarre != null && this.codeBarre.equals(obj.codeBarre));
        if (!res) break;
        res = this.qte == obj.qte;
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
