package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public class GererAccesProduitsPOATie extends GererAccesProduitsPOA {
  private siege.supermarche.GererAccesProduitsOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererAccesProduitsPOATie (final siege.supermarche.GererAccesProduitsOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererAccesProduitsPOATie (final siege.supermarche.GererAccesProduitsOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public siege.supermarche.GererAccesProduitsOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final siege.supermarche.GererAccesProduitsOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public siege.supermarche.AccesProduits[] listeAP () {
    return this._delegate.listeAP();
  }

  /**
   * <pre>
   *   siege.supermarche.AccesProduits creer (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public siege.supermarche.AccesProduits creer (java.lang.String agence) throws  siege.supermarche.GererAccesProduitsException {
    return this._delegate.creer(agence);
  }

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws  siege.supermarche.GererAccesProduitsException {
    this._delegate.supprimer(agence);
  }

  /**
   * <pre>
   *   siege.supermarche.AccesProduits rechercher (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public siege.supermarche.AccesProduits rechercher (java.lang.String agence) throws  siege.supermarche.GererAccesProduitsException {
    return this._delegate.rechercher(agence);
  }

}
