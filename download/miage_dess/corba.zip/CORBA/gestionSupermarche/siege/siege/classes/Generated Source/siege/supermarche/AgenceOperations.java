package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public interface AgenceOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeCaisses listeC;
   * </pre>
   */
  public siege.supermarche.Caisse[] listeC ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge ();

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge);

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public double TVA ();

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public void TVA (double TVA);

  /**
   * <pre>
   *   siege.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public siege.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws siege.supermarche.AgenceException;

  /**
   * <pre>
   *   siege.supermarche.Caisse creer (in string login, in string agence,
                                  in string loginCaissier)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public siege.supermarche.Caisse creer (java.lang.String login, 
                                         java.lang.String agence, 
                                         java.lang.String loginCaissier) throws siege.supermarche.AgenceException;

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws siege.supermarche.AgenceException;

  /**
   * <pre>
   *   siege.supermarche.Caisse rechercher (in string login)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public siege.supermarche.Caisse rechercher (java.lang.String login) throws siege.supermarche.AgenceException;

}
