package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public abstract class AgencePOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, siege.supermarche.AgenceOperations {

  public siege.supermarche.Agence _this () {
   return siege.supermarche.AgenceHelper.narrow(super._this_object());
  }

  public siege.supermarche.Agence _this (org.omg.CORBA.ORB orb) {
    return siege.supermarche.AgenceHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Agence:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_nomObjet", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("_get_listeC", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("_get_marge", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("_set_marge", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("_get_TVA", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("_set_TVA", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("recupererInfoProduit", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
    _methods.put("creer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 7));
    _methods.put("supprimer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 8));
    _methods.put("rechercher", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 9));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return siege.supermarche.AgencePOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (siege.supermarche.AgenceOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        java.lang.String _result = _self.nomObjet();
        _output = _handler.createReply();
        _output.write_string((java.lang.String)_result);
        return _output;
      }
      case 1: {
        siege.supermarche.Caisse[] _result = _self.listeC();
        _output = _handler.createReply();
        siege.supermarche.listeCaissesHelper.write(_output, _result);
        return _output;
      }
      case 2: {
        double _result = _self.marge();
        _output = _handler.createReply();
        _output.write_double((double)_result);
        return _output;
      }
      case 3: {
        double marge;
        marge = _input.read_double();
        _self.marge(marge);
        _output = _handler.createReply();
        return _output;
      }
      case 4: {
        double _result = _self.TVA();
        _output = _handler.createReply();
        _output.write_double((double)_result);
        return _output;
      }
      case 5: {
        double TVA;
        TVA = _input.read_double();
        _self.TVA(TVA);
        _output = _handler.createReply();
        return _output;
      }
      case 6: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        siege.supermarche.Produit _result = _self.recupererInfoProduit(codeBarre);
        _output = _handler.createReply();
        siege.supermarche.ProduitHelper.write(_output, _result);
      }
      catch (siege.supermarche.AgenceException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.AgenceExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 7: {
      try {
        java.lang.String login;
        login = _input.read_string();
        java.lang.String agence;
        agence = _input.read_string();
        java.lang.String loginCaissier;
        loginCaissier = _input.read_string();
        siege.supermarche.Caisse _result = _self.creer(login, agence, loginCaissier);
        _output = _handler.createReply();
        siege.supermarche.CaisseHelper.write(_output, _result);
      }
      catch (siege.supermarche.AgenceException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.AgenceExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 8: {
      try {
        java.lang.String login;
        login = _input.read_string();
        _self.supprimer(login);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.AgenceException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.AgenceExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 9: {
      try {
        java.lang.String login;
        login = _input.read_string();
        siege.supermarche.Caisse _result = _self.rechercher(login);
        _output = _handler.createReply();
        siege.supermarche.CaisseHelper.write(_output, _result);
      }
      catch (siege.supermarche.AgenceException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.AgenceExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
