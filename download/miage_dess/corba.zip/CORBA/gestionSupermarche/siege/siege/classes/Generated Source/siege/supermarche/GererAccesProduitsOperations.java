package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public interface GererAccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public siege.supermarche.AccesProduits[] listeAP ();

  /**
   * <pre>
   *   siege.supermarche.AccesProduits creer (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public siege.supermarche.AccesProduits creer (java.lang.String agence) throws siege.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws siege.supermarche.GererAccesProduitsException;

  /**
   * <pre>
   *   siege.supermarche.AccesProduits rechercher (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public siege.supermarche.AccesProduits rechercher (java.lang.String agence) throws siege.supermarche.GererAccesProduitsException;

}
