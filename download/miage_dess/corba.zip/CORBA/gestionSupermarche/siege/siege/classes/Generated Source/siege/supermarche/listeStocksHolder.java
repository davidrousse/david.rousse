package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::listeStocks
 * <li> <b>Repository Id</b> IDL:supermarche/listeStocks:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * typedef sequence&ltsiege.supermarche.Stock&gt listeStocks;
 * </pre>
 */
public final class listeStocksHolder implements org.omg.CORBA.portable.Streamable {
  public siege.supermarche.Stock[] value;

  public listeStocksHolder () {
  }

  public listeStocksHolder (final siege.supermarche.Stock[] _vis_value) {
    this.value = _vis_value;
  }

  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = siege.supermarche.listeStocksHelper.read(input);
  }

  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    siege.supermarche.listeStocksHelper.write(output, value);
  }

  public org.omg.CORBA.TypeCode _type () {
    return siege.supermarche.listeStocksHelper.type();
  }
}
