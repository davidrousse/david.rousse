package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererAccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererAccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererAccesProduits {
  ...
};
 * </pre>
 */
public class _GererAccesProduitsStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements GererAccesProduits {
  final public static java.lang.Class _opsClass = siege.supermarche.GererAccesProduitsOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererAccesProduits:1.0"
  };

  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeAccesProduits listeAP;
   * </pre>
   */
  public siege.supermarche.AccesProduits[] listeAP () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        siege.supermarche.AccesProduits[] _result;
        try {
          _output = this._request("_get_listeAP", true);
          _input = this._invoke(_output);
          _result = siege.supermarche.listeAccesProduitsHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_listeAP", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.GererAccesProduitsOperations _self = (siege.supermarche.GererAccesProduitsOperations)_so.servant;
        try {
          return _self.listeAP();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   siege.supermarche.AccesProduits creer (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public siege.supermarche.AccesProduits creer (java.lang.String agence) throws  siege.supermarche.GererAccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        siege.supermarche.AccesProduits _result;
        try {
          _output = this._request("creer", true);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
          _result = siege.supermarche.AccesProduitsHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(siege.supermarche.GererAccesProduitsExceptionHelper.id())) {
            throw             siege.supermarche.GererAccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("creer", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.GererAccesProduitsOperations _self = (siege.supermarche.GererAccesProduitsOperations)_so.servant;
        try {
          return _self.creer(agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void supprimer (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String agence) throws  siege.supermarche.GererAccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("supprimer", true);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(siege.supermarche.GererAccesProduitsExceptionHelper.id())) {
            throw             siege.supermarche.GererAccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("supprimer", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.GererAccesProduitsOperations _self = (siege.supermarche.GererAccesProduitsOperations)_so.servant;
        try {
          _self.supprimer(agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   siege.supermarche.AccesProduits rechercher (in string agence)
    raises (siege.supermarche.GererAccesProduitsException);
   * </pre>
   */
  public siege.supermarche.AccesProduits rechercher (java.lang.String agence) throws  siege.supermarche.GererAccesProduitsException {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        siege.supermarche.AccesProduits _result;
        try {
          _output = this._request("rechercher", true);
          _output.write_string((java.lang.String)agence);
          _input = this._invoke(_output);
          _result = siege.supermarche.AccesProduitsHelper.read(_input);
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          if (_exception_id.equals(siege.supermarche.GererAccesProduitsExceptionHelper.id())) {
            throw             siege.supermarche.GererAccesProduitsExceptionHelper.read(_exception.getInputStream());
          }
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("rechercher", _opsClass);
        if (_so == null) {
          continue;
        }
        final siege.supermarche.GererAccesProduitsOperations _self = (siege.supermarche.GererAccesProduitsOperations)_so.servant;
        try {
          return _self.rechercher(agence);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

}
