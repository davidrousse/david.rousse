package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererProduits
 * <li> <b>Repository Id</b> IDL:supermarche/GererProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererProduits {
  ...
};
 * </pre>
 */
public interface GererProduitsOperations {
  /**
   * <pre>
   *   void creer (in string codeBarre, in string designation, in double prixHT)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public void creer (java.lang.String codeBarre, 
                     java.lang.String designation, 
                     double prixHT) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void creerP (in siege.supermarche.Produit p)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public void creerP (siege.supermarche.Produit p) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimer (in string codeBarre)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimer (java.lang.String codeBarre) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void supprimerP (in siege.supermarche.Produit p)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public void supprimerP (siege.supermarche.Produit p) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifier (in string codeBarre, in string designation, in double prixHT)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifier (java.lang.String codeBarre, 
                        java.lang.String designation, 
                        double prixHT) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   void modifierP (in siege.supermarche.Produit p)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public void modifierP (siege.supermarche.Produit p) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   siege.supermarche.Produit rechercher (in string codeBarre)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public siege.supermarche.Produit rechercher (java.lang.String codeBarre) throws siege.supermarche.GererProduitsException;

  /**
   * <pre>
   *   siege.supermarche.Produit rechercherP (in siege.supermarche.Produit p)
    raises (siege.supermarche.GererProduitsException);
   * </pre>
   */
  public siege.supermarche.Produit rechercherP (siege.supermarche.Produit p) throws siege.supermarche.GererProduitsException;

}
