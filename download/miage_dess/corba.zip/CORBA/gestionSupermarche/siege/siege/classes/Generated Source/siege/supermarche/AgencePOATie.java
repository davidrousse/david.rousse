package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Agence
 * <li> <b>Repository Id</b> IDL:supermarche/Agence:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Agence {
  ...
};
 * </pre>
 */
public class AgencePOATie extends AgencePOA {
  private siege.supermarche.AgenceOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public AgencePOATie (final siege.supermarche.AgenceOperations _delegate) {
    this._delegate = _delegate;
  }

  public AgencePOATie (final siege.supermarche.AgenceOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public siege.supermarche.AgenceOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final siege.supermarche.AgenceOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet () {
    return this._delegate.nomObjet();
  }

  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeCaisses listeC;
   * </pre>
   */
  public siege.supermarche.Caisse[] listeC () {
    return this._delegate.listeC();
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public double marge () {
    return this._delegate.marge();
  }

  /**
   * <pre>
   *   attribute double marge;
   * </pre>
   */
  public void marge (double marge) {
    this._delegate.marge(marge);
  }

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public double TVA () {
    return this._delegate.TVA();
  }

  /**
   * <pre>
   *   attribute double TVA;
   * </pre>
   */
  public void TVA (double TVA) {
    this._delegate.TVA(TVA);
  }

  /**
   * <pre>
   *   siege.supermarche.Produit recupererInfoProduit (in string codeBarre)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public siege.supermarche.Produit recupererInfoProduit (java.lang.String codeBarre) throws  siege.supermarche.AgenceException {
    return this._delegate.recupererInfoProduit(codeBarre);
  }

  /**
   * <pre>
   *   siege.supermarche.Caisse creer (in string login, in string agence,
                                  in string loginCaissier)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public siege.supermarche.Caisse creer (java.lang.String login, 
                                         java.lang.String agence, 
                                         java.lang.String loginCaissier) throws  siege.supermarche.AgenceException {
    return this._delegate.creer(login, agence, loginCaissier);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  siege.supermarche.AgenceException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   siege.supermarche.Caisse rechercher (in string login)
    raises (siege.supermarche.AgenceException);
   * </pre>
   */
  public siege.supermarche.Caisse rechercher (java.lang.String login) throws  siege.supermarche.AgenceException {
    return this._delegate.rechercher(login);
  }

}
