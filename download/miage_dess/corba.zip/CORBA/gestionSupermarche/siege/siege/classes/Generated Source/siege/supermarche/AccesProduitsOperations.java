package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::AccesProduits
 * <li> <b>Repository Id</b> IDL:supermarche/AccesProduits:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface AccesProduits {
  ...
};
 * </pre>
 */
public interface AccesProduitsOperations {
  /**
   * <pre>
   *   readonly attribute string nomObjet;
   * </pre>
   */
  public java.lang.String nomObjet ();

  /**
   * <pre>
   *   siege.supermarche.Produit rechercher (in string codeBarre)
    raises (siege.supermarche.AccesProduitsException);
   * </pre>
   */
  public siege.supermarche.Produit rechercher (java.lang.String codeBarre) throws siege.supermarche.AccesProduitsException;

  /**
   * <pre>
   *   siege.supermarche.Produit rechercherP (in siege.supermarche.Produit p)
    raises (siege.supermarche.AccesProduitsException);
   * </pre>
   */
  public siege.supermarche.Produit rechercherP (siege.supermarche.Produit p) throws siege.supermarche.AccesProduitsException;

}
