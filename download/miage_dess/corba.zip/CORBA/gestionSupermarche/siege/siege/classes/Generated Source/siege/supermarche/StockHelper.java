package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Stock
 * <li> <b>Repository Id</b> IDL:supermarche/Stock:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Stock {
  ...
};
 * </pre>
 */
public final class StockHelper {
  private static boolean _inited = false;
  private static boolean _initing = false;
  private static org.omg.CORBA.TypeCode _type;
  private static boolean _initializing;

  private static org.omg.CORBA.ORB _orb () {
    return org.omg.CORBA.ORB.init();
  }

  public static siege.supermarche.Stock read (final org.omg.CORBA.portable.InputStream _input) {
    final siege.supermarche.Stock _result = new siege.supermarche.Stock();
    _result.codeBarre = _input.read_string();
    _result.qte = _input.read_long();
    return _result;
  }

  public static void write (final org.omg.CORBA.portable.OutputStream _output, final siege.supermarche.Stock _vis_value) {
    _output.write_string((java.lang.String)_vis_value.codeBarre);
    _output.write_long((int)_vis_value.qte);
  }

  public static void insert (final org.omg.CORBA.Any any, final siege.supermarche.Stock _vis_value) {
    any.insert_Streamable(new siege.supermarche.StockHolder(_vis_value));
  }

  public static siege.supermarche.Stock extract (final org.omg.CORBA.Any any) {
    siege.supermarche.Stock _vis_value;
    if (any instanceof com.inprise.vbroker.CORBA.Any) {
      siege.supermarche.StockHolder _vis_holder = new siege.supermarche.StockHolder();
      ((com.inprise.vbroker.CORBA.Any)any).extract_Streamable(_vis_holder);
      _vis_value = _vis_holder.value;
    }
    else {
      _vis_value = siege.supermarche.StockHelper.read(any.create_input_stream());
    }
    return _vis_value;
  }

  public static org.omg.CORBA.TypeCode type () {
    if (_type == null) {
      synchronized (org.omg.CORBA.TypeCode.class) {
        if (_type == null) {
          if (_initializing) {
            return _orb().create_recursive_tc(id());
          }
          _initializing = true;
          final org.omg.CORBA.StructMember[] members = new org.omg.CORBA.StructMember[2];
          members[0] = new org.omg.CORBA.StructMember("codeBarre", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string), null);
          members[1] = new org.omg.CORBA.StructMember("qte", _orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_long), null);
          _type = _orb().create_struct_tc(id(), "Stock", members);
          _initializing = false;
        }
      }
    }
    return _type;
  }

  public static java.lang.String id () {
    return "IDL:supermarche/Stock:1.0";
  }
}
