package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public abstract class GererEmployesPOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, siege.supermarche.GererEmployesOperations {

  public siege.supermarche.GererEmployes _this () {
   return siege.supermarche.GererEmployesHelper.narrow(super._this_object());
  }

  public siege.supermarche.GererEmployes _this (org.omg.CORBA.ORB orb) {
    return siege.supermarche.GererEmployesHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/GererEmployes:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_listeE", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("creer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("creerE", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("modifier", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("modifierE", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("supprimer", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("supprimerE", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
    _methods.put("rechercher", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 7));
    _methods.put("rechercherE", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 8));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return siege.supermarche.GererEmployesPOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (siege.supermarche.GererEmployesOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        siege.supermarche.Employe[] _result = _self.listeE();
        _output = _handler.createReply();
        siege.supermarche.listeEmployesHelper.write(_output, _result);
        return _output;
      }
      case 1: {
      try {
        java.lang.String login;
        login = _input.read_string();
        java.lang.String password;
        password = _input.read_string();
        java.lang.String droit;
        droit = _input.read_string();
        _self.creer(login, password, droit);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 2: {
      try {
        siege.supermarche.Employe e;
        e = siege.supermarche.EmployeHelper.read(_input);
        _self.creerE(e);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 3: {
      try {
        java.lang.String login;
        login = _input.read_string();
        java.lang.String password;
        password = _input.read_string();
        java.lang.String droit;
        droit = _input.read_string();
        _self.modifier(login, password, droit);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 4: {
      try {
        siege.supermarche.Employe e;
        e = siege.supermarche.EmployeHelper.read(_input);
        _self.modifierE(e);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 5: {
      try {
        java.lang.String login;
        login = _input.read_string();
        _self.supprimer(login);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 6: {
      try {
        siege.supermarche.Employe e;
        e = siege.supermarche.EmployeHelper.read(_input);
        _self.supprimerE(e);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 7: {
      try {
        java.lang.String login;
        login = _input.read_string();
        siege.supermarche.Employe _result = _self.rechercher(login);
        _output = _handler.createReply();
        siege.supermarche.EmployeHelper.write(_output, _result);
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 8: {
      try {
        siege.supermarche.Employe e;
        e = siege.supermarche.EmployeHelper.read(_input);
        siege.supermarche.Employe _result = _self.rechercherE(e);
        _output = _handler.createReply();
        siege.supermarche.EmployeHelper.write(_output, _result);
      }
      catch (siege.supermarche.GererEmployesException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.GererEmployesExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
