package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::GererEmployes
 * <li> <b>Repository Id</b> IDL:supermarche/GererEmployes:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface GererEmployes {
  ...
};
 * </pre>
 */
public class GererEmployesPOATie extends GererEmployesPOA {
  private siege.supermarche.GererEmployesOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public GererEmployesPOATie (final siege.supermarche.GererEmployesOperations _delegate) {
    this._delegate = _delegate;
  }

  public GererEmployesPOATie (final siege.supermarche.GererEmployesOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public siege.supermarche.GererEmployesOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final siege.supermarche.GererEmployesOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute siege.supermarche.listeEmployes listeE;
   * </pre>
   */
  public siege.supermarche.Employe[] listeE () {
    return this._delegate.listeE();
  }

  /**
   * <pre>
   *   void creer (in string login, in string password, in string droit)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void creer (java.lang.String login, 
                     java.lang.String password, 
                     java.lang.String droit) throws  siege.supermarche.GererEmployesException {
    this._delegate.creer(login, password, droit);
  }

  /**
   * <pre>
   *   void creerE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void creerE (siege.supermarche.Employe e) throws  siege.supermarche.GererEmployesException {
    this._delegate.creerE(e);
  }

  /**
   * <pre>
   *   void modifier (in string login, in string password, in string droit)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifier (java.lang.String login, 
                        java.lang.String password, 
                        java.lang.String droit) throws  siege.supermarche.GererEmployesException {
    this._delegate.modifier(login, password, droit);
  }

  /**
   * <pre>
   *   void modifierE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void modifierE (siege.supermarche.Employe e) throws  siege.supermarche.GererEmployesException {
    this._delegate.modifierE(e);
  }

  /**
   * <pre>
   *   void supprimer (in string login)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimer (java.lang.String login) throws  siege.supermarche.GererEmployesException {
    this._delegate.supprimer(login);
  }

  /**
   * <pre>
   *   void supprimerE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public void supprimerE (siege.supermarche.Employe e) throws  siege.supermarche.GererEmployesException {
    this._delegate.supprimerE(e);
  }

  /**
   * <pre>
   *   siege.supermarche.Employe rechercher (in string login)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public siege.supermarche.Employe rechercher (java.lang.String login) throws  siege.supermarche.GererEmployesException {
    return this._delegate.rechercher(login);
  }

  /**
   * <pre>
   *   siege.supermarche.Employe rechercherE (in siege.supermarche.Employe e)
    raises (siege.supermarche.GererEmployesException);
   * </pre>
   */
  public siege.supermarche.Employe rechercherE (siege.supermarche.Employe e) throws  siege.supermarche.GererEmployesException {
    return this._delegate.rechercherE(e);
  }

}
