package siege.supermarche;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/gestionSupermarche/siege/siege/src/siege/supermarche.idl"
 * <li> <b>IDL Name</b>      ::supermarche::Caisse
 * <li> <b>Repository Id</b> IDL:supermarche/Caisse:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Caisse {
  ...
};
 * </pre>
 */
public abstract class CaissePOA extends org.omg.PortableServer.Servant implements 
  org.omg.CORBA.portable.InvokeHandler, siege.supermarche.CaisseOperations {

  public siege.supermarche.Caisse _this () {
   return siege.supermarche.CaisseHelper.narrow(super._this_object());
  }

  public siege.supermarche.Caisse _this (org.omg.CORBA.ORB orb) {
    return siege.supermarche.CaisseHelper.narrow(super._this_object(orb));
  }

  public java.lang.String[] _all_interfaces (final org.omg.PortableServer.POA poa, final byte[] objectId) {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:supermarche/Caisse:1.0"
  };

  private static java.util.Dictionary _methods = new java.util.Hashtable();

  static {
    _methods.put("_get_nomObjet", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 0));
    _methods.put("_get_totalVentes", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 1));
    _methods.put("_set_totalVentes", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 2));
    _methods.put("_get_agence", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 3));
    _methods.put("_get_caissier", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 4));
    _methods.put("vendreS", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 5));
    _methods.put("vendreC", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 6));
    _methods.put("editerTicket", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 7));
    _methods.put("connecter", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 8));
    _methods.put("deconnecter", new com.inprise.vbroker.CORBA.portable.MethodPointer(0, 9));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (java.lang.String opName,
                                                      org.omg.CORBA.portable.InputStream _input,
                                                      org.omg.CORBA.portable.ResponseHandler handler) {
    com.inprise.vbroker.CORBA.portable.MethodPointer method =
      (com.inprise.vbroker.CORBA.portable.MethodPointer) _methods.get(opName);
    if (method == null) {
      throw new org.omg.CORBA.BAD_OPERATION();
    }
    switch (method.interface_id) {
      case 0: {
        return siege.supermarche.CaissePOA._invoke(this, method.method_id, _input, handler);
      }
    }
    throw new org.omg.CORBA.BAD_OPERATION();
  }

  public static org.omg.CORBA.portable.OutputStream _invoke (siege.supermarche.CaisseOperations _self,
                                                             int _method_id,
                                                             org.omg.CORBA.portable.InputStream _input,
                                                             org.omg.CORBA.portable.ResponseHandler _handler) {
    org.omg.CORBA.portable.OutputStream _output = null;
    {
      switch (_method_id) {
      case 0: {
        java.lang.String _result = _self.nomObjet();
        _output = _handler.createReply();
        _output.write_string((java.lang.String)_result);
        return _output;
      }
      case 1: {
        double _result = _self.totalVentes();
        _output = _handler.createReply();
        _output.write_double((double)_result);
        return _output;
      }
      case 2: {
        double totalVentes;
        totalVentes = _input.read_double();
        _self.totalVentes(totalVentes);
        _output = _handler.createReply();
        return _output;
      }
      case 3: {
        java.lang.String _result = _self.agence();
        _output = _handler.createReply();
        _output.write_string((java.lang.String)_result);
        return _output;
      }
      case 4: {
        java.lang.String _result = _self.caissier();
        _output = _handler.createReply();
        _output.write_string((java.lang.String)_result);
        return _output;
      }
      case 5: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        _self.vendreS(codeBarre);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.CaisseException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.CaisseExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 6: {
      try {
        java.lang.String codeBarre;
        codeBarre = _input.read_string();
        int qte;
        qte = _input.read_long();
        _self.vendreC(codeBarre, qte);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.CaisseException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.CaisseExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 7: {
      try {
        _self.editerTicket();
        _output = _handler.createReply();
      }
      catch (siege.supermarche.CaisseException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.CaisseExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 8: {
      try {
        java.lang.String login;
        login = _input.read_string();
        java.lang.String password;
        password = _input.read_string();
        _self.connecter(login, password);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.CaisseException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.CaisseExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      case 9: {
      try {
        java.lang.String login;
        login = _input.read_string();
        _self.deconnecter(login);
        _output = _handler.createReply();
      }
      catch (siege.supermarche.CaisseException _exception) {
        _output = _handler.createExceptionReply();
        siege.supermarche.CaisseExceptionHelper.write(_output, _exception);
      }
        return _output;
      }
      }
      throw new org.omg.CORBA.BAD_OPERATION();
    }
  }
}
