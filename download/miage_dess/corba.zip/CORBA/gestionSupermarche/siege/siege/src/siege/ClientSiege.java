package siege;

import siege.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ClientSiege {

  public static void main(String args[]) {

    try {
      // On intialise l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on r�cup�re ensuite la racine de l'arbre
      NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

      // On construit le nom � chercher dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[2];
      nom[0] = new org.omg.CosNaming.NameComponent(args[3],"designation");
      nom[1] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      // On recherche la r�f�rence aupr�s du naming service
      org.omg.CORBA.Object distant = racineArbre.resolve(nom);

      //casting de l'objet CORBA au type adequat
      Siege monObj = siege.supermarche.SiegeHelper.narrow(distant);

      // On appelle les methodes
      //ajout
      for(int i=1;i<10;i++) {
        String nomAgence = new String("Agence "+i);
        try {
          monObj.inscrire(nomAgence);
        }
        catch(siege.supermarche.SiegeException e) {
          System.out.println(e.toString());
        }
      }
      //verification ajout
      String listeA[] = monObj.listeA();
      for(int i=0;i<listeA.length;i++) {
        System.out.println(listeA[i].toString());
      }
      //ajout incorrect
      for(int i=1;i<10;i++) {
        String nomAgence = new String("Agence "+i);
        try {
          monObj.inscrire(nomAgence);
        }
        catch(siege.supermarche.SiegeException e) {
          System.out.println(e.toString());
        }
      }
      //suppression
      for(int i=1;i<10;i++) {
        String nomAgence = new String("Agence "+i);
        try {
          monObj.desinscrire(nomAgence);
        }
        catch(siege.supermarche.SiegeException e) {
          System.out.println(e.toString());
        }
      }
      //verification suppression
      listeA = monObj.listeA();
      for(int i=0;i<listeA.length;i++) {
        System.out.println(listeA[i].toString());
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }//fin du main
}