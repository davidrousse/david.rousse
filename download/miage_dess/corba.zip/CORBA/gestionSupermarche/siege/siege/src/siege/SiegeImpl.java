package siege;

import siege.supermarche.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class SiegeImpl extends SiegePOA {

  private Vector _liste; //liste des agences connectees (string)
  private String _nomObjet; //nom du servant CORBA

  public SiegeImpl(String nomObjet) {
    //initialisation des attributs
    _liste = new Vector();
    _nomObjet = new String(nomObjet);
  }
  public void inscrire(String nomAgence) throws siege.supermarche.SiegeException {
    // on verifie que l'agence n'est pas deja connectee
    Enumeration parcours = _liste.elements();
    while(parcours.hasMoreElements())
      if(parcours.nextElement().toString().equals(nomAgence))
        // on indique que l'agence est deja connectee
        throw new siege.supermarche.SiegeException(_nomObjet+" - Agence "+nomAgence+" deja connectee");

    // si ce n'est pas le cas, on l'ajoute
    _liste.addElement(nomAgence);
    System.out.println(_nomObjet+" - Agence "+nomAgence+" inscrite");
  }
  public String[] listeA() {
    Enumeration parcours = _liste.elements();
    String[] retour = new String[_liste.size()];
    int i=0;
    while(parcours.hasMoreElements()) {
      retour[i] = (String)parcours.nextElement();
      i++;
    }
    return retour;
  }
  public void desinscrire(String nomAgence) throws siege.supermarche.SiegeException {
    try{
      _liste.removeElement(nomAgence);
      System.out.println(_nomObjet+" - Agence "+nomAgence+" desinscrite");
    }
    catch(Exception e) {
      // l'agence n'a pas ete trouvee
      throw new siege.supermarche.SiegeException(_nomObjet+" - Agence "+nomAgence+" non connectee");
    }
  }
}