package siege;

import siege.supermarche.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ServeurSiege {

  public static void main(String[] args) {
    try {
      //verification des arguments
      //1� arg. = nom objet CORBA, 2� arg. = nom federation general
      //3� arg. = nom federation local, 4� arg. = nom designation
      //5� arg. = nom fichier IOR
      if(args.length!=5) {
        System.out.println(args.length+"Appel incorrect. Syntaxe : ServeurSiege nomObj nomFedeGene nomFedeLocal nomDesi nomFichierIOR");
        System.exit(0);
      }

      //intialisation de l'orb
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

      //on r�cup�re le rootPOA.
      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

      //on r�cupere en premier lieu la r�f�rence initiale du service de nommage
      org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");

      //on cree l'arborescence federation plus designation dans le service de nommage
      Federation utilFede = new Federation();
      utilFede.creerEspaceNom(racineObj,args[1],args[2],args[3]);
      //on ecrit l'IOR du contexte de federation dans un fichier
      utilFede.ecrireIOR(orb,utilFede.recupererFederation(),args[4]);

      //on r�cup�re ensuite la racine de l'arbre de designation
      NamingContext racineDesignation = utilFede.recupererContexteDesignation();

      //on construit le nom � enregistrer dans l'annuaire
      org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
      nom[0] = new org.omg.CosNaming.NameComponent(args[0],"objet_metier");

      //on va cr�er des politiques (policies)
      org.omg.CORBA.Policy[] policies = {
        rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
      };

      //cr�ation de son propre POA avec les politiques pr�c�dentes
      POA poa = rootPOA.create_POA("supermarchePOA",rootPOA.the_POAManager(),policies);

      //cr�ation du servant
      SiegeImpl monServant = new SiegeImpl(args[0]);

      //donner un Object ID au servant
      byte[] monId = args[0].getBytes();

      //activer le servant avec l'ID dans le POA
      poa.activate_object_with_id(monId, monServant);

      //activer le POA manager
      rootPOA.the_POAManager().activate();

      //on enregistre l'objet dans l'annuaire
      racineDesignation.rebind(nom,poa.servant_to_reference(monServant));

      //on affiche le contenu des contextes cr�es
      System.out.println("Contenu designation :");
      utilFede.parcourirDesignation();
      System.out.println("Contenu federation :");
      utilFede.parcourirFederation();
      System.out.println("Contenu racine :");
      utilFede.parcourirRacine();

      //trace ecran
      System.out.println(poa.servant_to_reference(monServant) + " est pret.");

      //mse en attente de requete
      orb.run();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  } //fin du main
}