package chatcorba;

import org.omg.CosNaming.*;
import java.lang.*;
import org.omg.PortableServer.*;
import com.inprise.vbroker.orb.*;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValue;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValueHelper;
import java.io.*;
import java.util.*;
/**
 * Title:        Chat en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class Client implements Runnable{

  private static chatcorba.chatCORBA.chatServeur monServeur;
  private Thread threadInterne;
  private boolean enService;
  private String nomClient;

  public Client(String nomCli){

    nomClient = new String(nomCli);

    try
    {
      this.lancer();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public synchronized void lancer() {
    if(!enService) {
      threadInterne = new Thread(this);
      threadInterne.start();
      enService = true;
    }
  }

  public synchronized void arreter() {
    if(enService) {
      //on se deconnecte
      monServeur.deconnecter(nomClient);
      //arret du Thread
      threadInterne = null;
      enService = false;
    }
  }

  public boolean isAlive() {
    return enService;
  }

  public void run() {
      try {
        String ligne;
        BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));

         while(enService) {

            // On attend des saisie
            System.out.println("Entrer votre texte. Taper FIN pour quitter.");
            while(!(ligne = entree.readLine()).equals("FIN")) {
              monServeur.envoyer_message(nomClient+">"+ligne);
            }
            //on arreter le Thread
            this.arreter();
          }

      }
      catch(Exception e) {
        e.printStackTrace();
      }

  }

  public static void main(String args[]) {

    try {
        //1� param = nomServeur, 2� param = nomClient

	// On intialise l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        /**
         * On r�cupere en premier lieu la r�f�rence initiale du service de nommage
         * c'est � dire la r�f�rence initalie dont le nom est NameService
         */
        org.omg.CORBA.Object racineObj = orb.resolve_initial_references("NameService");
        /**
         * On r�cup�re ensuite la racine de l'arbre de d�signation: l'annuaire est
         * hierarchis� en cat�gorie et sous-cat�gories,
         * le tout formant l'arbre (ou graphe) de d�signation.
         */
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racineObj);

        // On construit le nom � chercher dans l'annuaire
        org.omg.CosNaming.NameComponent[] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        // On recherche la r�f�rence aupr�s du naming service
        org.omg.CORBA.Object objectDistant = racineArbre.resolve(nom);

        //casting de l'objet CORBA au type chatServeur
	monServeur = chatcorba.chatCORBA.chatServeurHelper.narrow(objectDistant);

        //connexion au serveur
        monServeur.connecter(args[1]);

        //On construit un nom � enregistrer
        //org.omg.CosNaming.NameComponent [] tabNom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(args[1],"");

        //R�cup�ration du RootPOA
        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

        //Initilisation des polices
        org.omg.CORBA.Any any = orb.create_any();
        BindSupportPolicyValueHelper.insert(any,BindSupportPolicyValue.BY_INSTANCE);
        org.omg.CORBA.Policy bsPolicy = orb.create_policy(com.inprise.vbroker.PortableServerExt.BIND_SUPPORT_POLICY_TYPE.value,any);

        org.omg.CORBA.Policy [] policies = {rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT),bsPolicy};

        //Cr�ation et activation du POA
        org.omg.PortableServer.POA monPOA = rootPOA.create_POA("chatClientPOA",rootPOA.the_POAManager(),policies);

        //Cr�ation d'un objet d'impl�mentation (servant)
        ChatClientImpl monChat = new ChatClientImpl(args[1]);

        //Affectation d'un ID � l'objet d'impl�mentation
        byte[] chatId = args[1].getBytes();

        //Activer le servant avec son Id dans notre POA
        monPOA.activate_object_with_id(chatId,monChat);

        //Activer le POAManager qui g�re le rootPOA et notre POA
        rootPOA.the_POAManager().activate();

        //Enregistrement de l'objet dans le service de nommage
        racineArbre.rebind(nom,monPOA.servant_to_reference(monChat));

        //Informations d'execution
        System.out.println(monPOA.servant_to_reference(monChat)+" est pret");

        //lancement de la partie Saisie des donn�es au clavier
        new Client(args[1]);

        //en attente de requetes
        orb.run();

      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }//fin du main
}