package chatcorba;

/**
 * Title:        Chat en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class ChatClientImpl extends chatcorba.chatCORBA.chatClientPOA {

  private String _nom;

  public ChatClientImpl(java.lang.String nom) {
    super();
    _nom = new String(nom);

  }

  public java.lang.String nom (){
    return _nom;
  }

  public void afficher_message(java.lang.String message) {
    System.out.println(message);
  }

  public void arreter()
  {
    try{
      //String [] args = new String[0];
      this._default_POA().deactivate_object(this._object_id());
      //org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
      //orb.shutdown(false);
      System.out.println("Arret du servant du client "+_nom);
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }
}