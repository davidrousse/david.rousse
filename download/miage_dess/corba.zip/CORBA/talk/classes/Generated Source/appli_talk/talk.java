package appli_talk;


/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/utilisateur/miag/talk/talk.idl"
 * <li> <b>IDL Name</b>      ::appli_talk::talk
 * <li> <b>Repository Id</b> IDL:appli_talk/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public interface talk extends com.inprise.vbroker.CORBA.Object, appli_talk.talkOperations, org.omg.CORBA.portable.IDLEntity {
}
