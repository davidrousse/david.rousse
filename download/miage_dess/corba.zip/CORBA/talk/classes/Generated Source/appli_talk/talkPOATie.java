package appli_talk;


/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/utilisateur/miag/talk/talk.idl"
 * <li> <b>IDL Name</b>      ::appli_talk::talk
 * <li> <b>Repository Id</b> IDL:appli_talk/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public class talkPOATie extends talkPOA {
  private appli_talk.talkOperations _delegate;
  private org.omg.PortableServer.POA _poa;


  public talkPOATie (final appli_talk.talkOperations _delegate) {
    this._delegate = _delegate;
  }


  public talkPOATie (final appli_talk.talkOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }


  public appli_talk.talkOperations _delegate () {
    return this._delegate;
  }


  public void _delegate (final appli_talk.talkOperations delegate) {
    this._delegate = delegate;
  }


  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }


  /**
     * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {
  return this._delegate.nom();
  }

  /**
     * <pre>
   *   void envoi_message (in string message);
   * </pre>
   */
  public void envoi_message (java.lang.String message) {
  this._delegate.envoi_message(message);
  }

}
