package appli_talk;


/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/utilisateur/miag/talk/talk.idl"
 * <li> <b>IDL Name</b>      ::appli_talk::talk
 * <li> <b>Repository Id</b> IDL:appli_talk/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public final class talkHolder implements org.omg.CORBA.portable.Streamable {
  public appli_talk.talk value;


  public talkHolder () {
  }


  public talkHolder (final appli_talk.talk _vis_value) {
    this.value = _vis_value;
  }


  public void _read (final org.omg.CORBA.portable.InputStream input) {
    value = appli_talk.talkHelper.read(input);
  }


  public void _write (final org.omg.CORBA.portable.OutputStream output) {
    appli_talk.talkHelper.write(output, value);
  }


  public org.omg.CORBA.TypeCode _type () {
    return appli_talk.talkHelper.type();
  }
}
