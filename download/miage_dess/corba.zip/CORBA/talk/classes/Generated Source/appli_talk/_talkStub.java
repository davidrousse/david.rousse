package appli_talk;


/**
 * <ul>
 * <li> <b>IDL Source</b>    "C:/utilisateur/miag/talk/talk.idl"
 * <li> <b>IDL Name</b>      ::appli_talk::talk
 * <li> <b>Repository Id</b> IDL:appli_talk/talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface talk {
  ...
};
 * </pre>
 */
public class _talkStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements talk {
  final public static java.lang.Class _opsClass = appli_talk.talkOperations.class;


  public java.lang.String[] _ids () {
    return __ids;
  }


  private static java.lang.String[] __ids = {
    "IDL:appli_talk/talk:1.0"
  };


  /**
     * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nom", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nom", _opsClass);
        if (_so == null) {
          continue;
        }
        final appli_talk.talkOperations _self = (appli_talk.talkOperations)_so.servant;
        try {
          return _self.nom();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
     * <pre>
   *   void envoi_message (in string message);
   * </pre>
   */
  public void envoi_message (java.lang.String message) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("envoi_message", true);
          _output.write_string((java.lang.String)message);
          _input = this._invoke(_output);
                  }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("envoi_message", _opsClass);
        if (_so == null) {
          continue;
        }
        final appli_talk.talkOperations _self = (appli_talk.talkOperations)_so.servant;
        try {
          _self.envoi_message(message);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
