
/**
 * Titre : <p>
 * Description : <p>
 * Copyright : Copyright (c) <p>
 * Soci�t� : <p>
 * @author
 * @version 1.0
 */

package talk;

import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import com.inprise.vbroker.orb.*;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValue;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValueHelper;

public class Serveur {

  public Serveur() {
  }

  public static void main(String args[])
  {

    try{
        //Initialisation de l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        //R�cup�ration du RootPOA
        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

        //R�cup�ration de la r�f�rence initiale du service de nommage
        org.omg.CORBA.Object racine = orb.resolve_initial_references("NameService");

        //R�cup�ration de l'arbre de d�signation
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racine);

        //On construit un nom � enregistrer
        org.omg.CosNaming.NameComponent [] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        //Initilisation des polices
        org.omg.CORBA.Any any = orb.create_any();
        BindSupportPolicyValueHelper.insert(any,BindSupportPolicyValue.BY_INSTANCE);
        org.omg.CORBA.Policy bsPolicy = orb.create_policy(com.inprise.vbroker.PortableServerExt.BIND_SUPPORT_POLICY_TYPE.value,any);

        org.omg.CORBA.Policy [] policies = {rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT),bsPolicy};

        //Cr�ation et activation du POA

        org.omg.PortableServer.POA monPOA = rootPOA.create_POA("talk_POA",rootPOA.the_POAManager(),policies);

        //Cr�ation d'un objet d'impl�mentation (servant)
        TalkImpl monTalk = new TalkImpl(args[0]);

        //Affectation d'un ID � l'objet d'impl�mentation
        byte[] talkId = args[0].getBytes();

        //Activer le servant avec son Id dans notre POA
        monPOA.activate_object_with_id(talkId,monTalk);

        //Activer le POAManager qui g�re le rootPOA et notre POA
        rootPOA.the_POAManager().activate();

        //Enregistrement de l'objet dans le service de nommage
        racineArbre.rebind(nom,monPOA.servant_to_reference(monTalk));

        System.out.println(monPOA.servant_to_reference(monTalk)+" est pret");
        //en attente de requetes
        orb.run();
      }
      catch(Exception e){
        e.printStackTrace();
      }
  }
}