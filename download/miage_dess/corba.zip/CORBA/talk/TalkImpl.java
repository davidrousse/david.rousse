
/**
 * Titre : <p>
 * Description : <p>
 * Copyright : Copyright (c) <p>
 * Soci�t� : <p>
 * @author
 * @version 1.0
 */
package talk;

public class TalkImpl extends appli_talk.talkPOA {

  private String _nom;

  public TalkImpl(java.lang.String nom) {
    super();
    _nom = new String(nom);
  }

  public java.lang.String nom (){
    return _nom;
  }

  public void envoi_message (java.lang.String message) {
    System.out.println("Reception : "+message);
  }
}