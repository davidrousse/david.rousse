package chatcorba;

import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import com.inprise.vbroker.orb.*;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValue;
import com.inprise.vbroker.PortableServerExt.BindSupportPolicyValueHelper;


/**
 * Title:        Chat en CORBA
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author L & D
 * @version 1.0
 */

public class Serveur {

  public static void main(String args[])
  {

    try{
        //Initialisation de l'orb
        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

        //R�cup�ration du RootPOA
        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

        //R�cup�ration de la r�f�rence initiale du service de nommage
        org.omg.CORBA.Object racine = orb.resolve_initial_references("NameService");

        //R�cup�ration de l'arbre de d�signation
        NamingContextExt racineArbre = NamingContextExtHelper.narrow(racine);

        //On construit un nom � enregistrer
        org.omg.CosNaming.NameComponent [] nom = new org.omg.CosNaming.NameComponent[1];
        nom[0] = new org.omg.CosNaming.NameComponent(args[0],"");

        //Initilisation des polices
        org.omg.CORBA.Policy[] policies = {
          rootPOA.create_lifespan_policy(LifespanPolicyValue.PERSISTENT)
        };
        //Cr�ation et activation du POA

        org.omg.PortableServer.POA monPOA = rootPOA.create_POA("chatServeurPOA",rootPOA.the_POAManager(),policies);

        //Cr�ation d'un objet d'impl�mentation (servant)
        ChatServeurImpl monChat = new ChatServeurImpl(args[0],racineArbre);

        //Affectation d'un ID � l'objet d'impl�mentation
        byte[] chatId = args[0].getBytes();

        //Activer le servant avec son Id dans notre POA
        monPOA.activate_object_with_id(chatId,monChat);

        //Activer le POAManager qui g�re le rootPOA et notre POA
        rootPOA.the_POAManager().activate();

        //Enregistrement de l'objet dans le service de nommage
        racineArbre.rebind(nom,monPOA.servant_to_reference(monChat));

        System.out.println(monPOA.servant_to_reference(monChat)+" est pret");
        //en attente de requetes
        orb.run();
      }
      catch(Exception e){
        e.printStackTrace();
      }
  }
}