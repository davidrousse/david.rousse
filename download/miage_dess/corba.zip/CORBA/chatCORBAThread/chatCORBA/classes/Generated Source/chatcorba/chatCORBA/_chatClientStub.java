package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBAThread/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatClient
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatClient:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatClient {
  ...
};
 * </pre>
 */
public class _chatClientStub extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements chatClient {
  final public static java.lang.Class _opsClass = chatcorba.chatCORBA.chatClientOperations.class;

  public java.lang.String[] _ids () {
    return __ids;
  }

  private static java.lang.String[] __ids = {
    "IDL:chatCORBA/chatClient:1.0"
  };

  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        java.lang.String _result;
        try {
          _output = this._request("_get_nom", true);
          _input = this._invoke(_output);
          _result = _input.read_string();
          return _result;
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("_get_nom", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatClientOperations _self = (chatcorba.chatCORBA.chatClientOperations)_so.servant;
        try {
          return _self.nom();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
    }
  }

  /**
   * <pre>
   *   void afficher_message (in string message);
   * </pre>
   */
  public void afficher_message (java.lang.String message) {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("afficher_message", true);
          _output.write_string((java.lang.String)message);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("afficher_message", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatClientOperations _self = (chatcorba.chatCORBA.chatClientOperations)_so.servant;
        try {
          _self.afficher_message(message);
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

  /**
   * <pre>
   *   void arreter ();
   * </pre>
   */
  public void arreter () {

    while (true) {
      if (!_is_local()) {
        org.omg.CORBA.portable.OutputStream _output = null;
        org.omg.CORBA.portable.InputStream  _input  = null;
        try {
          _output = this._request("arreter", true);
          _input = this._invoke(_output);
        }
        catch (org.omg.CORBA.portable.ApplicationException _exception) {
          final org.omg.CORBA.portable.InputStream in = _exception.getInputStream();
          java.lang.String _exception_id = _exception.getId();
          throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: " + _exception_id);
        }
        catch (org.omg.CORBA.portable.RemarshalException _exception) {
          continue;
        }
        finally {
          this._releaseReply(_input);
        }
      } else {
        final org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("arreter", _opsClass);
        if (_so == null) {
          continue;
        }
        final chatcorba.chatCORBA.chatClientOperations _self = (chatcorba.chatCORBA.chatClientOperations)_so.servant;
        try {
          _self.arreter();
        }
        finally {
          _servant_postinvoke(_so);
        }
      }
      break;
    }
  }

}
