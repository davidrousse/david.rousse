package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBAThread/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatServeur
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatServeur:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatServeur {
  ...
};
 * </pre>
 */
public class chatServeurPOATie extends chatServeurPOA {
  private chatcorba.chatCORBA.chatServeurOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public chatServeurPOATie (final chatcorba.chatCORBA.chatServeurOperations _delegate) {
    this._delegate = _delegate;
  }

  public chatServeurPOATie (final chatcorba.chatCORBA.chatServeurOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public chatcorba.chatCORBA.chatServeurOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final chatcorba.chatCORBA.chatServeurOperations delegate) {
    this._delegate = delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom () {
    return this._delegate.nom();
  }

  /**
   * <pre>
   *   void envoyer_message (in string message);
   * </pre>
   */
  public void envoyer_message (java.lang.String message) {
    this._delegate.envoyer_message(message);
  }

  /**
   * <pre>
   *   void connecter (in string nom);
   * </pre>
   */
  public void connecter (java.lang.String nom) {
    this._delegate.connecter(nom);
  }

  /**
   * <pre>
   *   void deconnecter (in string nom);
   * </pre>
   */
  public void deconnecter (java.lang.String nom) {
    this._delegate.deconnecter(nom);
  }

}
