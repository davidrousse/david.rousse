package chatcorba.chatCORBA;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "D:/miage_dess/CORBA/chatCORBAThread/chatCORBA/src/chatcorba/chatCORBA.idl"
 * <li> <b>IDL Name</b>      ::chatCORBA::chatServeur
 * <li> <b>Repository Id</b> IDL:chatCORBA/chatServeur:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface chatServeur {
  ...
};
 * </pre>
 */
public interface chatServeurOperations {
  /**
   * <pre>
   *   readonly attribute string nom;
   * </pre>
   */
  public java.lang.String nom ();

  /**
   * <pre>
   *   void envoyer_message (in string message);
   * </pre>
   */
  public void envoyer_message (java.lang.String message);

  /**
   * <pre>
   *   void connecter (in string nom);
   * </pre>
   */
  public void connecter (java.lang.String nom);

  /**
   * <pre>
   *   void deconnecter (in string nom);
   * </pre>
   */
  public void deconnecter (java.lang.String nom);

}
