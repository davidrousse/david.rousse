*********************************************
************   Rapport de stage  ************
************    David ROUSSE     ************
************    CIMA S.a.r.l.    ************
*********************************************

readme.txt : ce fichier

Tous les documents ci-dessous sont au format Microsoft Office 2000.

rapportCIMA.doc : rapport de stage

annexesCIMA.doc : annexes du rapport (avec notamment un apercu de COM+)

diapoCIMA.pps : diaporama de la soutenance

evaluationCIMA.doc : dossier d'�valuation du stage

suiviCIMA.xls : suivi quotidien du stade

***********************************************
* Date de cr�ation : 07/12/2000		      *
* Derni�re mise � jour : 14/12/2000           *
***********************************************
* Stage David Rousse, Ma�trise IUP MIAGe 2000 *
***********************************************
