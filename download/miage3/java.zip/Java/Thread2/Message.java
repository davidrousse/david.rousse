package distributeurmessageext;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import java.util.*;
import java.lang.*;

public class Message {
  static final int MAXFILE = 5; // Nb max. de messages produits
  private Vector messages = new Vector();

  public Message() {
  }

  public synchronized String insererMessage () throws InterruptedException {
	while (messages.size() == MAXFILE)
		wait();
        String m = new String(new java.util.Date().toString());
	messages.addElement(m);
	notify(); // un message disponible
        return m;
  }
  public synchronized String recupererMessage() throws InterruptedException {
	notify(); // pour que le producteur reste eveill�
		// c'est � dire un element toujours dans la file
	while (messages.size() == 0)
		wait();
	String mess = (String)messages.firstElement();
	messages.removeElement(mess);
	return mess;
  }

}