package distributeurmessageext;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

import java.util.* ;
import java.lang.* ;
import java.io.*;
/**
 *
 * @author  PVIDAL
 * @version
 */
public class ProducteurExt implements Runnable {

  private static int identity=0; //identifiant automatique d'objets ...
  private int id;
  private boolean arretThread;
  private Thread threadInterne;
  private Message mes;

    /** Creates new Producteur */
  public ProducteurExt(Message pMes) {
    id = identity;
    identity++;
    mes=pMes;
    arretThread=false;

  }

  public void start() {
    /* lancement du Thread */
    if(threadInterne==null) {
      //cr�ation d'un nouveau Thread c'est � dire
      //d'un nouveau flot d'instructions
      threadInterne = new Thread(this);
      //d�marrage de ce nouveau thread
      threadInterne.start();
    }
  }

  public void stop() {
    //arret du Thread
    if(threadInterne!=null) {
      arretThread = true;
      threadInterne = null;
    }
  }

  public void run(){
	try {

		while (!arretThread) {
                System.out.println(" --> Message inser� par "+id+" : "+mes.insererMessage());
		Thread.sleep(1000);
		}
	}
	catch (InterruptedException e) {}
	}

}