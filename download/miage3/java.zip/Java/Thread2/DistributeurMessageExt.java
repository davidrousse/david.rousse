package distributeurmessageext;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import java.util.*;
import java.lang.*;

public class DistributeurMessageExt {

  public static void main(String args[]) {
        double i=0;
        int j=0, NBPROCESSUS=5;
	Message mes = new Message();
        Vector gpeProducteur = new Vector();
        Vector gpeConsommateur = new Vector();

        for(j=0;j<NBPROCESSUS;j++) {
          gpeProducteur.addElement(new ProducteurExt(mes));
          ((ProducteurExt)gpeProducteur.elementAt(j)).start();

          gpeConsommateur.addElement(new ConsommateurExt(mes));
          ((ConsommateurExt)gpeConsommateur.elementAt(j)).start();
        }

        while(i<400000000)
          i++;

        for(j=0;j<NBPROCESSUS;j++) {
          ((ProducteurExt)gpeProducteur.elementAt(j)).stop();
          ((ConsommateurExt)gpeConsommateur.elementAt(j)).stop();
        }
  }
}