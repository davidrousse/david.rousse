package distributeurmessageext;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

import java.lang.Thread;
import java.io.*;

/**
 *
 * @author  PVIDAL
 * @version
 */
public class ConsommateurExt implements Runnable{

  private static int identity=0; //identifiant automatique d'objets ...
  private int id;
  private boolean arretThread; //variable de controle du Thread
  private Thread threadInterne;
  private Message mes;

  /** Creates new Consommateur */
  public ConsommateurExt(Message pMes) {
    id = identity;
    identity++;
    mes = pMes ;
    arretThread=false;
  }

  public void start() {
    /* lancement du Thread */
    if(threadInterne==null) {
      //cr�ation d'un nouveau Thread c'est � dire
      //d'un nouveau flot d'instructions
      threadInterne = new Thread(this);
      //d�marrage de ce nouveau thread
      threadInterne.start();
    }
  }

  public void stop() {
    //arret du Thread
    if(threadInterne!=null) {
      arretThread = true;
      threadInterne = null;
    }

  }

  public void run(){
    //flot d'instructions du trhead threadInterne
	try {
		while (!arretThread) {
			String message = mes.recupererMessage();
			System.out.println(" Message recu par "+id+" : "+message);
			Thread.sleep(2000);
		}
	}
	catch (InterruptedException e) {}
	}

}