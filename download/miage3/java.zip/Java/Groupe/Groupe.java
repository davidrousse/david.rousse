package groupe;

import java.util.Hashtable;

/**
 * Title:        Groupe g�n�rique
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

public class Groupe extends Hashtable {

  private String nom;

  public Groupe(String pNom) {

    super();
    nom = new String(pNom);

  }
}