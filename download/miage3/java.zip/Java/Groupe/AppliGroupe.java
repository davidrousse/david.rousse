package groupe;

import java.util.*;

/**
 * Title:        Groupe g�n�rique
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

public class AppliGroupe {
  public static void main(String[] args) {
    Groupe monGroupe = new Groupe("Mon groupe g�n�rique");
    monGroupe.put("David","03081977");
    monGroupe.put("R�mi","05081984");
    monGroupe.put(new Vector(),"05081984");

    System.out.println(monGroupe.toString());
  }
}