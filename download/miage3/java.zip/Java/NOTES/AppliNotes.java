
/**
 * Titre : Application de notes<p>
 * Description : TP 1<p>
 * Copyright : Copyright Maya DARRIEULAT
 * Soci�t� : UPS IUP Miage<p>
 * @author Maya DARRIEULAT
 * @version 1.0
 */
package note;

public class AppliNotes {

  public static void main(String[] args) {

 /*   CumulNotes cn = new CumulNotes();

    try{
      cn.insererNote(20);
      cn.insererNote(16);
      }
    catch(BadNoteValueException bad){
      System.out.println(bad.toString());
    }

    System.out.println(cn.toString() + "\nMoyenne : " + cn.calculerMoyenne());
*/

    Module mod = new Module("Programmation Java");

    mod.insererNouvelleMatiere("JavaDeBase",0.25f);
    mod.insererNouvelleMatiere("JavaReseau",0.25f);
    mod.insererNouvelleMatiere("Projet",0.50f);

    try {
      mod.insererNoteMatiere("JavaDeBase",10);
      mod.insererNoteMatiere("JavaDeBase",10);
      mod.insererNoteMatiere("JavaReseau",10);
      mod.insererNoteMatiere("JavaReseau",10);
      mod.insererNoteMatiere("Projet",10);
    }
    catch(BadNoteValueException bad){
      System.out.println(bad.toString());
    }

    try {
    System.out.println(mod.toString() + "\nMoyenne : " + mod.calculerMoyenneModule());
      }
    catch(BadCoeffSumException bad){
      System.out.println(bad.toString());
    }

  }
}