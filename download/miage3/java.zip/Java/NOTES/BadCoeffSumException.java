
/**
 * Titre : Application de notes<p>
 * Description : TP 1<p>
 * Copyright : Copyright (c) Sylvain BRAULT<p>
 * Soci�t� : UPS IUP Miage<p>
 * @author Sylvain BRAULT
 * @version 1.0
 */
package note;

public class BadCoeffSumException extends Exception{

  private float badCoeff;

  public BadCoeffSumException(float n) {
    badCoeff=n;
  }

  public String toString(){
    return "Coefficient invalide : " + badCoeff;
  }

}