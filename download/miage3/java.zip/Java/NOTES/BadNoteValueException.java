
/**
 * Titre : Application de notes<p>
 * Description : TP 1<p>
 * Copyright : Copyright (c) Maya DARRIEULAT<p>
 * Soci�t� : UPS IUP Miage<p>
 * @author Maya DARRIEULAT
 * @version 1.0
 */
package note;

public class BadNoteValueException extends Exception {

  private float badNote;

  public BadNoteValueException(float n) {
    badNote=n;
  }

  public String toString(){
    return "Note invalide : " + badNote;
  }
}