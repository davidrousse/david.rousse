/*
 * Module.java
 *
 * Created on 13 novembre 2000, 12:17
 */

package note;
import java.lang.*;
import java.util.*;
import java.io.*;

/**
 *
 * @author  Maya DARRIEULAT
 * @version
 */

public class Module extends Object {

  private class Matiere {
    public CumulNotes notes;
    public float coeff;
    public Matiere(float c) {
      coeff = c;
      notes = new CumulNotes();
    }
    public String toString() {
      return "Coefficient : "+coeff+"\n"+notes.toString()+"\n"+"\n";
    }
 }

  private String nom;
  private Hashtable matieres;

  /** Creates new Module */

  public Module(String n) {
    nom = n;
    matieres = new Hashtable();
  }

  public void insererNouvelleMatiere(String m, float c){
  // m nom de la mati�re, c'est la cl� dans la hashtable
      Matiere mat = new Matiere(c);
      matieres.put(m,mat);
  }

  public void insererNoteMatiere(String m, float n) throws BadNoteValueException {
    Matiere matiereNote = (Matiere)matieres.get(m);
    matiereNote.notes.insererNote(n);
  }

  public float calculerMoyenneModule() throws java.lang.ArithmeticException,BadCoeffSumException {
    float totalCoeff = 0;
    float totalNotes = 0;
    for (Enumeration e = matieres.elements() ; e.hasMoreElements();)
    {
        Matiere mat = ((Matiere)e.nextElement());
        totalNotes = totalNotes + ((mat.notes.calculerMoyenne())*(mat.coeff));
        totalCoeff = totalCoeff + (mat.coeff);
    }
    if ( totalCoeff > 1) throw new BadCoeffSumException(totalCoeff);
    return totalNotes;
  }

  public String toString() {
    String s = new String(" ");
    Enumeration e = matieres.keys();
    s = "Module" + nom + "\n";
    while (e.hasMoreElements()) {
    String cle = (String)e.nextElement();
      s = s + cle + matieres.get(cle).toString();
    }
    return s;
  }
}