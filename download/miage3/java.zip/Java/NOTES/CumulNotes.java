/*

 * CumulNotes.java

 * Classe permettant de r�aliser le cumul de notes et d'en calculer la moyenne

 * Created on 9 octobre 2000, 13:29

 */



package note;

import java.lang.*;

import java.util.*;

import java.io.*;



/**

 *

 * @author  lot

 * @version

 */

public class CumulNotes {



  private Vector notes; // Vecteur de notes

  public static final int MIN_VALUE = 0; // Note minimale

  public static final int MAX_VALUE = 20; // Note maximale



  /** Creates new CumulNotes */

  public CumulNotes() {

    notes = new Vector();

  }



  /** Insertion d'une note */

  public void insererNote(float n) throws BadNoteValueException  {

    if ( n < MIN_VALUE || n > MAX_VALUE) throw new BadNoteValueException(n);
        notes.addElement(new Float(n));

  }



  /** Calcul de la moyenne */

  public float calculerMoyenne() throws java.lang.ArithmeticException {

    float somme = 0;

    Enumeration e = notes.elements();

    while (e.hasMoreElements()) {

      somme = somme + ((Float)e.nextElement()).floatValue();

    }

    return somme/notes.size();

  }



  public String toString() {

    String s = new String("Notes : ");

    Enumeration e = notes.elements();

    while (e.hasMoreElements()) {

      s = s + " " + ((Float)e.nextElement()).toString();

    }

    return s;

  }

}