package gestionparc;

/**
 * Title:        Gestion du parc avec des threads
 * Description:  Partiel MIAGe 3 1996 et 1998.
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */
import java.util.Vector ;
import java.lang.Thread ;

public class Transporteur implements Runnable {

  private boolean actif;
  private Thread threadInterne;
  private Expediteur exp;

  public Transporteur(Expediteur pExp) {
    actif=false;
    exp=pExp;
  }

  public void demarrer() {
    if(threadInterne==null) {
      actif=true;
      threadInterne = new Thread(this);
      threadInterne.start();
    }
  }

  public void arreter() {
    if(threadInterne!=null) {
      actif=false;
      threadInterne=null;
    }
  }

  public void run() {
    try {
      int i=0;
      while(actif) {
        /* traitement applicatif du thread */
        System.out.println("\n\nReception dans Transporteur : "+exp.Recuperer(i));
        Thread.sleep(2000);
      }
    }
    catch(InterruptedException e) {
      System.out.println("\n\nUne erreur s'est produite ...\n"+e.toString());
    }
  }

}