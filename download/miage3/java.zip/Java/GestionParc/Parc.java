package gestionparc;

/**
 * Title:        Gestion du parc avec des threads
 * Description:  Partiel MIAGe 3 1996 et 1998.
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

import java.util.*;
import java.lang.*;

public class Parc {

  public static void main(String[] args) throws InterruptedException {
    try {

      Expediteur monExp = new Expediteur();
      Transporteur monTran = new Transporteur(monExp);
      monExp.demarrer();
      monTran.demarrer();
    }
    catch(Exception e) {
    }

  }
}