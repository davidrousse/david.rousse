package gestionparc;

/**
 * Title:        Gestion du parc avec des threads
 * Description:  Partiel MIAGe 3 1996 et 1998.
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */
import java.util.*;
import java.lang.*;

public class Expediteur implements Runnable {

  static final int NBMAXOBJETS = 10; // Nb max. d'objets par container
  static final int NBMAXCONTAINERS = 5; // Nb max. de container

  private boolean actif;
  private Thread threadInterne;

  private Vector containers = new Vector(NBMAXCONTAINERS-1);


  public Expediteur() {
    int i=0;
    actif=false;
    for(i=0;i<NBMAXCONTAINERS-1;i++)
      containers.addElement(new Integer(0));
  }

  public void demarrer() {
    if(threadInterne==null) {
      actif=true;
      threadInterne = new Thread(this);
      threadInterne.start();
    }
  }

  public void arreter() {
    if(threadInterne!=null) {
      actif=false;
      threadInterne=null;
    }
  }

  public void run() {
    try {
      while(actif) {
        /* traitement applicatif du thread */
        Deposer(2);
        System.out.println("\nDepot effectu� ...");
        Thread.sleep(1000);
      }
    }
    catch(InterruptedException e) {
      System.out.println("\n\nUne erreur s'est produite ...\n"+e.toString());
    }
  }

  private synchronized void Deposer(int pNbObjets)
                                              throws InterruptedException  {
    int i=0, placesLibres=0;
    Integer nb;

    if(containers.size()==NBMAXCONTAINERS)
      wait();

    for(i=0;i<containers.size();i++) {
      nb=new Integer(containers.elementAt(i).toString());
      placesLibres=NBMAXOBJETS-nb.intValue();
      if(placesLibres>=pNbObjets) {
        containers.setElementAt(new Integer(nb.intValue()+pNbObjets),i);
        notify();
        return;
      }
    }
  }

  public synchronized int Recuperer(int numContaineur)
                                              throws InterruptedException  {
    int i=0, retour=0;
    Integer nb;

    while(containers.size()==0)
      wait();

    for(i=0;i<containers.size();i++) {
      nb=new Integer(containers.elementAt(i).toString());
      if(nb.intValue() ==NBMAXOBJETS) {
        retour =  nb.intValue();
        containers.removeElementAt(i);
        return retour;
      }
    }
    return -1;
  }
}