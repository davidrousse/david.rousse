/**
 * Title:        Compter les mots
 * Description:  MIAGe TP
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR
 * @version 1.0
 */

package compte;
import java.util.*;
import java.io.*;
import java.lang.*;

public class CompteMot
{

    public static void main(String[] args) throws IOException, Exception
    {

      try
      {
        /* on cr�e une instance de BufferedReader */
	BufferedReader tamponEntree = new BufferedReader(new FileReader("d:/java/Compte/texte.txt"));
        /* variable de lecture de chaque ligne */
        String ligneCourante;
        /* nombre d'occurrence de chaque mot */
        Integer nbOccurrence;
        /* mots de la ligne a lire */
        StringTokenizer motsLigne;
        /* mot courant */
        String motCourant;
        /* stockage mot/nb occurrence */
        Hashtable tableMots = new Hashtable();
        /* reference � 2 Enumeration pour le parcours de la Hastable */
        Enumeration parcoursResultats1, parcoursResultats2;

        /* parcours du fichier ligne par ligne */
        while((ligneCourante = tamponEntree.readLine())!=null)
        {
          /* traitement des mots de la ligne courants */
          motsLigne = new StringTokenizer(ligneCourante);
          while(motsLigne.hasMoreTokens())
          {
            /* enregistrement de l'occurrence du mot */
            motCourant = motsLigne.nextToken();

            if(tableMots.containsKey(motCourant))
            {
              /* le mot des deja present */
              nbOccurrence = (Integer)(tableMots.get(motCourant));
              tableMots.put(motCourant,new Integer(nbOccurrence.intValue()+1));
            }
            else
              /* le mot est nouveau */
              tableMots.put(motCourant,new Integer("1"));

          } /* fin traitement ligne */

        } /* fin parcours fichier */

        /* affichage des r�sultats du traitement */
        parcoursResultats1 = tableMots.keys();
        parcoursResultats2 = tableMots.elements();

        while(parcoursResultats1.hasMoreElements() && parcoursResultats2.hasMoreElements())
        {
          /* affichage mot */
          System.out.println("Mot : "+parcoursResultats1.nextElement());
          /* affichage occurrence du mot */
          System.out.println("Occ. : "+parcoursResultats2.nextElement()+"\n");
        }

        /* fermeture fichier */
        tamponEntree.close();

      } //fin try

      /* traitement erreur */
      catch(IOException error)
      {
        System.out.println("Une erreur a �t� lev�e ...");
        System.out.println(error.toString());
      }
      catch(Exception error)
      {
        System.out.println("Une erreur a �t� lev�e ...");
        System.out.println(error.toString());
      }
    }

}