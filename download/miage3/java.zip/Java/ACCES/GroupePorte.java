package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class GroupePorte extends Vector {

  private String nom;

  /* partie publique de la classe */

  /* constructeur */
  public GroupePorte(String pNom) {
    super();
    nom = new String(pNom);
  }

  public void addElement(Object pElement) {
    /* il faudrait v�rifier que l'on ins�re une instance */
    /* de la hi�rarchie issue de Porte                   */
    super.addElement(pElement);
  }

  public boolean removeElement(Object pElement) {
    /* � post�riori, cette red�finition est inutile ... */
    if(super.contains(pElement))
    {
      super.removeElement(pElement);
      return true;
    }
    else
      return false;
  }

  public Object elementAt(int pRangeOfElement) throws UnknowValueException {
    /* cette red�finition peut paraitre inutile .. */
    if(super.size()==pRangeOfElement)
      throw new UnknowValueException("Indice en dehors de la plage : "+
                                                              pRangeOfElement);
    else
      return super.elementAt(pRangeOfElement);
  }
  /* r�cuperation du nom du groupe */
  public String getNom() {
    return nom;
  }

  public String toString() {
    int nbPortes = super.size();
    StringBuffer chaineRetour = new StringBuffer("Groupe de Portes : "+nom
                                +" - Nombre de Portes : "+nbPortes);
    /* si le groupe contient des portes, on les affiche */
    if(nbPortes>0)
        chaineRetour.append("\nContenu : \n"+super.toString());
    return chaineRetour.toString();
  }

}