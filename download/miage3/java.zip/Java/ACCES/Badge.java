package gestionacces3;

/**
 * Title:        Gestion des Acc�s
 * Description:  TP MIAGe 2000/2001
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR et MH
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class Badge {

  int numero;
  Date finValidite;

  /* partie publique de la classe */

  /* constructeur */
  public Badge(int pNumero, String pFinValidite) {
    numero = pNumero;
    finValidite = new Date(pFinValidite);
  }

  /* conversion en String */
  public String toString() {
    return "Num�ro : "+numero+" - Valide jusqu'� : "+finValidite.toString();
  }
}