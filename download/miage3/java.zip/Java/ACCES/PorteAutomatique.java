package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class PorteAutomatique extends Porte {

  protected boolean porteOuverte;
  static protected Vector lstPortesAuto = new Vector(); /* attribut de classe */

  /* partie publique de la classe */

  /* constructeur */
  public PorteAutomatique(int pNumero, String pNomSalle) {
    super(pNumero,pNomSalle);
    porteOuverte = false;
    lstPortesAuto.addElement(this);
  }

  /* constructeur */
  public PorteAutomatique(int pNumero, String pNomSalle, boolean pPorteOuverte){
    super(pNumero,pNomSalle);
    porteOuverte = pPorteOuverte;
    lstPortesAuto.addElement(this);
  }

  /* conversion en String */
  public String toString() {
    if(porteOuverte)
      return super.toString()+" - Etat : ouvert";
    else
      return super.toString()+" - Etat : ferm�";
  }

  public void open() {
    porteOuverte = true;
  }

  public void close() {
    porteOuverte = false;
  }

  /* m�tohde de classe */
  static public Enumeration getAll() {
    return lstPortesAuto.elements();
  }

}