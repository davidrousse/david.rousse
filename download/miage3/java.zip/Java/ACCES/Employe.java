package gestionacces3;

/**
 * Title:        Gestion des Acc�s
 * Description:  TP MIAGe 2000/2001
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR et MH
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class Employe extends Personne {

  private String fonction;
  private Badge refBadge;

  /* partie publique de la classe */

  /* constructeur */
  public Employe(String pNom, String pFonction) {
    /* appel constructeur classe m�re */
    super(pNom);
    /* donn�es sp�cifique � ce fils */
    fonction = new String(pFonction);
    refBadge = null;
  }

  /* constructeur */
  public Employe(String pNom, String pFonction, GroupePersonne pGroupePersonne) {
    /* appel constructeur classe courante */
    this(pNom, pFonction);
    /* donn�es sp�cifique � ce fils */
    fonction = new String(pFonction);
    refBadge = null;
  }
  /* recuperation du badge */
  public Badge getBadge() {
    return refBadge;
  }

  /* affectation d'un badge */
  public void setBadge(int pNumero, String pFinValidite) {
    refBadge = new Badge(pNumero,pFinValidite);
  }

  /* recuperation du groupe de this */
  final public GroupePersonne getGroupeAffiliation() {
    return super.getGroupeAffiliation();
  }

  /* affectation de this � un groupe */
  final public void setGroupeAffiliation(GroupePersonne pNomGroupe) {
    super.setGroupeAffiliation(pNomGroupe);
  }

  /* conversion en String */
  public String toString() {
    return super.toString()+" - Fonction : "+fonction;
  }
}