package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class PorteMagnetique extends Porte {

  private int numeroSerieLecteur;

  public PorteMagnetique(int pNumero, String pNomSalle) {
    super(pNumero,pNomSalle);
    numeroSerieLecteur = 0;
  }

  public PorteMagnetique(int pNumero, String pNomSalle, int pNumeroSerieLecteur) {
    super(pNumero,pNomSalle);
    numeroSerieLecteur = pNumeroSerieLecteur;
  }

  /* conversion en String */
  public String toString() {
      return super.toString()+" - Num�ro s�rie : "+numeroSerieLecteur;
  }

}