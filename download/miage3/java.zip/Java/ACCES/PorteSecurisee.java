package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class PorteSecurisee extends PorteAutomatique {

  protected int codeAcces;
  protected int codeSecurite;

  /* partie publique de la classe */

  /* constructeur */
  public PorteSecurisee(int pNumero, String pNomSalle, boolean pPorteOuverte) {
    super(pNumero,pNomSalle, pPorteOuverte);
    codeAcces = 0;
    codeSecurite = 0;
  }

  /* constructeur */
  public PorteSecurisee(int pNumero, String pNomSalle, boolean pPorteOuverte,
                                         int pCodeAcces, int pCodeSecurite) {
    super(pNumero,pNomSalle, pPorteOuverte);
    codeAcces = pCodeAcces;
    codeSecurite = pCodeSecurite;
  }

  /*  modification du code d'acc�s */
  public void setCodeAcces(int pSecu) throws IOException {
    int oldCode, newCode1, newCode2;
    if (codeSecurite == pSecu)
    {
      /* le code de s�curit� est correct */
      System.out.println("\nModification du code d'acc�s..."+
                         "\nAncien code d'acces : ");
      oldCode = System.in.read();
      if (codeAcces == oldCode)
      {
        /* l'ancien code d'acc�s est correct */
        System.out.println("\nNouveau code d'acc�s : ");
        newCode1 = System.in.read();
        System.out.println("\nSConfirmer le nouveau code d'acces : ");
        newCode2 = System.in.read();
        if (newCode1 == newCode2)
        {
          /* on enregistre le nouveau code */
          codeAcces = newCode1;
          System.out.println("\nCode d'acc�s modifi�.");
        }
      }
    }
  }

  /* conversion en String */
  public String toString() {
      return super.toString()+" - Code acc�s : "+codeAcces+
                                      " - Code S�curit� : "+codeSecurite;
  }

}