 package gestionacces3;

/**
 * Title:        Gestion des Acc�s
 * Description:  TP MIAGe 2000/2001
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author DR et MH
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class Personne {

  protected String nom;
  protected GroupePersonne refGroupeAffiliation;

  /* partie publique de la classe */

  /* constructeur */
  public Personne(String pNom) {
    nom = new String(pNom);
    refGroupeAffiliation = null;
  }

  /* constructeur */
  public Personne(String pNom, GroupePersonne pGroupePersonne) {
    this(pNom);
    refGroupeAffiliation = pGroupePersonne;
  }

  /* recuperation du groupe de this */
  public GroupePersonne getGroupeAffiliation() {
    return refGroupeAffiliation;
  }

  /* affectation de this � un groupe */
  public void setGroupeAffiliation(GroupePersonne pNomGroupe) {
    /* il faudrait v�rifier si l'employ� n'est pas d�j� */
    /* affili� � un autre groupe                        */
    refGroupeAffiliation = pNomGroupe;
    pNomGroupe.addElement(this);
  }

  /* conversion en String */
  public String toString() {
    return "Nom : "+nom;
  }
}