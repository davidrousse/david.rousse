package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

public class UnknowValueException extends ArrayIndexOutOfBoundsException {

  private String UnknowValue;

  public UnknowValueException(String pUnknowValue) {
    super();
    UnknowValue = new String(pUnknowValue);
  }

  public String toString() {
    return "\n"+UnknowValue;
  }
}