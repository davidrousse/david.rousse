package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class BadRelationException extends Exception {

  private String badRelation;

  public BadRelationException(Object pBadRelation1, Object pBadRelation2) {
    badRelation = new String(pBadRelation1.hashCode()+"-"+pBadRelation2.hashCode());
  }

  public String toString() {
    return "Le couple suivant existe d�j� : "+badRelation;
  }
}