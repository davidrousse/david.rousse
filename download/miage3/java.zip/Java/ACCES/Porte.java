package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class Porte
 {

  protected int numero;
  protected String nomSalle;

  /* partie publique de la classe */

  /* constructeur */
  public Porte(int pNumero, String pNomSalle) {
    /* il faudrait v�rifier �ventuellement dans un cas r�el */
    /* si le num�ro n'est pas d�j� utilis�                  */
    numero = pNumero;
    nomSalle = new String(pNomSalle);
  }

  /* conversion en String */
  public String toString() {
    return "Porte n� : "+numero+" - Salle : "+nomSalle;
  }
}