package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class UnknowKeyException extends Exception {

  private String unknowKey;

  public UnknowKeyException(String pUnknowKey) {
    unknowKey = new String(pUnknowKey);
  }

  public String toString() {
    return "Cl� inconnue : "+unknowKey;
  }
}