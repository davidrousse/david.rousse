package gestionacces3;

import java.util.*;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

public class GroupePersonne extends Vector {

  String nom;

  /*partie publique de la classe */

  /* constructeur */
  public GroupePersonne(String pNom) {
    super();
    nom = new String(pNom);
  }

  /* r�cuperation du nom du groupe */
  public String getNom() {
    return nom;
  }

  /* cr�ation du contenu du groupe en String */
  public String toString() {
    StringBuffer chaineRetour = new StringBuffer("Groupe de Personnes : "+nom);
    if(super.size()>0)
    {
      /* enumeration pour parcourir lstPersonnes */
      Enumeration parcoursLstPersonnes = super.elements();
      chaineRetour.append("\n\tListe des membres du groupe :");
      while(parcoursLstPersonnes.hasMoreElements())
      {
        /* ajout de chaque personne afili�e au groupe */
        chaineRetour.append("\n\t\t"+
                                 parcoursLstPersonnes.nextElement().toString());
      }
      /* remarque : on aurait pu ecrire directement       */
      /* chaineRetour.append("\n\t\t"+ super.toString()); */
    }
    return chaineRetour.toString();
  }
}