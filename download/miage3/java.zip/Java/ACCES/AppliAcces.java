package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;
import java.lang.reflect.*;

public class AppliAcces {
  public static void main(String[] args) {
    try {

      /***********************************************************************/
      /*                Instanciations et affichage des donn�es              */
      /***********************************************************************/
      /* Les groupes de portes */
      GroupePorte tabGroupePorte[] = {new GroupePorte("Zone Critique"),
                                      new GroupePorte("Zone Priv�e"),
                                      new GroupePorte("Zone Publique")};
      /* Les portes de Zone Critique */
      tabGroupePorte[0].addElement(new PorteSecurisee(3,"Coffre",false,
                                                               1308,1977));
      tabGroupePorte[0].addElement(new PorteMagnetique(5,
                                          "Couloir acc�s au coffre", 12258));
      /* Les portes de Zone Priv�e */
      tabGroupePorte[1].addElement(new PorteSecurisee(4,"Bureau Direction",true,
                                                              1234,9876));
      /* Les portes de Zone Publique */
      tabGroupePorte[2].addElement(new Porte(1,"Toillettes"));
      tabGroupePorte[2].addElement(new PorteAutomatique(2,"Entr�e Client�le",
                                                                         true));

      System.out.print("\n*********\n"+tabGroupePorte[0].toString()+
                                                          "\n*********\n");
      System.out.print("\n*********\n"+tabGroupePorte[1].toString()+
                                                          "\n*********\n");
      System.out.print("\n*********\n"+tabGroupePorte[2].toString()+
                                                          "\n*********\n");

      /* Les groupes de personnes */
      GroupePersonne tabGroupePersonne[] = {new GroupePersonne("Direction"),
                                            new GroupePersonne("S�curit�"),
                                            new GroupePersonne("Agent")};
      /* Les Personnes de Direction */
      tabGroupePersonne[0].addElement(new Employe("Marqui�","Directeur"));
      tabGroupePersonne[0].addElement(new Employe("Zurfluh","Sous-Directeur"));

      /* Les personnes de S�curit� */
      tabGroupePersonne[1].addElement(new Employe("Baba","Videur"));
      tabGroupePersonne[1].addElement(new Employe("Pascal","Videuse"));

      /* Les personnes de Agent */
      tabGroupePersonne[2].addElement(new Employe("Maya","Agent 1"));
      tabGroupePersonne[2].addElement(new Employe("Audrey","Agent 2"));
      tabGroupePersonne[2].addElement(new Employe("Monia","Agent 3"));

      System.out.print("\n*********\n"+tabGroupePersonne[0].toString()+
                                                            "\n*********\n");
      System.out.print("\n*********\n"+tabGroupePersonne[1].toString()+
                                                            "\n*********\n");
      System.out.print("\n*********\n"+tabGroupePersonne[2].toString()+
                                                            "\n*********\n");


      /***********************************************************************/
      /*                Affectation des droits d'acc�s                       */
      /***********************************************************************/
      /* Cr�ation de l'association */
      Acces droitAcces = new Acces("Acc�der");
      /* Zone Critique - Direction */
      droitAcces.addElement(tabGroupePorte[0],tabGroupePersonne[0]);
      /* Zone Critique - S�curit� */
      droitAcces.addElement(tabGroupePorte[0],tabGroupePersonne[1]);
      /* Zone Priv�e - Direction */
      droitAcces.addElement(tabGroupePorte[1],tabGroupePersonne[0]);
      /* Zone Publique - Direction */
      droitAcces.addElement(tabGroupePorte[2],tabGroupePersonne[0]);
      /* Zone Publique - S�curit� */
      droitAcces.addElement(tabGroupePorte[2],tabGroupePersonne[1]);
      /* Zone Publique - Agent */
      droitAcces.addElement(tabGroupePorte[2],tabGroupePersonne[2]);
      /* affichage du contenu de l'association */
      System.out.print("\n*********\n"+droitAcces.toString()+"\n*********\n");


      /***********************************************************************/
      /*     Ouverture et fermeture des portes automatiques en m�me temps    */
      /***********************************************************************/
      System.out.print(
          "\n********* Fermeture de toutes les PorteAutomatique *********\n");
      Enumeration parcours = PorteAutomatique.getAll();
      PorteAutomatique porteCourante;
      /* parcours de toutes les instances de PorteAutomatique */
      while(parcours.hasMoreElements())
      {
        porteCourante = (PorteAutomatique)parcours.nextElement();
        /* affichage */
        System.out.print("\nAvant la fermeture ...\n"+
                                            porteCourante.toString());
        /* fermeture */
        porteCourante.close();
        /* affichage */
        System.out.print("\nApr�s la fermeture ...\n"+
                                            porteCourante.toString());
      }

    }
    catch(Exception error) {
      System.out.print("\nUne erreur s'est produite ...\n"+error.toString());
    }
  }
}