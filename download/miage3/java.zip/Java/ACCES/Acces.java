package gestionacces3;

/**
 * Title:        Gestion des acc�s
 * Description:  Sp�cialisation de classes conteneurs
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MH et DR
 * @version 1.0
 */

import java.lang.*;
import java.util.*;
import java.io.*;

public class Acces {

  protected String nom;
  protected Vector indexKeyA;
  protected Vector indexKeyB;

  /* partie publique de la classe */

  /* constructeur */
  public Acces(String pNomRelation) {
    nom = new String(pNomRelation);
    indexKeyA = new Vector();
    indexKeyB = new Vector();
  }

  /* ajoute un couple A-B                                */
  /* !!! il faut toujours ajouter les A du cot� de KeyA  */
  /* et les B du cot� de KeyB                            */
  public void addElement(Object pKeyA, Object pKeyB)
                                                  throws BadRelationException {

    int position=0;;
    Enumeration parcours;

    //on v�rifie que le couple n'existe pas d�j�
    if(!indexKeyA.isEmpty() && indexKeyA.contains(pKeyA))
    {
      parcours = indexKeyA.elements();
      //on regarde si la cl� A est li�e � B
      while(parcours.hasMoreElements())
      {
        if(parcours.nextElement()==pKeyA)
        {
          if(pKeyB == indexKeyB.elementAt(position))
            //on l�ve une exception d'insertion
            throw new BadRelationException(pKeyA, pKeyB);
        }
        position++;
      }
    }
    else
    {
      if(!indexKeyB.isEmpty() && indexKeyB.contains(pKeyB))
      {
        parcours = indexKeyB.elements();
        //on regarde si la cl� B est li�e � B
        while(parcours.hasMoreElements())
        {
          if(parcours.nextElement()==pKeyB)
          {
            if(pKeyA == indexKeyA.elementAt(position))
              //on l�ve une exception d'insertion
              throw new BadRelationException(pKeyA, pKeyB);
          }
          position++;
        }
      }
    }
    //si aucune exception n'a �t� lev�e, on ins�re les 2 cl�s
    indexKeyA.addElement(pKeyA);
    indexKeyB.addElement(pKeyB);

  }

  /* supprime un uncouple en fonction de sa position */
  /* commence � 0                                    */
  public void removeElement(int position) {
    indexKeyA.removeElementAt(position);
    indexKeyB.removeElementAt(position);
    indexKeyA.trimToSize();
    indexKeyB.trimToSize();
  }

  /* renvoie toutes les cl�s li�es � une autre cl�s   */
  /* par ex. si on a : indexKeyA = { A1, A1, A2, A1 } */
  /*                et indexKeyB = { B1, B2, B1, B3 } */
  /* pour get(A1), on renvoie { B1, B2, B3 }          */
  public Enumeration get(Object pKey) throws UnknowKeyException {

    int position=0;
    Enumeration parcours;
    Vector retour = new Vector();

    //si la cl� fait partie de indexKeyA, on parcours ce vecteur,
    //sinon on parcours indexKeyB
    if(indexKeyA.contains(pKey))
    {
      parcours = indexKeyA.elements();
      //on parcours A et on r�cup�re tous les B li�s avec pKey de A
      while(parcours.hasMoreElements())
      {
        if(parcours.nextElement()==pKey)
        {
          //on ajoute la cl� B li�e avec pKey
          retour.addElement(indexKeyB.elementAt(position));
        }
        position++;
      }
    }
    else
    {
      if(indexKeyB.contains(pKey))
      {
        parcours = indexKeyB.elements();
        //on parcours B et on r�cup�re tous les A li�s avec pKey de B
        while(parcours.hasMoreElements())
        {
          if(parcours.nextElement()==pKey)
          {
            //on ajoute la cl� A li�e avec pKey
            retour.addElement(indexKeyA.elementAt(position));
          }
          position++;
        }
      }
      else
      {
        //cl� inconnue, on l�ve une exception
        throw new UnknowKeyException(pKey.toString());
      }
    }

    return retour.elements();
  }

  /* on renvoie le nom, le nombre de relations et ces relations             */
  public String toString() {
    StringBuffer chaineRetour = new StringBuffer("Acc�s : "+nom
                                +" - Nombre de lignes : "+indexKeyA.size());

    //parcours des cl�s si il en existe
    if(indexKeyA.size()>0)
    {
      Enumeration parcoursKeyA = indexKeyA.elements();
      Enumeration parcoursKeyB = indexKeyB.elements();
      chaineRetour.append("\nRelations existantes : \n");
      while(parcoursKeyA.hasMoreElements() && parcoursKeyB.hasMoreElements())
      {
          chaineRetour.append("\n---->\n"+parcoursKeyA.nextElement().toString()
                              +"\n ...... li� avec ...... \n"
                              +parcoursKeyB.nextElement().toString()+"\n\n");
      }
    }
    return chaineRetour.toString();
  }

} /* fin classe */