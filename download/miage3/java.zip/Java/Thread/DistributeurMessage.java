/*
 * DistributeurMessage.java
 *
 * Created on 26 septembre 2000, 21:50
 */
 
package tpThread;

/** 
 *
 * @author  PVIDAL
 * @version 
 */
public class DistributeurMessage {

  /**
  * @param args the command line arguments
  */
  public static void main (String args[]) {
	Producteur producteur = new Producteur();
	producteur.start() ;
	Consommateur consommateur = new Consommateur(producteur);
        consommateur.start() ;

  }
 
}