/*
 * Producteur.java
 *
 * Created on 26 septembre 2000, 21:07
 */
 
package tpThread;
import java.util.Vector ;
import java.lang.Thread ;
/** 
 *
 * @author  PVIDAL
 * @version 
 */
public class Producteur extends Thread {
  static final int MAXFILE = 5; // Nb max. de messages produits
  private Vector messages = new Vector();


  public void run(){
	try {
		while (true) {
		insererMessage();
		sleep(1000);
		}
	}
	catch (InterruptedException e) {}
	}
  private synchronized void insererMessage () throws InterruptedException {
	while (messages.size() == MAXFILE)
		wait();
	messages.addElement(new java.util.Date().toString());
	notify(); // un message disponible
  }
  public synchronized String recupererMessage() throws InterruptedException {
	notify(); // pour que le producteur reste eveill�
		// c'est � dire un element toujours dans la file
	while (messages.size() == 0)
		wait();
	String mess = (String)messages.firstElement();
	messages.removeElement(mess);
	return mess;
  }

}