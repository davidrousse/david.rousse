/*
 * Consommateur.java
 *
 * Created on 26 septembre 2000, 21:05
 */
 
package tpThread;
import java.lang.Thread;
import java.io.*;

/** 
 *
 * @author  PVIDAL
 * @version 
 */
public class Consommateur extends Thread {

  Producteur producteur;
  
  /** Creates new Consommateur */
  public Consommateur(Producteur p) {
    producteur = p ;
  }
  public void run(){
	try {
		while (true) {
			String message = producteur.recupererMessage();
			System.out.println(" Message recu : " +message);
			sleep(2000);
		}
	}
	catch (InterruptedException e) {}
	}

}