/**************************************************************************
*
* Nom du projet     : Programmation des sockets TCP/IP
* Objet 				  : TP R�seau MIAGe 3
*
***************************************************************************
*
* R�pertoire                : miage3\reseau\socket
* Nom du fichier            : annuaire.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 08 / 05 / 2001
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MSG_MAX_SIZE 20
#define LG_MAX_SIZE 40

/*
************************************************************
* NOM : nomToNumero
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : recherche dans un fichier le num�ro de t�l�phone
*					 pour un nom pass� en param�tre.
*					 A charge pour l'appelant de g�rer le fichier.
*
* SYNTAXE : retour = nomToNumero(f,nom,tel);
************************************************************
*/
int nomToNumero(FILE *f,char *nom,char *retour)
{
	char ligne[LG_MAX_SIZE];
   unsigned short trouve=0;

   /* repositionnement en tete du fichier */
   fseek(f, 0L, SEEK_SET);

   /* recherche du numero dans le fichier */
   while(fgets(ligne,LG_MAX_SIZE,f) && !trouve)
   {
   	/* suppression de \012 */
   	ligne[strlen(ligne)-1] = '\0';

      if(!strcmp(nom,ligne+5))
      {
       	/* le nom a �t� trouv� */
         trouve = 1;
         strncpy(retour,ligne,4);
         retour[4] = '\0';
      }
   }

   /* si le num�ro de t�l�phone n'a pas �t� trouv�, on renvoie ???? */
   if(!trouve)
   {
   	strcpy(retour,"????");
      retour[4] = '\0';
      return 0;
   }
   else
    	return 1;
}

void main(void)
{
   FILE *f;
   char tel[5];
	char nom[LG_MAX_SIZE];

   /* ouverture du fichier */
   if ((f = fopen("annuaire.txt", "r")) == NULL)
   {
   	puts("\nImpossible d'ouvrir le fichier source !!!\n"),exit(1);
   }

   /* saisie jusqu'a appuie sur Q */
   printf("\nEntrez le nom (Q pour Quitter): ");
   scanf("%s", nom);
   while(strcmp(nom, "Q") && strcmp(nom, "q"))
   {
      if(!nomToNumero(f,nom,tel))
	      printf("\nLe nom %s est inconnue.",nom);
      else
		   printf("\nLe num�ro de t�l�phone de %s est %s.",nom,tel);

      printf("\n\nEntrez le nom (Q pour Quitter): ");
	   scanf("%s", nom);
   }


   /* fermeture fichier */
   fclose(f);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();
   getchar();

   return;
}
