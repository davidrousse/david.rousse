/**************************************************************************
*
* Nom du projet     : Programmation des sockets sous HP-UX
* Objet 	    : TP R�seaux MIAGe 3
*		      Serveur en mode datagrammes
* Principe	    :
* On cree un serveur X ports UDP cad X sockets DGRAM <-> X ports UDP
* On a donc int s[3], un tab. de descripteurs d'E/S
* ---> Il faut scruter l'activit� sur ces sockets. 
* Pour ce faire on cree une file d'attente de decripteurs d'E/S qui va contenir
* des descripteurs logiques d'E/S (on y mettra des sockets mais on pourrait y trouver des fichiers, ...).
* Cette technique permet donc au serveur de scruter des descripteurs
* de fichiers, et ainsi de repondre a plusieurs requetes sur differents ports.
* On cree donc : fd_set attente;
* 4 etapes ensuite :
* 1) initialisation
*	FD_ZERO(&attente);
* 2) enregistrement des descripteurs dans attente :
*	FD_SET(s[i],&attente);
* 3) scruter l'activite d'entree
*	nb = select(FD_SETSIZE,&attente,(fd_set*)NULL,(fd_set*)NULL,0);
*  	--> nb renvoie le nb. de desc. sur lesquels un message est arrive
*	    il faut donc chercher sur quels sockets ...
* 4) determiner les sockets (nb>0)
* 	FD_ISSET(s[i],&attente);
*	--> si la macro renvoie un nb!=0, un message est arrive sur la socket
*	    il faut donc pour cette requete faire - recvfrom()
*						  - traitement de la requete
*						  - sento()
*	--> si la macro renvoie 0, rien a faire pour cette socket
*
* !!! Il faut integer les etapes 2, 3 et 4 dans le while(1) !!!	
*
***************************************************************************
*/

#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

#define MSG_MAX_SIZE 20
#define LG_MAX_SIZE 40
#define NUM_PORT 10070

/*
************************************************************
* NOM : nomToNumero
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : recherche dans un fichier le num�ro de t�l�phone
*					 pour un nom pass� en param�tre.
*					 A charge pour l'appelant de g�rer le fichier.
*
* SYNTAXE : retour = nomToNumero(f,nom,tel);
************************************************************
*/
int nomToNumero(f,nom,retour)
FILE *f;
char *nom;
char *retour;
{
   char ligne[LG_MAX_SIZE];
   unsigned short trouve=0;

   /* repositionnement en tete du fichier */
   fseek(f, 0L, SEEK_SET);

   /* recherche du numero dans le fichier */
   while(fgets(ligne,LG_MAX_SIZE,f) && !trouve)
   {
   	/* suppression de \012 */
   	ligne[strlen(ligne)-1] = '\0';

      if(!strcmp(nom,ligne+5))
      {
       	/* le nom a �t� trouv� */
         trouve = 1;
         strncpy(retour,ligne,4);
         retour[4] = '\0';
      }
   }

   /* si le num�ro de t�l�phone n'a pas �t� trouv�, on renvoie ???? */
   if(!trouve)
   {
   	strcpy(retour,"????");
      retour[4] = '\0';
      return 0;
   }
   else
    	return 1;
}


main(argc, argv)
int argc;
char *argv[];
{
	/* declaration */
	int s[3];
	int nb; 
	int reception;
	int i;
	int lg;
	int ret_fdisset;
	struct hostent *serveur;
	struct sockaddr_in cnx_serveur[3];
	struct sockaddr_in cnx_client;
	char requete[MSG_MAX_SIZE];
	char tel[5];
	FILE *f;
	fd_set attente;

        /* ouverture du fichier */
        if ((f = fopen("annuaire.txt", "r")) == NULL)
        {
  		puts("\nImpossible d'ouvrir le fichier source !!!\n"),exit(1);
  	 }
		
	/* creation des 3 sockets */
	for(i=0;i<3;i++)
		s[i] = socket(AF_INET,SOCK_DGRAM,0);
	
	/* recuperation @IP du serveur */
	serveur = gethostbyname(argv[1]);
	if(serveur->h_length==0)
	{
		printf("\nErreur lors de la recuperation de l'adresse IP du serveur !\n");
		exit(0);	
	}

	/* initialisation sockaddr client */
	bzero(&cnx_client,sizeof(cnx_client));
	
	
	/* initialisation des 3 sockaddr serveur */
	for(i=0;i<3;i++)
	{
		bzero(&cnx_serveur[i],sizeof(cnx_serveur[i]));
	
		/* champ sin_family */
		cnx_serveur[i].sin_family = AF_INET;
	
		/* numero de port */
		cnx_serveur[i].sin_port = NUM_PORT+i;
		
	
		/* @IP du serveur */
		bcopy(serveur->h_addr_list[0],&(cnx_serveur[i].sin_addr),serveur->h_length);
	
		if (bind(s[i],&cnx_serveur[i],sizeof(cnx_serveur[i]))<0)
		{
			printf("\nErreur lors de l'execution du bind !\n");
			exit(0);	
		}
	
	}
	
	
	/* 1) initialisation */
	FD_ZERO(&attente);
	
	/* reception */
	while(1)
	{
		/* 2) enregistrement des descripteurs dans attente */
		for(i=0;i<3;i++)
			FD_SET(s[i],&attente);

		/* 3) scruter l'activite d'entree */
		nb = select(FD_SETSIZE,&attente,(fd_set*)NULL,(fd_set*)NULL,0);
		
		/* nb renvoie le nb. de desc. sur lesquels un message est arrive */
		/* il faut donc chercher sur quels sockets ...			 */
		
		/* 4) determiner les sockets (nb>0) */
		if(nb>0)
		{
			for(i=0;i<3;i++)
			{
				ret_fdisset = FD_ISSET(s[i],&attente);

				/* si la macro renvoie un nb!=0, un message est arrive sur la socket */
				/* il faut donc pour cette requete faire - recvfrom()
								  - traitement de la requete
								  - sento()
			   	si la macro renvoie 0, rien a faire pour cette socket  	     */	
		
				if(ret_fdisset)
				{
					/* initialisation de lg */
					lg = sizeof(cnx_client);
		
					/* reception */
					reception = recvfrom(s[i],requete,sizeof(requete),0,&cnx_client,&lg);
					if(reception)
					{
		
						printf("\nRequete recue : %s\n",requete);		
      
      						if(!nomToNumero(f,requete,tel))
						      printf("\nLe nom %s est inconnue.",requete);
						else
						      printf("\nLe num�ro de t�l�phone de %s est %s.",requete,tel);
			
					}
					
					/* envoi */
					sendto(s[i],tel,sizeof(tel),0,&cnx_client,sizeof(cnx_client));
				}
			}	
		}
	}
	
        /* fermeture fichier */
        fclose(f);

}
	