/**************************************************************************
*
* Nom du projet     : Programmation des sockets sous HP-UX
* Objet 	    : TP R�seaux MIAGe 3
*		      Serveur en mode datagrammes
*
***************************************************************************
*/

#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

#define MSG_MAX_SIZE 20
#define LG_MAX_SIZE 40

/*
************************************************************
* NOM : nomToNumero
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : recherche dans un fichier le num�ro de t�l�phone
*					 pour un nom pass� en param�tre.
*					 A charge pour l'appelant de g�rer le fichier.
*
* SYNTAXE : retour = nomToNumero(f,nom,tel);
************************************************************
*/
int nomToNumero(f,nom,retour)
FILE *f;
char *nom;
char *retour;
{
   char ligne[LG_MAX_SIZE];
   unsigned short trouve=0;

   /* repositionnement en tete du fichier */
   fseek(f, 0L, SEEK_SET);

   /* recherche du numero dans le fichier */
   while(fgets(ligne,LG_MAX_SIZE,f) && !trouve)
   {
   	/* suppression de \012 */
   	ligne[strlen(ligne)-1] = '\0';

      if(!strcmp(nom,ligne+5))
      {
       	/* le nom a �t� trouv� */
         trouve = 1;
         strncpy(retour,ligne,4);
         retour[4] = '\0';
      }
   }

   /* si le num�ro de t�l�phone n'a pas �t� trouv�, on renvoie ???? */
   if(!trouve)
   {
   	strcpy(retour,"????");
      retour[4] = '\0';
      return 0;
   }
   else
    	return 1;
}


main(argc, argv)
int argc;
char *argv[];
{
	/* declaration */
	int id_s_serv;
	int reception;
	int lg;
	struct hostent *serveur;
	struct sockaddr_in cnx_serveur;
	struct sockaddr_in cnx_client;
	char requete[MSG_MAX_SIZE];
	char tel[5];
	FILE *f;

        /* ouverture du fichier */
        if ((f = fopen("annuaire.txt", "r")) == NULL)
        {
  		puts("\nImpossible d'ouvrir le fichier source !!!\n"),exit(1);
  	 }
		
	/* cr�ation socket */
	id_s_serv = socket(AF_INET,SOCK_DGRAM,0);
	
	/* recuperation @IP du serveur */
	serveur = gethostbyname(argv[1]);
	if(serveur->h_length==0)
	{
		printf("\nErreur lors de la recuperation de l'adresse IP du serveur !\n");
		exit(0);	
	}

	/* initialisation sockaddr client */
	bzero(&cnx_client,sizeof(cnx_client));
	
	
	/* initialisation sockaddr */
	bzero(&cnx_serveur,sizeof(cnx_serveur));
	
	/* champ sin_family */
	cnx_serveur.sin_family = AF_INET;
	
	/* numero de port */
	cnx_serveur.sin_port = 1069;
	
	/* @IP du serveur */
	bcopy(serveur->h_addr_list[0],&(cnx_serveur.sin_addr),serveur->h_length);
	
	if (bind(id_s_serv,&cnx_serveur,sizeof(cnx_serveur))<0)
	{
		printf("\nErreur lors de l'execution du bind !\n");
		exit(0);	
	}
	
	/*reception*/
	while(1)
	{
		/* initialisation de lg */
		lg = sizeof(cnx_client);
		
		/* reception */
		reception = recvfrom(id_s_serv,requete,sizeof(requete),0,&cnx_client,&lg);
		if(reception)
		{
	
			printf("\nRequete recue : %s\n",requete);		
      
      			if(!nomToNumero(f,requete,tel))
			      printf("\nLe nom %s est inconnue.",requete);
			else
			      printf("\nLe num�ro de t�l�phone de %s est %s.",requete,tel);
			
		}
	
		/* envoi */
		sendto(id_s_serv,tel,sizeof(tel),0,&cnx_client,sizeof(cnx_client));
	
		
	}
        /* fermeture fichier */
        fclose(f);

}
	