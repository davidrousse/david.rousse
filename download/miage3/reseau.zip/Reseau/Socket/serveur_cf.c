/**************************************************************************
*
* Nom du projet     : Programmation des sockets sous HP-UX
* Objet 				  : TP R�seaux MIAGe 3
*							 Serveur en mode connect� � acc�s concurrent
*
***************************************************************************
*/

#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

#define MAX_CNX 10
#define MSG_MAX_SIZE 20
#define LG_MAX_SIZE 40

/*
************************************************************
* NOM : nomToNumero
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : recherche dans un fichier le num�ro de t�l�phone
*					 pour un nom pass� en param�tre.
*					 A charge pour l'appelant de g�rer le fichier.
*
* SYNTAXE : retour = nomToNumero(f,nom,tel);
************************************************************
*/
int nomToNumero(f,nom,retour)
FILE *f;
char *nom;
char *retour;
{
   char ligne[LG_MAX_SIZE];
   unsigned short trouve=0;

   /* repositionnement en tete du fichier */
   fseek(f, 0L, SEEK_SET);

   /* recherche du numero dans le fichier */
   while(fgets(ligne,LG_MAX_SIZE,f) && !trouve)
   {
   	/* suppression de \012 */
   	ligne[strlen(ligne)-1] = '\0';

      if(!strcmp(nom,ligne+5))
      {
       	/* le nom a �t� trouv� */
         trouve = 1;
         strncpy(retour,ligne,4);
         retour[4] = '\0';
      }
   }

   /* si le num�ro de t�l�phone n'a pas �t� trouv�, on renvoie ???? */
   if(!trouve)
   {
      strcpy(retour,"????");
      retour[4] = '\0';
      return 0;
   }
   else
    	return 1;
}


main(argc, argv)
int argc;
char *argv[];
{
	/* declaration */
	int sid, newsock;
	int reception;
	int lg, pid;
	struct hostent *serveur;
	struct sockaddr_in s_addr;
	struct sockaddr_in c_addr;
	char requete[MSG_MAX_SIZE];
	char tel[5];
	FILE *f;

        /* ouverture du fichier */
        if ((f = fopen("annuaire.txt", "r")) == NULL)
        {
  		puts("\nImpossible d'ouvrir le fichier source !!!\n"),exit(1);
  	 }
		
	/* cr�ation socket */
	sid = socket(AF_INET,SOCK_STREAM,0);
	
	/* recuperation @IP du serveur */
	serveur = gethostbyname(argv[1]);
	if(serveur->h_length==0)
	{
		printf("\nErreur lors de la recuperation de l'adresse IP du serveur !\n");
		exit(0);	
	}

	/* initialisation sockaddr client */
	bzero(&c_addr,sizeof(c_addr));
	
	/* initialisation sockaddr */
	bzero(&s_addr,sizeof(s_addr));
	
	/* champ sin_family */
	s_addr.sin_family = AF_INET;
	
	/* numero de port */
	s_addr.sin_port = 10000;
	
	/* @IP du serveur */
	bcopy(serveur->h_addr_list[0],&(s_addr.sin_addr),serveur->h_length);
	
	if (bind(sid,&s_addr,sizeof(s_addr))<0)
	{
		printf("\nErreur lors de l'execution du bind !\n");
		exit(0);	
	}

	/* ecoute des requetes */
	listen(sid,MAX_CNX);
			
			
	/* reception */
	while(1)
	{
		/* initialisation de lg */
		lg = sizeof(c_addr);
		
		/* acceptation des requetes entrantes */		
		newsock = accept(sid,&c_addr,sizeof(c_addr));
		
		/* CREATION DU PROCESSUS FILS */
		if ((pid=fork()) == -1) 
		{
		     printf("\nPERE: creation du processus impossible\n");
		     exit(1);
		}
		
		/* CODE DU FILS */
		if (pid == 0 ) 
		{
		        printf("\nFILS: debut d' execution du processus fils\n");
			reception = recv(newsock,requete,sizeof(requete),0);
			if(reception)
			{
		
				printf("\nRequete recue : %s\n",requete);		
      
      				if(!nomToNumero(f,requete,tel))
				      printf("\nLe nom %s est inconnue.",requete);
				else
				      printf("\nLe num�ro de t�l�phone de %s est %s.",requete,tel);
			
			}
		
			/* envoi */
			send(newsock,tel,sizeof(tel),0);
		
			 /* fermeture connexion */
	        	close(newsock);
	        }
	}
	
	/* CODE DU PERE */
	if(pid)
	{
	        /* fermeture fichier */
        	fclose(f);
   }	
        
       
}
	