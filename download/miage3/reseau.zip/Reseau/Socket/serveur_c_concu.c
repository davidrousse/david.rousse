/**************************************************************************
*
* Nom du projet     : Programmation des sockets sous HP-UX
* Objet 	    : TP R�seaux MIAGe 3
*		      Serveur en mode connect� � acc�s concurrent
*
***************************************************************************
*/

#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

#define MAX_CNX 10
#define MSG_MAX_SIZE 20
#define LG_MAX_SIZE 40
#define NUM_PORT 10000

/*
************************************************************
* NOM : nomToNumero
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : recherche dans un fichier le num�ro de t�l�phone
*					 pour un nom pass� en param�tre.
*					 A charge pour l'appelant de g�rer le fichier.
*
* SYNTAXE : retour = nomToNumero(f,nom,tel);
************************************************************
*/
int nomToNumero(f,nom,retour)
FILE *f;
char *nom;
char *retour;
{
   char ligne[LG_MAX_SIZE];
   unsigned short trouve=0;

   /* repositionnement en tete du fichier */
   fseek(f, 0L, SEEK_SET);

   /* recherche du numero dans le fichier */
   while(fgets(ligne,LG_MAX_SIZE,f) && !trouve)
   {
   	/* suppression de \012 */
   	ligne[strlen(ligne)-1] = '\0';

      if(!strcmp(nom,ligne+5))
      {
       	/* le nom a �t� trouv� */
         trouve = 1;
         strncpy(retour,ligne,4);
         retour[4] = '\0';
      }
   }

   /* si le num�ro de t�l�phone n'a pas �t� trouv�, on renvoie ???? */
   if(!trouve)
   {
   	strcpy(retour,"????");
      retour[4] = '\0';
      return 0;
   }
   else
    	return 1;
}


main(argc, argv)
int argc;
char *argv[];
{
	/* declarations */
	int pid; /* pid processus fils cree pour realiser la concurrence d'acces */
	int id_s_serv_gen, id_s_serv_spec; /* descripteurs de sockets */
	int reception; /* etat de la reception */
	struct hostent *serveur; /* informations sur le serveur */
	struct sockaddr_in cnx_serveur; /* extremite de connexion serveur */
	struct sockaddr_in cnx_client; /* extremite de connexion client */
	char requete[MSG_MAX_SIZE]; /* requete recue et a traiter */
	char tel[5]; /* reponse a renvoyer au client */
	FILE *f; /* descripteur de fichier d'annuaire */

	/* verifier les arguments */
	if(argc!=2)
	{
		printf("\nNombre d'arguments incorrect\n");
		printf("Syntaxe : programme <nom_host>\n");
		exit(0);	
	}
	
        /* ouverture du fichier */
        if ((f = fopen("annuaire.txt", "r")) == NULL)
        {
  		puts("\nImpossible d'ouvrir le fichier source !!!\n"),exit(1);
  	 }
		
	/* cr�ation socket */
	id_s_serv_gen = socket(AF_INET,SOCK_STREAM,0);
	
	/* recuperation @IP du serveur */
	serveur = gethostbyname(argv[1]);
	if(serveur->h_length==0)
	{
		printf("\nErreur lors de la recuperation de l'adresse IP du serveur !\n");
		exit(0);	
	}

	/* initialisation extremite de connexion client */
	bzero(&cnx_client,sizeof(cnx_client));
	
	/* initialisation extremite de connexion serveur */
	bzero(&cnx_serveur,sizeof(cnx_serveur));
	
	/* initialisation champ sin_family serveur */
	cnx_serveur.sin_family = AF_INET;
	
	/* initialisation numero de port serveur */
	cnx_serveur.sin_port = NUM_PORT;
	
	/* initialisation @IP du serveur serveur */
	bcopy(serveur->h_addr_list[0],&(cnx_serveur.sin_addr),serveur->h_length);
	
	/* association au descripteur de fichier generique de l'extremite de connexion serveur */
	if (bind(id_s_serv_gen,&cnx_serveur,sizeof(cnx_serveur))<0)
	{
		printf("\nErreur lors de l'execution du bind !\n");
		exit(0);	
	}

	/* ecoute des requetes sur la socket genereique id_s_serv_gen (ouverture passive) */
	listen(id_s_serv_gen,MAX_CNX);
	
	/* le serveur est pret */
	printf("\nLe serveur en mode connecte (acces concurrent) sur le port %d est pret ...\n",NUM_PORT);
		
	/* reception et traitement des requetes */
	while(1)
	{
		/* acceptation d'une requete entrante et creation d'une socket dedie */		
		id_s_serv_spec = accept(id_s_serv_gen,&cnx_client,sizeof(cnx_client));
	
		/* CREATION DU PROCESSUS FILS */
		if ((pid=fork()) == -1) 
		{
		     printf("\nPERE: creation du processus impossible\n");
		     exit(1);
		}
		
		/* CODE DU FILS */
		if (pid == 0 ) 
		{
		
			reception = recv(id_s_serv_spec,requete,sizeof(requete),0);
			if(reception)
			{
	
				printf("\nRequete recue : %s\n",requete);		
      
      				if(!nomToNumero(f,requete,tel))
				      printf("\nLe nom %s est inconnue.",requete);
				else
				      printf("\nLe num�ro de telephone de %s est %s.",requete,tel);
			
			}
	
			/* envoi sur la socket specifique */
			send(id_s_serv_spec,tel,sizeof(tel),0);
		
			/* fermeture socket specifique client */
		        close(id_s_serv_spec);
		        
		} /* Fin du traitement specifique */
		
	}
	
	/* CODE DU PERE */
	if(pid)
	{
	
		/* fermeture socket serveur */
		close(id_s_serv_gen);
	        
	        /* fermeture fichier */
        	fclose(f); 
 	}
 	       	 
}
	