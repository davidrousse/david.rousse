/**************************************************************************
*
* Nom du projet     : Programmation des sockets sous HP-UX
* Objet 	    : TP R�seaux MIAGe 3
*		      Client en mode connect�
*
***************************************************************************
*/

#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

#define NUM_PORT 10000

main(argc, argv)
int argc;
char *argv[];
{
	/* declarations */
	int id_s_cli;
	int reception;
	struct hostent *serveur;
	struct sockaddr_in cnx_serveur;
	char reponse[100];
	
	/* verifier les arguments */
	if(argc!=3)
	{
		printf("\nNombre d'arguments incorrect\n");
		printf("Syntaxe : programme <nom_host> <nom_personne>\n");
		exit(0);	
	}
		
	/* creation socket */
	id_s_cli = socket(AF_INET,SOCK_STREAM,0);
	
	/* recuperation @IP du serveur */
	serveur = gethostbyname(argv[1]);
	if(serveur->h_length==0)
	{
		printf("\nErreur lors de la recuperation de l'adresse IP du serveur !\n");
		exit(0);	
	}
	
	/* initialisation extremite de connexion serveur */
	bzero(&cnx_serveur,sizeof(cnx_serveur));
	
	/* initialisation champ sin_family serveur */
	cnx_serveur.sin_family = AF_INET;
	
	/* numero de port */
	cnx_serveur.sin_port = NUM_PORT;

	/* initialisation numero de port serveur */
	bcopy(serveur->h_addr_list[0],&(cnx_serveur.sin_addr),serveur->h_length);
	
	/* connexion du client au serveur (ouverture active) en specifiant l'extremite de cnx serveur */
	if(connect(id_s_cli,&cnx_serveur,sizeof(cnx_serveur))<0)
	{
		printf("\nErreur lors de la connexion !\n");
		exit(0);	
	}
	
	/* la connexion est reussie */
	printf("\nLa connexion en mode connecte est reussie avec le serveur %s sur le port %d ...\n",argv[1],NUM_PORT);
		
	/* envoi de la requete sur la socket client */
	send(id_s_cli,argv[2],strlen(argv[2]),0);
	
	/* reception reponse serveur sur socket client */
	reception = recv(id_s_cli,reponse,sizeof(reponse),0);
	if(reception)
	{
		printf("\nReponse recue : %s\n",reponse);
	}
	
	/* fermeture socket client */
	close(id_s_cli);
}	