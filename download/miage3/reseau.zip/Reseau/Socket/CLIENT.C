/**************************************************************************
*
* Nom du projet     : Programmation des sockets sous HP-UX
* Objet 	    : TP R�seaux MIAGe 3
*		      Client en mode datagrammes
*
***************************************************************************
*/
#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

main(argc, argv)
int argc;
char *argv[];
{
	/* declaration */
	int id_s_cli, lg;
	int reception;
	struct hostent *serveur;
	struct sockaddr_in cnx_serveur;
	char reponse[100];
	
	/* cr�ation socket */
	id_s_cli = socket(AF_INET,SOCK_DGRAM,0);
	
	/* recuperation @IP du serveur */
	serveur = gethostbyname(argv[1]);
	if(serveur->h_length==0)
	{
		printf("\nErreur lors de la recuperation de l'adresse IP du serveur !\n");
		exit(0);	
	}
	
	/* initialisation sockaddr */
	bzero(&cnx_serveur,sizeof(cnx_serveur));
	
	/* champ sin_family */
	cnx_serveur.sin_family = AF_INET;
	
	/* numero de port */
	cnx_serveur.sin_port = 1069;
	
	/* @IP du serveur */
	bcopy(serveur->h_addr_list[0],&(cnx_serveur.sin_addr),serveur->h_length);
	
	printf("\nEnvoi de %s :",argv[2]);
	
	/* envoi */
	sendto(id_s_cli,argv[2],strlen(argv[2]),0,&cnx_serveur,sizeof(cnx_serveur));
	
	/* reception */
	lg = sizeof(cnx_serveur);
	reception = recvfrom(id_s_cli,reponse,sizeof(reponse),&cnx_serveur,&lg,0);
	if(reception)
	{
		printf("\nReponse recue : %s\n",reponse);
	}
}	