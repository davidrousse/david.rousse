#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>

char hello[] = "et apres la fiesta ?";
char texte_clic[] = "...";

main (argc,argv)
	int argc;
	char **argv;

{

Display *canal_aff;
Window *fenetre;
GC contx_graph;
XEvent evenem;
KeySym touche;
XSizeHints infos_fen;
XWMHints infos_WM;
int ecran;
unsigned long couleur_AVplan,couleur_ARRplan;
int i,station;
char frappe[10];
int test_boucle;
int xtexte,ytexte;

/* init */

printf ("sur quelle station ?\n");
printf (" <1> 195.220.39.65\n");
printf (" <2> hadrien\n");
printf (" <3> cecile\n");
scanf("%d",&station);printf("\n");

switch (station)
	{
	case 1 : canal_aff = XOpenDisplay("195.220.39.65:0");break;
	case 2 : canal_aff = XOpenDisplay("hadrien.edu.ups-tlse.fr:0");break;
	case 3 : canal_aff = XOpenDisplay("195.220.39.60:0");break;
	default : canal_aff = XOpenDisplay("");
	}

ecran = (int) DefaultScreen(canal_aff);
couleur_AVplan = WhitePixel(canal_aff,ecran);
couleur_ARRplan = BlackPixel(canal_aff,ecran);

infos_fen.x = 200; infos_fen.y = 200;
infos_fen.width = 350; infos_fen.height = 250;
infos_fen.flags = PPosition | PSize;
infos_WM.flags = InputHint;
infos_WM.input = True;

/* creat fen */


fenetre = XCreateSimpleWindow(canal_aff,
			DefaultRootWindow(canal_aff),infos_fen.x,infos_fen.y,
			infos_fen.width,infos_fen.height,
			5,couleur_AVplan,couleur_ARRplan);
			
XSetStandardProperties(canal_aff,fenetre,hello,hello,None,argv,argc,&infos_fen);


XSetWMHints(canal_aff,fenetre,&infos_WM);

/* creat contxt gr */

contx_graph = XCreateGC(canal_aff,fenetre,0,0);
XSetBackground(canal_aff,contx_graph,couleur_ARRplan);
XSetForeground(canal_aff,contx_graph,couleur_AVplan);

/* sel evt in */

XSelectInput(canal_aff,fenetre,ButtonPressMask | KeyPressMask | ExposureMask);

/* aff fen */

XMapRaised(canal_aff,fenetre);

test_boucle = 0;
xtexte = 50; ytexte = 50; 

while (! test_boucle)
	{
	XNextEvent(canal_aff,&evenem);

	if (xtexte >= 350) xtexte = 50;
	if (ytexte >= 250) ytexte = 50;

	switch(evenem.type)
		{
		case Expose : 
			xtexte = 50;
			if (evenem.xexpose.count == 0)
				XDrawImageString(evenem.xexpose.display,
						evenem.xexpose.window,
						contx_graph,xtexte,ytexte+=50,
						hello,strlen(hello) );
			
			/*	XDrawLine(  evenem.xexpose.display,
				    evenem.xexpose.window,
				    contx_graph,
				    0, 0, xtexte, ytexte);
			*/
			XMapWindow(canal_aff,fenetre);		
			break;

		case MappingNotify :
			XRefreshKeyboardMapping(&evenem);
			XMapWindow(canal_aff,fenetre);
			break;

		case ButtonPress :
			XDrawImageString(evenem.xexpose.display,
					evenem.xexpose.window,
					contx_graph,xtexte+=50,ytexte+=50,
					texte_clic,strlen(texte_clic) );
			break;

		case KeyPress :
			i = XLookupString(&evenem,frappe,10,&touche,0);
			if (i==1 && frappe[0] == 'q') test_boucle = 1;
			break;		
		}
	}

XFreeGC(canal_aff,contx_graph);
XDestroyWindow(canal_aff,fenetre);
XCloseDisplay(canal_aff);
exit(0);
}


