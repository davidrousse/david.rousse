#include <stdio.h>
#include <X11/Xlib.h>

/* Variables globales X */
Display *dpy;
Window win;
int scr;
int depth;  /* Profondeur fenetre par defaut */
Visual *visual;  /* Visual par defaut */
unsigned long mask;  /* Attributs fenetres par defaut */
XSetWindowAttributes attr;

/* Contexte graphique */
GC gc;

/* Hauteur et largeur de fenetre */
int wtot,htot;

/* Coordonnee du segment a tracer */
int xs,ys,xd,yd,x1,x2,y1,y2;

/* Indicateurs */
int sel;
int noir =1;

void main(argc,argv)
  int argc;
  char *argv[];
  {
  XEvent event;
  int ok;
  
  /* Connexion serveur X */
  dpy = XOpenDisplay(getenv("DISPLAY"));
  
  /* Ecran, visual, attributs fenetres par defaut */
  scr = (int)XDefaultScreen(dpy);
  visual = XDefaultVisual(dpy,scr);
  depth = XDefaultDepth(dpy,scr);
  mask = CWBackPixel | CWBorderPixel;
  attr.background_pixel = XWhitePixel(dpy,scr);
  attr.border_pixel = XBlackPixel(dpy,scr);
  
  wtot = 300;
  htot = 200;
  
  /* Creation des fenetres drawable */
  win = XCreateWindow(dpy,
                      RootWindow(dpy,scr),
                      0,0,wtot,htot,1,depth,
                      InputOutput,visual,mask,&attr);
                      
  /* Contexte graphique pour affichage en mode normal */
  gc = XCreateGC(dpy,win,0,0);
  XSetForeground(dpy,gc,XBlackPixel(dpy,scr));
  XSetFunction(dpy,gc,GXinvert);
   
  /* Recuperation des evenements souris sur la fenetre */
  XSelectInput(dpy,win,ButtonPressMask);
  
  /* Affichage fenetre et image source */ 
  XMapWindow(dpy,win);

   XNextEvent(dpy,&event);
   while (event.type != ButtonPress)
  	{
        XNextEvent(dpy,&event);
	}
    xd = event.xbutton.x;
    yd = event.xbutton.y;
 	
  
  /* Boucle d'evenements */
  while (1)
    {
    XNextEvent(dpy,&event);
    switch(event.type)
      {
      case ButtonPress :
      if (event.xbutton.button == 1){
          xs = event.xbutton.x;
          ys = event.xbutton.y;
          x1=xd;y1=yd;x2=xs;y2=ys;
          XDrawLine(dpy,win,gc,xd,yd,xs,ys);
          xd = xs;
          yd = ys;
          ok = 1;
        }
      if (event.xbutton.button == 3) 
      	if (ok)
       		{
       		XDrawLine(dpy,win,gc,x1,y1,x2,y2); /* corrige */
    		ok = 0;
    		xd=x1;yd=y1;
       		}
       break;
      default :
        break;
      }                         
    }
  }                         
