/********************************************************
    morphing
********************************************************/

#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/keysym.h>

#define NMAX 20


/* variables globales X */
int 		nbseg[3] = {0, 0, 0 };
XPoint		seg[3][NMAX+1];		/* coordonnees des segments a tracer */



void ajuster_points()
{
int i, j=0, k, rt, rs;

if (nbseg[0] < nbseg[1])    /* 0 en a le moins */
    {
    nbseg[2] = nbseg[1];
    rt = (int) ( ( nbseg[1] - 1 ) / ( nbseg[0] - 1 ) ) ;
    rs = ( nbseg[1] - 1 ) % ( nbseg[0] - 1 ) ;
    
    printf("rt %d, rs %d\n", rt, rs);
    
    for (i=0;i<nbseg[0];i++)
	{
    	if (i<rs) {
	    seg[2][j] = seg[0][i] ;
	    j++;
	    for (k=0;k<rt;k++)
		{
		printf("1) %d <- ajout du pt k=%d au pt %d\n", k, j, i); 
		seg[2][j] = seg[0][i] ;
		j++;
		}
	    }
	else {
	    seg[2][j] = seg[0][i] ;
	    j++;
	    for (k=0;k<rt-1;k++)
		{
		printf("2) %d <- ajout du pt k=%d au pt %d\n", k, j, i); 
		seg[2][j] = seg[0][i] ;
		j++;
		}
	    }
	}
    nbseg[0] = nbseg[2];
    for (i=0;i<nbseg[0];i++) seg[0][i] = seg[2][i] ; 
    }
    
else { if (nbseg[0] > nbseg[1])	
	{	    
	nbseg[2] = nbseg[0];
	rt = (int) ( ( nbseg[0] - 1 ) / ( nbseg[1] - 1 ) ) ;
	rs = ( nbseg[0] - 1 ) % ( nbseg[1] - 1 ) ;
    
	printf("rt %d, rs %d\n", rt, rs);
	
    for (i=0;i<nbseg[1];i++)
	{
    	if (i<rs) {
	    seg[2][j] = seg[1][i] ;
	    j++;
	    for (k=0;k<rt;k++)
		{
		printf("1) %d <- ajout du pt k=%d au pt %d\n", k, j, i); 
		seg[2][j] = seg[1][i] ;
		j++;
		}
	    }
	else {
	    seg[2][j] = seg[1][i] ;
	    j++;
	    for (k=0;k<rt-1;k++)
		{
		printf("2) %d <- ajout du pt k=%d au pt %d\n", k, j, i); 
		seg[2][j] = seg[1][i] ;
		j++;
		}
	    }
	}
    nbseg[1] = nbseg[2];
    for (i=0;i<nbseg[1];i++) seg[1][i] = seg[2][i] ; 
	
	}
	else nbseg[2] = nbseg[0];
    }
}


void morphing(p)
int p;
{
int i;
for (i=0;i<nbseg[2];i++)
    {
	seg[2][i].x = (short) ( (1.0 - (float)p/100.0) * seg[0][i].x + ((float)p/100.0) * seg[1][i].x );
	seg[2][i].y = (short) ( (1.0 - (float)p/100.0) * seg[0][i].y + ((float)p/100.0) * seg[1][i].y );
    }
}



void main (argc,argv)
	int argc;
	char * argv[];
{
Display		    *dpy;
Window		    win;
int 		    scr;
int 		    depth;	/* profondeur fenetres par defaut */
Visual		    *visual;	/* Visual par defaut */
unsigned long	    mask;	/* Attributs fenetres par defaut */
XSetWindowAttributes attr;
GC		    gc;		/* contexte graphique */
int 		    wtot,htot;	/* Hauteur et largeur de fenetre */
XEvent 		    event;
int		    trace, col = 0, c, fig = 0, fini = 0, colmax = 4, nbchar;
Colormap	    colormap;
unsigned	    long pix[4];
XColor		    palette[4];
char		    buffer[5];
KeySym		    keysym;
int		    i, prop = 0;
	
	/* connexion au serveur X */
	dpy = XOpenDisplay(getenv("DISPLAY"));
	
	/*Ecran, visual, attributs fenetre par defaut */
	
	scr = (int) XDefaultScreen(dpy);
	visual = XDefaultVisual(dpy,scr);
	depth = XDefaultDepth(dpy,scr);
	mask = CWBackPixel | CWBorderPixel;
	attr.background_pixel = XWhitePixel(dpy,scr);
	attr.border_pixel = XBlackPixel(dpy,scr);
	
	wtot = 300;
	htot = 200;
		
	/* creation des fenetres drawable */
	win = XCreateWindow(dpy, 
			    RootWindow(dpy,scr),
			    0,0,wtot,htot, 1,depth,
			    InputOutput, visual,mask, &attr);
	/* contexte graphique pour affichage en mode normal */
	gc = XCreateGC(dpy,win,0,0);
	XSetForeground(dpy,gc, XBlackPixel(dpy,scr));
	
	/* recuperation des evenements souris sur la fenetre */
	XSelectInput(dpy,win,ButtonPressMask|ButtonReleaseMask|PointerMotionMask|KeyPressMask);
	
	/* initialisation des couleurs */
	colormap=XCreateColormap(dpy, win, DefaultVisual(dpy, scr), AllocNone);
        if(XAllocColorCells(dpy, colormap, False, 0, 0, pix, 4)==0)printf("erreur1");
        XInstallColormap(dpy, colormap);
    
        palette[0].pixel=pix[0];
        palette[0].flags=DoRed|DoGreen|DoBlue;
        palette[0].red=0;
        palette[0].green=0;
        palette[0].blue=0;
    
        palette[1].pixel=pix[1];
        palette[1].flags=DoRed|DoGreen|DoBlue;
        palette[1].red=65535;
        palette[1].green=65535; 
        palette[1].blue=0; 
    
        palette[2].pixel=pix[2];
        palette[2].flags=DoRed|DoGreen|DoBlue;
        palette[2].red=0;
        palette[2].green=65535;
        palette[2].blue=65535;
    
        palette[3].pixel=pix[3];
        palette[3].flags=DoRed|DoGreen|DoBlue;
        palette[3].red=65535;
        palette[3].green=0;
        palette[3].blue=65535;
        
        XStoreColors(dpy, colormap, palette, 4);
	XSetWindowColormap(dpy, win, colormap);
	
	/* affichage fenetre et image source */	
	XMapWindow(dpy,win);
	
	/* boucle d'evenements */
	while (!fini) {
		XNextEvent(dpy,&event);
		switch(event.type) {
			/* evenement d'exposure */
			case ButtonPress :
				/* un point de plus */
				if (event.xbutton.button == 1) {
					if (nbseg[fig] < NMAX ) {
					    seg[fig][nbseg[fig]].x = event.xbutton.x;
					    seg[fig][nbseg[fig]].y = event.xbutton.y;
					    if (nbseg[fig] != 0) XDrawLine(dpy,win,gc,
									seg[fig][nbseg[fig]-1].x,seg[fig][nbseg[fig]-1].y,
									seg[fig][nbseg[fig]].x,seg[fig][nbseg[fig]].y);
					    if (nbseg[fig] != NMAX) nbseg[fig]++;
					    printf("cree nbseg = %d \n", nbseg[fig]);
					    
					    }
				}
				if (event.xbutton.button == 2) {
					c = col++ % colmax;
					XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
					XDrawLines(dpy,win,gc,seg[fig],nbseg[fig],CoordModeOrigin);
					XSetForeground(dpy, gc, pix[c]) ;
					XDrawLines(dpy,win,gc,seg[fig],nbseg[fig],CoordModeOrigin);
					printf("couleur : %d \n", c );
					}
					
				if (event.xbutton.button == 3) {
				    if (nbseg[fig] > 0){
					XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
					XDrawLines(dpy,win,gc,seg[fig],nbseg[fig],CoordModeOrigin);
				/*	XSetForeground(dpy,gc,XBlackPixel(dpy,scr));	*/
					XSetForeground(dpy,gc,pix[c]);
					nbseg[fig]--;
					printf("detruit nbseg= %d\n", nbseg[fig]);
					XDrawLines(dpy,win,gc,seg[fig],nbseg[fig],CoordModeOrigin);
					}
				}
				break;
				
			case KeyPress : 
				nbchar=XLookupString(&event,buffer,5,&keysym,0);
				if((keysym==XK_f) && (fig<2))
				    {
				    seg[fig][nbseg[fig]].x = seg[fig][0].x;
				    seg[fig][nbseg[fig]].y = seg[fig][0].y;
				    nbseg[fig]++;
				    colmax--;
				    XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
				    XDrawLines(dpy,win,gc,seg[fig],nbseg[fig],CoordModeOrigin);
				    XSetForeground(dpy, gc, pix[colmax]) ;
				    XDrawLines(dpy,win,gc,seg[fig],nbseg[fig],CoordModeOrigin);
				    fig++;
				    if (fig == 2) {
						    XSelectInput(dpy,win,PointerMotionMask|KeyPressMask);
						    printf("%d %d %d\n", nbseg[0], nbseg[1], nbseg[2]);
						    ajuster_points();
						    printf("%d %d %d\n", nbseg[0], nbseg[1], nbseg[2]);
						   }
				    XSetForeground(dpy, gc, pix[0]) ;
				    }
				
				if ( (keysym==XK_Left) && (prop >= 5)) {
						    prop = prop - 5;
						    XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
						    XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
						    morphing(prop);
						    XSetForeground(dpy, gc, pix[0]) ;
						    XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
						    XSetForeground(dpy, gc, pix[3]) ;
						    XDrawLines(dpy,win,gc,seg[0],nbseg[0],CoordModeOrigin);
						    XSetForeground(dpy, gc, pix[2]) ;
						    XDrawLines(dpy,win,gc,seg[1],nbseg[1],CoordModeOrigin);
						    printf("gauche, prop %d\n", prop);			    
						    }

				if ( (keysym==XK_Right) && (prop <= 95)) {
						    prop = prop + 5;
						    XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
						    XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
						    morphing(prop);
						    XSetForeground(dpy, gc, pix[0]) ;
						    XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
						    XSetForeground(dpy, gc, pix[3]) ;
						    XDrawLines(dpy,win,gc,seg[0],nbseg[0],CoordModeOrigin);
						    XSetForeground(dpy, gc, pix[2]) ;
						    XDrawLines(dpy,win,gc,seg[1],nbseg[1],CoordModeOrigin);
						    printf("droite, prop %d\n", prop);
						    }
		
				if ( (keysym==XK_Up) && (prop <= 95)) {
						    for (i=prop;i<=100;i=i+5)
							{
							XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
							XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
							morphing(i);
							XSetForeground(dpy, gc, pix[0]) ;
							XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
							XSetForeground(dpy, gc, pix[3]) ;
							XDrawLines(dpy,win,gc,seg[0],nbseg[0],CoordModeOrigin);
							XSetForeground(dpy, gc, pix[2]) ;
							XDrawLines(dpy,win,gc,seg[1],nbseg[1],CoordModeOrigin);
							}
						    prop=i;
						    }
		
				if ( (keysym==XK_Down) && (prop >= 5)) {
						    for (i=prop;i>=0;i=i-5)
							{
							XSetForeground(dpy,gc,XWhitePixel(dpy,scr));
							XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
							morphing(i);
							XSetForeground(dpy, gc, pix[0]) ;
							XDrawLines(dpy,win,gc,seg[2],nbseg[2],CoordModeOrigin);
							XSetForeground(dpy, gc, pix[3]) ;
							XDrawLines(dpy,win,gc,seg[0],nbseg[0],CoordModeOrigin);
							XSetForeground(dpy, gc, pix[2]) ;
							XDrawLines(dpy,win,gc,seg[1],nbseg[1],CoordModeOrigin);
							}
						    prop=i;
						    }
		
				if(keysym==XK_q) fini=1;
				
			    break ;
			default :
				break;
		}
	}
}
