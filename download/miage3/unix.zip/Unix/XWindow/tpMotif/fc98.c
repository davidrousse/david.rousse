
#include <Xm/Xm.h>
/*  #include <Xm/BulletinB.h>	*/
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/List.h>
#include <Xm/RowColumn.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <stdio.h>
#include <string.h>

#define MAX_ENTRIES  20
#define LINE_LENGTH  80

char  postit[255], *cible;

void choix(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmListCallbackStruct    *calldata;
{
XmStringGetLtoR(calldata->item, XmSTRING_OS_CHARSET, &cible);
}

void envoimessage(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, label;
FILE *tmp;
char commande[20];

strcpy(commande,"mail ");
strcat(commande, cible);
tmp=fopen("tmp", "w");
fprintf(tmp, "%s\n", postit);
fclose(tmp);
strcat(commande, " < tmp");
system(commande);
strcpy(commande,"");
}

void afficheici(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, label;
XmString xmstr;

xmstr = XmStringCreateSimple(postit);
top = XtCreateApplicationShell("postit", topLevelShellWidgetClass, NULL, 0);
label = XtVaCreateManagedWidget("postit", 
                                xmLabelWidgetClass, 
				top, 
				XmNheight, (XtArgVal) 50, 
				XmNwidth, (XtArgVal) 200,
				XmNlabelString, xmstr,  
				NULL);
XtRealizeWidget(top);
}


void email(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, forme, table, bouton;
XmString xmstr2;

int i;
char     list_entry[LINE_LENGTH], *ch;
FILE     *file;
Arg      arg[4];
Widget   toplevel, list;
XmString xmstr[MAX_ENTRIES];

file = fopen("liste_mail", "r");
for (i = 0; !feof(file) && i < MAX_ENTRIES; i++)
    {
    fgets(list_entry, LINE_LENGTH, file);
    list_entry[strlen(list_entry) - 1] = NULL;
    xmstr[i] = XmStringCreateSimple(list_entry);
    }
i--;

top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);

forme = XtVaCreateManagedWidget("forme", 
				xmFormWidgetClass,
				top, 
				XmNheight, (XtArgVal) 400, 
				XmNwidth, (XtArgVal) 400,  
				NULL);

table = XtVaCreateManagedWidget("table", 
                                xmListWidgetClass, 
				forme, 
				XmNitemCount, i, 
				XmNitems, xmstr, 
				XmNvisibleItemCount, i, 
				XmNselectionPolicy, XmSINGLE_SELECT, 
				NULL);

xmstr2 = XmStringCreateSimple("envoyer");
bouton = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass,
				forme,
				XmNlabelString, xmstr2,
				XmNx, (XtArgVal) 0,
				XmNy, (XtArgVal) 300,
				NULL);

XtAddCallback(table, XmNsingleSelectionCallback, choix, NULL);
XtAddCallback(bouton, XmNactivateCallback, envoimessage, NULL);

XtRealizeWidget(top);
}

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}

void enter(widget, client_data, call_data)
Widget   widget;
caddr_t  client_data, call_data;
{
char *string;
string = XmTextGetString(widget);
strcpy(postit, string);
}

main(argc, argv)
int argc;
char *argv[];
{
   Widget toplevel, label1, label2, label3, texte, boite;
   XmString xmstr;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite", 
				xmRowColumnWidgetClass,
				toplevel, 
				XmNheight, (XtArgVal) 300, 
				XmNwidth, (XtArgVal) 400,  
				NULL);

texte = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				boite, 
				NULL);

xmstr = XmStringCreateSimple("afficher  ici");
label1 = XtVaCreateManagedWidget("b1", 
                                xmPushButtonWidgetClass, 
				boite,
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple("envoyer mail");
label2 = XtVaCreateManagedWidget("b2",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple("   quitter   ");
label3 = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				NULL);

XtRealizeWidget(toplevel); 

XtAddCallback(texte, XmNactivateCallback, enter, NULL);
XtAddCallback(label1, XmNactivateCallback, afficheici, NULL);
XtAddCallback(label2, XmNactivateCallback, email, NULL);
XtAddCallback(label3, XmNactivateCallback, quit, NULL);

XtMainLoop();
}
