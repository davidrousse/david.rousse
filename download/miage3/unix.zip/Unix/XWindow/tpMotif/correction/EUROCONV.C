/**************************************************************************
*
* Nom du projet     : Programmation X-Window sous HP-UX
* Objet 				  : TP Interphaces graphiques MIAGe 3
*							 Convertisseur de devises, version simple par le prof.
*
***************************************************************************
*
* R�pertoire                : miage3\Unix\XWindow\tpMotif\correction
* Nom du fichier            : euroconv.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 08 / 05 / 2001
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*/

#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/List.h>
#include <Xm/RowColumn.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <stdio.h>
#include <string.h>

#define MAX_ENTRIES  20
#define LINE_LENGTH  80

float tauxcour,  taux[MAX_ENTRIES];
float qtedevise;

/********************************************************************************/

void choixtaux(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmListCallbackStruct    *calldata;
{
tauxcour = taux[calldata->item_position - 1];
}

/******************************************************************************/

void convertir(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
XmString xmstr;
char ch[10];
Arg arg;

sprintf(ch, "%f", qtedevise * tauxcour) ;
strcat(ch," e");
xmstr = XmStringCreateSimple(ch);
XtSetArg(arg, XmNlabelString, xmstr);
XtSetValues((Widget)clientdata, &arg, 1);
}

/******************************************************************************/

void choixdevise(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, table;
XmString xmstr2;

int i;
char     list_entry[LINE_LENGTH], *ch;
FILE     *file;
Arg      arg[4];
Widget   toplevel, list;
XmString xmstr[MAX_ENTRIES];

file = fopen("liste_devise", "r");
for (i = 0; !feof(file) && i < MAX_ENTRIES; i++)
    {    
    fscanf(file, "%s %f",list_entry,&(taux[i]));
    xmstr[i] = XmStringCreateSimple(list_entry);
    }
i--;

top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);
table = XtVaCreateManagedWidget("table", 
                                xmListWidgetClass, 
				top, 
				XmNitemCount, i, 
				XmNitems, xmstr, 
				XmNvisibleItemCount, i, 
				XmNselectionPolicy, XmSINGLE_SELECT, 
				NULL);

XtAddCallback(table, XmNsingleSelectionCallback, choixtaux, NULL);

XtRealizeWidget(top);
}

/******************************************************************************/

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
XtCloseDisplay(XtDisplay(w));
exit(0);
}

/******************************************************************************/

void enter(widget, client_data, call_data)
Widget   widget;
caddr_t  client_data, call_data;
{
char *ent;
ent=XmTextGetString(widget);
sscanf(ent,"%f",&qtedevise);
}

/******************************************************************************/
main(argc, argv)
int argc;
char *argv[];
{
Widget toplevel, bquit, bconv, bdevise,  boite, texte, label;
XmString xmstr;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite", 
                                xmRowColumnWidgetClass, 
				toplevel, 
				XmNx, (XtArgVal) 0,
				XmNy, (XtArgVal) 100,
				NULL);

texte = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				boite, 
				NULL);

xmstr = XmStringCreateSimple("0.");
label = XtVaCreateManagedWidget("b1", 
                                xmLabelWidgetClass, 
				boite,
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple("devise");
bdevise = XtVaCreateManagedWidget("b2",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple("convertir");
bconv = XtVaCreateManagedWidget("b2",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple("quitter");
bquit = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				NULL);

XtRealizeWidget(toplevel); 

XtAddCallback(texte, XmNactivateCallback, enter, NULL);
XtAddCallback(bdevise, XmNactivateCallback, choixdevise, NULL);
XtAddCallback(bconv, XmNactivateCallback, convertir, label);
XtAddCallback(bquit, XmNactivateCallback, quit, NULL);

XtMainLoop();
}
