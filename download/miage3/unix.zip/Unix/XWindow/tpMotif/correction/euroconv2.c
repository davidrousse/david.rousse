/**************************************************************************
*
* Nom du projet     : Programmation X-Window sous HP-UX
* Objet 				  : TP Interphaces graphiques MIAGe 3
*							 Convertisseur de devises, version avanc�e par le prof.
*
***************************************************************************
*
* R�pertoire                : miage3\Unix\XWindow\tpMotif\correction
* Nom du fichier            : euroconv.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 08 / 05 / 2001
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*/

#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/List.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <stdio.h>
#include <string.h>

#define MAX_ENTRIES  20
#define LINE_LENGTH  80
#define eur2dev  0
#define dev2eur  1

Widget texte_eur, texte_dev, labdev;

float taux[MAX_ENTRIES];
XmString tabxmstr[MAX_ENTRIES];
int num, sens, nbdevises;
float qte;

/******************************************************************************/

void choixtaux(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmListCallbackStruct    *calldata;
{
num = calldata->item_position;

XtDestroyWidget((Widget)clientdata);
}

/******************************************************************************/

void convertir(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char ch[10];
Arg arg;

if (sens == eur2dev) {
	sprintf(ch, "%f", qte / taux[num - 1]) ;
	XmTextSetString(texte_dev, ch);
}
else {
	sprintf(ch, "%f", qte * taux[num - 1]) ;
	XmTextSetString(texte_eur, ch);
}
XtSetArg(arg, XmNlabelString, tabxmstr[num - 1]);
XtSetValues(labdev, &arg, 1);
}

/******************************************************************************/

void choixdevise(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, table;

top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);

table = XtVaCreateManagedWidget("table", 
                                xmListWidgetClass, 
				top, 
				XmNitemCount, nbdevises, 
				XmNitems, tabxmstr, 
				XmNvisibleItemCount, nbdevises, 
				XmNselectionPolicy, XmSINGLE_SELECT, 
				NULL);

XtAddCallback(table, XmNsingleSelectionCallback, choixtaux, top);

XtRealizeWidget(top);
}

/******************************************************************************/

void enter(widget, clientdata, call_data)
Widget   widget;
caddr_t  clientdata, call_data;
{
char *ent;
ent=XmTextGetString(widget);

sscanf(ent, "%f", &qte);

if (widget == texte_dev ) sens = dev2eur;
if (widget == texte_eur) sens = eur2dev;
}

/******************************************************************************/

void entertaux(widget, clientdata, calldata)
Widget widget;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char *ent;
ent=XmTextGetString(widget);
sscanf(ent, "%f", &(taux[num -1]) );
}

/******************************************************************************/

void enlevedev(widget, clientdata, calldata)
Widget widget;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
int i;

if (nbdevises!=0) {
	for (i=num - 1;i<nbdevises-1;i++) {
		taux[i]=taux[i+1];
		tabxmstr[i]=tabxmstr[i+1];
		}
	nbdevises--;
	}
}

/******************************************************************************/

void enterdev(widget, clientdata, calldata)
Widget widget;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char *ent,nom[20];
if (nbdevises<MAX_ENTRIES) {
	ent=XmTextGetString(widget);
	sscanf(ent, "%s %f", nom, &(taux[nbdevises]) );
	tabxmstr[nbdevises] = XmStringCreateSimple(nom);
	nbdevises++;
	}
}

/******************************************************************************/

void ajoutdev(widget, clientdata, calldata)
Widget widget;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, text;

top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);

text = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				top, 
				XmNwidth, 200, XmNheight, 50, 
				NULL);
XtRealizeWidget(top); 
XtAddCallback(text, XmNactivateCallback, enterdev, NULL);
}

/******************************************************************************/

void modiftaux(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, text;

top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);

text = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				top, 
				XmNwidth, 200, XmNheight, 50, 
				NULL);
XtRealizeWidget(top); 
XtAddCallback(text, XmNactivateCallback, entertaux, NULL);
}

/******************************************************************************/

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
FILE *file;
int i;
char *string;

file = fopen("liste_devise", "w");
for (i = 0; i < nbdevises; i++)
    {    
    XmStringGetLtoR(tabxmstr[i], XmSTRING_OS_CHARSET, &string);
    fprintf(file, "%s %f\n",string,taux[i]);
    }

fclose(file);
XtCloseDisplay(XtDisplay(w));
exit(0);
}

/******************************************************************************/
main(argc, argv)
int argc;
char *argv[];
{
Widget toplevel, bquit, bconv, bdevise,  boite, labeur, btaux, bsupp, bajout;
XmString xmstr;
int i;
char     list_entry[LINE_LENGTH];
FILE     *file;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite", 
                                xmFormWidgetClass, 
				toplevel, 
				XmNwidth, 400, XmNheight, 200, 
				NULL);

texte_eur = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				boite, 
				XmNx, 0, XmNy, 0,
				XmNwidth, 200, XmNheight, 50, 
				NULL);
				
xmstr = XmStringCreateSimple("euros");
labeur = XtVaCreateManagedWidget("l",
				xmLabelWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				XmNx, 200, XmNy, 0,
				XmNwidth, 200, XmNheight, 50, 
				NULL);
				
				
texte_dev = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				boite, 
				XmNx, 0, XmNy, 50,
				XmNwidth, 200, XmNheight, 50, 
				NULL);
				
xmstr = XmStringCreateSimple("devises");
labdev = XtVaCreateManagedWidget("l",
				xmLabelWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				XmNx, 200, XmNy, 50,
				XmNwidth, 200, XmNheight, 50, 
				NULL);

xmstr = XmStringCreateSimple("choix devise");
bdevise = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				XmNx, 0, XmNy, 100,
				XmNwidth, 200, XmNheight, 50, 
				NULL);

xmstr = XmStringCreateSimple("convertir");
bconv = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				XmNx, 200, XmNy, 100,
				XmNwidth, 200, XmNheight, 50, 
				NULL);

xmstr = XmStringCreateSimple("modif");
btaux = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNx, 0, XmNy, 150,
				XmNwidth, 100, XmNheight, 50, 
				NULL);

xmstr = XmStringCreateSimple("supprime");
bsupp = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNx, 100, XmNy, 150,
				XmNwidth, 100, XmNheight, 50, 
				NULL);

xmstr = XmStringCreateSimple("ajoute");
bajout = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNx, 200, XmNy, 150,
				XmNwidth, 100, XmNheight, 50, 
				NULL);

xmstr = XmStringCreateSimple("quitter");
bquit = XtVaCreateManagedWidget("b",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNx, 300, XmNy, 150,
				XmNwidth, 100, XmNheight, 50, 
				NULL);

XtRealizeWidget(toplevel); 


file = fopen("liste_devise", "r");
for (i = 0; !feof(file) && i < MAX_ENTRIES; i++)
    {    
    fscanf(file, "%s %f",list_entry,&(taux[i]));
    tabxmstr[i] = XmStringCreateSimple(list_entry);
    }
 
i--;
nbdevises = i;

XtAddCallback(texte_dev, XmNactivateCallback, enter, NULL);
XtAddCallback(texte_eur, XmNactivateCallback, enter, NULL);
XtAddCallback(bdevise, XmNactivateCallback, choixdevise, NULL);
XtAddCallback(bconv, XmNactivateCallback, convertir, NULL);
XtAddCallback(btaux, XmNactivateCallback, modiftaux, NULL);
XtAddCallback(bsupp, XmNactivateCallback, enlevedev, NULL);
XtAddCallback(bajout, XmNactivateCallback, ajoutdev, NULL);
XtAddCallback(bquit, XmNactivateCallback, quit, NULL);

XtMainLoop();
}
