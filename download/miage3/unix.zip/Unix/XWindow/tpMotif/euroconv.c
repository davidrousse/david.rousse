/**************************************************************************
*
* Nom du projet     : Programmation X-Window sous HP-UX
* Objet 				  : TP Interphaces graphiques MIAGe 3
*							 Convertisseur de devises, version en cours ...
*
***************************************************************************
*
* R�pertoire                : miage3\Unix\XWindow\tpMotif
* Nom du fichier            : euroconv.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 08 / 05 / 2001
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*/

#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/List.h>
#include <Xm/RowColumn.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <stdio.h>
#include <string.h>

#define MAX_ENTRIES  20
#define LINE_LENGTH  80

Widget devise, euro, libelle_devise_1;
char chaine_entree[10], *cible;
float taux_conversion = 6.55;
float somme_a_convertir, somme_convertie;
int pos_devise;
float float_entry[MAX_ENTRIES];
XmString tampon_devises[MAX_ENTRIES];
int taille_tampon_devises=0;

int lire_fichier()
{
	FILE     *file;
	int i;
	char     list_entry[LINE_LENGTH], *ch;

	file = fopen("liste_devise", "r");
	for (i = 0; !feof(file) && i < MAX_ENTRIES; i++)
	{
	    fscanf(file,"%s %f",list_entry,&(float_entry[i]));
	    list_entry[strlen(list_entry)] = NULL;
	    tampon_devises[i] = XmStringCreateSimple(list_entry);
	}
	
	taille_tampon_devises = i-1;
	
	return i;

}

void enterdev(widget, clientdata, calldata)
Widget widget;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char *ent,nom[20];
if (taille_tampon_devises<MAX_ENTRIES) {
	ent=XmTextGetString(widget);
	sscanf(ent, "%s %f", nom, &(float_entry[taille_tampon_devises]) );
	tampon_devises[nbdevises] = XmStringCreateSimple(nom);
	taille_tampon_devises++;
	}
}

void gestion_taux(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmListCallbackStruct    *calldata;
{
	FILE     *file;
	int i;
	char     list_entry[LINE_LENGTH], *ch;
	float float_temp;
	XmString xm_temp;

		
	if((int)clientdata==1)
	{
		/* ajout */
		Widget top, text;

		top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);

		text = XtVaCreateManagedWidget("text", 
                                xmTextWidgetClass, 
				top, 
				XmNwidth, 200, XmNheight, 50, 
				NULL);
		XtRealizeWidget(top); 
		XtAddCallback(text, XmNactivateCallback, enterdev, NULL);
		
	}
	else
	{

		if((int)clientdata==2)
		{
			/* suppression */
			i = pos_devise;
			printf("\ni=%d taille_tamp=%d pos_devi=%d ",i,taille_tampon_devises,
         																			pos_devise);
			if(taille_tampon_devises!=0)
			{
				for(i=pos_devise-1; i<taille_tampon_devises-1; i++)
				{
					float_entry[i] = float_entry[i+1];
					tampon_devises[i] = tampon_devises[i+1];
	  
				}	
				taille_tampon_devises--;
					
				/*file = fopen("liste_devise", "w");*/
				for (i = 0; i<taille_tampon_devises; i++)
				{
				   	XmStringGetLtoR(tampon_devises[i], XmSTRING_OS_CHARSET, &ch);
				   	printf("\n%s %f\n",ch,float_entry[i]);
					/*fprintf(file,"%s %f\n",ch,float_entry[i]);*/
				}	

				/*fclose(file);*/
				
			} /* fin suppression */			
		}
		else
		{
			/* modification */
		}	

	}	
}

void clic_liste(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmListCallbackStruct    *calldata;
{

Arg args[1];
XmString xmstr;

XmStringGetLtoR(calldata->item, XmSTRING_OS_CHARSET, &cible);
pos_devise = (calldata->item_position)-1;

/* modification du libelle de la devise */
xmstr = XmStringCreateSimple(cible);
XtSetArg(args[0],XmNlabelString,xmstr);
XtSetValues(libelle_devise_1,args,1);

}

void valider_clic_liste(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
	taux_conversion = float_entry[pos_devise];
}

void convertir(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{

	char chaine[10];	
	somme_convertie = somme_a_convertir * taux_conversion;

	sprintf(chaine,"%f",somme_convertie);
	XmTextSetString(euro,chaine);	
	
}

void traite_euro(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
	char *string;
	char chaine[10];	
		
	string = XmTextGetString(w);
	sscanf(string,"%f",&somme_a_convertir);
	
	somme_convertie = somme_a_convertir * 1/taux_conversion;

	sprintf(chaine,"%f",somme_convertie);
	XmTextSetString(devise,chaine);	
}

void choix_devise(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
Widget top, forme, table, valider, ajouter, supprimer, modifier;
XmString xmstr2;

int i;
char     list_entry[LINE_LENGTH], *ch;

Arg      arg[4];
Widget   toplevel, list;

/*
FILE     *file;
Arg      arg[4];
Widget   toplevel, list;
XmString xmstr[MAX_ENTRIES];

file = fopen("liste_devise", "r");
for (i = 0; !feof(file) && i < MAX_ENTRIES; i++)
    {
    fscanf(file,"%s %f",list_entry,&(float_entry[i]));
    list_entry[strlen(list_entry)] = NULL;
    xmstr[i] = XmStringCreateSimple(list_entry);
    }
i--;
*/

i = lire_fichier(tampon_devises);
i--;

top = XtCreateApplicationShell("table", topLevelShellWidgetClass, NULL, 0);

forme = XtVaCreateManagedWidget("forme", 
				xmRowColumnWidgetClass,
				top, 
				XmNheight, (XtArgVal) 300, 
				XmNwidth, (XtArgVal) 400,  
				NULL);

table = XtVaCreateManagedWidget("table", 
                                xmListWidgetClass, 
				forme, 
				XmNitemCount, i, 
				XmNitems, tampon_devises, 
				XmNvisibleItemCount, i, 
				XmNselectionPolicy, XmSINGLE_SELECT, 
				NULL);

xmstr2 = XmStringCreateSimple("  Valider  ");
valider = XtVaCreateManagedWidget("valider",
				xmPushButtonWidgetClass,
				forme,
				XmNlabelString, xmstr2,
				XmNx, (XtArgVal) 0,
				XmNy, (XtArgVal) 300,
				NULL);

xmstr2 = XmStringCreateSimple("  Ajouter  ");
ajouter = XtVaCreateManagedWidget("ajouter",
				xmPushButtonWidgetClass,
				forme,
				XmNlabelString, xmstr2,
				XmNx, (XtArgVal) 0,
				XmNy, (XtArgVal) 300,
				NULL);

xmstr2 = XmStringCreateSimple("  Supprimer  ");
supprimer = XtVaCreateManagedWidget("Supprimer",
				xmPushButtonWidgetClass,
				forme,
				XmNlabelString, xmstr2,
				XmNx, (XtArgVal) 0,
				XmNy, (XtArgVal) 300,
				NULL);

xmstr2 = XmStringCreateSimple("  Modifier  ");
modifier = XtVaCreateManagedWidget("modifier",
				xmPushButtonWidgetClass,
				forme,
				XmNlabelString, xmstr2,
				XmNx, (XtArgVal) 0,
				XmNy, (XtArgVal) 300,
				NULL);
												
XtAddCallback(table, XmNsingleSelectionCallback, clic_liste, NULL);
XtAddCallback(valider, XmNactivateCallback, valider_clic_liste, NULL);
XtAddCallback(ajouter, XmNactivateCallback, gestion_taux, 1);
XtAddCallback(supprimer, XmNactivateCallback, gestion_taux, 2);
XtAddCallback(modifier, XmNactivateCallback, gestion_taux, 3);

XtRealizeWidget(top);
}

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}

void traite_devise(widget, client_data, call_data)
Widget   widget;
caddr_t  client_data, call_data;
{
	char *string;
	char chaine[10];	
		
	string = XmTextGetString(widget);
	sscanf(string,"%f",&somme_a_convertir);
	
	somme_convertie = somme_a_convertir * taux_conversion;

	sprintf(chaine,"%f",somme_convertie);
	XmTextSetString(euro,chaine);	
	
}

main(argc, argv)
int argc;
char *argv[];
{
   Widget toplevel, quitter, conversion, bt_devise, boite, libelle_devise_2;
   XmString xmstr;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite", 
				xmFormWidgetClass,
				toplevel, 
				XmNheight, (XtArgVal) 310, 
				XmNwidth, (XtArgVal) 310,  
				NULL);

devise = XtVaCreateManagedWidget("devise", 
                                xmTextWidgetClass, 
				boite, 
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,0, 				 
 				XmNy,10, 				
				NULL);

euro = XtVaCreateManagedWidget("euro", 
                                xmTextWidgetClass, 
				boite,
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,0, 				 
 				XmNy,70, 				
				NULL);

xmstr = XmStringCreateSimple("   Convertir   ");
conversion = XtVaCreateManagedWidget("conversion",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,0, 				 
 				XmNy,130, 				
				NULL);

xmstr = XmStringCreateSimple("   Devise ...   ");
bt_devise = XtVaCreateManagedWidget("bt_devise",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,0, 				 
 				XmNy,190, 				
				NULL);

xmstr = XmStringCreateSimple("   Quitter   ");
quitter = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,0, 				 
 				XmNy,250, 				
				NULL);

xmstr = XmStringCreateSimple("   Francs   ");
libelle_devise_1 = XtVaCreateManagedWidget("lib1",
				xmLabelWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,160, 				 
 				XmNy,10, 				
				NULL);

xmstr = XmStringCreateSimple("   Euros   ");
libelle_devise_2 = XtVaCreateManagedWidget("lib2",
				xmLabelWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNwidth,150,	
 				XmNheight,50,
 				XmNx,160, 				 
 				XmNy,70, 				
				NULL);

XtRealizeWidget(toplevel); 

XtAddCallback(devise, XmNactivateCallback, traite_devise, NULL);
XtAddCallback(euro, XmNactivateCallback, traite_euro, NULL);
XtAddCallback(conversion, XmNactivateCallback, convertir, NULL);
XtAddCallback(bt_devise, XmNactivateCallback, choix_devise, NULL);
XtAddCallback(quitter, XmNactivateCallback, quit, NULL);

XtMainLoop();
}
