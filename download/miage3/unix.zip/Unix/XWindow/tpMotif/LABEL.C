/*
 *    label.c
 *
 *  Ceci illustre un simple programe "Hello World" en Motif avec un widget label.
 *  On introduit aussi le concept Motif de "compound string".  Pour etre utile
 *  dans une plus large mesure, Motif n'affiche pas les chaines de caracteres
 *  avec le type char *. Il utilise le type XmString, et offre des fonctions
 *  pour creer des XmStrings, ou extraire des vrais chaines ASCII des XmStrings.
 *  En plus, il illustre l'affectation de ressources de widget.
 *  
 *  SGI
 */

#include <Xm/Xm.h>      /* X/Motif header ... toujours necessaire pour Motif */
                        /* Xm/Xm.h doit preceder tout autre fichier Xm/*.h */
#include <Xm/Label.h>   /* header pour le widget Label. */

main(argc, argv)
int argc;
char *argv[];
{

/*----------------------------------------------------------------------------
Declaration des variables
Toutes les variables sont de types specifiques a X Intrinsic toolkit ou X/Motif.

Widget   - principal block de base de toute application X toolkit.
XmString - chaine de caracteres Motif. Utilisee dans presque toute application
	   ou l'affichage de texte est desire.
Arg	 - type X toolkit pour demander/changer une characteristique d'un widget.
-----------------------------------------------------------------------------*/


   Widget   toplevel, label;
   XmString xmstr;
   Arg	    arg[1];


/*----------------------------------------------------------------------------
Creer le principal widget de l'application, et ouvre aussi la connexion
au serveur X. Cette ligne est necessaire dans toute application X toolkit :
le serveur X sait que l'application demande a creer une fenetre, prend soin
d'etablir la communication entre le serveur et l'application cliente,  et
cree le premier widget (un shell),  qui est la base de tous les autres
widget de l'application.

Les parametres de la fonction sont :

   1) le NOM de l'APPLICATION. X/Motif utilise le mot "Application" a la place de
"programme".  Passer argv[0] doit etre une habitude.

   2) la CLASSE de l'application est une chaine de characteres. Par exemple
"MotifDemo". Ceci est utilise pour les situations avancees ou le programmeur
veux que toutes les applications d'une classe se ressemblent.

   3) un POINTEUR vers les structures qui definissent le parsing pour les parametres
speciaux ajoutes a la ligne des commandes. Ici on se contente de NULL

   4) Le NOMBRE de structures passees dans l'arguement prcedent.
Comme l'argument 3 est NULL, on passe zero (0) ici.

   5) Un POINTEUR vers le nombre d'arguments de la ligne de commande du programme
Prtatiquement, on peux toujours mettre "&argc" si argc est le nom defini dans la
definition du main. Ce parametre est change (remplace) car X parse les option de la
ligne de commande, et laisse l'utilisateur la traiter.

   6) Un POINTEUR vers le tableau de caracteres qui contients les arguments de la
ligne de commande. C'est generalement "argv" si argv est le nom donne dans la
declaration du main. Cette liste est detruite et remplacee de la meme maniere que
pour l'argument precedent
-----------------------------------------------------------------------------*/


   toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);


/*-----------------------------------------------------------------------------
Creation d'une chaine de caracteres Motif pour utiliser comme texte dans le widget
label a creer. La fonction "XmStringCreateSimple" prend une chaine, la convertit 
et retourne une chaine XmString
-----------------------------------------------------------------------------*/


   xmstr = XmStringCreateSimple("Hello World");


/*-----------------------------------------------------------------------------
Assignation de la structure Arg avec la fonction XtSetArg. Cette fonction
prepare la demande dans une forme acceptable par Motif. Dans ce cas, on veut
affecter la chaine du label (XmNlabelString) avec la chaine XmString nouvellement
creee. 
    Chaque widget a sa liste d'attribut de la forme XmN<un attribut>. Chaque type
de ressource XmN* demande un type d'argument specifique dans l'appel de XtSetArg.

Les parametres de cette fonction sont :

   1) La structure Arg a affecter. Ici, arg[0].

   2) Le NOM de cet attribut (appele aussi resource) qui est compris par X/Motif.
Ici, on veut affecter la chaine a afficher, donc le nom de la ressource est 
"XmNlabelString".

   3) Le type de valeur qui est attendu avec la ressource en argument 2.
Ici, XmNlabelString demande une chaine de type XmString : "xmstr" l'est.
-----------------------------------------------------------------------------*/


   XtSetArg(arg[0], XmNlabelString, xmstr);


/*-----------------------------------------------------------------------------
Enfin, on cree le widget label avec la chaine desiree (passee dans le parametre
&arg. Cette fonction prend les parametres suivants et retourne le nouveau widget :

   1) Le WIDGET parent de ce widget. Ici, toplevel.

   2) Le NOM de ce widget (une chaine de caracteres) : "label". Ce nom est utilise
pour l'affectation des ressources en dehors du programme (fichier .Xdefaults par
exemple).

   3) Un POINTEUR vers les strutures Arg qui ont ete definies pour changer les
ressources de ce widget. Ici, on passe arg, comme c'est un tableau. Si c'etait
une simple structure, on passerait "&arg".

   4) Le NOMBRE de structures Arg de l'argument precedent.
-----------------------------------------------------------------------------*/


   label = XmCreateLabel(toplevel, "label", arg, 1);


/*-----------------------------------------------------------------------------
Apres avoir ete cree, le widget doit etre manage.  C'est fait avec l'appel a
XtManageWidget(). Le parametre de cette fonction est le widget qui doit
etre manage.
-----------------------------------------------------------------------------*/


   XtManageChild(label);


/*-----------------------------------------------------------------------------
On alerte le server X qu'on a fini de creer l'appilcation et qu'on veut qu'elle
soit affichee sur le terminal. Cette fonction (habituellement) prend le widget
cree avec XtInitialize() comme parametre.
-----------------------------------------------------------------------------*/


   XtRealizeWidget(toplevel);


/*-----------------------------------------------------------------------------
Entrer dans la boucle principale de gestion des evenements. Les applis X
sont guidees par les evenements (event driven). On attend que quelquechose se
produit,  et on reagi a cette action. La boucle XtMainLoop() est une boucle sans
fin qui traite les evenements quand ils arrivent.
-----------------------------------------------------------------------------*/


   XtMainLoop();
}
