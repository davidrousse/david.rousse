/*
 *    scroll_bar.c
 *
 *  Ceci illustre un widget XmScrollBar.
 *  Cet exemple illustre aussi les XmString, l'affectation des ressources, et le
 *  mecanisme de callback : ici on associe plusieurs callbacks pour un meme widget
 *
 *
 *  SGI
 */

#include <Xm/Xm.h>         /* X/Motif header file */
#include <Xm/ScrollBar.h>  /* header file for scroll bar widget type. */



/*----------------------------------------------------------------------------
Definition d'une fonction callback attachee par l'appel XtAddCallback() call.
[voir push_button.c]

Ici on va utiliser a la fois les parametres passe comme client_data (par l'appli)
et comme call_data (par le systeme). Ici client_data sera un pointeur vers une
chaine de carateres et call_data donnera des informations sur le callback lui-meme
(la nouvelle valeur pour la localisation du slider).
Ici encore client_data et call_data sont declare en tant que caddr_t. Ceci nous
oblige a faire le forcage de type (cast) des valeurs retournees dans le type qui est
attendu. Par exemple, client_data est transforme en "char *". Dans de vraies
applications, il peut etre souhaitable de definir le type dans la declaration de
la fonction, et on aurait pu ecrire :

   void scroll(widget, char_string, callback_info)
   Widget   widget;
   char     *char_string;
   XmScrollBarCallbackStruct  callback_info;
   {
printf("You %s the slider to value %d\n", char_string,
   callback_info);
   }

La defintion de la structure convenable XmScrollBarCallbackStruct se trouve dans
Xm.h (il y a une structure appropriee pour les callbacks de chaque type de widget) :

   typedef struct
   {
    int reason;
    XEvent * event;
    int value; <---  contains the new slider location value.
    int pixel;
   } XmScrollBarCallbackStruct;

On est interresse par le champ "value",  qui donne la valeur du slider dans le
scroll bar.
-----------------------------------------------------------------------------*/

void scroll(widget, client_data, call_data)
Widget   widget;
caddr_t  client_data, call_data;
{
   char *direction;
   XmScrollBarCallbackStruct  *callback;

   direction = (char *) client_data;
    callback = (XmScrollBarCallbackStruct *) call_data;

   printf("  You %s the slider to value %d\n", direction, callback->value);
}



/*----------------------------------------------------------------------------
M A I N
-----------------------------------------------------------------------------*/

main(argc, argv)
int argc;
char *argv[];
{

/*----------------------------------------------------------------------------
Declaration des variables et initialisation de l'application.  [label.c]
-----------------------------------------------------------------------------*/

   Widget   toplevel, scroll_bar;

   static char *id[] = {
			"incremented",
			"drug",
			"decremented",
			"page up'ed",
			"page down'ed",
			"end'ed",
			"home'ed"
		       };

   toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

/*----------------------------------------------------------------------------
Cree widget scroll bar avec  XmCreateScrollBar(). Cette fonction a les memes
parametres que XmCreateLabel() dans label.c.
-----------------------------------------------------------------------------*/

   scroll_bar = XmCreateScrollBar(toplevel, "scrollbar", NULL, 0);

/*----------------------------------------------------------------------------
Enregistre plusieurs callbacks pour le widget scroll bar.
Tous les callbacks vont faire appel a la meme fonction "scroll", mais vont lui
passer des donnees differentes : quelque chose en plus dans ces XtAddCallback()
par rapport a pushbutton.c, c'est qu'on passe des donnes (ici un pointeur pour
une chaine de caractere. 
-----------------------------------------------------------------------------*/

   XtAddCallback(scroll_bar, XmNdecrementCallback, scroll, id[0]);
   XtAddCallback(scroll_bar, XmNdragCallback, scroll, id[1]);
   XtAddCallback(scroll_bar, XmNincrementCallback, scroll, id[2]);
   XtAddCallback(scroll_bar, XmNpageDecrementCallback, scroll, id[3]);
   XtAddCallback(scroll_bar, XmNpageIncrementCallback, scroll, id[4]);
   XtAddCallback(scroll_bar, XmNtoBottomCallback, scroll, id[5]);
   XtAddCallback(scroll_bar, XmNtoTopCallback, scroll, id[6]);


   XtManageChild(scroll_bar);
   XtRealizeWidget(toplevel);
   XtMainLoop();
}

