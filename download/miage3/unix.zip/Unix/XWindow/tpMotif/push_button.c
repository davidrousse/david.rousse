/*
 *    push_button.c
 *
 *  Ceci illustre un widget XmPushB.
 *  Cet exemple illustre aussi les XmString, l'affectation des ressources, et le
 *  mecanisme de callback
 *
 *
 *  SGI
 */

#include <Xm/Xm.h>      /* X/Motif header */
#include <Xm/PushB.h>   /* header pour le widget pushbutton */



/*----------------------------------------------------------------------------
Definition d'une fonction callback attachee par l'appel XtAddCallback() call.

La declaration d'une fonction de callback est toujours du type :

   void function_name(widget, client_supplied_data, callback_data)
   Widget   widget;
   caddr_t  client_supplied_data, callback_data;

   les parametres sont :

1) le WIDGET pour lequel survient l'appel. On ne doit trouver ici comme valeur que
un des widgets avec lesquels la fonction a ete associee. 

2) la DONNEE que l'utilisateur peut mettre dans le dernier argument de XtAddCallback()

Le type caddr_t est juste un marqueur d'emplacement,  et doit etre remplace par le
vrai type passe. Par exemple,  si on passe une chaine de caractere (char *), alors
on devra declare "client_supplied_data" comme un "char *", et pas caddr_t [voir
scroll_bar.c pour un exemple de passage de donnes dans un sous programme de gestion
de callback.

3) l'information sur le CALLBACK lui meme.  Generalement, Motif definit une structure
de callback specifique a chaque widget. Par exemple le type de structure retourrne
pour un push button est une "XmPushButtonCallbackStruct". Une fois encore, la 
declaration caddr_t comme argument est pour marquer la place.

C'est comme ca car une fonction de retour de callback doit pouvoir traiter plusieurs
types de callbacks [voir scroll_bar.c]

-----------------------------------------------------------------------------*/

void appui_bouton(widget, client_data, callback_data)
Widget widget;
caddr_t client_data, callback_data;
{

/*----------------------------------------------------------------------------
Fait l'action qui doit arriver quand l'utilisateur presse le push button.
-----------------------------------------------------------------------------*/

   printf("  You pressed a push button.\n");
}


/*----------------------------------------------------------------------------
     MAIN
-----------------------------------------------------------------------------*/

main(argc, argv)
int argc;
char *argv[];
{

/*----------------------------------------------------------------------------
Declaration des variables et initialisation de l'application.  [label.c]
-----------------------------------------------------------------------------*/

   Widget	toplevel, button;
   Arg		arg;
   XmString	xmstr;

   toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

/*----------------------------------------------------------------------------
Affecte la chaine du label pour le push button.
-----------------------------------------------------------------------------*/

   xmstr = XmStringCreateSimple("Push Me");
   XtSetArg(arg, XmNlabelString, xmstr);

/*----------------------------------------------------------------------------
Cree widget push button avec XmCreatePushButton(). Cette fonction a les memes
parametres que XmCreateLabel() dans label.c.
-----------------------------------------------------------------------------*/

   button = XmCreatePushButton(toplevel, "button", &arg, 1);

/*----------------------------------------------------------------------------
Ajoute une fonction de traitement de callback pour un widget push button
Un callback est un des moyens que X/Motif donne a l'utilisateur de savoir qu'il
s'est passe quelque chose. Chaque type de widget a des ensembles de ressources de
callbacks auxquels il peut inscrire des fonctions de traitement.

Les callbacks sont du type l'utilisateur a "active un push button" ou "bouge un
scrollbar", a compare avec des evenements de plus bas niveau comme "le pointeur de
la souris a bouge" ou "une touche du clavier a ete enfoncee", qui sont traites
generalement par des "event handler".

Les parametres de cette fonction sont :

   1) le WIDGET a qui le callback doit etre ajoute (ici "button")

   2) l'action de CALLBACK en cause (l'utilisateur appuye sur le bouton,  ce que
Motif connait comme "XmNactivateCallback")

   3) la FONCTION qui devra repondre a l'appel (au callback) quand l'utilisateur
fera son action. Cette fonction est "appui_bouton"

   4) n'importe quelle donnee que l'on veut passer a la fonction : une valeur, un
pointeur sur n'importe quel type. Ici on ne veut rien passer et on met NULL.

-----------------------------------------------------------------------------*/

   XtAddCallback(button, XmNactivateCallback, appui_bouton, NULL);


   XtManageChild(button);
   XtRealizeWidget(toplevel);
   XtMainLoop();
}



