/************************************************************/
/* Description :															*/
/* Application comment�e �crite avec Xt et Motif				*/
/*																				*/
/*	 Inclusion fichiers en-t�tes										*/
/*	 Fonctions de traitements des �v�nements					   */
/*	 Programme principal 												*/
/*		Initialisations                                       */
/*		Cr�ation des Widgets												*/
/*    Ajout des �v�nements par widget � traiter					*/
/*    Affichage des Widgets											*/
/*		Boucle de traitement des evenements                   */
/*																				*/
/* Auteur : D.R.															*/
/* Soci�t� : MIAGe 3� ann�e, UPS, Toulouse						*/
/************************************************************/

/************************************************************/
/*	 Inclusion fichiers en-t�tes										*/
/************************************************************/
#include <Xm.h> 			/* X/Motif header ... toujours necessaire pour Motif */
                        /* Xm.h doit preceder tout autre fichier Xm/*.h 	  */
#include <Xm/List.h>    /* header pour le widget List */
#include <PushB.h>
#include <RowColumn.h>
#include <stdio.h>

/************************************************************/
/*	 Callbacks : fonctions de traitements des �v�nements	   */
/*  c'est � dire fonctions ex�cut�es en r�ponse aux actions */
/*  de l'utilisateur dans un Widget									*/
/************************************************************/

/* Definition d'une fonction callback
   La declaration d'une fonction de callback est toujours du type :

   void function_name(widget, client_supplied_data, callback_data)
   Widget   widget;
   caddr_t  client_supplied_data, callback_data;

   les parametres sont :

1) le WIDGET pour lequel survient l'appel.

2) la DONNEE que l'utilisateur peut mettre dans le dernier argument
	de XtAddCallback()
   Le type caddr_t est juste un marqueur d'emplacement,
   et doit etre remplace par le vrai type passe.

3) l'information sur le CALLBACK lui meme.
   Generalement, Motif definit une structure
   de callback specifique � chaque widget
   (ex: XmListCallbackStruct pour un labal List).

C'est comme ca car une fonction de retour de callback
doit pouvoir traiter plusieurs types de callbacks
*/
void proc1(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
	if((int)clientdata==1)
		system("xclock &");
	else
		system("xterm &");
}

void proc2(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    printf("choix bouton %d\n", (int)clientdata);
}

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0); /* permet de sortir de XtMainLoop() */
}

/************************************************************/
/* 				Programme principal 									*/
/************************************************************/

main(argc, argv)
int argc;
char *argv[];
{
   Widget   toplevel, label1, label2, label3, label4, boite;
   XmString xmstr;
   Arg      arg[1];

/************************************************************/
/*								Initialisations                     */
/************************************************************/

/* creer le principal widget de l'application, alloue les ressources et      */
/* ouvre aussi la connexion au serveur X. Cette ligne est necessaire         */
/* dans toute application X toolkit :                                        */
/* le serveur sait que l'application demande a creer une fenetre, prend soin */
/* d'etablir la communication entre le serveur et l'application cliente,  et */
/* cree le premier widget (un shell),  qui est la base de tous les autres    */
/* widget de l'application.                                                  */
toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

/************************************************************/
/*              		Cr�ation des Widgets					   	*/
/************************************************************/

/* cr�ation, valuation et management du widget conteneur de type RowColumn */
boite = XtVaCreateManagedWidget("boite a boutons",
            xmRowColumnWidgetClass,
				toplevel,
				NULL);

/* conversion d'un char* en XmString pour pr�parer la valuation du widget */
xmstr = XmStringCreateSimple(" horloge ");

/* cr�ation, valuation et management du widget */
label1 = XtVaCreateManagedWidget("b1",
            xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,
				NULL);

xmstr = XmStringCreateSimple(" appuyer ");

label2 = XtVaCreateManagedWidget("b2",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,
				NULL);


xmstr = XmStringCreateSimple(" quitter ");

label3 = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,
				NULL);

xmstr = XmStringCreateSimple(" terminal ");

label4 = XtVaCreateManagedWidget("b4",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,
				NULL);

/************************************************************/
/*    		Ajout des �v�nements par widget � traiter			*/
/************************************************************/

/* Ajoute la fonction de traitement de callback proc1 pour le widget label1 */
XtAddCallback(label1, XmNactivateCallback, proc1, 1);

XtAddCallback(label2, XmNactivateCallback, proc2, 2);

XtAddCallback(label3, XmNactivateCallback, quit, NULL);

XtAddCallback(label4, XmNactivateCallback, proc1, 2);

/************************************************************/
/*    			Affichage des Widgets								*/
/************************************************************/

/* Seule la racine de l'arborescence est mat�rialis�e explicitement, */
/* les fils le seront implicitement via cet appel ...						*/
XtRealizeWidget(toplevel);

/************************************************************/
/*		      Boucle de traitement des evenements             */
/************************************************************/

/* toute application Xt/Motif doit g�rer une boucle d'�v�nements         */
/* pour r�cup�rer puis dispatcher ces derniers aux finctions de callback */
/* pr�vu�es � cet effet selon le widget concern�								 */
XtMainLoop();
}
