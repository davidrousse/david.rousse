/*
 *    list.c
 *
 *     Ceci illustre un simple programe Motif avec un widget liste.
 *  Le programme requiere comme entree un simple fichier texte file qui contient
 *  des lignes terminees par un "newline". Un exemple est donne par "list.data".
 *  Cet exemple illustre aussi les XmString, l'affectation des ressources,  et le
 *  mecanisme de callback
 *
 *  SGI
 */

#include <stdio.h>
#include <Xm/Xm.h>      /* X/Motif header ... toujours necessaire pour Motif */
#include <Xm/List.h>    /* header pour le widget List */

#define MAX_ENTRIES  20 /* constante pour le nombre d'entree de liste */
#define LINE_LENGTH  80 /* constante pour la longueur maximum d'une ligne */




/*-----------------------------------------------------------------------------
Definition d'une fonction callback qui affiche a l'utilisateur la selection faite.
On utilise l'information de la structure callback [see scroll_bar.c] pour determiner
ce qu'a fait l'utilisateur.

En plus,  on utilise la fonction XmStringGetLtoR() pour retrouver la vrai 
representation a partir du type XmString. Ceci est utilise comme suit :

   XmStringGetLtoR(xm_string, char_set, string);

les parametres requis sont :

   1) la XmString qui a la donnee que l'on veut. Dans l'example ci-dessous, la
structure du callback a un champ qui contient une XmString : l'item selectionne
bdans le widget list.

   2) L'ENSEMBLE DE CARACTERES dans lequel la XmString est codee. Dans la plupart
des cas, c'est "XmSTRING_OS_CHARSET" Ceci definit la traduction de XmString en
chaine ASCII normale.

   a) XmSTRING_OS_CHARSET est defini dans Xm.h. C'est plus si;ple et plus rapide
d'utiliser la version definie, a moins d'avoir besoin specifiquement d'un autre
type.

   b) La fonction XmStringCreateSimple() utilise (sauf si vous avez spcifie
autrement ... ) XmSTRING_OS_CHARSET pour encoder les chaines de caracteres.

La fonction pour traduire les chaines de caracteres en XmStrings a partir d'une
autre representation est :

   XmStringCreate(char *text, XmStringCharSet charset);

qui retourne un XmString.

Par exemple, XmStringCreateSimple() (label.c) peut etre replacee par

   XmStringCreate(text, XmSTRING_OS_CHARSET);

   3) L'ADDRESSE du pointeur vers un caractere (string est un "char *string",
et passe string to XmStringGetLtoR en utilisant "&string")
-----------------------------------------------------------------------------*/

void affiche_selection(widget, client_data, callback)
Widget	    widget;
caddr_t     client_data;
XmListCallbackStruct    *callback;
{
   char *string;
   int i;

   XmStringGetLtoR(callback->item, XmSTRING_OS_CHARSET, &string);

   printf("  You chose item %d : %s\n", callback->item_position, string);
}



/*---------------------------------------------------------------------------*/

main(argc, argv)
int argc;
char *argv[];
{
   int      i;
   char     list_entry[LINE_LENGTH], *ch;
   FILE     *file;
   Arg      arg[4];
   Widget   toplevel, list;
   XmString xmstr[MAX_ENTRIES];

   if (argc < 2) {
      printf("  usage : %s <filename>\n\n", argv[0]);
      exit();
   }

   if ((file = fopen(argv[1], "r")) == NULL) {
      printf("  unable to open file '%s'\n", argv[1]);
      exit();
   }

   for (i = 0; !feof(file) && i < MAX_ENTRIES; i++) {
      fgets(list_entry, LINE_LENGTH, file);

/*-----------------------------------------------------------------------------
Ceci remplace le caractere NEWLINE ('\n') a la fin de chaque ligne lue par un 
caractere NULL. C'est une preparation pour la conversion en chaine Motif XmString
-----------------------------------------------------------------------------*/

list_entry[strlen(list_entry) - 1] = NULL;

/*-----------------------------------------------------------------------------
Creation d'une chaine de caracteres Motif pour utiliser comme texte dans le widget
label a creer. La fonction "XmStringCreateSimple" prend une chaine, la convertit 
et retourne une chaine XmString
-----------------------------------------------------------------------------*/

xmstr[i] = XmStringCreateSimple(list_entry);
   }

/*-----------------------------------------------------------------------------
Decremente le nombrer de chaines lues et enleve la redondance de la derniere
-----------------------------------------------------------------------------*/

   --i;


   toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

/*-----------------------------------------------------------------------------
Affectation des ressources pour le widget list, incluses les donnees lues dans
le fichier.  [voir label.c]
-----------------------------------------------------------------------------*/

   XtSetArg(arg[0], XmNitemCount, i);
   XtSetArg(arg[1], XmNitems, xmstr);
   XtSetArg(arg[2], XmNvisibleItemCount, i);
   XtSetArg(arg[3], XmNselectionPolicy, XmSINGLE_SELECT);

/*-----------------------------------------------------------------------------
Creation du widget list avec ses arguments values
-----------------------------------------------------------------------------*/

   list = XmCreateList(toplevel, "list", arg, 4);

/*-----------------------------------------------------------------------------
Ajoute un callback pour quand l'utilisateur choisit un seul item.
-----------------------------------------------------------------------------*/

   XtAddCallback(list, XmNsingleSelectionCallback, affiche_selection, NULL);


   XtManageChild(list);
   XtRealizeWidget(toplevel);
   XtMainLoop();
}


