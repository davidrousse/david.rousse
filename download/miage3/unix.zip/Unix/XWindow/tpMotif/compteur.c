
#include <Xm.h>
#include <PushB.h>
#include <Label.h>
#include <Form.h>
#include <stdio.h>

int compteur=0;
Widget valeur;
XmString xmstr;

void plus(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char str[4];
Arg argument;

compteur++;
sprintf(str, "%d", compteur);
xmstr = XmStringCreateSimple(str);
XtSetArg(argument, XmNlabelString, xmstr);
XtSetValues(valeur, &argument, 1);
}


void moins(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char str[4];
Arg argument;

compteur--;
sprintf(str, "%d", compteur);
xmstr = XmStringCreateSimple(str);
XtSetArg(argument, XmNlabelString, xmstr);
XtSetValues(valeur, &argument, 1);
}

void raz(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
char str[4];
Arg argument;

compteur=0;
sprintf(str, "%d", compteur);
xmstr = XmStringCreateSimple(str);
XtSetArg(argument, XmNlabelString, xmstr);
XtSetValues(valeur, &argument, 1);
}

void job(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
int i;
for (i=0;i<compteur;i++) printf("%d\n", i);
printf("c'est fait\n");
}


void quitter(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
XtCloseDisplay(XtDisplay(w));
exit(0);
}


main(argc, argv)
int argc;
char *argv[];
{
   Widget   toplevel, boite,  inc, dec, init, go, quit;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite a boutons", 
                                xmFormWidgetClass, 
				toplevel,
				XmNheight, (XtArgVal) 100, 
				XmNwidth, (XtArgVal) 300,  
				NULL);
				
xmstr = XmStringCreateSimple(" + ");
inc = XtVaCreateManagedWidget("Inc",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNheight, (XtArgVal) 50,
				XmNwidth, (XtArgVal) 100,
				XmNx, 0, 
				XmNy, 0,  
				NULL);

xmstr = XmStringCreateSimple(" - ");
dec = XtVaCreateManagedWidget("Dec",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNheight, (XtArgVal) 50,
				XmNwidth, (XtArgVal) 100,
				XmNx, 0, 
				XmNy, 50,  
				NULL);

xmstr = XmStringCreateSimple(" Init ");
init = XtVaCreateManagedWidget("init",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNheight, (XtArgVal) 50,
				XmNwidth, (XtArgVal) 100,
				XmNx, (XtArgVal) 100, 
				XmNy, (XtArgVal) 0,  
				NULL);

xmstr = XmStringCreateSimple(" GO ! ");
go = XtVaCreateManagedWidget("go",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNheight, (XtArgVal) 50,
				XmNwidth, (XtArgVal) 100,
				XmNx, (XtArgVal) 100, 
				XmNy, (XtArgVal) 50,  
				NULL);

xmstr = XmStringCreateSimple(" Quitter ");
quit = XtVaCreateManagedWidget("quitter",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNheight, (XtArgVal) 50,
				XmNwidth, (XtArgVal) 100,
				XmNx, (XtArgVal) 200, 
				XmNy, (XtArgVal) 50,  
				NULL);
				
xmstr = XmStringCreateSimple("0");
valeur = XtVaCreateManagedWidget("valeur",
				xmLabelWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				XmNheight, (XtArgVal) 50,
				XmNwidth, (XtArgVal) 100,
				XmNx, (XtArgVal) 200, 
				XmNy, (XtArgVal) 0,  
				NULL);

XtRealizeWidget(toplevel);

XtAddCallback(inc, XmNactivateCallback, plus, NULL);
XtAddCallback(dec, XmNactivateCallback, moins, NULL);
XtAddCallback(init, XmNactivateCallback, raz, NULL);
XtAddCallback(go, XmNactivateCallback, job, NULL);
XtAddCallback(quit, XmNactivateCallback, quitter, NULL);

XtMainLoop();
}
