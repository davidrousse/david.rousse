#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Xm/Xm.h>
#include <Xm/PushB.h>
#include <Xm/Text.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <X11/keysym.h>

#define EFFA 0
#define PLUS 1
#define MOINS 2
#define MULT 3
#define DIVI 4
#define EGAL 5

int operateur;
int operande[2];
int op_prec=0;
char str[20];

Widget toplevel, affiche, boite;

/* ***************************************************************************** */
  
void proc_chiffre(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
if (! operande[1]) {XmTextSetString(affiche, ""); str[0] = '\0';}

switch ((int)clientdata)
    {
    case 0:
	operande[1] *= 10;
	if (operande[1]) strcat(str, "0");
	break;
    case 1:
	operande[1] = operande[1]*10 + 1;
	strcat(str, "1");
	break;
    case 2:
	operande[1] = operande[1]*10 + 2;
	strcat(str, "2");
	break;
    case 3:
	operande[1] = operande[1]*10 + 3;
	strcat(str, "3");
	break;
    case 4:
	operande[1] = operande[1]*10 + 4;
	strcat(str, "4");
	break;
    case 5:
	operande[1] = operande[1]*10 + 5;
	strcat(str, "5");
	break;
    case 6:
	operande[1] = operande[1]*10 + 6;
	strcat(str, "6");
	break;
    case 7:
	operande[1] = operande[1]*10 + 7;
	strcat(str, "7");
	break;
    case 8:
	operande[1] = operande[1]*10 + 8;
	strcat(str, "8");
	break;
    case 9:
	operande[1] = operande[1]*10 + 9;
	if (operande[1]) strcat(str, "9");
	break;
    }
XmTextSetString(affiche, str);
}

/* ***************************************************************************** */

void exec()
{
switch (op_prec)
    {
    case PLUS:
	operande[0] += operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	break;
    case MOINS:
	operande[0] -= operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	break;
    case MULT:
	operande[0] *= operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);	    
	break;
    case DIVI:
	if (operande[0]) operande[0] /= operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	break;
    default:
	break;
    }	
}



/* ***************************************************************************** */

void proc_operation(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
switch ((int)clientdata)
    {
    case PLUS:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	op_prec = PLUS;
	break;
    case MOINS:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	op_prec = MOINS;
	break;
    case MULT:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	op_prec = MULT;
	break;	
    case DIVI:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	op_prec = DIVI;
	break;
    case EGAL:
	if (op_prec) exec(op_prec);
	op_prec = 0;
	operande[0] = 0;
	break;
    case EFFA:
	operande[0] = 0;
	op_prec = 0;
	XmTextSetString(affiche, "");
	break;	
    }
operande[1] = 0;
}

/* ***************************************************************************** */
void proc_affiche(w, client, evt)
Widget w;
caddr_t client;
XEvent *evt;
{
KeySym k;
int n;
char buf[4];

n=XLookupString(evt,buf,4,&k,0);

if (! operande[1]) {XmTextSetString(affiche, ""); str[0] = '\0';}

switch (k)
    {
    case XK_0:
	operande[1] *= 10;
	if (operande[1]) strcat(str, "0");
	XmTextSetString(affiche, str);
	break;
    case XK_1:
	operande[1] = operande[1]*10 + 1;
	strcat(str, "1");
	XmTextSetString(affiche, str);
	break;
    case XK_2:
	operande[1] = operande[1]*10 + 2;
	strcat(str, "2");
	XmTextSetString(affiche, str);
	break;
    case XK_3:
	operande[1] = operande[1]*10 + 3;
	strcat(str, "3");
	XmTextSetString(affiche, str);
	break;
    case XK_4:
	operande[1] = operande[1]*10 + 4;
	strcat(str, "4");
	XmTextSetString(affiche, str);
	break;
    case XK_5:
	operande[1] = operande[1]*10 + 5;
	strcat(str, "5");
	XmTextSetString(affiche, str);
	break;
    case XK_6:
	operande[1] = operande[1]*10 + 6;
	strcat(str, "6");
	XmTextSetString(affiche, str);
	break;
    case XK_7:
	operande[1] = operande[1]*10 + 7;
	strcat(str, "7");
	XmTextSetString(affiche, str);
	break;
    case XK_8:
	operande[1] = operande[1]*10 + 8;
	strcat(str, "8");
	XmTextSetString(affiche, str);
	break;
    case XK_9:
	operande[1] = operande[1]*10 + 9;
	if (operande[1]) strcat(str, "9");
	XmTextSetString(affiche, str);
	break;
    case XK_plus:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	operande[1] = 0;
	op_prec = PLUS;
	break;
    case XK_minus:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	operande[1] = 0;
	op_prec = MOINS;
	break;
    case XK_asterisk:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	operande[1] = 0;
	op_prec = MULT;
	break;	
    case XK_slash:
	if (op_prec) exec(op_prec);
	else operande[0] = operande[1];
	sprintf(str, "%d", operande[0]);
	XmTextSetString(affiche, str);
	operande[1] = 0;
	op_prec = DIVI;
	break;
    case XK_Return:
    case XK_equal:
	if (op_prec) exec(op_prec);
	op_prec = 0;
	operande[0] = 0;
	operande[1] = 0;
	break;
    case XK_BackSpace:
	operande[0] = 0;
	operande[1] = 0;
	op_prec = 0;
	XmTextSetString(affiche, "");
	break;
    }
}

/* ***************************************************************************** */

void proc_quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}

/* ***************************************************************************** */
void creer_touche(wi, h, w, x, y, texte)
Widget *wi;
XtArgVal h, w, x, y;
char *texte;
{
XmString xmstr;

xmstr = XmStringCreateSimple(texte);

*wi = XtVaCreateManagedWidget(	"b2",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,
				XmNheight, h, 
				XmNwidth, w,  
				XmNx, x, 
				XmNy, y,  
				NULL);
}

/* ***************************************************************************** */

main(argc, argv)
int argc;
char *argv[];
{
   Widget   t0, t1, t2, t3, t4, t5, t6, t7, t8, t9,
	    plus, moins, mult, divi, effa, quit, egal;
	    
   XmString xmstr;

operande[0] = operande[1] = 0;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite a boutons", 
                                xmFormWidgetClass, /* xmRowColumnWidgetClass, */ 
				toplevel,
				XmNheight, (XtArgVal) 650, 
				XmNwidth, (XtArgVal) 420, 
				/* XmNnumColumns, 4,
				XmNpacking, XmPACK_NONE, */
				NULL);

affiche = XtVaCreateManagedWidget("aff", 
                                 xmTextWidgetClass, 
				 boite,
				 XmNvalue, "",
				 XmNeditable, False, 
				 XmNeditMode, XmSINGLE_LINE_EDIT, 
				 XmNheight, (XtArgVal) 100, 
				 XmNwidth, (XtArgVal) 400,
				 XmNx, (XtArgVal) 10, 
				 XmNy, (XtArgVal) 10, 
				 NULL);

creer_touche(  &t7, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal)  10, (XtArgVal) 120, "7");
creer_touche(  &t8, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 110, (XtArgVal) 120, "8");
creer_touche(  &t9, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 210, (XtArgVal) 120, "9");
creer_touche(&divi, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 310, (XtArgVal) 120, "/");

creer_touche(  &t4, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal)  10, (XtArgVal) 220, "4");
creer_touche(  &t5, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 110, (XtArgVal) 220, "5");
creer_touche(  &t6, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 210, (XtArgVal) 220, "6");
creer_touche(&mult, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 310, (XtArgVal) 220, "*");

creer_touche(  &t1, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal)  10, (XtArgVal) 320, "1");
creer_touche(  &t2, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 110, (XtArgVal) 320, "2");
creer_touche(  &t3, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 210, (XtArgVal) 320, "3");
creer_touche(&moins,(XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 310, (XtArgVal) 320, "-");

creer_touche(  &t0, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal)  10, (XtArgVal) 420, "0");
creer_touche(&egal, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 210, (XtArgVal) 420, "=");
creer_touche(&plus, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 310, (XtArgVal) 420, "+");

creer_touche(&quit, (XtArgVal) 100, (XtArgVal) 200, (XtArgVal)  10, (XtArgVal) 520, "quitter");
creer_touche(&effa, (XtArgVal) 100, (XtArgVal) 100, (XtArgVal) 310, (XtArgVal) 520, "C");


XtRealizeWidget(toplevel);

XtAddEventHandler(affiche, KeyPressMask, False, proc_affiche, NULL);

/*  XtAddCallback(affiche, XmNactivateCallback, proc_affiche, NULL);
    XtAddCallback(affiche, XmNfocusCallback, proc_affiche, NULL);
 */
XtAddCallback(t0, XmNactivateCallback, proc_chiffre, 0);
XtAddCallback(t1, XmNactivateCallback, proc_chiffre, 1);
XtAddCallback(t2, XmNactivateCallback, proc_chiffre, 2);
XtAddCallback(t3, XmNactivateCallback, proc_chiffre, 3);
XtAddCallback(t4, XmNactivateCallback, proc_chiffre, 4);
XtAddCallback(t5, XmNactivateCallback, proc_chiffre, 5);
XtAddCallback(t6, XmNactivateCallback, proc_chiffre, 6);
XtAddCallback(t7, XmNactivateCallback, proc_chiffre, 7);
XtAddCallback(t8, XmNactivateCallback, proc_chiffre, 8);
XtAddCallback(t9, XmNactivateCallback, proc_chiffre, 9);

XtAddCallback(plus,  XmNactivateCallback, proc_operation, PLUS);
XtAddCallback(moins, XmNactivateCallback, proc_operation, MOINS);
XtAddCallback(mult,  XmNactivateCallback, proc_operation, MULT);
XtAddCallback(divi,  XmNactivateCallback, proc_operation, DIVI);
XtAddCallback(egal,  XmNactivateCallback, proc_operation, EGAL);
XtAddCallback(effa,  XmNactivateCallback, proc_operation, EFFA);

XtAddCallback(quit, XmNactivateCallback, proc_quit, NULL);

XtMainLoop();
}
