/*
 *    text.c
 *
 *  Ceci illustre un widget XmText.
 *  Cet exemple illustre aussi les XmString, l'affectation des ressources, et le
 *  mecanisme de callback
 *
 *
 *  SGI
 */

#include <Xm/Xm.h>      /* X/Motif header */
#include <Xm/Text.h>    /*  header pour le widget Text */




/*----------------------------------------------------------------------------
Definition d'une fonction callback attachee par l'appel XtAddCallback() call.

Cette fonction utilise la fonction XmTextGetString() pour lire le texte entre dans
le widget. En plus on utilise la fonction XtFree() pour liberer la memoire.
-----------------------------------------------------------------------------*/

void enter(widget, client_data, call_data)
Widget   widget;
caddr_t  client_data, call_data;
{
   char  *string;

   string = XmTextGetString(widget);
   printf(" The text widget contains : '%s'\n", string);
   XtFree(string);
}


/*--------------------------------------------------------------------------*/


main(argc, argv)
int argc;
char *argv[];
{

/*----------------------------------------------------------------------------
Declaration des variables et initialisation de l'application.  [label.c]
-----------------------------------------------------------------------------*/

   Widget   toplevel, text;
   Arg	    arg;

   toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

/*----------------------------------------------------------------------------
Cree widget text avec XmCreateText(). Cette fonction a les memes parametres
que XmCreateLabel() dans label.c.
-----------------------------------------------------------------------------*/

   text = XmCreateText(toplevel, "text", NULL, 0);

/*----------------------------------------------------------------------------
Definit la largeur du widget a 400 pixels. [voir label.c pour XtSetArg]
-----------------------------------------------------------------------------*/

   XtSetArg(arg, XmNwidth, 400);

/*----------------------------------------------------------------------------
Affecte la valeur de la ressource du widget text apres sa creation. Parfois
ce n'est pas possible d'affecter les ressources avant que les widgets soient
crees, et la fonction XtSetValues() permet d'utiliser la structure X Arg, et
de le faire ailleurs dans le code apres la creation du widget
-----------------------------------------------------------------------------*/

   XtSetValues(text, &arg, 1);

/*----------------------------------------------------------------------------
Enregistre un callback d'activation pour le widget text. L'activation du widget
text se fait quand on presse <return>. [voir push_button.c pour plus sur les
callbacks]
-----------------------------------------------------------------------------*/

   XtAddCallback(text, XmNactivateCallback, enter, NULL);


   XtManageChild(text);
   XtRealizeWidget(toplevel);
   XtMainLoop();
}


