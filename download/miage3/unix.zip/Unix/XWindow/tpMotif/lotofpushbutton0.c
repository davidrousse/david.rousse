
#include <Xm.h>
#include <PushB.h>
#include <RowColumn.h>
#include <stdio.h>

void proc1(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
	if((int)clientdata==1)
		system("xclock &");
	else
		system("xterm &");			
}


void proc2(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    printf("choix bouton %d\n", (int)clientdata);
}

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}


main(argc, argv)
int argc;
char *argv[];
{
   Widget   toplevel, label1, label2, label3, label4, boite;
   XmString xmstr;
   Arg      arg[1];

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite a boutons", 
                                xmRowColumnWidgetClass, 
				toplevel, 
				NULL);

xmstr = XmStringCreateSimple(" horloge ");

label1 = XtVaCreateManagedWidget("b1", 
                                 xmPushButtonWidgetClass, 
				 boite,
				 XmNlabelString, xmstr,  
				 NULL);

xmstr = XmStringCreateSimple(" appuyer ");

label2 = XtVaCreateManagedWidget("b2",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				NULL);


xmstr = XmStringCreateSimple(" quitter ");

label3 = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple(" terminal ");

label4 = XtVaCreateManagedWidget("b4", 
                                 xmPushButtonWidgetClass, 
				 boite,
				 XmNlabelString, xmstr,  
				 NULL);

XtAddCallback(label1, XmNactivateCallback, proc1, 1);
XtAddCallback(label2, XmNactivateCallback, proc2, 2);
XtAddCallback(label3, XmNactivateCallback, quit, NULL);
XtAddCallback(label4, XmNactivateCallback, proc1, 2);

XtRealizeWidget(toplevel);

XtMainLoop();
}
