
#include <Xm/Xm.h>
/*  #include <Xm/BulletinB.h>	*/
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/List.h>
#include <Xm/RowColumn.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <stdio.h>
#include <string.h>

#define MAX_ENTRIES  20
#define LINE_LENGTH  80

char  chaine_entree[255], *cible;


void convertir(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{

}

void traite_affichage(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{

}

void quit(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}

void traite_saisie(widget, client_data, call_data)
Widget   widget;
caddr_t  client_data, call_data;
{
char *string;
string = XmTextGetString(widget);
strcpy(chaine_entree, string);
}

main(argc, argv)
int argc;
char *argv[];
{
   Widget toplevel, quitter, conversion, affichage, saisie, boite;
   XmString xmstr;

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("boite", 
				xmRowColumnWidgetClass,
				toplevel, 
				XmNheight, (XtArgVal) 300, 
				XmNwidth, (XtArgVal) 400,  
				NULL);

saisie = XtVaCreateManagedWidget("saisie", 
                                xmTextWidgetClass, 
				boite, 
				NULL);

affichage = XtVaCreateManagedWidget("affichage", 
                                xmPushButtonWidgetClass, 
				boite,
				NULL);

xmstr = XmStringCreateSimple("   Convertir   ");
conversion = XtVaCreateManagedWidget("conversion",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr,  
				NULL);

xmstr = XmStringCreateSimple("   Quitter   ");
quitter = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
				NULL);

XtRealizeWidget(toplevel); 

XtAddCallback(saisie, XmNactivateCallback, traite_saisie, NULL);
XtAddCallback(affichage, XmNactivateCallback, traite_affichage, NULL);
XtAddCallback(conversion, XmNactivateCallback, convertir, NULL);
XtAddCallback(quitter, XmNactivateCallback, quit, NULL);

XtMainLoop();
}
