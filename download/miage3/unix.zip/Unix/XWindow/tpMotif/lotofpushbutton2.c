
#include <Xm.h>
#include <PushB.h>
#include <Xm/Xm.h>
#include <Xm/Label.h>  
#include <Form.h>
#include <stdio.h>

/* variables globales */
int compteur = 0;
Widget affiche; 

void modif(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
	char chaine[10];
	Arg arg[1];	
	XmString xmstr;

	if((int)clientdata==1)
		/* incrementer le compteur */
		compteur++;		
	else
	{
		if((int)clientdata==2)
		{
			/* decremeter le compteur */
			if(compteur)
				compteur--;		
		}
		else
		{
			/* mise a 0 */
			compteur = 0;
		}
	}
	

	/* conversion en chaine puis en XmString */
	sprintf(chaine,"%d",compteur);
	xmstr = XmStringCreateSimple(chaine);
	
	/* valuation de la ressource du label */
	XtSetArg(arg[0],XmNlabelString,xmstr);
	XtSetValues(affiche,arg,1);

}

void traite(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    printf("Valeur du compteur %d\n", compteur);
}

void quitter(w, clientdata, calldata)
Widget w;
caddr_t clientdata;
XmAnyCallbackStruct calldata;
{
    XtCloseDisplay(XtDisplay(w));
    exit(0);
}


main(argc, argv)
int argc;
char *argv[];
{
   Widget   toplevel, go, plus, moins, raz, quit, boite;
   XmString xmstr;
   Arg      arg[1];

toplevel = XtInitialize(argv[0], "MotifDemo", NULL, 0, &argc, argv);

boite = XtVaCreateManagedWidget("calculatrice", 
                                xmFormWidgetClass, 
				toplevel, 
				NULL);

xmstr = XmStringCreateSimple(" plus ");

plus = XtVaCreateManagedWidget("b1", 
                                 xmPushButtonWidgetClass, 
				 boite,
				 XmNlabelString, xmstr, 
 				 XmNwidth,50,	
 				 XmNheight,50,
 				 XmNx,0, 				 
 				 XmNy,0, 				 
				 NULL);

xmstr = XmStringCreateSimple(" moins ");

moins = XtVaCreateManagedWidget("b2",
				xmPushButtonWidgetClass, 
				boite, 
				XmNlabelString, xmstr, 
 				XmNwidth,50,	
 				XmNheight,50,
 				XmNx,0, 				 
 				XmNy,50, 				 				 
				NULL);


xmstr = XmStringCreateSimple(" raz ");

raz = XtVaCreateManagedWidget("b3",
				xmPushButtonWidgetClass,
				boite,
				XmNlabelString, xmstr,  
 				XmNwidth,50,	
 				XmNheight,50,
 				XmNx,50, 				 
 				XmNy,0, 				 
				NULL);

xmstr = XmStringCreateSimple(" go ");

go = XtVaCreateManagedWidget("b4", 
                                 xmPushButtonWidgetClass, 
				 boite,
				 XmNlabelString, xmstr,  
 				 XmNwidth,50,	
 				 XmNheight,50,
 				 XmNx,50, 				 
 				 XmNy,50, 				 
				 NULL);

xmstr = XmStringCreateSimple(" 0 ");

affiche = XtVaCreateManagedWidget("b5", 
                                 xmLabelWidgetClass, 
				 boite,
				 XmNlabelString, xmstr,  				 
 				 XmNwidth,50,	
 				 XmNheight,50,
 				 XmNx,100, 				 
 				 XmNy,0, 				 
				 NULL);

xmstr = XmStringCreateSimple(" quit ");

quit = XtVaCreateManagedWidget("b6", 
                                 xmPushButtonWidgetClass, 
				 boite,
				 XmNlabelString, xmstr,  
 				 XmNwidth,50,	
 				 XmNheight,50,
 				 XmNx,100, 				 
 				 XmNy,50, 				 
				 NULL);

XtAddCallback(plus, XmNactivateCallback, modif, 1);
XtAddCallback(moins, XmNactivateCallback, modif, 2);
XtAddCallback(raz, XmNactivateCallback, modif, 3);
XtAddCallback(quit, XmNactivateCallback, quitter, NULL);
XtAddCallback(go, XmNactivateCallback, traite, NULL);

XtRealizeWidget(toplevel);

XtMainLoop();
}
