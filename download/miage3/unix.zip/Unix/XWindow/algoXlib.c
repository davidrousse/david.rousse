/************************************************************/
/* Description :															*/
/* Structure de base d'une application �crite avec la X-Lib */
/*																				*/
/*	Programme principal :												*/
/*		Initialisations                                       */
/*		Boucle de traitement des evenements                   */
/*		Terminaison                                           */
/*																				*/
/* Auteur : D.R.															*/
/* Soci�t� : MIAGe 3� ann�e, UPS, Toulouse						*/
/************************************************************/

/*	Fichiers inclus */
#include	<stdio.h>
#include	<X11/Xlib.h>
#include	<X11/Xresource.h>
#include	<X11/X.h>
#include	<X11/Xutil.h>

/*	Procedures de traitement des evenements (specifiques au client) */
/* ... */

/*	Declaration de variables globales */

/* eventuellement structure XWMHints � d�clarer */
Display		* dpy;		/* X server connection */
Window		win;			/* window id  */
GC				gc;			/* graphic context to draw with */
XEvent		event;		/* event received */
int			scrn;			/* screen */
Window		rootwindow 	/* the root window id */

/************************************************************/
/*									Initialisations 						*/
/************************************************************/

/*	Declaration de variables locales */
XFontStruct		*fontstruct;/* font descriptor */
XGCValues		gcv;			/* struct for creating GC */
XSizeHints		xsh;			/* size hints for WM for a window */
unsigned long	fg,bg,bd;	/* pixel values */
unsigned long	bw;			/* border width */

/* debut du main */
main(int argc, char *argv[])
{

/*	Connexion avec un serveur X */
dpy = XOpenDisplay((char *) NULL) ; /* n'importe ou */
/* ou		dpy = XOpenDisplay("station:0"); sur l'ecran 0 de "station" */

/* Obtention d'informations ; par exemple liees au materiel (taille ecran) */
scrn = DefaultScreen(dpy) ; 				/* le numero de l'ecran */
rootwindow = RootWindow(dpy, scrn) ; 	/* id fenetre de fond */

/*	Chargement de fonte de caracteres (indispensable des qu'il y a ecriture) */
XLoadQueryFont

/* Creation de Pixmap (pour icones par exemple) */

/* Creation de fenetre */
win = XCreateSimpleWindow(dpy,parent,x,y,width,height,
									borderwidth,borderpixel,
									backgroungpixel) ;
win = XCreateWindow(dpy,parent,x,y,width,height,
								borderwidth,depth,class, visual,
								attributemask,&attribute) ;

/* avec, pour les variables non encore rencontrees, les types suivant :
Window			parent,
int				x,y,depth;
unsigned int		width,height,borderwidth,class;
unsigned long		borderpixel,backgroungpixel,attributemask;
Visual			*visual;
XSetWindowAttributes	attribute;

XSetWMHints(dpy, win, &wmhints) ;
	ou wmhints est du type XWMHints

XSetStandardProperties

XChangeWindowAttributes */

/*	Initialisation de contexte graphique */
gc = XCreateGC(dpy, drawable, mask, &gcv) ;

/* ou drawable est un Drawable c'est a dire une fenetre ou un tab. de pixel */
/* et gcv est un XGCValues																	 */

/*	Selection des evenements desires pour chaque fenetre */
XSelectInput (dpy, win, eventmasks)

/* ou eventmasks est un long, qui est le OU de (entre autre) :
ButtonPressMask, ButtonReleaseMask, KeyPressMask, KeyReleaseMask
StructureNotifyMask, ExposureMask, MotionNotifyMask */

/*	Affichage des fenetres */
XMapWindow(dpy,xin);

/************************************************************/
/*			Boucle de lecture des evenements (exemple) 			*/
/************************************************************/
Xevent	event;
while (1)
{
	XNextEvent(dpy,&event);

   switch(event.type)
   {

		case Expose
			/* vider les autres evenements Expose */
			/* de la file d'attente */
			while (XCheckTypedEvent(...))
				/* redessiner le fenetre par la procedure client */

   		break;

	   case ButtonPress :
			/* ... */
	   	break;

	   default :
   		break;

   } /* end case */

}

/************************************************************/
/*									Terminaison								*/
/************************************************************/

/*	Liberation des contextes graphiques */
XFreeGC(dpy, gc) ;

/*	Liberation des Pixmap */
XFreePixmap

/*	Liberation des fontes de caracteres */
XFreeFont

/*	Destruction de fenetre */
XDestroySubWindow(dpy, win) ;
XDestroyWindow(dpy, win) ;

/*	Deconnexion du serveur */
XCloseDisplay(dpy);

} /* fin du main */
