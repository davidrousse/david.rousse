#include <stdio.h>

main(argc,argv)
int argc;       /* nombre d'arguments */
char **argv;    /* pointeur sur la liste des arguments */
{
int pid;        /* variable locale recuperant mon numero de pid */
 
printf("\nFILS: Debut d' execution de l' exec \n");
pid=getpid();   /* recuperation de mon numero de pid */
printf("\nFILS: PID du fils dans l' exec = %d\n",pid);
printf("\nFILS: nombre d'arguments = %d\n", argc);
printf("\nFILS: message = %s \n\n", argv[1]);
exit(3);
}
