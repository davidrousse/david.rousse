#include <stdio.h>
#include <errno.h>

extern int errno;
main()
{
int pidp,pidf,pid;
char *name,*arg,*chemin;

printf("\nPERE: debut d' execution du processus pere\n");
chemin="affiche";
name="affiche";
arg="VIVE LES VACANCES";
pidp=getpid();
printf("\nPERE: PID du pere = %d\n",pidp);

/* CREATION DU PROCESSUS FILS */
if ((pid=fork()) == -1) {
     printf("\nPERE: creation du processus impossible\n");
     exit(1);
}
/* CODE DU FILS */
if (pid == 0 ) {
        printf("\nFILS: debut d' execution du processus fils\n");
        printf("\nFILS: valeur retournee par le fork = %d\n",pid);
        pidf=getpid();
        printf("\nFILS: PID du fils avant l' exec = %d\n",pidf);
        execlp(chemin,name,arg,0);
        printf("\nLa Mer , le Soleil et la Plage ....\n");
	printf("\nNon ce n'est pas tout ca mais une erreur errno=%d \n",errno);
		exit(1);
        }

/* CODE DU PERE */
if (pid)
printf("\nPERE: valeur retournee par le fork = %d\n\n",pid);
pid = wait(0);   /* attente terminaison du fils sans compte rendu souhaite */
printf("\nPERE: PID du fils venant de se terminer = %d\n\n",pid);
exit(0);
}


