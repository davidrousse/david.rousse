/*
** source name : execlp.c
**
** author      : julius
**
** content     :
**
** subject     : faher don't do anything while its child spawns fork.
**
** creation date : XX/XX/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>

/* Local headers */

/* Macros */

/* External variables */

/* File scope variables */

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
main ()
{
int i, status = 0;

   switch ( fork () )
   {
      case -1 : /* fork failed */
                printf ("fork failed ...\n");
                status = 1;
                break;
		   
      case 0  : /* son process */
                status = execlp ("fork", "fork", "aaaa", "bbbbb", NULL);
                if (status == -1) printf ("execlp failed ...\n");
                printf ("\t\t\t\t\t\tend of son\n");
                break;
	   
      default : /* father process */
                printf ("\t\t\t\t\t\tend of father\n");
                break;

   }
   
   exit ( status );
}

/* functions */
