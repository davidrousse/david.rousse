#include <stdio.h>
#include <process.h>
#include <malloc.h>
#include <string.h>

main()
{
	/****************************************************************/
	/* TP3 : Utilisation de fork, exit, getpid, getppid, wait, exec	*/
	/****************************************************************/

	int pere, fils, res_fork; /* pid du pere, du fils et retour du fork */
	int * comment; /* circonstance de terminaison du fils */


	/* Creation du fils */
	if ((res_fork = fork()) < 0 ) { fflush(stdout) ;
					printf("\n Echec creation fils \n") ;
					exit(1) ; }
	
	if (res_fork == 0 ) { execl("tp3fils","tp3fils",0) ;
			      exit(-1) ; }

	/* traitement pere */
	comment = (int *) malloc(sizeof(int)) ;
	fils = wait(comment) ;
	pere = getpid() ;

	if ((* comment & 0xFF) == 0)
	     {  /* L'octet de plus faible poids = 0 donc fin volontaire du fils */
	        fflush(stdout) ;
		printf("\n Pere fin volontaire du fils \n") ;
		/* recuperation du compte_rendu : 2eme octet */
		* comment = * comment >> 8 ;

		if (* comment & 0x80)
		   {    /* le retour est -1 donc echec du exec */
			printf("\n pere : echec de la commutation \n") ;
			free(comment) ;
			exit(0) ;
		   }

		if ((* comment & 0xff) >0)
		    /*  le retour = position du 1er espace */
	   	    printf("\n Pere : Le rang du premier espace est %d \n", (*comment & 0xFF))
; 	 			
		
		else  /* le retour = 0 donc pas d'espace */
		      printf("\n Pere : Pas d'espace trouve \n") ;
	 
		free(comment) ;
		exit(0) ;

	     }
	fflush(stdout) ;
	printf("\n Pere : fin involontaire du fils %d \n", fils) ;
	free(comment) ;
	exit(0) ;
} 		
    		  	
   	 	
