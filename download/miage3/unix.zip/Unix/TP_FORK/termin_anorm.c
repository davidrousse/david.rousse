/*
** source name : args.c
**
** author      : julius
**
** content     :
**
** subject     : process arguments in a C proggy
**
** creation date : XX/XX/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>

/* Local headers */

/* Macros */

/* External variables */

/* File scope variables */

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
main ()
{ if (fork() == 0)

   {
      printf ("proc fils de no %d\n",getpid());
      for(;;) ;
   }
   else
   { int m,n;
      m=wait(&n); 
         printf ("fin du proc %d avec code retour %d\n",m,n);
   }
   
   }

/* functions */
