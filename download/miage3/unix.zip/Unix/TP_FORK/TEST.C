



#include <stdio.h>
#include <sys/signal.h>


int pere,fils; 

 

void trait1()
{ 
    printf("\n FILS : DEBUT trait1 ");

  /* avis de capture de la prochaine occurrence de SIGUSR1 */
  signal(SIGUSR1,trait1);
 
  printf("\n FILS : j'ai recu SIGUSR1 ");
      
  /* envoie de SIGUSR2 a pere */ 
  kill(pere,SIGUSR2); 
  return;
} 
  


void trait2()
{  
  static int tour = 0;

  /* avis de capture de la prochaine occurrence de SIGUSR2 */
  signal(SIGUSR2,trait2); 
  printf("\n PERE : j'ai recu SIGUSR2 "); 
  tour++;
  if (tour == 10)
    { 
      printf("\n PERE : envoi de SIGKILL a FILS ");

      kill(fils,SIGKILL);
      printf("\n PERE : terminaison de PERE ");
      exit(0);  
    }
  else
    { 

      printf("\n PERE : envoi de SIGUSR1 a FILS ");
      /* envoi de SIGUSR1 a fils */ 
      kill(fils,SIGUSR1);  
    }

  return;
}  


 

main()
{ 
   pere = getpid();


   /* avis d'interception de SIGUSR2 */
   signal(SIGUSR2,trait2);   

  
   if ((fils=fork()) == -1)
     {
       printf("\n echec du fork ");
       exit(1);   
     }
       

   if (fils == 0) 
     {	
       
       
       /* avis d'interception de SIGUSR1 */
       signal(SIGUSR1,trait1);  
       
       sleep(10);

        
       /* envoi de SIGUSR2 a pere */
       kill(pere,SIGUSR2);  

       while(1);
     } 
     

   while(1) ;

}


