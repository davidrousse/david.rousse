/*
** source name : Wait.c
**
** author      : julius
**
** content     :
**
** subject     : En of father before son termination.
**
** creation date : XX/XX/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>
#include <signal.h>

/* Local headers */

/* Macros */

/* External variables */

/* File scope variables */

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
main (argc, argv)
int argc;
char **argv;
{
int i, status = 0, signal = SIGCLD;
int SonPID;

   if ( argc != 2 )
   {
      printf ("give only one argument please ...\n");
      fflush (stdout);
   }
   else
   {
      switch ( (SonPID = fork ()) )
      {
         case -1 : /* fork failed */
	           printf ("fork failed ...\n");
		   status = 1;
		   break;
		   
         case 0  : /* son process */
                   for (i = 0; i != 1000; i++) 
		      printf ("%d times, arg1 : %s\n", i + 1, argv [1]);
	           printf ("\t\t\t\t\tend of son\n");
		   break;
		   
	 default : /* father process */
	           while ( wait (&signal) != SonPID);
	           printf ("\t\t\t\t\tend of father\n");
		   break;

      }
   }
   
   exit ( status );
}

/* functions */
