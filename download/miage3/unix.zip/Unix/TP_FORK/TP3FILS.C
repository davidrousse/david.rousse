#include <stdio.h>
#include <process.h>
#include <malloc.h>
#include <string.h> 

main(argv,argc)
int argc ;
char ** argv ;
{
	/****************************************************************/
	/* TP3 : Utilisation de fork, exit, getpid, getppid, wait, exec	*/
	/****************************************************************/

	int pere, fils ; /* pid du pere, du fils */


	/* variables utilisees */
	char *chaine, * schaine ; /* chaine a etudier */
	int i, cpte_rendu ; /* variables de travail */
	fils = getpid() ;
	//pere = getppid() ;
	chaine = (char *) malloc(30 * sizeof(char)) ;
	schaine = chaine ;

	fflush(stdout) ;
	printf("\n Fils pid = %d : Entrer la chaine de caractere ",fils) ;
	fflush(stdin) ;
	gets(chaine) ;
 	for (i=1 ; i <= (strlen(schaine)) ; i++)
	    { if (* chaine == ' ') { cpte_rendu = i ;
				     break ; }
	      chaine++;
	    }
	if ( i > (strlen(schaine))) cpte_rendu = 0 ;
	free(schaine) ;
	exit(cpte_rendu);
}  	 	 	 	