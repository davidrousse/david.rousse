/*
** source name : args.c
**
** author      : julius
**
** content     :
**
** subject     : process arguments in a C proggy
**
** creation date : XX/XX/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>

/* Local headers */

/* Macros */

/* External variables */

/* File scope variables */

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
main (argc, argv)
int argc;
char **argv;
{
int i;

   if ( argc != 3 )
   {
      printf ("give two arguments please ...\n");
      fflush (stdout);
   }
   else
   {
      for (i = 0; i != 100; i++) 
         printf ("%d times, arg1 : %s\n", i + 1, argv [1]);
      for (i = 0; i != 100; i++) 
         printf ("%d times, arg2 : %s\n", i + 1, argv [2]);
   }
   
   exit (0);
}

/* functions */
