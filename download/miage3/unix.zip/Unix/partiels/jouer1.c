/*****************************************************************************/
/*                      Partiel 1� session MIAGe 3� ann�e Juin 1996			  */
/*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <sys/signal.h>

/* variables globales */
struct carte
{
	char nom[15];
   int valeur;
};
struct carte jeu1[5], jeu2[5]; /* 2 jeux de cartes */

int cp; /* nombre de cartes jou�es */
int pid1, pid2;
int sc1, sc2; /* scores de pid1 et pid2 */
int tube[2];
char val; /* valeur de la carte jou�e par pid2 */

void jouer()
{
	static int i=0;

   signal(SIGUSR1,jouer);

   fflush(stdout);
   printf("\nPid2 processus %d joue : %s",pid2,jeu2[i].nom);

   val = (char)jeu2[i].valeur;
   write(tube[1],&val,sizeof(val));

   kill(pid1,SIGUSR1);

   i++;
   if(i==5)
   {
   	/* fin de pid2 */
      close(tube[1]);
      exit(0);
   }
}

void lire()
{
	signal(SIGUSR1,lire);
   return;
}
main()
{
	pid1 = getpid();

   if((pipe(tube))<0)
		exit(0);

   if((pid2=fork()) == -1)
   	exit(0);

   if(pid2 == 0)
   {
   	/* traitement fils */
      /*close(tube[0]);*/

      strcpy(jeu2[0].nom,"RC");
      strcpy(jeu2[1].nom,"DT");
      strcpy(jeu2[2].nom,"VC");
      strcpy(jeu2[3].nom,"9C");
      strcpy(jeu2[4].nom,"AP");
      jeu2[0].valeur = 13;
      jeu2[1].valeur = 12;
      jeu2[2].valeur = 11;
      jeu2[3].valeur = 9;
      jeu2[4].valeur = 1;

      pid2 = getpid();

      fflush(stdout);
      printf("\n Pid2 processus fils = %d",pid2);

      signal(SIGUSR1,jouer);
      while(1);
   } /* fin traitement fils */

   /* traitement p�re */
   /*close(tube[1]);*/

   strcpy(jeu1[0].nom,"10C");
   strcpy(jeu1[1].nom,"RP");
   strcpy(jeu1[2].nom,"6C");
   strcpy(jeu1[3].nom,"DC");
   strcpy(jeu1[4].nom,"AT");
   jeu1[0].valeur = 10;
   jeu1[1].valeur = 13;
   jeu1[2].valeur = 6;
   jeu1[3].valeur = 12;
   jeu1[4].valeur = 1;

   sc1 =0;
   sc2 = 0;

   signal(SIGUSR1,lire);

   for(cp=0;cp<5;cp++)
   {
   	fflush(stdout);
      printf("\n Pid1 processus %d joue : %s",pid1,jeu1[cp].nom);

      /* demander � pid2 de jouer */
      kill(pid2,SIGUSR1);
      pause();

      /* apr�s l'action de pid2 */
      read(tube[0],&val,sizeof(val));

      fflush(stdout);
      printf("Valeurs = %d %d",jeu1[cp].valeur,val);

      /* comparer */
      if((int)val>jeu1[cp].valeur) sc2 = sc2 + (int)val+jeu1[cp].valeur;
      if((int)val<jeu1[cp].valeur) sc1 = sc1 + (int)val+jeu1[cp].valeur;
   }

   /* resultat */
   fflush(stdout);
   if(sc1>sc2)
   	printf("\n le processus%d a gagne avec le score %d\n",pid1,sc1);
   else
   	printf("\n le processus%d a gagne avec le score %d\n",pid2,sc2);

   /* fin du jeu */
   /*close(tube[0]);*/
   exit(0);
}
