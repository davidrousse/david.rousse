/*****************************************************************************/
/*                      Partiel 1� session MIAGe 3� ann�e Juin 1997			  */
/*****************************************************************************/
#include <stdio.h>
#include <sys/signal.h>

#define TAILLE 40

/* variables globales */
int poete, poete19_1, poete19_2, poete17;
int parchemin[2];
int papyrus[2];
char aubade[10][TAILLE];

reflexion()
{
	/* r�amemaner reception de SIGUSR1 */
	signal(SIGUSR1,reflexion);
}

echo()
{
	/* r�amemaner reception de SIGUSR2 */
	signal(SIGUSR2,echo);
   /* envoie SIGUSR1 � poete19_1 */
   kill(poete19_1,SIGUSR1);
}

/* point d'entree */
main()
{
	/* declaration et initialisation */
   int i=0;

   printf("\nAvant que les poetes aient disparus ...\n");
   strcpy(aubade[0],"\nLe ciel est par dessus le toit");
   strcpy(aubade[1],"\nHeureux qui comme Ulysse");
   strcpy(aubade[2],"si bleu, si calme");
   strcpy(aubade[3],"a fait un beau voyage");
   strcpy(aubade[4],"\nUn arbre par dessus le toit");
   strcpy(aubade[5],"\nou comme cestuila");
   strcpy(aubade[6],"\nBerce sa palme");
   strcpy(aubade[7],"Qui conquit la toison");
   strcpy(aubade[8],"\n    VERLAIN");
   strcpy(aubade[9],"\n    RONSARD");

   /* pid du pere */
   poete = getpid();

   /* cre�ation de 2 pipes */
   pipe(parchemin);
   pipe(papyrus);

   /* armer reception SIGUSR2 */
   signal(SIGUSR2,echo);

   /* creation poete19_1 */
   if((poete19_1=fork()) == -1)
   {
   	exit(1);
   }
   if(poete19_1 == 0)
   {
   	/* traitement poete19_1 */
      int i=0;
      char poeme[5][TAILLE];
      printf("\n19_1Une approche de po�me du 19 siecle ...\n");

      /* lecture tube parchemin */
      for(i=0;i<5;i++)
      	read(parchemin[0],poeme[i],TAILLE);

      /* affichage donnees lues */
      for(i=0;i<2;i++)
      	printf("19_1%s\n",poeme[i]);

      /* ecriture dans papyrus de poeme[2] et poeme[3] */
      for(i=0;i<2;i++)
			write(papyrus[1],poeme[2+i],TAILLE);

		/* armer reception de SIGUSR1 */
      signal(SIGUSR1,reflexion);

      /* attendre un signal */
      pause();

      /* on regarde si contenu de poeme[4] a chang� */
      printf("19_1%s\n",poeme[4]);

      /* fin poete19_1 */
      exit(0);
   }

   /* dans le pere, ecriture dans parchemin[1] */
   for(i=0;i<10;i+=2)
		write(parchemin[1],aubade[i],TAILLE);

   /* creation poete19_2 */
   if((poete19_2=fork()) == -1)
   {
   	exit(1);
   }
   if(poete19_2 == 0)
   {
   	/* traitement poete19_2 */
      int i=0;
      char strophe[2][TAILLE];

      /* lecture tube parchemin */
      for(i=0;i<2;i++)
      	read(papyrus[0],strophe[i],TAILLE);

      /* affichage donnees lues */
      for(i=0;i<2;i++)
      	printf("19_2%s\n",strophe[i]);

		/* envoie SIGUSR2 � pere */
      kill(poete,SIGUSR2);

      /* fin poete19_1 */
      exit(0);
   }

   /* traitement pere */
   /* !!! sans attente fin de poete19_1 !!! */
   /* while(poete19_1 != (wait(0))); */

   printf("\nChangement de siecle");

   /* creation poete17 */
   if((poete17=fork()) == -1)
   {
   	exit(1);
   }
   if(poete17 == 0)
   {
   	/* traitement poete19_2 */
      int i=0;
      char strophe[5][TAILLE];

      /* lecture tube parchemin */
      for(i=0;i<4;i++)
      	read(parchemin[0],strophe[i],TAILLE);

      /* affichage donnees lues */
      for(i=0;i<4;i++)
      	printf("17%s\n",strophe[i]);

		/* envoie SIGUSR1 � pere */
      kill(poete,SIGUSR1);

      /* fin poete17 */
      exit(0);
   }

   /* traitement pere */
   /* armer reception SIGUSR1 */
   signal(SIGUSR1,reflexion);

   /* ecriture dans parchemin de aubade par pas de 2*/
   for(i=1;i<9;i+=2)
		write(parchemin[1],aubade[i],TAILLE);

   /* attente qu'un fils se termine */
   wait(0);

   /* affichage fin tableau aubade */
   printf("\npoete%s\n",aubade[9]);
   printf("\npoeteIl n'y as plus de poetes\n");
   exit(0);
}
