#include <stdio.h>
#include <signal.h>

int pipe1[2], pipe2[2], p1, p2, p3, lg, mil, i, egaux;

char chaine[20], c1, c2;

main()
  {   
  
  p1 = getpid();
  puts("Entrez une chaine");
  fgets(chaine, 19, stdin);
  
  lg  = strlen(chaine);                
  mil = lg / 2;
  
  if(!lg)
    {
    printf("Il faut entrer une chaine");
    exit(0);
    }
  
  pipe(pipe1);
  pipe(pipe2);
   
  if( (p2=fork()) == -1)
    exit(-1);

  if( p2 == 0 )
    {
    for(i=0; i < mil+1; i++)
      write(pipe1[1], chaine[i], 1);
    exit(0);
    }
  
  if( (p3=fork()) == -1 )
    exit(-1);
 
  if( p3 == 0)
    {
    for(i = lg-1; i > mil-1; i--)
      write(pipe2[1], chaine[i], 1);
    exit(0);
    }
        
  i = 0;
  do
    {
    read(pipe1[0], &c1, 1);
    read(pipe2[0], &c2, 1);
    egaux = !(c2-c1);
    i++;
    }
  while( (i<lg) && (egaux) );
  
  if ( egaux )
    printf("Cela marche");
  else 
    printf("Cela ne marche pas");
  
  exit(0);
  }
