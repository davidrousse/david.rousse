/*
** source name : cl_serv_examp.c
**
** author      : jmb
**
** content     :
**		int main ()
**
** subject     : Two file descriptions are returned - filedes[0] which is open **		for reading and filedes[1] which is open for writing.
**
** creation date : 30/11/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>

/* Local headers */

/* Macros */

/* External variables */

/* File scope variables */

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
main()
{
int 	pipefd[2], n;
char	buff[100];

	if (pipe(pipefd) < 0)
		printf("pipe error");	/* system error */

	printf("read fd = %d, write fd = %d\n", pipefd[0], pipefd[1]);
	if (write(pipefd[1], "hello world\n", 12) != 12)
		printf("write error");	/* system error */

	if ((n = read(pipefd[0], buff, sizeof(buff))) <= 0)
		printf("read error");	/* system error */
	
	write(1, buff, n);	/* fd1 = stdout */
	exit(0);
}

/* functions */