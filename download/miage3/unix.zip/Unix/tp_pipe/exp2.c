/*
** source name : cl_serv_examp.c
**
** author      : jmb
**
** content     :
**		int main ()
**		void client(int readfd, int writefd)
**		void server(int readfd, int writefd)
**
** subject     : Two file descriptions are returned - filedes[0] which is open **		for reading and filedes[1] which is open for writing.
**
** creation date : 30/11/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>

/* Local headers */
#define MAXBUFF	1024

/* Macros */

/* External variables */

/* File scope variables */

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
main()
{
int 	childpid, pipe1[2], pipe2[2];

	if (pipe(pipe1) < 0 || pipe(pipe2) < 0)
		printf("can�t create pipes");	/* system error */

	if ((childpid = fork()) < 0) {
		printf("can)t fork");	/* system error */

	} else if (childpid > 0) {	/* parent */
		close(pipe1[0]);
		close(pipe2[1]);
		client(pipe2[0], pipe1[1]);
		printf("ok\n");
		while (wait((int *) 0) != childpid);	/* wait for child */

		close(pipe1[1]);	
		close(pipe2[0]);
		exit(0);
		} else {		/* child */
			close(pipe1[1]);
			close(pipe2[0]);
	
			server(pipe1[0], pipe2[1]);

			close(pipe1[0]);
			close(pipe2[1]);
			exit(0);
			}
}

/* functions */

client(readfd, writefd)
int	readfd;
int	writefd;
{
char 	buff[MAXBUFF];
int	n;

	/* Read the filename from standard input,
	   Write it to the IPC descriptor. */

	if (fgets(buff, MAXBUFF, stdin) == NULL)
		printf("client : filename read error");	/* system error */
	n = strlen(buff);

	if (buff[n-1] == '\n')
		n--;

	if (write(writefd, buff, n) != n)
		printf("client : filename write error");/* system error */

	/* Read the data from the IPC descriptor and
	   Write to standard output. */

	while ((n = read(readfd, buff, MAXBUFF)) > 0)
		if (write(1, buff, n) != n)	/* fd1 = stdout */
			printf("client : data write error");/* system error */

	if (n < 0)
		printf("client : data read error");	/* system error */
}

server(readfd, writefd)
int	readfd;
int	writefd;
{
char 		buff[MAXBUFF];
char		errmesg[256];
int		n, fd;
extern int	errno;

	/* Read the filename from IPC descriptor. */
	if (n = read(readfd, buff, MAXBUFF) <= 0)
		printf("server : filename read error");	/* system error */
/*	buff[n] = '\0';	*/	
	if ((fd = open(buff, 0)) < 0) {
		/* Error. Format an error message and
		 send it back to the client. */

		sprintf(errmesg, "can�t open file\n");
		strcat(buff, errmesg);
		n = strlen(buff);
		if (write(writefd, buff, n) != n)
			printf("server : errmesg write error"); /*system error */		
	} else {

		/* Read the data from the file and
		   write to the IPC descriptor. */

		while ((n = read(fd, buff, MAXBUFF)) > 0)
			if (write(writefd, buff, n) != n)
				printf("server : data write error");/* system error */
		if (n<0)
			printf("server : read error");	/* system error */
		}
}
