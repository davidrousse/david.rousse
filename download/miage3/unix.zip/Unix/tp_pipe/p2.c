#include <stdio.h>

char string[] = "hello";
main()
{
char buf[1024];
char *cp1, *cp2;
int fds[2];

cp1 = string;
cp2 = buf;
while (*cp1)
*cp2++ = *cp1++;
pipe(fds);

if (fork() == 0)
for (;;)
{
	write(fds[1], buf,6);
	printf("	Processus fils %d : write completed!!!\n",getpid());
	sleep(3);
}
for (;;) 
{
	buf[0] = '\0';
	printf("Processus pere %d : buf (before read) =%s\n",getpid(),buf);
	read (fds[0], buf,6);
	printf("Processus pere %d : buf (after read) =%s\n",getpid(),buf);
}
}

