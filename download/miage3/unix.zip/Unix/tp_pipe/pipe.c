/*
** source name : pipe.c
**
** content     :
**               int main (int argc, char **argv)
**               int son ( void )
**               int father ( char *string )
**
** subject     : father writes arg into pipe, son reads it from pipe and
**               displays it on the screen.
**
** creation date : 03/02/92
**
** modifications :   date     author    subject                        code
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
                   XX/XX/XX   XXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXX   XXX
*/


/* Feature test switches */

/* System headers */
#include <stdio.h>

/* Local headers */

/* Macros */

/* External variables */
extern int errno;

/* File scope variables */
static int PipeDescriptors [2];
static int BufferSize;

/* External functions */

/* Structures and unions */

/* signal catching functions */

/* main */
int main (argc, argv)
int argc;
char **argv;
{
int status = 0;

   if (argc != 2)
   {
      printf ("give one arg please ...\n");
      exit (0);
   }
   argv++;    /* strip the pipe argument */
   BufferSize = strlen ( *argv );
   
   /* create the pipe */
   if ( pipe ( PipeDescriptors ) == -1 )
   {
      printf ("\nFailed to create the pipe in main, error number %d.", errno);
      status = 1;
   }

   if ( status == 0 )
   {
      /* create arbre_b son process : */
      switch ( fork () )
      {
         case -1 : printf ("\nfork failed in main, error number %d.", errno);
                   status = 1;
                   break;

         case 0  : /* son process, stub arbre_b : */
		   status = son ();
                   break;

         default : /* father process : */
                   status = father (*argv);
                   break;
		   
      } /* end of switch */
   } /* end of if */
   
   exit ( status );
   
} /*end of main */

/* functions */

int son ()
{
int status = 0;
char string [31];
   
   memset (string, '\0', 30);
   if ( read (PipeDescriptors [0], string, BufferSize) != BufferSize )
   {
      printf ("\nError %d reading from pipe in son.", errno);
      status = 1;
   }
   printf ("son : %s\n", string);

   close (PipeDescriptors [0]);
   return ( status );
}

int father (string)
char *string;
{
int status = 0;

   
   if ( write (PipeDescriptors [1], string, BufferSize) != BufferSize )
   {
      printf ("\nError %d writing into pipe in father.", errno);
      status = 1;
   }
   close (PipeDescriptors [1]);
		      
		   
   return ( status );
}
