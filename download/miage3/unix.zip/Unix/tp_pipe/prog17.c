#include <stdio.h>
#include <signal.h>

#define TAILLE 40

int  poete, poete19_1, poete19_2 ,poete17;
int  parchemin[2];
int  papyrus[2];
char aubade[10][TAILLE];

reflexion()
{ 
signal(SIGUSR1,reflexion);
} 

echo()
{ 
signal(SIGUSR2,echo);
kill(poete19_1,SIGUSR1);
}

main()
{
int i=0;

printf("\n Avant que les poetes aient disparus ...\n");
strcpy(aubade[0],"\nLe ciel est par dessus le toit");
strcpy(aubade[1],"\nHeureux qui comme Ulysse");
strcpy(aubade[2],"Si bleu, si calme");
strcpy(aubade[3],"A fait un beau voyage");
strcpy(aubade[4],"\nUn arbre par dessus le toit");
strcpy(aubade[5],"\nOu comme cestuila");
strcpy(aubade[6],"Berce sa palme");
strcpy(aubade[7],"Qui conquit la toison");
strcpy(aubade[8],"\n         VERLAINE");
strcpy(aubade[9],"\n         RONSARD");
poete = getpid();
pipe(parchemin);
pipe(papyrus);
signal(SIGUSR2,echo); 

if ((poete19_1=fork()) == -1)
	{
    exit(1);
	}
	if (poete19_1 == 0 ) 
		{
		int i=0;
        char poeme[5][TAILLE];
		printf("\nUne approche de poeme du 19eme ...\n");
        for ( i=0 ; i<5 ; i++ )
	        read(parchemin[0],poeme[i],TAILLE);
        for ( i=0 ; i<2 ; i++ )
	        printf("%s\n",poeme[i]);
        for ( i=0 ; i<2 ; i++ )
	        write(papyrus[1],poeme[2+i],TAILLE);
		signal(SIGUSR1,reflexion); 
        pause();
        printf("%s\n",poeme[4]);
		exit(0) ;
        }

for ( i=0 ; i<10 ; i += 2 )
	write(parchemin[1],aubade[i],TAILLE);

if ((poete19_2=fork()) == -1)
	{
    exit(1);
	}
	if (poete19_2 == 0 )
		{
        int i=0;
		char strophe[2][TAILLE];
        for ( i=0 ; i<2 ; i++ )
	        read(papyrus[0],strophe[i],TAILLE);
        for ( i=0 ; i<2 ; i++ )
	        printf("%s\n",strophe[i]);
        kill(poete,SIGUSR2);
        exit(0) ;
        }

while  ( poete19_1 != (wait(0)));

printf("\nChangement de siecle\n");


if ((poete17=fork()) == -1)
	{
    exit(1);
	}
	if (poete17 == 0 ) 
		{
        int i=0;
	char strophe[5][TAILLE];
		for ( i=0 ; i<4 ; i++ )
	        read(parchemin[0],strophe[i],TAILLE);
        for ( i=0 ; i<4 ; i++ )
	        printf("%s\n",strophe[i]);
		kill(poete,SIGUSR1);
		exit(0) ;
        }


signal(SIGUSR1,reflexion); 

for ( i=1 ; i<9 ; i += 2 )
	write(parchemin[1],aubade[i],TAILLE);
	
wait(0);

printf("\n%s\n",aubade[9]);
printf("\nIl n\'y a plus de poetes\n");
exit(0);
}
