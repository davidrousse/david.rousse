#include <stdio.h>

char string[] = "hello";
main()
{
char buf[1024];
char *cp1, *cp2;
int i,fds[2];

cp1 = string;
cp2 = buf;
while (*cp1)
*cp2++ = *cp1++;
pipe(fds);

if (fork() == 0)
{
/* Processus Fils */

printf("	Processus fils %d !!!\n",getpid());
close(1);
i=dup(fds[1]);
fprintf(stderr, "Processus pere %d : dup = %d\n",getpid(),i);
close(fds[1]);
for (;;)
{	write(1, buf,6);
	fprintf(stderr,"	Processus fils %d : write completed!!!\n",getpid());
	sleep(3);
}

}

/* Processus Pere */

close(0);
i=dup(fds[0]);
printf("Processus pere %d : dup = %d\n",getpid(),i);
close(fds[0]);
for (;;) 
{	
	buf[0] = '\0';
	printf("Processus pere %d : buf (before read) =%s\n",getpid(),buf);
	read (0, buf,6);
	printf("Processus pere %d : buf (after read) =%s\n",getpid(),buf);
}

}

