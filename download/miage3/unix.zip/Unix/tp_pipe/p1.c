#include <stdio.h>

char string[] = "hello";
main()
{
char buf[1024];
char *cp1, *cp2;
int fds[2];

cp1 = string;
cp2 = buf;
while (*cp1)
*cp2++ = *cp1++;
pipe(fds);


for (;;) /* boucle R/W */
{
write(fds[1], buf,6);
printf("	Write completed!!!\n");
sleep(3);
read (fds[0], buf,6);
printf("Read buf : %s\n",buf);
}
}

