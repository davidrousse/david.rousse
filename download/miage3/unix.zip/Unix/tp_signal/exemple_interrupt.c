#include <sys/signal.h>
main()
{

signal(SIGINT,SIG_IGN);
signal(SIGQUIT,SIG_IGN);
for(;;);

}