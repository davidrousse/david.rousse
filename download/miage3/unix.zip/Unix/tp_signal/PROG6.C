/***************************************************************************
/*                     UTILISATION DE : SIGNAL
/*                     -----------------------
/*
/*   Ce programme met en oeuvre 2 processus qui s'envoient les signaux
/*  SIGUSR1 et SIGUSR2 :
/*   -> PERE envoie a FILS SIGUSR1 
/*   -> FILS envoie a PERE SIGUSR2
/*
/*   Lorsque PERE a recu 10 occurrences de SIGUSR2, il envoie SIGKILL
/*  a FILS pour le suicider, et se termine a son tour par un EXIT.
/*
/***************************************************************************/




#include <stdio.h>
#include <sys/signal.h>

/*  VARIABLES  */   
/*  ---------- */  

/* identificateurs des processus en jeu */
int pere,fils; 

 
/* TRAITEMENT associe a SIGUSR1 */ 
/* -------------------------- */
void trait1()
{ 
    printf("\n FILS : DEBUT trait1 ");

  /* avis de capture de la prochaine occurrence de SIGUSR1 */
  signal(SIGUSR1,trait1);
 
  printf("\n FILS : j'ai recu SIGUSR1 ");
 
  /* envoie de SIGUSR2 a pere */ 
  kill(pere,SIGUSR2); 
  return;
} 
  

/* TRAITEMENT associe a SIGUSR2 */ 
/* -------------------------- */
void trait2()
{  
  static int tour = 0;
  
  /* avis de capture de la prochaine occurrence de SIGUSR2 */
  signal(SIGUSR2,trait2); 
  printf("\n PERE : j'ai recu SIGUSR2 "); 
  tour++;
  if (tour == 10)
    { 
      printf("\n PERE : envoi de SIGKILL a FILS ");
      kill(fils,SIGKILL);
      printf("\n PERE : terminaison de PERE ");
      exit(0);  
    }
  else
    { 
      
      printf("\n PERE : envoi de SIGUSR1 a FILS ");
      /* envoi de SIGUSR1 a fils */ 
      kill(fils,SIGUSR1);  
    

    }

  return;
}  


 
  
/* CODE DU PROGRAMME */
/* ------------------- */
main()
{ 
   pere = getpid();

   /* avis d'interception de SIGUSR2 */
   signal(SIGUSR2,trait2); 

   /* CREATION DU PROCESSUS FILS */
   if ((fils=fork()) == -1)
     {
       printf("\n echec du fork ");
       exit(1);   
     }
       

   /* ------------ */
   /* CODE DU FILS */  
   /* ------------ */ 

   if (fils == 0) 
     {	
      sleep (10);
       /* avis d'interception de SIGUSR1 */
       signal(SIGUSR1,trait1);  

       /* envoi de SIGUSR2 a pere */
       kill(pere,SIGUSR2);  

       while(1);
     } 
   

   /* ------------- */ 
   /* CODE DU PERE */
   /* -------------*/    
   
   while(1) ;

}


