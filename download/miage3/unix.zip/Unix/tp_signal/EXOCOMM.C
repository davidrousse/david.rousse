#include <stdio.h>  
#include <sys/file.h>
#include <signal.h> 
#include <strings.h>

#define taille 25 

/* variable temoin de la reception de SIGUSR1 */
int temoin; 

/* descripteurs de processus */
int passeprod,rep1,rep2;

/* descripteur du fichier TOTO utilise pour le transfert des produits */
FILE *toto; 

/* identificateur du fichier des produits */  
FILE *id_produits;  

/* variable de travail pour le retour des primitives appelees */
int retour,proc;   

/* variable de recuperation des produits pour les fils */
char prod[taille]; 

/* structure de donnees pour les produits */
struct produit  {  char cible[5];
                   char prod[taille]; 
                }; 
struct produit p;
  
/* traitememt associe a SIGUSR2 pour rep1 et rep2 */
void sigusr2_trait()
{    
     /* fermeture de transprod[0] */
     printf("\n %d : fin d execution ",getpid());
     exit(0);
     return; 
}


/* traitememt associe a SIGUSR1 pour passeprod */
void pere_sigusr1()
{  

   /* armement prochaine occurence */
   signal(SIGUSR1,pere_sigusr1);  

   temoin = 0;
   return; 
}
 
/* traitememt associe a SIGUSR1 pour rep1 et rep2 */
void fils_sigusr1()
{      

   /* armement prochaine occurence */
   signal(SIGUSR1,fils_sigusr1);  

   /* recuperation du produit du fichier toto */ 

      if ((toto=fopen("toto.dat","r"))==NULL)
        {
         printf("\n Erreur ouverture du fichier toto");
         exit(1);
        }
      fread(&p,sizeof(struct produit),1,toto); 
      fclose (toto); 

   printf("\n Representant = %s    Identification produit = %s",p.cible,p.prod); 
         
   /* envoi de SIGUSR1 a passeprod */
   kill(passeprod,SIGUSR1);

   return; 
}


main()
{   
printf("\, PASSEPROD : debut d execution ");  

/* initialisations */
temoin = -1;
passeprod = getpid();

/* creation du fils rep1 */
if ((rep1 = fork()) < 0)
   { 
      printf("\n PASSEPROD : Echec creation de rep1");
      exit(0);
   }
 

if (rep1 == 0)  /* on est chez rep1 */   
   {
      /* execution du travail de rep1 */   
      printf("\n REP1 : debut d execution ");
      temoin = -1;  
 
      /* armememt de l avis d interception  de SIGUSR1 */  
      signal(SIGUSR1,fils_sigusr1);
  
      /* armememt de l avis d interception  de SIGUSR2 */  
      signal(SIGUSR2,sigusr2_trait);    
      
      while(1);
   }
    

/* on est chez passeprod : creation du fils rep2 */  

if ((rep2 = fork()) == -1)
   { 
      printf("\n PASSEPROD : Echec creation de rep2");
      exit(0);
   }
  

if (rep2 == 0)  /* on est chez rep2 */   
   {
      /* execution du travail de rep2 */ 
      printf("\n REP2 : debut d execution ");
      temoin = -1;  
 
      /* armememt de l avis d interception  de SIGUSR1 */  
      signal(SIGUSR1,fils_sigusr1);
  
      /* armememt de l avis d interception  de SIGUSR2 */  
      signal(SIGUSR2,sigusr2_trait);    
      
      while(1);
   }   
       
/* on est chez passeprod */   

/* armememt de l avis d interception  de SIGUSR1 */  
signal(SIGUSR1,pere_sigusr1);  

/* ouverture du fichier produits.dat */
if ((id_produits = fopen("produits.dat","r")) == NULL) 
   {
      printf("\n PASSEPROD : echec ouverture produits ");
      exit(0);
   }

/* lecture de produits */
while (fread(&p,sizeof(struct produit),1,id_produits) > 0) 
   {   
      temoin = -1; 
      
      /* ecriture du produit dans le fichier toto*/
      if ((toto = fopen("toto.dat","w")) == NULL)
        {
         printf(" \n Erreur PERE lors de l'ouverture de toto");
         exit(1);
        }
      fwrite(&p,sizeof(struct produit),1,toto); 
      fclose (toto); 

      /* analyse du representant cible */                                      
      if (strcmp(p.cible,"rep1") == 0)
         {  printf("\n PASSEPROD : envoie a rep1 ");
            /* produit destine a rep1 */  
            kill(rep1,SIGUSR1);  
         }
      else 
         {
            printf("\n PASSEPROD : envoie a rep2 ");
            /* produit destine a rep2 */  
            kill(rep2,SIGUSR1);       
          }
      
      /* on attend que le fils ait recupere le produit */
      while (temoin == -1) pause();  
   }

printf("\n PASSEPROD : fin de produits ");     
/* fermeture de produits */
fclose(id_produits);

/* envoi de SIGUSR2 aux fils */
kill(rep1,SIGUSR2);
kill(rep2,SIGUSR2);  
exit(0);
 

}






                                       
