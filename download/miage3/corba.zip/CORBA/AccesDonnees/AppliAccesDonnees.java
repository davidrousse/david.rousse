package accesdonnees;
import java.util.*;
import java.sql.*;

/**
 * Title:        Acc�s � une base de donn�es relationnelle
 * Description:  Acc�s � des donn�es via JDBC
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MIAGistes
 * @version 1.0
 */

import java.util.*;

public class AppliAccesDonnees {

  /* choisir une des 3 lignes pour lancer la demo ... */
  static String DEBUG ="STATEMENT";
  //static String DEBUG ="PREPAREDSTATEMENT";
  //static String DEBUG ="CALLABLESTATEMENT";

  public static void main (String args[]) {
    try { // Charger le driver jdbc-odbc bridge
          Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
          // Connexion au driver (fournir la source odbc, utilisateur, mot de passe)
          AccesDonnees.con = DriverManager.getConnection ("jdbc:odbc:pubs");

          // ici, on est connect�, sinon on a g�n�r� une exception

          if(DEBUG.equals("STATEMENT")) {
          // ************ STATEMENT  ************
          // Cr�er la table BANQUE
          System.out.println(AccesDonnees.ExecDML("drop table BANQUE"));
          System.out.println(AccesDonnees.ExecDML("create table BANQUE(NOM_COMPTE CHAR(20), MONTANT Integer)"));
          System.out.println(AccesDonnees.ExecDML("Select * from BANQUE"));

          //insertions
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('monia' , 100)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('dominica' , 200)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('c�cile' , 300)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('audrey' , 400)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('claire' , 500)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('baba' , 600)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('david' , 700)"));

          //resultat
          System.out.println(AccesDonnees.ExecSelect("Select * from BANQUE"));

          //update
          System.out.println(AccesDonnees.ExecDML("update BANQUE set MONTANT= 200 where NOM_COMPTE='monia'"));
          System.out.println(AccesDonnees.ExecSelect("Select * from BANQUE"));

          //delete
          System.out.println(AccesDonnees.ExecDML("delete from BANQUE where MONTANT > 300"));
          System.out.println(AccesDonnees.ExecSelect("Select * from BANQUE"));

          //ferme l'instance Statement
          AccesDonnees.requeteSimple.close();
          } // ************ fin cas STATEMENT  ************


          if(DEBUG.equals("PREPAREDSTATEMENT")) {
          // ************ PREPAREDSTATEMENT  ************
          Vector param = new Vector();
          Vector paramType = new Vector();
          param.addElement("200");
          paramType.addElement("INT");

          System.out.println(AccesDonnees.ExecDML("drop table BANQUE"));
          System.out.println(AccesDonnees.ExecDML("create table BANQUE(NOM_COMPTE CHAR(20), MONTANT Integer)"));
          System.out.println(AccesDonnees.ExecDML("Select * from BANQUE"));

          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('monia' , 100)"));
          System.out.println(AccesDonnees.ExecDML("insert into BANQUE values ('dominica' , 200)"));

          System.out.println(AccesDonnees.ExecRequeteParam("Select * from BANQUE where montant = ?",param,paramType));

          AccesDonnees.requeteParam.close();
          }// ************ fin cas PREPAREDSTATEMENT  ************


          if(DEBUG.equals("CALLABLESTATEMENT")) {
          // ************ CALLABLESTATEMENT  ***********
          // Cr�er la table BANQUE
          System.out.println(AccesDonnees.ExecProcStoc("sp_testCreate"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testSelect"));

          //insertions
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'monia' , 100"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'dominica' , 200"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'c�cile' , 300"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'audrey' , 400"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'claire' , 500"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'baba' , 600"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert 'david' , 700"));

          //resultat
          System.out.println(AccesDonnees.ExecProcStoc("sp_testSelect"));

          //insertions en mode batch
          Vector param = new Vector();
          Vector paramType = new Vector();
          param.addElement("toto1");
          paramType.addElement("STRING");
          param.addElement("1000");
          paramType.addElement("INT");

          param.addElement("toto2");
          paramType.addElement("STRING");
          param.addElement("2000");
          paramType.addElement("INT");

          param.addElement("toto3");
          paramType.addElement("STRING");
          param.addElement("3000");
          paramType.addElement("INT");

          System.out.println(AccesDonnees.ExecProcStoc("sp_testInsert2(?,?)",param, paramType, 2));

          //update
          System.out.println(AccesDonnees.ExecProcStoc("sp_testUpdate 'monia', 200"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testSelect"));

          //delete
          System.out.println(AccesDonnees.ExecProcStoc("sp_testDelete 300"));
          System.out.println(AccesDonnees.ExecProcStoc("sp_testSelect"));

          AccesDonnees.requeteProcSto.close();
          }// ************ fin cas CALLABLESTATEMENT  ************

          // Close the connection
          AccesDonnees.con.close();

     }
     catch (SQLException e) {AccesDonnees.PrintSQLError(e);}
     catch (Exception e   ) {e.printStackTrace ();}
  }
}

