package accesdonnees;

/**
 * Title:        Acc�s � une base de donn�es relations
 * Description:  Acc�s � des donn�es via JDBC
 * Copyright:    Copyright (c) 2001
 * Company:      MIAGe
 * @author MIAGistes
 * @version 1.0
 */


import java.net.URL;
import java.sql.*;
import java.util.*;
import java.lang.Runtime;
import java.lang.*;

public class AccesDonnees {

public static String query;
public static Connection con;
public static Statement  requeteSimple;
public static PreparedStatement  requeteParam;
public static CallableStatement  requeteProcSto;
public static ResultSet  results;


public static String ExecDML(String sqlText) {

/* permet d'executer une commande de manipulation des donnees
   - insert, delete, update
   ou de manipulation du schema
   - create, drop, ...
*/
  int resultCode;

  try {
       requeteSimple = con.createStatement();
       resultCode = requeteSimple.executeUpdate(sqlText);
       return ("OK ("+resultCode+"): "+sqlText);
  }
  catch (SQLException e) {
       return "** Erreur dans: "+sqlText+"\n"+e.toString();
  }
  catch (Exception e) {
       return ( "** Erreur dans: "+sqlText);
  }
}

public static String ExecSelect(String sqlText) {
/* permet d'executer une selection
   - select ... from ... where ...
   et d'afficher le resultat
*/
  try {
      requeteSimple = con.createStatement();
      results = requeteSimple.executeQuery( sqlText );
      PrintResults( results );
      return ("OK: "+sqlText);
  }
  catch (SQLException e) {
       return "** Erreur dans: "+sqlText+"\n"+e.toString();
  }
  catch (Exception e) {
       return ( "** Erreur dans: "+sqlText);
  }
}

public static String ExecRequeteParam(String sqlText, Vector parametres, Vector parametresType) {
// permet d'executer une selection
//   - select ... from ... where ...
//  et d'afficher le resultat

  int nbTuples=0,i=0;
  String paramType;

  try {
      requeteParam = con.prepareStatement(sqlText);

      if(parametres.size()!=parametresType.size())
        return "-1";

      for(i=0;i<parametres.size();i++)
      {
        paramType = (String)parametresType.elementAt(i);
        if(paramType=="STRING")
            requeteParam.setString(i+1,(parametres.elementAt(i)).toString());
        if(paramType=="INT")
            requeteParam.setInt(i+1,new Integer((String)parametres.elementAt(i)).intValue());
        if(paramType=="TIME")
            requeteParam.setTime(i+1,(Time)parametres.elementAt(i));
        if(paramType=="FLOAT")
            requeteParam.setFloat(i+1,new Float((String)parametres.elementAt(i)).floatValue());
      }

      results = requeteParam.executeQuery();
      PrintResults( results );

      return ("OK: "+sqlText);
  }
  catch (SQLException e) {
       return "** Erreur dans: "+sqlText+"\n"+e.toString();
  }
  catch (Exception e) {
       return ( "** Erreur dans: "+sqlText);
  }
}

public static String ExecProcStoc(String sqlText) {
/* permet d'executer une procedure stockee qui ne renvoie pas de tuples
*/
  try {
      requeteProcSto = con.prepareCall(sqlText);
      requeteProcSto.execute();
      return ("OK: "+sqlText);
  }
  catch (SQLException e) {
       return "** Erreur dans: "+sqlText+"\n"+e.toString();
  }
  catch (Exception e) {
       return ( "** Erreur dans: "+sqlText);
  }
}

public static String ExecProcStoc(String sqlText,
              Vector parametres, Vector parametresType, int nbParam) {
/* permet d'executer une procedure stockee qui est parametr�e
*/
  int nbTuples=0,i=0,numParam;
  String paramType;

  try {
      requeteProcSto = con.prepareCall("{call "+sqlText+"}");

      if(parametres.size()!=parametresType.size())
        return "-1";

      for(i=0;i<parametres.size();i=i+nbParam)
      {
        //enregistrement du ieme batch
        for(numParam=0;numParam<nbParam;numParam++) {
          //fixation des parametres du ieme batch
          paramType = (String)parametresType.elementAt(i+numParam);
          if(paramType=="STRING")
              requeteProcSto.setString(numParam+1,(parametres.elementAt(i+numParam)).toString());
          if(paramType=="INT")
              requeteProcSto.setInt(numParam+1,(new Integer((String)parametres.elementAt(i+numParam))).intValue());
          if(paramType=="TIME")
              requeteProcSto.setTime(numParam+1,(Time)parametres.elementAt(i+numParam));
          if(paramType=="FLOAT")
              requeteProcSto.setFloat(numParam+1,new Float((String)parametres.elementAt(i+numParam)).floatValue());
        }
        nbTuples = nbTuples + requeteProcSto.executeUpdate();
      }

      return ("OK: "+sqlText+" - Nombre d'instructions batch trait�es: "+nbTuples);
  }
  catch (SQLException e) {
       return "** Erreur dans: "+sqlText+"\n"+e.toString();
  }
  catch (Exception e) {
       return ( "** Erreur dans: "+sqlText);
  }
}

public static void PrintResults( ResultSet results )
  throws SQLException
     {int     i;
      int     nbLigne=0; // nbre de lignes du resultat
      int     nbCol; // nbre de colonnes du resultat
      boolean pasfini= results.next (); // indique qu'il a encore des donn�es

      // recupere le schema du resultat (nom des colonnes, type, ...)
      ResultSetMetaData resultSchema = results.getMetaData ();
      nbCol= resultSchema.getColumnCount (); //nbre de colonnes du resultat

      // affiche les entetes des colonnes
      System.out.println();
      for (i=1; i<=nbCol; i++)
        {System.out.print(resultSchema.getColumnLabel(i));
         System.out.print("|"); // s�parateur de colonne
        }
      System.out.println();

      // affiche les donn�es ligne par ligne
      while (pasfini)
        { for (i=1; i<=nbCol; i++) // pour chaque colonne
            { System.out.print(results.getString(i));
              System.out.print("|");
            }
          System.out.println("");
          nbLigne++;
          pasfini = results.next (); //prochaine ligne
        }
      System.out.println(nbLigne+" lignes trouvees par la requete");
}

public static void PrintSQLError(SQLException ex) {
   System.out.println ("**ERREUR SQLException\n");
   while (ex != null)
      { System.out.println ("Etat   : " +ex.getSQLState ());
        System.out.println ("Message: " +ex.getMessage ());
        System.out.println ("Fournis: " +ex.getErrorCode ());
        ex = ex.getNextException ();
        System.out.println ();
     }
  }
}
