/* package projetw - TP4 - CM et DR - MIAGe3 */
CREATE OR REPLACE PACKAGE projetw AS
pNChercheur2 VARCHAR2(255);
pNProjet2 VARCHAR2(255);
pNEquipe2 VARCHAR2(255);
pNomChercheur2 VARCHAR2(255);
PROCEDURE saisie_proj(num_proj IN VARCHAR2 DEFAULT NULL);
procedure affich_source(nom_proc IN VARCHAR2 DEFAULT NULL);
procedure ajout_proj(pNProjet IN VARCHAR2 DEFAULT NULL,
		pNomProjet IN VARCHAR2 DEFAULT NULL,
		pNEquipe IN VARCHAR2 DEFAULT NULL,
		pNCherResp IN VARCHAR2 DEFAULT NULL,
		pSpecialite IN VARCHAR2 DEFAULT NULL);
procedure fin_proj(num_proj IN VARCHAR2 DEFAULT NULL);
procedure choix_equipe(num_equ IN VARCHAR2 DEFAULT NULL);
procedure ajout_chercheur(	pNChercheur IN VARCHAR2 DEFAULT NULL, 
			pNomChercheur IN VARCHAR2 DEFAULT NULL, 
			pSpecialite IN VARCHAR2 DEFAULT NULL, 
			pUniversite IN VARCHAR2 DEFAULT NULL, 
			Equipe IN VARCHAR2 DEFAULT NULL); 
procedure affich_proj(pNChercheur IN VARCHAR2 DEFAULT NULL);
procedure affich_prj_equipe(pNEquipe IN VARCHAR2 DEFAULT NULL,
			pNChercheur IN VARCHAR2 DEFAULT NULL, 
			pNomChercheur IN VARCHAR2 DEFAULT NULL);
procedure affecte_proj(pNChercheur IN VARCHAR2 DEFAULT NULL,
		       pNProjet IN VARCHAR2 DEFAULT NULL,
		       pNbJourSem IN VARCHAR2 DEFAULT NULL,
		       pNEquipe IN VARCHAR2 DEFAULT NULL,
		       pNomChercheur IN VARCHAR2 DEFAULT NULL);

END projetw;
/
show errors;

CREATE OR REPLACE package body projetw as

/* fonction priv�e controle_resp */
function controle_resp(pNEquipe IN VARCHAR2 DEFAULT NULL,
                       pNChercheur IN VARCHAR2 DEFAULT NULL)
 return boolean

is

retour boolean;
equipeChercheur VARCHAR2(30);
begin
	select n_equipe into equipeChercheur
	from chercheur
	where n_chercheur = pNChercheur;

	/* on compare le parametre � la donn�e lue */
	if (pNEquipe != equipeChercheur) then
		retour:=false;
	else
		retour:=true;
	end if;

	return(retour);

end controle_resp;

/* fonction priv�e controle_nb_chercheur */
function controle_nb_chercheur(pNEquipe IN VARCHAR2 DEFAULT NULL,
                               pSpecialite IN VARCHAR2 DEFAULT NULL)
 return boolean

is

retour boolean;
nb integer;

begin
	select count(*) into nb
	from chercheur
	where n_equipe = pNEquipe
	and specialite = pSpecialite;

	/* on verifie que l'on a au moins un chercheur competent */
	if (nb>0) then
		retour:=true;
	else
		retour:=false;
	end if;

	return(retour);

end controle_nb_chercheur;

/* fonction priv�e chercheur_projet */
function chercheur_projet(pNProjet IN VARCHAR2 DEFAULT NULL)
 return boolean 

is

retour boolean;
nb integer;

begin
	select count(*) into nb
	from travailler
	where n_projet = pNProjet;

	/* on verifie que l'on a au moins un chercheur affect� */
	if (nb>0) then
		retour:=true;
	else
		retour:=false;
	end if;

	return(retour);

end chercheur_projet;

-- procedure privee affich_ins
procedure affich_ins(num_proj IN VARCHAR2 DEFAULT NULL)
is

CURSOR cur_proj IS SELECT c.nom_chercheur,c.specialite,c.universite, t.nb_jour_sem
FROM CHERCHEUR c, TRAVAILLER t
WHERE C.n_chercheur=t.n_chercheur
and t.n_projet=num_proj;

nb INTEGER;
nom_p PROJET.nom_projet%type;
nom_e EQUIPE.nom_equipe%type;
nom_c CHERCHEUR.nom_chercheur%type;
n_cher_r PROJET.n_cher_resp%type;
n_equipe_p PROJET.n_equipe%type;
n_cher_resp_p PROJET.n_cher_resp%type;

mauvais_num_projet exception;
non_trouve exception;

begin
	select count(*) into nb from PROJET where n_projet= num_proj;

	if (nb!=1) then
		raise mauvais_num_projet;
	end if;

	select nom_projet, n_equipe, n_cher_resp into nom_p, n_equipe_p, n_cher_resp_p 
	from PROJET 
	where n_projet= num_proj; 

	select nom_equipe into nom_e 
	from EQUIPE
	where n_equipe = n_equipe_p;

	if(n_cher_resp_p is not null) then
		select nom_chercheur into nom_c 
		from CHERCHEUR
		where n_chercheur = n_cher_resp_p;
	end if;
	
	select n_cher_resp into n_cher_r from PROJET
	where n_projet= num_proj;
	
	htp.line;
	
	htp.tableOpen('border');
	htp.tableCaption('Caracteristiques du projet','CENTER');
	htp.tableRowOpen;
		htp.tableHeader('Nom du projet');
		htp.tableHeader('Nom de l''equipe');
		htp.tableHeader('Nom du chercheur responsable');
	htp.tableRowClose;
	htp.tableRowOpen;
		htp.tableData(nom_p);
		htp.tableData(nom_e);
		If nom_c is not null then
			htp.tableData(nom_c);
		else
			htp.tableData('Non connu');
		end if;
	htp.tableRowClose;
	htp.tableClose;
	
	htp.line;

	if n_cher_resp_p is null then
		raise non_trouve;
	end if;

	htp.tableOpen('border');
	htp.tableCaption('Liste des chercheurs affectes au projet','CENTER');
	htp.tableRowOpen;
		htp.tableHeader('Nom du chercheur');
		htp.tableHeader('Specialite');
		htp.tableHeader('Universite');
		htp.tableHeader('Nombre de jours');
	htp.tableRowClose;

	FOR cur_proj_rec IN cur_proj LOOP
		htp.tableRowOpen;
			htp.tableData(cur_proj_rec.nom_chercheur);
			htp.tableData(cur_proj_rec.specialite);
			htp.tableData(cur_proj_rec.universite);
			IF cur_proj_rec.nb_jour_sem IS NOT NULL THEN
				htp.tableData(cur_proj_rec.nb_jour_sem);
			ELSE
				htp.tableData('Non connu');
			END IF;
		htp.tableRowClose;
	END LOOP;

	htp.tableClose;
	htp.line;

exception
when mauvais_num_projet then
	htp.line;
	htp.print('N� de projet inconnu.');
when non_trouve then
	htp.line;
	htp.print('Aucun chercheur n''est encore affecte a ce projet');
when others then
	htp.print(SQLCODE||' : '||SQLERRM);
end affich_ins;


/* proc�dure priv�e affich_proj */
procedure affich_proj(pNChercheur IN VARCHAR2 DEFAULT NULL)
is

CURSOR cprojet is 
	select P.N_PROJET, P.NOM_PROJET, T.NB_JOUR_SEM, C.NOM_CHERCHEUR
	from CHERCHEUR C, PROJET P, TRAVAILLER T
	where T.N_CHERCHEUR=pNChercheur
	and T.N_PROJET=P.N_PROJET
	and C.N_CHERCHEUR=P.N_CHER_RESP;

nom_ch CHERCHEUR.NOM_CHERCHEUR%TYPE;
lien varchar2(255);
num_equip varchar(255);

begin

	select nom_chercheur, n_equipe into nom_ch, num_equip from chercheur where n_chercheur = pNChercheur;

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/applipl/mg3g7.projetw.choix_equipe?num_equ='||num_equip,'Retour');
	htp.print(lien);
	htp.hr;

	htp.formOpen('mg3g7.projetw.affich_proj');
	htp.p('<font size=3>');
	htp.header(1, 'Projet(s) de '||nom_ch,'CENTER');

	htp.line;
	htp.tableOpen('border');

	htp.tableRowOpen;
		htp.tableHeader('Num projet');
		htp.tableHeader('Nom projet');
		htp.tableHeader('Nombre de jours');
		htp.tableHeader('Responsable');
	htp.tableRowClose;
	
	htp.tableCaption('Activite(s)','CENTER');

	For cprojet_rec in cprojet loop
		htp.tableRowOpen;
			htp.tableData(cprojet_rec.N_PROJET);
			htp.tableData(cprojet_rec.NOM_PROJET);
			htp.tableData(cprojet_rec.NB_JOUR_SEM);
			htp.tableData(cprojet_rec.NOM_CHERCHEUR);
		htp.tableRowClose;
	end loop;
	htp.tableClose;

	htp.formClose;
	htp.bodyClose;

exception
when others then
	htp.line;
	htp.print(SQLCODE||' : '||SQLERRM);

end affich_proj;

/* proc�dure publique affecte_proj */
procedure affecte_proj(pNChercheur IN VARCHAR2 DEFAULT NULL,
		       pNProjet IN VARCHAR2 DEFAULT NULL,
		       pNbJourSem IN VARCHAR2 DEFAULT NULL,
		       pNEquipe IN VARCHAR2 DEFAULT NULL,
		       pNomChercheur IN VARCHAR2 DEFAULT NULL)

is

nom_ch CHERCHEUR.NOM_CHERCHEUR%TYPE;
num_univ CHERCHEUR.UNIVERSITE%TYPE;
nom_prj PROJET.NOM_PROJET%TYPE;
num_equipe VARCHAR(255);
num_chercheur VARCHAR(255); 
lien VARCHAR2(255);
nb integer;
dup_val_on_travailler exception;

begin

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/applipl/mg3g7.projetw.ajout_chercheur','Retour');
	htp.print(lien);
	htp.hr;

	htp.formOpen('mg3g7.projetw.affecte_proj');
	htp.p('<font size=3>');

	if pNChercheur is not null and pNProjet is not null then
		pNChercheur2:=pNChercheur;
		pNProjet2:=pNProjet;
		pNEquipe2:=pNEquipe;
		pNChercheur2:=pNChercheur;
		pNomChercheur2:=pNomChercheur;
	end if;
		
	/* on verifie que la cl� n_chercheur-n_projet n existe pas */
	select count(*) into nb from travailler 
	where n_chercheur = pNChercheur2
	and n_projet = pNProjet2;
	htp.br;

	if nb>0 then
		raise dup_val_on_travailler;
	end if;

	select nom_chercheur,universite into nom_ch, num_univ from chercheur where n_chercheur = pNChercheur2;
	select nom_projet into nom_prj from projet where n_projet = pNProjet2;

	htp.header(1, 'Affectation du chercheur '||nom_ch||' au projet '||nom_prj,'CENTER');

	htp.line;
	
	if pNbJourSem is not null then
		/* insertion dans travailler */
		/* v�rification de l universit� du chercheur */
		if(num_univ = '2') then
			/* insertion sur salines */
			insert into travailler_s@base_sal
			values(pNProjet2,pNChercheur2,pNbJourSem);		
			
		else
			/* insertion sur lagune */
			insert into travailler_l@base_lag
			values(pNProjet2,pNChercheur2,pNbJourSem);
		end if;
		htp.br;
		htp.print('<B>Enregistrement du chercheur '||nom_ch||' dans TRAVAILLER</B>'); 		

		/* commint de la transaction */
		commit;
		htp.br;
		htp.print('<B><I>Transaction reussie</I></B>'); 
		htp.br;

		/* liens de navigation */
		/* page precedente */
		htp.hr;
		lien:=htf.anchor('mg3g7.projetw.affich_prj_equipe?pNEquipe='||pNEquipe2||'&'||'pNChercheur='||pNChercheur2||'&'||'pNomChercheur='||pNomChercheur2,'Continuer');		
		htp.print(lien);

	else
		htp.print('Entrer le nombre de jours de travail :');
		htp.formText('pNbJourSem');
		htp.br;
		htp.br;
		htp.formSubmit(cvalue=>'Executer');
		htp.formReset(cvalue=>'Annuler');
	end if;

	htp.formClose;
	htp.bodyClose;

exception
when dup_val_on_travailler then
	htp.line;
	htp.br;
	htp.print('<B><I>La cle existe deja dans TRAVAILLER. Affectation impossible.</I></B>');
	htp.br;

	/* liens de navigation */
	/* page precedente */
	htp.hr;
	lien:=htf.anchor('mg3g7.projetw.affich_prj_equipe?pNEquipe='||pNEquipe2||'&'||'pNChercheur='||pNChercheur2||'&'||'pNomChercheur='||pNomChercheur2,'Continuer');		
	htp.print(lien);

when others then
	htp.line;
	htp.print(SQLCODE||' : '||SQLERRM);
	/* liens de navigation */
	/* page precedente */
	htp.hr;
	lien:=htf.anchor('mg3g7.projetw.affich_prj_equipe?pNEquipe='||pNEquipe2||'&'||'pNChercheur='||pNChercheur2||'&'||'pNomChercheur='||pNomChercheur2,'Continuer');		
	htp.print(lien);

end affecte_proj;


/* proc�dure priv�e affich_equipe */
procedure affich_equipe(pNEquipe IN VARCHAR2 DEFAULT NULL)
is

CURSOR cequipe is 
	select C.N_CHERCHEUR, C.NOM_CHERCHEUR, C.SPECIALITE, C.UNIVERSITE
	from EQUIPE E, CHERCHEUR C
	where E.N_EQUIPE=C.N_EQUIPE
	and E.N_EQUIPE=pNEquipe;

nom_equ EQUIPE.NOM_EQUIPE%TYPE;

texte VARCHAR2(255);
num_ch VARCHAR2(255);

begin

	select NOM_EQUIPE into nom_equ from EQUIPE where N_EQUIPE=pNEquipe;

	htp.line;
	htp.tableOpen('border');
	htp.tableCaption('Equipe: ' ||' '||nom_equ,'CENTER');
	htp.tableRowOpen;
		htp.tableHeader('N� chercheur');
		htp.tableHeader('Nom chercheur');
		htp.tableHeader('Specialite');
		htp.tableHeader('Universite');
	htp.tableRowClose;
	For cequipe_rec in cequipe loop

		htp.tableRowOpen;
			htp.tableData(cequipe_rec.N_CHERCHEUR);
			num_ch:=cequipe_rec.N_CHERCHEUR;
			texte:=htf.anchor('mg3g7.projetw.affich_proj?pNChercheur='||num_ch, cequipe_rec.NOM_CHERCHEUR);
			htp.tableData(texte);
			htp.tableData(cequipe_rec.SPECIALITE);
			htp.tableData(cequipe_rec.UNIVERSITE);
		htp.tableRowClose;
	end loop;
	htp.tableClose;

end affich_equipe;


/* proc�dure publique affich_prj_equipe */
procedure affich_prj_equipe(pNEquipe IN VARCHAR2 DEFAULT NULL,
			pNChercheur IN VARCHAR2 DEFAULT NULL, 
			pNomChercheur IN VARCHAR2 DEFAULT NULL)
is

CURSOR cprojet is 
	select P.N_PROJET, P.NOM_PROJET 
	from PROJET P
	where P.N_EQUIPE = pNEquipe;

nom_equ EQUIPE.NOM_EQUIPE%TYPE;
texte VARCHAR(255);
num_ch varchar2(255);
num_prj varchar2(255);
num_e varchar2(255);
nom_chercheur varchar2(255);
lien varchar2(255);

begin

	select NOM_EQUIPE into nom_equ from EQUIPE where N_EQUIPE=pNEquipe;

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/applipl/mg3g7.projetw.ajout_chercheur','Retour');
	htp.print(lien);
	htp.hr;

	htp.formOpen('mg3g7.projetw.affich_prj_equipe');
	htp.p('<font size=3>');
	htp.header(1, 'Projet(s) associe(s) a l''equipe '||nom_equ,'CENTER');
	htp.line;

	num_ch:=pNChercheur;
	nom_chercheur:=pNomChercheur;
	num_e:=pNEquipe;

	htp.tableOpen('border');
	htp.tableCaption('Affectation du chercheur '||pNomChercheur||' ('||pNChercheur||')','CENTER');
	htp.tableRowOpen;
		htp.tableHeader('Num projet');
		htp.tableHeader('Nom projet');
		htp.tableHeader('Decision d''affectation');
	htp.tableRowClose;

	for cprojet_rec in cprojet loop

		htp.tableRowOpen;
			htp.tableData(cprojet_rec.N_PROJET);
			htp.tableData(cprojet_rec.NOM_PROJET);
			num_prj:=cprojet_rec.N_PROJET;
			texte:=htf.anchor('mg3g7.projetw.affecte_proj?pNChercheur='||num_ch||'&'||'pNProjet='||num_prj||'&'||'pNEquipe='||num_e||'&'||'pNomChercheur='||nom_chercheur, 'Affecter '||pNChercheur||' a '||cprojet_rec.NOM_PROJET);
			htp.tableData(texte);
		htp.tableRowClose;

	end loop;
	htp.tableClose;

	htp.formClose;

end affich_prj_equipe;


/* procedure publique saisie_proj */
procedure saisie_proj(num_proj IN VARCHAR2 DEFAULT NULL) IS
CURSOR cnumproj IS SELECT n_projet, nom_projet FROM projet order by nom_projet;
message varchar2(200);
lien VARCHAR2(255);

begin

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Retour');
	htp.print(lien);
	htp.hr;

	htp.header(1,'Informations sur un projet','CENTER');
	htp.hr;
	htp.formOpen('mg3g7.projetw.saisie_proj');
	htp.p('<font size=3>');

	htp.formSelectOpen('num_proj', 'Choix d''un projet : ');
	htp.line;
	for recp in cnumproj LOOP
		htp.formSelectOption(recp.nom_projet,cattributes=>'VALUE='||recp.n_projet);
	end loop;
	htp.formSelectClose;

	htp.p('<font size=4>');
	htp.br;
	htp.br;
	htp.formSubmit(cvalue=>'Executer');
	htp.formReset(cvalue=>'Annuler');
	htp.formClose;

	htp.hr;
	if num_proj is not null then
		affich_ins(num_proj);
	else
		htp.print('Veuillez choisir un numero de projet ...');
	end if;

	htp.bodyClose;

end saisie_proj;

/* procedure publique affich_source */
procedure affich_source(nom_proc IN VARCHAR2 DEFAULT NULL) is
lien VARCHAR2(255);
begin

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Retour');
	htp.print(lien);
	htp.hr;

	htp.header(1,'Informations sur les auteurs','CENTER');
	htp.hr;

	htp.print('Pour toutes informations sur les programmes, vous pouvez ecrire a :');
	htp.line;
	htp.address(htf.anchor('mailto:meda@archipel.siera.ups-tlse.fr','Carole MEDA'));
	htp.address(htf.anchor('mailto:d.rousse@wanadoo.fr','David ROUSSE'));
	htp.line;

	htp.formOpen('mg3g7.projetw.affich_source');
	htp.p('<font size=3>');
	htp.print('Entrez le nom d''un package :');
	htp.formText('nom_proc');
	
	htp.p('<font size=4>');

	htp.formSubmit(cvalue=>'Executer');
	htp.formReset(cvalue=>'Annuler');
	if nom_proc is not null then
		owa_util.signature(nom_proc);
		owa_util.showsource(nom_proc);
	end if;
	htp.formClose;
	htp.line;
	owa_util.print_cgi_env;
	htp.bodyClose;

end affich_source;

/* proc�dure publique pour ajouter un projet */
procedure ajout_proj(	pNProjet IN VARCHAR2 DEFAULT NULL, 
			pNomProjet IN VARCHAR2 DEFAULT NULL, 
			pNEquipe IN VARCHAR2 DEFAULT NULL, 
			pNCherResp IN VARCHAR2 DEFAULT NULL, 
			pSpecialite IN VARCHAR2 DEFAULT NULL) IS 


cursor cur_chercheur is
select n_chercheur, nom_chercheur, universite 
from chercheur 
where n_equipe = pNEquipe;

nb integer;
message varchar2(100);
lien VARCHAR2(255);
mauvais_num_equipe exception;
mauvais_num_projet exception;
mauvais_chercheur_resp_equipe exception;
mauvais_chercheur_specialite exception;

begin

	/* formulaire */
	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Retour');
	htp.print(lien);
	htp.hr;

	htp.formOpen('mg3g7.projetw.ajout_proj');
	htp.p('<font size=3>');
	htp.header(1, 'Ajout d''un nouveau projet','CENTER');
	htp.print('Entrer le numero de projet: ');
	htp.formText('pNProjet');
	htp.br;
	htp.br;
	htp.print('Entrer le nom de projet: ');
	htp.formText('pNomProjet');
	htp.br;
	htp.br;
	htp.print('Entrer le numero de l''equipe qui obtient le contrat: ');
	htp.formText('pNEquipe');
	htp.br;
	htp.br;
	htp.print('Entrer le numero du chercheur responsable: ');
	htp.formText('pNCherResp');
	htp.br;
	htp.br;
	htp.print('Entrer la specialite requise: ');
	htp.formText('pSpecialite');
	htp.br;
	htp.br;
	htp.p('<font size=4>');
	htp.formSubmit(cvalue=>'Executer');
	htp.formReset(cvalue=>'Annuler');
	

	IF pNProjet IS NOT NULL and pNomProjet IS NOT NULL and pNEquipe IS NOT NULL and pNCherResp IS NOT NULL and pSpecialite IS NOT NULL THEN
 
/* v�rification equipe */
	select count(*) into nb from equipe where n_equipe = pNEquipe;
	if (nb!=1) then 
		raise mauvais_num_equipe;		
	end if;

/* v�rification projet */
	select count(*) into nb from projet where n_projet = pNProjet;
	if (nb=1) then 
		raise mauvais_num_projet;		
	end if;

/* v�rification  que chercheur responsable appartient � l �quipe */
	if not controle_resp(pNEquipe,pNCherResp) then
		raise mauvais_chercheur_resp_equipe;
	end if;

/* v�rification au moins un chercheur avec specialite */
	if not controle_nb_chercheur(pNEquipe,pSpecialite) then
		raise mauvais_chercheur_specialite;
	end if;


	
/* insertion dans projet_s */
	insert into projet_s@base_sal
	values(pNProjet,pNomProjet);
	insert into projet_l@base_lag
	values(pNProjet,pNEquipe,pNCherResp);
	htp.hr;
	htp.print('<B>Enregistrement du projet '||pNomProjet||' dans PROJET.</B>'); 		
		

/* insertion dans travailler */
	for cur_chercheur_rec in cur_chercheur loop
		/* v�rification de l universit� du chercheur */
		if(cur_chercheur_rec.universite = '2') then
			/* insertion sur salines */
			insert into travailler_s@base_sal
			values(pNProjet,cur_chercheur_rec.n_chercheur,null);
			htp.br;
			htp.print('<B>Affectation du chercheur '||cur_chercheur_rec.nom_chercheur||' a ce projet.</B>'); 		
						
		else
			/* insertion sur lagune */
			insert into travailler_l@base_lag
			values(pNProjet,cur_chercheur_rec.n_chercheur,null);
			htp.br;
			htp.print('<B>Affectation du chercheur '||cur_chercheur_rec.nom_chercheur||' a ce projet.</B>'); 		
				

		end if;
		
	end loop;	

	/* commint de la transaction */
	commit;
	htp.hr;
	htp.print('<B><I>Transaction reussie</I></B>'); 		
	

	
END IF;


	htp.formClose;
	htp.htmlClose;	

exception
	
when mauvais_num_equipe then
	htp.line;
	htp.print('<B>Numero d equipe inconnue</B>');
	htp.print('<B>Transaction annulee</B>');
	
when mauvais_num_projet then
	htp.line;
	htp.print('<B>Numero de projet dej� present</B>');
	htp.print('<B>Transaction annulee</B>');
	

when mauvais_chercheur_resp_equipe then	
	htp.line;
	htp.print('<B>Le chercheur responsable n appartient pas � l equipe</B>');
	htp.print('<B>Transaction annulee</B>');
	
when mauvais_chercheur_specialite then
	htp.line;
	htp.print('<B>Aucun chercheur de cette equipe n appartient � cette specialite</B>');
	htp.print('<B>Transaction annulee</B>');


when others then
	htp.print(SQLCODE||' : '||SQLERRM);
	htp.print('<B>Transaction annulee</B>');
		
-- fin proc�dure ajout_proj
end ajout_proj;


/* proc�dure publique pour supprimer un projet */
procedure fin_proj( num_proj IN VARCHAR2 DEFAULT NULL) IS 


cursor cur_travailler is
select chercheur.n_chercheur, chercheur.nom_chercheur, chercheur.universite
from chercheur, travailler
where travailler.n_projet = num_proj
and chercheur.n_chercheur = travailler.n_chercheur;

cursor cnumproj is
select n_projet from PROJET order by n_projet;

nb integer;
message varchar2(100);
nomProjet VARCHAR2(30);
lien VARCHAR2(255);
no_data_found exception;
--pragma exception_init(no_data_found,+100);
mauvais_chercheur_projet exception;

begin

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Retour');
	htp.print(lien);
	htp.hr;

	htp.header(1, 'Arret d''un projet','CENTER');
	htp.formOpen('mg3g7.projetw.fin_proj');
	htp.p('<font size=3>');
		
	htp.formSelectOpen('num_proj', ' Choix d''un projet : ');

	for cnumproj_rec in cnumproj loop
		htp.formSelectOption(cnumproj_rec.n_projet,cattributes=>'VALUE='||cnumproj_rec.n_projet);
	end loop;
		
	htp.formSelectClose;
	htp.p('</P>');
	htp.hr;
	htp.p('<font size=4>');
	htp.formSubmit(cvalue=>'Executer');
	htp.formReset(cvalue=>'Annuler');

	IF num_proj IS NOT NULL THEN

		/* v�rification projet */
		select nom_projet into nomProjet from projet where n_projet = num_proj;
		/* si le projet n existe pas, l erreur no_data_found est lev�e */

		/* v�rification affection chercheur */
		if not chercheur_projet(num_proj) then 
			raise mauvais_chercheur_projet;		
		end if;

		/* suppression dans projet_s */
		delete from projet_s@base_sal
		where n_projet = num_proj;
		delete from projet_l@base_lag
		where n_projet = num_proj;
		htp.hr;
		htp.print('<B>Suppression du projet '||nomProjet||'.</B>'); 		
	
		/* suppression dans travailler */
		for cur_travailler_rec in cur_travailler loop
			/* v�rification de l universit� du chercheur */
			if(cur_travailler_rec.universite = '2') then
				/* suppression sur salines */
				delete from travailler_s@base_sal
				where n_chercheur = cur_travailler_rec.n_chercheur
				and n_projet = num_proj;
				htp.br;
				htp.print('<B>Suppression du travail de '||cur_travailler_rec.nom_chercheur||'.</B>'); 		

			
			else
				/* suppression sur lagune */
				delete from travailler_l@base_lag
				where n_chercheur = cur_travailler_rec.n_chercheur
				and n_projet = num_proj;
				htp.br;
				htp.print('<B>Suppression du travail de '||cur_travailler_rec.nom_chercheur||'.</B>'); 		

			end if;
		
		end loop;	

		/* commit de la transaction */
		commit;
		htp.hr;
		htp.print('<B><I>Transaction reussie</I></B>'); 		
		
	END IF;

	htp.formClose;

exception

when no_data_found then
	htp.line;
	htp.print('<B>Numero de projet inconnu</B>');
	htp.print('<B>Transaction annulee</B>');
	

when mauvais_chercheur_projet then	
	htp.line;
	htp.print('<B>Pas de chercheur affecte � ce projet</B>');
	htp.print('<B>Transaction annulee</B>');
	
when others then
	htp.print(SQLCODE||' : '||SQLERRM);
	htp.print('<B>Transaction annulee</B>');

 -- fin proc�dure fin_proj
end fin_proj;

/* proc�dure publique choix_equipe */

procedure choix_equipe(num_equ IN VARCHAR2 DEFAULT NULL)

is

CURSOR cequip is 
	select n_equipe, nom_equipe from EQUIPE order by nom_equipe;

lien VARCHAR2(255);

begin

	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Retour');
	htp.print(lien);
	htp.hr;

	htp.formOpen('mg3g7.projetw.choix_equipe');
	htp.p('<font size=3>');
	htp.header(1, 'Information sur les equipes', 'CENTER');
	htp.formSelectOpen('num_equ','Choix d''une equipe : ');

	for cequip_rec in cequip loop
		htp.formSelectOption(cequip_rec.nom_equipe,cattributes=>'VALUE='||cequip_rec.n_equipe);
	end loop;

	htp.formSelectClose;
	htp.p('</P>');
	htp.p('<font size=4>');
	htp.br;
	htp.formSubmit(cvalue=>'Executer');
	htp.formReset(cvalue=>'Annuler');

	IF num_equ IS NOT NULL THEN
		affich_equipe(num_equ);
	END IF;

	htp.formClose;

end choix_equipe;

/* proc�dure publique pour ajouter un chercheur */
procedure ajout_chercheur(pNChercheur IN VARCHAR2 DEFAULT NULL, 
			pNomChercheur IN VARCHAR2 DEFAULT NULL, 
			pSpecialite IN VARCHAR2 DEFAULT NULL, 
			pUniversite IN VARCHAR2 DEFAULT NULL, 
			Equipe IN VARCHAR2 DEFAULT NULL) IS 


cursor cequipe is
	select n_equipe, nom_equipe
	from EQUIPE
	order by nom_equipe;

cursor cuniv is
	select distinct universite 
	from chercheur
	order by universite;

num_e VARCHAR(255);
num_c VARCHAR(255);
nom_c VARCHAR(255);
lien VARCHAR2(255);

begin

	/* formulaire */
	
	htp.bodyOpen('http://salines.cict.fr:9000/back2.jpg');

	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Sommaire');
	htp.print(lien);
	htp.br;
	lien:=htf.anchor('http://web-etu.cict.fr:7777/miage3/mg3g7/index.html','Retour');
	htp.print(lien);
	htp.hr;

	htp.formOpen('mg3g7.projetw.ajout_chercheur');
	htp.p('<font size=3>');
	htp.header(1, 'Ajout d''un chercheur','CENTER');
	htp.br;
	htp.br;
	htp.print('Entrer le numero de chercheur: ');
	htp.formText('pNChercheur');
	htp.br;
	htp.br;
	htp.print('Entrer le nom du chercheur: ');
	htp.formText('pNomChercheur');
	htp.br;
	htp.br;
	htp.print('Entrer la specialite du chercheur: ');
	htp.formText('pSpecialite');
	htp.br;
	htp.br;
	htp.formSelectOpen('pUniversite', 'Choix de l''universite: ');
		for cuniv_rec in cuniv loop
			htp.formSelectOption(cuniv_rec.universite,cattributes=>'VALUE='||cuniv_rec.universite);
		end loop;
	htp.formSelectClose;
	htp.br;
	htp.br;
	htp.formSelectOpen('Equipe', 'Choix de l''equipe: ');
		for cequipe_rec in cequipe loop
			htp.formSelectOption(cequipe_rec.nom_equipe,cattributes=>'VALUE='||cequipe_rec.n_equipe);
		end loop;
	htp.formSelectClose;
	htp.p('<font size=4>');
	htp.br;

	IF pNChercheur IS NOT NULL and pNomChercheur IS NOT NULL and pSpecialite IS NOT NULL and pUniversite IS NOT NULL and Equipe IS NOT NULL THEN

	
		/* insertion dans chercheur */
		insert into chercheur
		values(pNChercheur, pNomChercheur, pSpecialite, pUniversite, Equipe);
		htp.hr;
		htp.print('<B>Enregistrement du chercheur '||pNomChercheur||' dans CHERCHEUR</B>'); 		

		/* commint de la transaction */
		commit;
		htp.br;
		htp.print('<B><I>Transaction reussie</I></B>');

	ELSE

		htp.br;
		htp.formSubmit(cvalue=>'Executer');
		htp.formReset(cvalue=>'Annuler');

	END IF;

	if Equipe is not null then
		/* affectation de projets */
		num_e:=Equipe;
		num_c:=pNChercheur;
		nom_c:=pNomChercheur;

		lien:=htf.anchor('mg3g7.projetw.affich_prj_equipe?pNEquipe='||num_e||'&'||'pNChercheur='||num_c||'&'||'pNomChercheur='||nom_c,'Affecter les nombres de jours de '||nom_c);		
		
		htp.hr;
		htp.br;
		htp.print(lien);
		htp.br;
	end if;

	htp.formClose;

exception

	
when others then
	htp.br;
	htp.print(SQLCODE||' : '||SQLERRM);
	htp.br;
	htp.print('<B>Transaction annulee</B>');


end ajout_chercheur;



end projetw;
/
grant execute on projetw to webetu;
show errors;