/* Client pour les proc�dures du package gestproj */

/* appel de ajout_proj */

prompt 'Fichier sortie : '
accept fichierSortie
spool &fichierSortie.log;

set serverout on;

prompt 'Numero projet : '
accept NumProjet

prompt 'Nom projet : '
accept NomProjet

prompt 'Numero equipe : '
accept NumEquipe

prompt 'Numero chercheur responsable : '
accept NumCherResp

prompt 'Specialite : '
accept Specialite

execute gestproj.ajout_proj('&NumProjet','&NomProjet','&NumEquipe','&NumCherResp','&Specialite');

select * from projet;
select * from travailler;

spool off;