/* trigger sur la vue chercheur pour permettre les insert, update et delete 	 */
/* avec mise � jour des tables sous-jacentes	 		    	 */	
/* Remarque : la verification du numero de l universite en insertion ou mise � jour */ 
/*	      n est pas faite donc on peut pour l instant inserer des chercheurs  */
/*	      avec un numero d universite differents de 1, 2 ou 3. Dans ce cas,	 */
/*	      le chercheur sera inser� dans chercher_l@base_lag		 */
					
create or replace trigger iud_chercheur 
instead of insert or update or delete on chercheurvue

declare
	message varchar2(100);
	nb integer;
	numverif integer;
	pk_chercheur exception;
	pragma exception_init(pk_chercheur, -00001); 
	fk_equipe exception;
	pragma exception_init(fk_equipe, -2291); 
	parent_sans_enfant exception;
	pragma exception_init(parent_sans_enfant, -2292); 
	mauvaise_universite exception;
begin
	/* insertion */
	if inserting then
		/* verification de la cl� primaire sur chercheur,						*/
		/* � noter que si des contraintes PRIMARY KEY etaient presentes dans chercheur_s et chercheur_l */
		/* cette v�rification devient inutile puisque l'erreur est lev�e par Oracle ...			*/	
		select count(*) into nb from chercheurvue where n_chercheur = :NEW.n_chercheur;
		if(nb > 0) then
			raise pk_chercheur;
		end if;

		/* verification de la cl� etrangere de chercheur vers equipe 	*/
		/* (meme remarque que pour la cl� primaire 		*/
		select count(*) into nb from equipevue where n_equipe = :NEW.n_equipe;
		if(nb != 1) then	
			raise fk_equipe;
		end if;

		if(:NEW.universite = 2) then
			insert into chercheur_s 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);
		else
			insert into chercheur_l 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);
		end if;		
	end if;

	/* mise � jour */
	if updating('n_chercheur') then
		/* verification de la cl� primaire sur chercheur */
		select count(*) into nb from chercheurvue where n_chercheur = :NEW.n_chercheur;
		if(nb > 0) then
			raise pk_chercheur;
		end if;

		update chercheur_s set n_chercheur = :NEW.n_chercheur where n_chercheur = :OLD.n_chercheur;
		update chercheur_l set n_chercheur = :NEW.n_chercheur where n_chercheur = :OLD.n_chercheur;
	end if;

	if updating('nom_chercheur') then
		update chercheur_s set nom_chercheur = :NEW.nom_chercheur where n_chercheur = :OLD.n_chercheur;
		update chercheur_l set nom_chercheur = :NEW.nom_chercheur where n_chercheur = :OLD.n_chercheur;
	end if;

	if updating('specialite') then
		update chercheur_s set specialite = :NEW.specialite where n_chercheur = :OLD.n_chercheur;
		update chercheur_l set specialite = :NEW.specialite where n_chercheur = :OLD.n_chercheur;
	end if;

	if updating('universite') then
		if(:NEW.universite = 2 and (:OLD.universite = 1 or :OLD.universite = 3)) then
			/* changement d universit�, de l universite 1 ou 3 vers la 2 */
			delete from chercheur_l where n_chercheur = :OLD.n_chercheur;
			insert into chercheur_s 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);
		else
			/* changement d universit�, de l universite 2 vers 1 ou 3 */
			delete from chercheur_s where n_chercheur = :OLD.n_chercheur;
			insert into chercheur_l 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);

		end if;
	end if;

	if updating('n_equipe') then

		/* verification de la cl� etrangere de chercheur vers equipe 	*/
		select count(*) into nb from equipevue where n_equipe = :NEW.n_equipe;
		if(nb != 1) then	
			raise fk_equipe;
		end if;

		update chercheur_s set n_equipe = :NEW.n_equipe where n_chercheur = :OLD.n_chercheur;
		update chercheur_l set n_equipe = :NEW.n_equipe where n_chercheur = :OLD.n_chercheur;
	end if;

	/* suppression */
	if deleting then

		numverif := 0;

		/* verification de la cl� etrangere de projet sur chercheur */
		select count(*) into nb from projetvue where n_cher_resp = :OLD.n_chercheur;
		if(nb > 0) then	
			numverif := 1;
			raise parent_sans_enfant;
		end if;

		/* verification de la cl� etrangere de travailler sur chercheur */
		select count(*) into nb from travaillervue where n_chercheur = :OLD.n_chercheur;
		if(nb > 0) then	
			numverif := 2;
			raise parent_sans_enfant;
		end if;
	
		delete from chercheur_s where n_chercheur = :OLD.n_chercheur; 	
		delete from chercheur_l where n_chercheur = :OLD.n_chercheur;
	end if;

exception

when pk_chercheur then
	message:='Violation de contrainte PRIMARY KEY: CHERCHEUR.N_CHERCHEUR';
	dbms_output.put_line(message);

when fk_equipe then
	message:='Violation de contrainte FOREIGN KEY: CHERCHEUR.N_EQUIPE';
	dbms_output.put_line(message);
	
when parent_sans_enfant then
	if(numverif = 1) then
		message:='Suppression impossible; le chercheur est encore r�f�renc� dans PROJET : PROJET.N_CHER_RESP';
	else
		message:='Suppression impossible; le chercheur est encore r�f�renc� dans TRAVAILLER : TRAVAILLER.N_CHERCHEUR';
	end if;

	dbms_output.put_line(message);

when others then
	message:=substr(sqlerrm,1,80);
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		
end;
/