/* Client pour les proc�dures du package gestproj - question 2 */

/* appel de fin_proj */

prompt 'Fichier sortie : '
accept fichierSortie
spool &fichierSortie.log;

set serverout on;

prompt 'Numero projet : '
accept NumProjet

execute gestproj.fin_proj('&NumProjet');

select * from projet;
select * from travailler;

spool off;