/* TP3 - 1 */
/* Sp�cification du package gestproj */
create or replace package gestproj as -
procedure ajout_proj(	pNProjet PROJET.N_PROJET%TYPE, -
			pNomProjet PROJET.NOM_PROJET%TYPE, -
			pNEquipe PROJET.N_EQUIPE%TYPE, -
			pNCherResp PROJET.N_CHER_RESP%TYPE, -
			pSpecialite CHERCHEUR.SPECIALITE%TYPE);

procedure fin_proj(	pNProjet PROJET.N_PROJET%TYPE);

END gestproj;
/