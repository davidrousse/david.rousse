/* trigger sur la vue chercheur pour permettre les insert, update et delete */
/* avec mise � jour des tables sous-jacentes	 		     */	
					
create or replace trigger iud_chercheur 
instead of insert or update or delete on chercheur

declare
	message varchar2(100);
begin
	/* insertion */
	if inserting then
		if(:NEW.universite = 2) then
			insert into chercheur_s@base_sal 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);
		else
			insert into chercheur_l@base_lag 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);
		end if;		
	end if;

	/* mise � jour */
	if updating('n_chercheur') then
		update chercheur_s@base_sal set n_chercheur = :NEW.n_chercheur where n_chercheur = :OLD.n_chercheur;
		update chercheur_l set n_chercheur = :NEW.n_chercheur where n_chercheur = :OLD.n_chercheur;
	end if;

	if updating('nom_chercheur') then
		update chercheur_s@base_sal set nom_chercheur = :NEW.nom_chercheur where n_chercheur = :OLD.n_chercheur;
		update chercheur_l@base_lag set nom_chercheur = :NEW.nom_chercheur where n_chercheur = :OLD.n_chercheur;
	end if;

	if updating('specialite') then
		update chercheur_s@base_sal set specialite = :NEW.specialite where n_chercheur = :OLD.n_chercheur;
		update chercheur_l@base_lag set specialite = :NEW.specialite where n_chercheur = :OLD.n_chercheur;
	end if;

	if updating('universite') then
		if(:NEW.universite = 2 and (:OLD.universite = 1 or :OLD.universite = 3)) then
			/* changement d universit�, de l universite 1 ou 3 vers la 2 */
			delete from chercheur_l@base_lag where n_chercheur = :OLD.n_chercheur;
			insert into chercheur_s@base_sal 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);
		else
			/* changement d universit�, de l universite 2 vers 1 ou 3 */
			delete from chercheur_s@base_sal where n_chercheur = :OLD.n_chercheur;
			insert into chercheur_l@base_lag 
			values (:NEW.n_chercheur,:NEW.nom_chercheur,:NEW.specialite,:NEW.n_equipe);

		end if;
	end if;

	if updating('n_equipe') then
		update chercheur_s@base_sal set n_equipe = :NEW.n_equipe where n_chercheur = :OLD.n_chercheur;
		update chercheur_l@base_lag set n_equipe = :NEW.n_equipe where n_chercheur = :OLD.n_chercheur;
	end if;

	/* suppression */
	if deleting then
		delete from chercheur_s@base_sal where n_chercheur = :OLD.n_chercheur; 	
		delete from chercheur_l@base_lag where n_chercheur = :OLD.n_chercheur;
	end if;

exception /* on a une gestion g�n�raliste des erreurs ...*/

when others then
	message:=substr(sqlerrm,1,80);
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		
end;
/