/* Client pour le trigger iud_chercheu avec la clause instead of */

prompt 'Fichier sortie : '
accept fichierSortie
spool &fichierSortie.log;

set serverout on;

--insert into chercheur values('c9','carole','bd',1,'e1');
--insert into chercheur values('c10','david','rx',2,'e2');
--insert into chercheur values('c11','magalie','si',2,'e3');
--insert into chercheur values('','magalie','bd',3,'e1'); /* une erreur sera lev�e */

--update chercheur set n_chercheur = 'c12' where n_chercheur = 'c11';
--update chercheur set nom_chercheur = 'dave' where n_chercheur = 'c10';
--update chercheur set specialite = 'oo' where n_chercheur = 'c9';
--update chercheur set universite = '2' where n_chercheur = 'c9'; /* changement d'universit�, 1 vers 2 */
--update chercheur set universite = '1' where n_chercheur = 'c10'; /* changement d'universit�, 2 vers 1 */
--update chercheur set n_equipe = 'e3' where n_chercheur = 'c10';

--delete from chercheur where n_chercheur = 'c9';
--delete from chercheur where n_chercheur = 'c10';
--delete from chercheur where n_chercheur = 'c12';

select * from chercheur;
select * from chercheur_s@base_sal;
select * from chercheur_l@base_lag;

spool off;