/* TP3 - 1 */
/* Impl�mentation du package gestproj */
create or replace package body gestproj as 

/* fonction priv�e controle_resp */
function controle_resp(pNEquipe CHERCHEUR.N_EQUIPE%TYPE, pNChercheur CHERCHEUR.N_CHERCHEUR%TYPE) return boolean is

retour boolean;
equipeChercheur CHERCHEUR.N_EQUIPE%TYPE;

begin

	select n_equipe into equipeChercheur
	from chercheur
	where n_chercheur = pNChercheur;

	/* on compare le parametre � la donn�e lue */
	if (pNEquipe != equipeChercheur) then
		retour:=false;
	else
		retour:=true;
	end if;

	return(retour);

end controle_resp; /* fin fonction */

/* fonction priv�e controle_nb_chercheur */
function controle_nb_chercheur(pNEquipe CHERCHEUR.N_EQUIPE%TYPE, pSpecialite CHERCHEUR.SPECIALITE%TYPE) return boolean is

retour boolean;
nb integer;

begin
	select count(*) into nb
	from chercheur
	where n_equipe = pNEquipe
	and specialite = pSpecialite;

	/* on verifie que l'on a au moins un chercheur competent */
	if (nb>0) then
		retour:=true;
	else
		retour:=false;
	end if;

	return(retour);

end controle_nb_chercheur; /* fin fonction */

/* fonction priv�e chercheur_projet */
function chercheur_projet(pNProjet PROJET.N_PROJET%TYPE) return boolean is

retour boolean;
nb integer;

begin
	select count(*) into nb
	from travailler
	where n_projet = pNProjet;

	/* on verifie que l'on a au moins un chercheur affect� */
	if (nb>0) then
		retour:=true;
	else
		retour:=false;
	end if;

	return(retour);

end chercheur_projet; /* fin fonction */

/* proc�dure publique pour ajouter un projet */
procedure ajout_proj(	pNProjet PROJET.N_PROJET%TYPE, 
			pNomProjet PROJET.NOM_PROJET%TYPE, 
			pNEquipe PROJET.N_EQUIPE%TYPE, 
			pNCherResp PROJET.N_CHER_RESP%TYPE, 
			pSpecialite CHERCHEUR.SPECIALITE%TYPE) IS 


cursor cur_chercheur is
select n_chercheur, nom_chercheur, universite 
from chercheur 
where n_equipe = pNEquipe;

nb integer;
message varchar2(100);
mauvais_num_equipe exception;
mauvais_num_projet exception;
mauvais_chercheur_resp_equipe exception;
mauvais_chercheur_specialite exception;

begin

	/* v�rification equipe */
	select count(*) into nb from equipe where n_equipe = pNEquipe;
	if (nb!=1) then 
		raise mauvais_num_equipe;		
	end if;

	/* v�rification projet */
	select count(*) into nb from projet where n_projet = pNProjet;
	if (nb=1) then 
		raise mauvais_num_projet;		
	end if;

	/* v�rification  que chercheur responsable appartient � l �quipe */
	if not controle_resp(pNEquipe,pNCherResp) then
		raise mauvais_chercheur_resp_equipe;
	end if;

	/* v�rification au moins un chercheur avec specialite */
	if not controle_nb_chercheur(pNEquipe,pSpecialite) then
		raise mauvais_chercheur_specialite;
	end if;

	/* insertion dans projet_s */
	insert into projet_s@base_sal
	values(pNProjet,pNomProjet);
	insert into projet_l@base_lag
	values(pNProjet,pNEquipe,pNCherResp);
	
	message:='enregistrement du projet '||pNomProjet||' dans PROJET'; 		
	dbms_output.put_line(message);		

	/* insertion dans travailler */
	for cur_chercheur_rec in cur_chercheur loop
		/* v�rification de l universit� du chercheur */
		if(cur_chercheur_rec.universite = '2') then
			/* insertion sur salines */
			insert into travailler_s@base_sal
			values(pNProjet,cur_chercheur_rec.n_chercheur,null);
	
			message:='affectation du chercheur '||cur_chercheur_rec.nom_chercheur||' � ce projet'; 		
			dbms_output.put_line(message);		
			
		else
			/* insertion sur lagune */
			insert into travailler_l@base_lag
			values(pNProjet,cur_chercheur_rec.n_chercheur,null);
	
			message:='affectation du chercheur '||cur_chercheur_rec.nom_chercheur||' � ce projet'; 		
			dbms_output.put_line(message);		

		end if;
		
	end loop;	

	/* commint de la transaction */
	commit;
	message:='Transaction reussie'; 		
	dbms_output.put_line(message);		

exception
	
when mauvais_num_equipe then
	rollback;
	message :='Num�ro d �quipe inconnue';
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		

when mauvais_num_projet then
	rollback;
	message :='Num�ro de projet d�j� pr�sent';
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		

when mauvais_chercheur_resp_equipe then	
	rollback;
	message:='Le chercheur responsable n appartient pas � l �quipe';
	dbms_output.put_line(message);	
	message:='Transaction annul�e';
	dbms_output.put_line(message);	

when mauvais_chercheur_specialite then
	rollback;
	message :='Aucun chercheur de cette �quipe n appartient � cette sp�cialit�';
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);	

when others then
	rollback;
	message:=substr(sqlerrm,1,80);
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		

end ajout_proj; /* fin proc�dure ajout_proj */

/* proc�dure publique pour supprimer un projet */
procedure fin_proj(	pNProjet PROJET.N_PROJET%TYPE) IS 


cursor cur_travailler is
select chercheur.n_chercheur, chercheur.nom_chercheur, chercheur.universite
from chercheur, travailler
where travailler.n_projet = pNProjet
and chercheur.n_chercheur = travailler.n_chercheur;

nb integer;
message varchar2(100);
nomProjet PROJET.NOM_PROJET%TYPE;
no_data_found exception;
pragma exception_init(no_data_found,+100);
mauvais_chercheur_projet exception;

begin

	/* v�rification projet */
	select nom_projet into nomProjet from projet where n_projet = pNProjet;
	/* si le projet n existe pas, l erreur no_data_found est lev�e */

	/* v�rification affection chercheur */
	if not chercheur_projet(pNProjet) then 
		raise mauvais_chercheur_projet;		
	end if;

	/* suppression dans projet_s */
	delete from projet_s@base_sal
	where n_projet = pNProjet;
	delete from projet_l@base_lag
	where n_projet = pNProjet;
	
	message:='suppression du projet '||nomProjet||'.'; 		
	dbms_output.put_line(message);		

	/* suppression dans travailler */
	for cur_travailler_rec in cur_travailler loop
		/* v�rification de l universit� du chercheur */
		if(cur_travailler_rec.universite = '2') then
			/* suppression sur salines */
			delete from travailler_s@base_sal
			where n_chercheur = cur_travailler_rec.n_chercheur
			and n_projet = pNProjet;

			message:='suppression du travail de '||cur_travailler_rec.nom_chercheur||'.'; 		
			dbms_output.put_line(message);		
			
		else
			/* suppression sur lagune */
			delete from travailler_l@base_lag
			where n_chercheur = cur_travailler_rec.n_chercheur
			and n_projet = pNProjet;

			message:='suppression du travail de '||cur_travailler_rec.nom_chercheur||'.'; 		
			dbms_output.put_line(message);		

		end if;
		
	end loop;	

	/* commint de la transaction */
	commit;
	message:='Transaction reussie'; 		
	dbms_output.put_line(message);		

exception
	

when no_data_found then
	rollback;
	message :='Num�ro de projet inconnu';
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		

when mauvais_chercheur_projet then	
	rollback;
	message:='Pas de chercheur affect� � ce projet';
	dbms_output.put_line(message);	
	message:='Transaction annul�e';
	dbms_output.put_line(message);	

when others then
	rollback;
	message:=substr(sqlerrm,1,80);
	dbms_output.put_line(message);
	message:='Transaction annul�e';
	dbms_output.put_line(message);		

end fin_proj; /* fin proc�dure fin_proj */

end gestproj;
/

show errors;