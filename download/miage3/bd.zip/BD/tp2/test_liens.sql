select * from CHERCHEUR_S@base_sal -
union select *  from CHERCHEUR_L@base_lag;

select * from TRAVAILLER_S@base_sal -
union select * from TRAVAILLER_L@base_lag;

select PROJET_S.N_PROJET, PROJET_S.NOM_PROJET, PROJET_L.N_EQUIPE, PROJET_L.N_CHER_RESP -
from PROJET_S@base_sal, PROJET_L@base_lag -
where PROJET_S.N_PROJET=PROJET_L.N_PROJET;


select * from EQUIPE_L@base_lag;