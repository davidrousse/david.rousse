select * from CHERCHEUR_S;

select * from TRAVAILLER_S;

select *  from PROJET_S;