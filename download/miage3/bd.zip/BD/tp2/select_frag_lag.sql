select * from CHERCHEUR_L;

select * from TRAVAILLER_L;

select *  from PROJET_L;

select *  from EQUIPE_L;