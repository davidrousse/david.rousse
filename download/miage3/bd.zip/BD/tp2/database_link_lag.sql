alter session set global_names=false;

create database link base_sal-
connect to mg3g7 identified by david -
using 'etu';

create database link base_lag -
connect to mg3g7 identified by david -
using 'lag';

