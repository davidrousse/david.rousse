Script started on Tue May  2 17:43:34 2000
$ pro1

Entrer votre nom d'utilisateur ou /: /

Entrer votre mot de passe ou /: 


............. CONNEXION  REUSSIE .............


Entrer un numero de poste (chaine vide pour quitter) : p1

Nom du poste	Type du poste	Adresse IP		Nom salle	Nom de segment
   Poste 1	    TX		130.120.80.01	        Salle 1          segment 80
 --------------------------------------------------------------------------------------- 

Entrer un numero de poste (chaine vide pour quitter) : p3

Nom du poste	Type du poste	Adresse IP		Nom salle	Nom de segment
   Poste 3	    TX		130.120.80.03	        Salle 1          segment 80
 --------------------------------------------------------------------------------------- 

Entrer un numero de poste (chaine vide pour quitter) : p100

Poste    p100 inconnu !
 --------------------- 

Entrer un numero de poste (chaine vide pour quitter) : 


............. DECONNEXION .............

$ 

script done on Tue May  2 17:44:21 2000
