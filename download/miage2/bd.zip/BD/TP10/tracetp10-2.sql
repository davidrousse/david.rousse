Script started on Tue May  2 17:44:47 2000
$ pro1

Entrer votre nom d'utilisateur ou /: 

Entrer votre mot de passe ou /: 


............. ERREUR A LA CONNEXION .............


ORA-24315: illegal attribute type
                                     (24315)
$ 

script done on Tue May  2 17:45:02 2000
