Script started on Tue May 16 18:02:25 2000
$ pro2

Entrer votre nom d'utilisateur ou /: /

Entrer votre mot de passe ou /: 


............. CONNEXION  REUSSIE .............



Entrer un numero de poste (chaine vide pour quitter) : p2

Nom du poste	Type du poste	Adresse IP		Nom salle	Nom de segment
 --------------------------------------------------------------------------------------- 

   Poste 2	  UNIX		130.120.80.02	        Salle 1          segment 80

 Logiciel installe sur le    Poste 2 :

Nom du logiciel		Date achat	Date installattion		Nom type
 ---------------------------------------------------------------------------------
       Oracle 7		 13-MAY-99	 15-MAY-99		   Systeme UNIX	       Oracle 8		 15-SEP-99	 17-SEP-99		   Systeme UNIX	        Sql*Net		 13-MAY-99	  inconnue		   Systeme UNIX	

Entrer un numero de poste (chaine vide pour quitter) : p1

Nom du poste	Type du poste	Adresse IP		Nom salle	Nom de segment
 --------------------------------------------------------------------------------------- 

   Poste 1	    TX		130.120.80.01	        Salle 1          segment 80

 Logiciel installe sur le    Poste 1 :

Nom du logiciel		Date achat	Date installattion		Nom type
 ---------------------------------------------------------------------------------

Pas de logiciel installe
 --------------------- 


Entrer un numero de poste (chaine vide pour quitter) : p8

Nom du poste	Type du poste	Adresse IP		Nom salle	Nom de segment
 --------------------------------------------------------------------------------------- 

   Poste 8	  UNIX		130.120.81.01	       Salle 11          segment 81

 Logiciel installe sur le    Poste 8 :

Nom du logiciel		Date achat	Date installattion		Nom type
 ---------------------------------------------------------------------------------
       Oracle 7		 13-MAY-99	  inconnue		   Systeme UNIX	       Oracle 8		 15-SEP-99	 19-MAY-99		   Systeme UNIX	        Sql*Net		 13-MAY-99	 20-MAY-99		   Systeme UNIX	

Entrer un numero de poste (chaine vide pour quitter) : p11

Nom du poste	Type du poste	Adresse IP		Nom salle	Nom de segment
 --------------------------------------------------------------------------------------- 

  Poste 11	  PCNT		130.120.82.01	       Salle 21          segment 82

 Logiciel installe sur le   Poste 11 :

Nom du logiciel		Date achat	Date installattion		Nom type
 ---------------------------------------------------------------------------------
     Sql server		 12-APR-99	 20-MAY-99		  PC Windows NT	       I. I. S.		 12-APR-99	 20-APR-99		  PC Windows NT	

Entrer un numero de poste (chaine vide pour quitter) : p500

Poste    p500 inconnu !
 --------------------- 


Entrer un numero de poste (chaine vide pour quitter) : 


............. DECONNEXION .............

$ 

script done on Tue May 16 18:04:25 2000
