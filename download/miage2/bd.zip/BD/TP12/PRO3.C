
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned long magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[8];
};
static struct sqlcxp sqlfpn =
{
    7,
    "pro3.pc"
};


static unsigned long sqlctx = 9827;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   unused;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
            void  *sqhstv[5];
   unsigned int   sqhstl[5];
            int   sqhsts[5];
            void  *sqindv[5];
            int   sqinds[5];
   unsigned int   sqharm[5];
   unsigned int   *sqharc[5];
   unsigned short  sqadto[5];
   unsigned short  sqtdso[5];
} sqlstm = {10,5};

/* SQLLIB Prototypes */
extern sqlcxt (/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned long *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned long *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern void sqliem(/*_ char *, int * _*/);

 static char *sq0001 = 
"select N_POSTE ,NOM_P  from POSTE P ,SALLE S where ((P.TYPE_P=:b0 and P.N_SE\
GMENT=:b1) and P.N_SALLE=S.N_SALLE)           ";

 static char *sq0002 = 
"select I.N_POSTE ,N_LOG ,DATE_INS  from POSTE P ,INSTALLER I where (N_SALLE=\
:b0 and P.N_POSTE=I.N_POSTE) for update of PROBLEME,DATE_RE_INS ";

 static char *sq0003 = 
"select INSTALLER.N_POSTE ,N_LOG ,DATE_INS ,PROBLEME ,DATE_RE_INS  from INSTA\
LLER ,POSTE where (POSTE.N_SEGMENT=:b0 and POSTE.N_POSTE=INSTALLER.N_POSTE)   \
        ";

 static char *sq0004 = 
"select INSTALLER.N_POSTE ,N_LOG ,DATE_INS ,probleme ,date_re_ins  from INSTA\
LLER ,SALLE ,POSTE where ((SALLE.N_SALLE=:b0 and SALLE.N_SALLE=POSTE.N_SALLE) \
and INSTALLER.N_POSTE=POSTE.N_POSTE)           ";

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* CUD (Compilation Unit Data) Array */
static short sqlcud0[] =
{10,4130,0,0,0,
5,0,0,5,0,0,27,91,0,0,4,4,0,1,0,1,9,0,0,1,9,0,0,1,10,0,0,1,10,0,0,
36,0,0,6,0,0,30,156,0,0,0,0,0,1,0,
51,0,0,7,0,0,31,161,0,0,0,0,0,1,0,
66,0,0,8,51,0,3,313,0,0,5,5,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,
101,0,0,1,122,0,9,319,0,0,2,2,0,1,0,1,9,0,0,1,9,0,0,
124,0,0,1,0,0,13,324,0,0,2,0,0,1,0,2,9,0,0,2,9,0,0,
147,0,0,9,68,0,3,341,0,0,2,2,0,1,0,1,9,0,0,1,9,0,0,
170,0,0,1,0,0,15,354,0,0,0,0,0,1,0,
185,0,0,10,0,0,29,373,0,0,0,0,0,1,0,
200,0,0,11,56,0,4,391,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
223,0,0,12,56,0,4,404,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
246,0,0,13,53,0,4,417,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
269,0,0,14,53,0,4,430,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
292,0,0,15,59,0,4,443,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
315,0,0,16,59,0,4,456,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
338,0,0,2,140,0,9,491,0,0,1,1,0,1,0,1,9,0,0,
357,0,0,2,0,0,13,496,0,0,3,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,
384,0,0,17,68,0,5,528,0,0,3,3,0,1,0,1,9,0,0,1,9,0,0,1,9,0,0,
411,0,0,2,0,0,15,544,0,0,0,0,0,1,0,
426,0,0,18,0,0,29,563,0,0,0,0,0,1,0,
441,0,0,19,55,0,4,579,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
464,0,0,20,55,0,4,592,0,0,2,1,0,1,0,2,3,0,0,1,9,0,0,
487,0,0,3,162,0,9,628,0,0,1,1,0,1,0,1,9,0,0,
506,0,0,3,0,0,13,635,0,0,5,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,
541,0,0,3,0,0,15,670,0,0,0,0,0,1,0,
556,0,0,4,201,0,9,702,0,0,1,1,0,1,0,1,9,0,0,
575,0,0,4,0,0,13,709,0,0,5,0,0,1,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,2,9,0,0,
610,0,0,4,0,0,15,744,0,0,0,0,0,1,0,
};


/*  TP12 : CONSULTATION MULTITUPLE */
#include <ctype.h>
#include <stdio.h>

/* EXEC SQL BEGIN DECLARE SECTION; */ 

/* D�clarations des variables hote*/
	/* VARCHAR user[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } user;

	/* VARCHAR pwd[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } pwd;

	/* VARCHAR nump[7]; */ 
struct { unsigned short len; unsigned char arr[7]; } nump;

	/* VARCHAR nomp[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } nomp;

	/* VARCHAR typep[6]; */ 
struct { unsigned short len; unsigned char arr[6]; } typep;
	
	/* VARCHAR adp[2]; */ 
struct { unsigned short len; unsigned char arr[2]; } adp;
	
	/* VARCHAR numsegment[15]; */ 
struct { unsigned short len; unsigned char arr[15]; } numsegment;
	
	/* VARCHAR nomsegment[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } nomsegment;
	
	/* VARCHAR nums[10]; */ 
struct { unsigned short len; unsigned char arr[10]; } nums;

	/* VARCHAR noms[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } noms;

	/* VARCHAR numl[6]; */ 
struct { unsigned short len; unsigned char arr[6]; } numl;
	
	/* VARCHAR noml[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } noml;

	/* VARCHAR versionl[7]; */ 
struct { unsigned short len; unsigned char arr[7]; } versionl;

	/* VARCHAR typel[6]; */ 
struct { unsigned short len; unsigned char arr[6]; } typel;
		
	/* VARCHAR nomtype[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } nomtype;
		
	/* VARCHAR dateinstall[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } dateinstall;

	/* VARCHAR date_re_install[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } date_re_install;
	
	/* VARCHAR dateachat[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } dateachat;

	/* VARCHAR probleme[15]; */ 
struct { unsigned short len; unsigned char arr[15]; } probleme;

		
	/* variable pour recupere le resultat d'un COUNT */
	int nb;
	
	/*variable indicatrice*/	
	short i_dateinstall;
	short i_probl;
	short i_datereins;
	
/* EXEC SQL END DECLARE SECTION; */ 


/* curseur TP12-1 */
/* EXEC SQL DECLARE c1 CURSOR FOR

SELECT N_POSTE, NOM_P
FROM POSTE P, SALLE S
WHERE P.TYPE_P = :typel
AND P.N_SEGMENT = :numsegment
AND P.N_SALLE = S.N_SALLE; */ 


/* curseur TP12-2 */
/* EXEC SQL DECLARE c2 CURSOR FOR

SELECT I.N_POSTE, N_LOG, DATE_INS
FROM POSTE P, INSTALLER I
WHERE N_SALLE = :nums
AND P.N_POSTE = I.N_POSTE
FOR UPDATE OF PROBLEME, DATE_RE_INS; */ 


/* curseur TP12-3 */
/* EXEC SQL DECLARE c3 CURSOR FOR

SELECT INSTALLER.N_POSTE,N_LOG, DATE_INS,PROBLEME,DATE_RE_INS
FROM  INSTALLER,POSTE
WHERE POSTE.N_SEGMENT=:numsegment
AND POSTE.N_POSTE=INSTALLER.N_POSTE; */ 


/* curseur TP12-4 */
/* EXEC SQL DECLARE c4 CURSOR FOR

SELECT INSTALLER.N_POSTE,N_LOG, DATE_INS,probleme,date_re_ins
FROM  INSTALLER,SALLE,POSTE
WHERE SALLE.N_SALLE=:nums
AND SALLE.N_SALLE=POSTE.N_SALLE
AND INSTALLER.N_POSTE=POSTE.N_POSTE; */ 


/* EXEC SQL INCLUDE sqlca.h;
 */ 
/*
 * $Header: sqlca.h,v 1.3 1994/12/12 19:27:27 jbasu Exp $ sqlca.h 
 */

/* Copyright (c) 1985,1986 by Oracle Corporation. */
 
/*
NAME
  SQLCA : SQL Communications Area.
FUNCTION
  Contains no code. Oracle fills in the SQLCA with status info
  during the execution of a SQL stmt.
NOTES
  **************************************************************
  ***                                                        ***
  *** This file is SOSD.  Porters must change the data types ***
  *** appropriately on their platform.  See notes/pcport.doc ***
  *** for more information.                                  ***
  ***                                                        ***
  **************************************************************

  If the symbol SQLCA_STORAGE_CLASS is defined, then the SQLCA
  will be defined to have this storage class. For example:
 
    #define SQLCA_STORAGE_CLASS extern
 
  will define the SQLCA as an extern.
 
  If the symbol SQLCA_INIT is defined, then the SQLCA will be
  statically initialized. Although this is not necessary in order
  to use the SQLCA, it is a good pgming practice not to have
  unitialized variables. However, some C compilers/OS's don't
  allow automatic variables to be init'd in this manner. Therefore,
  if you are INCLUDE'ing the SQLCA in a place where it would be
  an automatic AND your C compiler/OS doesn't allow this style
  of initialization, then SQLCA_INIT should be left undefined --
  all others can define SQLCA_INIT if they wish.

  If the symbol SQLCA_NONE is defined, then the SQLCA variable will
  not be defined at all.  The symbol SQLCA_NONE should not be defined
  in source modules that have embedded SQL.  However, source modules
  that have no embedded SQL, but need to manipulate a sqlca struct
  passed in as a parameter, can set the SQLCA_NONE symbol to avoid
  creation of an extraneous sqlca variable.
 
MODIFIED
    jbasu      12/12/94 -  Bug 217878: note this is an SOSD file
    losborne   08/11/92 -  No sqlca var if SQLCA_NONE macro set 
  Clare      12/06/84 - Ch SQLCA to not be an extern.
  Clare      10/21/85 - Add initialization.
  Bradbury   01/05/86 - Only initialize when SQLCA_INIT set
  Clare      06/12/86 - Add SQLCA_STORAGE_CLASS option.
*/
 
#ifndef SQLCA
#define SQLCA 1
 
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ long    sqlabc;
         /* b4  */ long    sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ long    sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };

#ifndef SQLCA_NONE 
#ifdef   SQLCA_STORAGE_CLASS
SQLCA_STORAGE_CLASS struct sqlca sqlca
#else
         struct sqlca sqlca
#endif
 
#ifdef  SQLCA_INIT
         = {
         {'S', 'Q', 'L', 'C', 'A', ' ', ' ', ' '},
         sizeof(struct sqlca),
         0,
         { 0, {0}},
         {'N', 'O', 'T', ' ', 'S', 'E', 'T', ' '},
         {0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0}
         }
#endif
         ;
#endif
 
#endif
 
/* end SQLCA */


main()
	{
	 connexion();
	 travail();
	 deconnexion();
	}



connexion()
{
	/* Lecture user et password */
	
	user.len=asks("\nEntrer votre nom d'utilisateur ou /: ",user.arr);
	pwd.len=asks("\nEntrer votre mot de passe ou /: ",pwd.arr);
		
	/* EXEC SQL  WHENEVER SQLERROR GOTO errlogin; */ 

	/* EXEC SQL  CONNECT :user IDENTIFIED BY :pwd; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 4;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )10;
 sqlstm.offset = (unsigned int  )5;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&user;
 sqlstm.sqhstl[0] = (unsigned int  )22;
 sqlstm.sqhsts[0] = (         int  )22;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (         void  *)&pwd;
 sqlstm.sqhstl[1] = (unsigned int  )22;
 sqlstm.sqhsts[1] = (         int  )22;
 sqlstm.sqindv[1] = (         void  *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto errlogin;
}


	printf("\n\n............. CONNEXION  REUSSIE .............\n\n");
	 
	return;
errlogin:
	printf("\n\n............. ERREUR A LA CONNEXION .............\n\n");
	errpt();
	arret();
	exit();
}


/* affichage du menu general et lecture du choix */
travail()
{	
	int choix=0;
	
	/* on sort du while quand on tape 0 dans le menu */
	do
	{
		/* affichage du menu */
		menu();
		
		/* lecture du choix */
		/*asks("\n\n Votre choix : ", &choix);*/
		printf("\n\n Votre choix : ");
		scanf("%d", &choix);
		
		/* traitement en fonction du choix de l'utilisateur */
		switch(choix)
		{
			case 0:
			/* fin du programme */
			break;
			
			case 1:
			/* installation d'un nouveau logiciel */
			installer();
			break;
			
			case 2:
			/* re-installation d'un nouveau logiciel */
			re_installer();
			break;
			
			case 3:
			/* affichage des installations */
			travail_affich();
			break;
			
			default :
			/* choix de l'utilisateur erronne */
			printf("\n Choix errone. Recommencez SVP !!!");
			attendre();
		}
	}
	while(choix);
	
	return;
}

deconnexion()
{	
	printf("\n\n............. DECONNEXION .............\n\n");
	/* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

	/* EXEC SQL COMMIT WORK RELEASE; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 4;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )36;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


}

arret()	{
	/* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

	/* EXEC SQL ROLLBACK; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 4;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )51;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


	}

errpt()
	{
	printf("\n%.70s (%d)\n",sqlca.sqlerrm.sqlerrmc,-sqlca.sqlcode);
	}

int askn(text,variable)
char text[];
int *variable;
{
char s[20];

printf(text);
if (gets(s)==(char *)0)
   return (EOF);
*variable = atoi(s);
return(1);

}

int asks(text,variable)
char text[],variable[];
{
printf(text);
return(gets(variable)==(char *)0 ? EOF : strlen(variable));
}


/* menu de choix */			 
menu()
{
   	system("clear"); /* effacement de l'�cran */

	/* Menu de choix */
	printf("\n               GESTION DES INSTALLATIONS              \n\n");
	printf("  ***********************************************************\n");
	printf("  *  0. Quitter                                             *\n");
   	printf("  *  1. Installtion d'un nouveau logiciel                   *\n");
	printf("  *  2. Re-installtion d'un nouveau logiciel                *\n");
	printf("  *  3. Affichage des installations                         *\n");
   	printf("  ***********************************************************\n\n");

}

/* affichage du menu d'afficage des installations et lecture du choix */
travail_affich()
{	
	int choix=0;
	
	/* on sort du while quand on tape 0 dans le menu */
	do
	{
		/* affichage du menu d'affichage des installations */
		menu_affich();
		
		/* lecture du choix */
		/*asks("\n\n Votre choix : ", &choix);*/
		printf("\n\n Votre choix : ");
		scanf("%d", &choix);
		
		/* traitement en fonction du choix de l'utilisateur */
		switch(choix)
		{
			case 0:
			/* fin du programme */
			break;
			
			case 1:
			/* affichage par segment */
			affichage_segment();
			attendre();
			break;
			
			case 2:
			/* affichage par salle */
			affichage_salle();
			attendre();
			break;
			
					
			default :
			/* choix de l'utilisateur erronne */
			printf("\n Choix errone. Recommencez SVP !!!");
			attendre();
		}
	}
	while(choix);
	
	return;
}

/* menu d'affichage */			 
menu_affich()
{
   	system("clear"); /* effacement de l'�cran */
   	
	/* Menu d'affichage */
	printf("\n               AFFICHAGE DES INSTALLATIONS              \n\n");
	printf("  ***********************************************************\n");
	printf("  *  0. Retour menu principal                               *\n");	
	printf("  *  1. Affichage par segment                               *\n");
	printf("  *  2. Affichage par salle                                 *\n");
   	printf("  ***********************************************************\n\n");

}

/***********************************************/
/* TP12-1 : Installation d'un nouveau logiciel */
/***********************************************/
installer()
{
	int i_lecture; /* indicateur de lecture avec le FETCH */
	int reponse; /* reponse a la demande d'installation du log sur un poste */
	
	 /* effacement de l'�cran */
   	system("clear");
	
	/* vidage du tampon */
   	fflush(stdin);	
	numl.len=asks("\nEntrer le numero du logiciel (f/F pour quitter): ",numl.arr);
	
	while(numl.arr[0] != 'f' && numl.arr[0] != 'F')
	{
		/* verification du numero de logiciel */
		verif_log();
	
		/* vidage du tampon */
   		fflush(stdin);	
   	
		/* saisie des donnees */
		/* logiciel */
		noml.len=asks("\nEntrer le nom du logiciel : ",noml.arr);
		dateachat.len=asks("\nEntrer la date d'achat du logiciel : ",dateachat.arr);
		versionl.len=asks("\nEntrer la version du logiciel : ",versionl.arr);

		typel.len=asks("\nEntrer le type du logiciel : ",typel.arr);
		/* verification du type de logiciel */
		verif_typel();
			
		/* segment */
		numsegment.len=asks("\nEntrer le numero du segment : ",numsegment.arr);
		/* verification du numero de segment */
		verif_numsegment();
	
		/* debut de transaction */
		
		/* EXEC SQL WHENEVER SQLERROR GOTO erreur_sql; */ 

		/* EXEC SQL WHENEVER NOTFOUND GOTO non_trouve; */ 

								
		/* insertion */
		/* EXEC SQL INSERT INTO LOGICIEL VALUES (:numl, :noml, :dateachat, :versionl, :typel, 0); */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "insert into LOGICIEL values (:b0,:b1,:b2,:b3,:b4,0)";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )66;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&numl;
  sqlstm.sqhstl[0] = (unsigned int  )8;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&noml;
  sqlstm.sqhstl[1] = (unsigned int  )22;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (         void  *)&dateachat;
  sqlstm.sqhstl[2] = (unsigned int  )22;
  sqlstm.sqhsts[2] = (         int  )0;
  sqlstm.sqindv[2] = (         void  *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned int  )0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (         void  *)&versionl;
  sqlstm.sqhstl[3] = (unsigned int  )9;
  sqlstm.sqhsts[3] = (         int  )0;
  sqlstm.sqindv[3] = (         void  *)0;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned int  )0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqhstv[4] = (         void  *)&typel;
  sqlstm.sqhstl[4] = (unsigned int  )8;
  sqlstm.sqhsts[4] = (         int  )0;
  sqlstm.sqindv[4] = (         void  *)0;
  sqlstm.sqinds[4] = (         int  )0;
  sqlstm.sqharm[4] = (unsigned int  )0;
  sqlstm.sqadto[4] = (unsigned short )0;
  sqlstm.sqtdso[4] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode == 1403) goto non_trouve;
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		/* i_lecture indique si on a pu ou non lire avec le curseur */
		i_lecture=0; 
		
		/* ouverture du curseur */
		/* EXEC SQL OPEN c1; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = sq0001;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )101;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&typel;
  sqlstm.sqhstl[0] = (unsigned int  )8;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&numsegment;
  sqlstm.sqhstl[1] = (unsigned int  )17;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		/* on sort du while grace au NOTFOUND */
		while(1)
		{
			/* EXEC SQL FETCH c1 INTO :nump, :nomp; */ 

{
   struct sqlexd sqlstm;

   sqlstm.sqlvsn = 10;
   sqlstm.arrsiz = 5;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )124;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)0;
   sqlstm.sqhstv[0] = (         void  *)&nump;
   sqlstm.sqhstl[0] = (unsigned int  )9;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)&nomp;
   sqlstm.sqhstl[1] = (unsigned int  )22;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode == 1403) goto non_trouve;
   if (sqlca.sqlcode < 0) goto erreur_sql;
}


			
	 		/* on a pu lire au moins un tuple avec le curseur, on passe a 1 i_lecture */
			i_lecture = 1;
	
			do
			{
				/* vidage du tampon */
   				fflush(stdin);	
				printf("\nVoulez-vous installer le logiciel %10s sur le poste %10s ? \nVotre choix (1=Oui/0=Non) : ",noml.arr,nomp.arr);
				scanf("%d",&reponse);
			}
			while((reponse != 1) && (reponse != 0));
		
			if(reponse)
			{
				/* installation du logiciel sur le poste courant */
				/* EXEC SQL INSERT INTO INSTALLER VALUES (:nump, :numl, TO_DATE(SYSDATE), NULL, NULL); */ 

{
    struct sqlexd sqlstm;

    sqlstm.sqlvsn = 10;
    sqlstm.arrsiz = 5;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "insert into INSTALLER values (:b0,:b1,TO_DATE(sysdate ),n\
ull ,null )";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )147;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (         void  *)&nump;
    sqlstm.sqhstl[0] = (unsigned int  )9;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         void  *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqhstv[1] = (         void  *)&numl;
    sqlstm.sqhstl[1] = (unsigned int  )8;
    sqlstm.sqhsts[1] = (         int  )0;
    sqlstm.sqindv[1] = (         void  *)0;
    sqlstm.sqinds[1] = (         int  )0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqadto[1] = (unsigned short )0;
    sqlstm.sqtdso[1] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto non_trouve;
    if (sqlca.sqlcode < 0) goto erreur_sql;
}


			};		
			
			
		};
		
non_trouve :
		if(!i_lecture)
		{	
			printf("\nPas de poste correspondant au type %6s et au segment %15s .",typel.arr,numsegment.arr);
			printf("\n --------------------- ");
			attendre();
		}; 		
		/* EXEC SQL CLOSE c1; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )170;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		
		/* vidage du tampon */
   		fflush(stdin);
		/* nouvelle lecture */
		numl.len=asks("\nEntrer le numero du logiciel (f/F pour quitter): ",numl.arr);	
		continue;
		
erreur_sql :
		/* pour les autres cas d'erreur, la fonction se termine */
		errpt();
		arret();
		attendre();
		return;			
			
	}; /* fin while */
	
	/* validation de la transaction et sortie de la fonction */
	/* EXEC SQL COMMIT; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )185;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto erreur_sql;
}


	printf("\nTraitement realise.");
	attendre();
	
	/* retour a l'appelant */
	return;						
	

}

/* verification du numero de logiciel */
verif_log()
{
	/* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

	/* EXEC SQL WHENEVER NOTFOUND CONTINUE; */ 

	
	nb=0;
	
	/* EXEC SQL SELECT COUNT(*) INTO :nb
	FROM LOGICIEL
	WHERE N_LOG = :numl; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = "select count(*)  into :b0  from LOGICIEL where N_LOG=:b1";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )200;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&nb;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (         void  *)&numl;
 sqlstm.sqhstl[1] = (unsigned int  )8;
 sqlstm.sqhsts[1] = (         int  )0;
 sqlstm.sqindv[1] = (         void  *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


	
	while(nb!=0)
	{	
	
		system("clear");
		printf("\nLe numero de logiciel %6s est deja present !",numl.arr);
		/* vidage du tampon */
   		fflush(stdin);	
		numl.len=asks("\nEntrer le numero du logiciel :",numl.arr);
		
		/* EXEC SQL SELECT COUNT(*) INTO :nb
		FROM LOGICIEL
		WHERE N_LOG = :numl; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "select count(*)  into :b0  from LOGICIEL where N_LOG=:b1";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )223;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nb;
  sqlstm.sqhstl[0] = (unsigned int  )4;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&numl;
  sqlstm.sqhstl[1] = (unsigned int  )8;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}



	};
}

/* verification du type de logiciel */
verif_typel()
{
	/* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

	/* EXEC SQL WHENEVER NOTFOUND CONTINUE; */ 

	
	/* EXEC SQL SELECT COUNT(*) INTO :nb
	FROM TYPE
	WHERE TYP_LP = :typel; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = "select count(*)  into :b0  from TYPE where TYP_LP=:b1";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )246;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&nb;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (         void  *)&typel;
 sqlstm.sqhstl[1] = (unsigned int  )8;
 sqlstm.sqhsts[1] = (         int  )0;
 sqlstm.sqindv[1] = (         void  *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


	
	while(nb!=1)
	{	
	
		system("clear");
		printf("\nLe type de logiciel %6s est inconnu !",typel.arr);
		/* vidage du tampon */
   		fflush(stdin);	
		typel.len=asks("\nEntrer le type du logiciel : ",typel.arr);
		
		/* EXEC SQL SELECT COUNT(*) INTO :nb
		FROM TYPE
		WHERE TYP_LP = :typel; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "select count(*)  into :b0  from TYPE where TYP_LP=:b1";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )269;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nb;
  sqlstm.sqhstl[0] = (unsigned int  )4;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&typel;
  sqlstm.sqhstl[1] = (unsigned int  )8;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}



	};
}

/* verification du numero de segment */
verif_numsegment()
{
	/* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

	/* EXEC SQL WHENEVER NOTFOUND CONTINUE; */ 

	
	/* EXEC SQL SELECT COUNT(*) INTO :nb
	FROM SEGMENT
	WHERE N_SEGMENT = :numsegment; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = "select count(*)  into :b0  from SEGMENT where N_SEGMENT=:b1";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )292;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&nb;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (         void  *)&numsegment;
 sqlstm.sqhstl[1] = (unsigned int  )17;
 sqlstm.sqhsts[1] = (         int  )0;
 sqlstm.sqindv[1] = (         void  *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


	
	while(nb!=1)
	{	
	
		system("clear");
		printf("\nLe numero de segment %6s est inconnu !",numsegment.arr);
		/* vidage du tampon */
   		fflush(stdin);	
		numsegment.len=asks("\nEntrer le numero du segment : ",numsegment.arr);
		
		/* EXEC SQL SELECT COUNT(*) INTO :nb
		FROM SEGMENT
		WHERE N_SEGMENT = :numsegment; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "select count(*)  into :b0  from SEGMENT where N_SEGMENT=:b1";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )315;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nb;
  sqlstm.sqhstl[0] = (unsigned int  )4;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&numsegment;
  sqlstm.sqhstl[1] = (unsigned int  )17;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


	};
}

/******************************************/
/* TP12-2 : Re-installation d'un logiciel */
/******************************************/
re_installer()
{
	int i_lecture; /* indicateur de lecture avec le FETCH */
	int reponse; /* reponse a la demande d'installation du log sur un poste */
	
	 /* effacement de l'�cran */
   	system("clear");
	
	/* vidage du tampon */
   	fflush(stdin);	
	nums.len=asks("\nEntrer le numero de salle (f/F pour quitter): ",nums.arr);
	
	while(nums.arr[0] != 'f' && nums.arr[0] != 'F')
	{
		/* verification du numero de salle */
		verif_nums();
		
		/* debut de transaction */
		
		/* EXEC SQL WHENEVER SQLERROR GOTO erreur_sql; */ 

		/* EXEC SQL WHENEVER NOTFOUND GOTO non_trouve; */ 

										
		/* i_lecture indique si on a pu ou non lire avec le curseur */
		i_lecture=0; 
		
		/* ouverture du curseur */
		/* EXEC SQL OPEN c2; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = sq0002;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )338;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nums;
  sqlstm.sqhstl[0] = (unsigned int  )12;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		/* on sort du while grace au NOTFOUND */
		while(1)
		{
			/* EXEC SQL FETCH c2 INTO :nump, :numl, :dateinstall :i_dateinstall; */ 

{
   struct sqlexd sqlstm;

   sqlstm.sqlvsn = 10;
   sqlstm.arrsiz = 5;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )357;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)0;
   sqlstm.sqhstv[0] = (         void  *)&nump;
   sqlstm.sqhstl[0] = (unsigned int  )9;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)&numl;
   sqlstm.sqhstl[1] = (unsigned int  )8;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (         void  *)&dateinstall;
   sqlstm.sqhstl[2] = (unsigned int  )22;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         void  *)&i_dateinstall;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned int  )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode == 1403) goto non_trouve;
   if (sqlca.sqlcode < 0) goto erreur_sql;
}


			
			/* on a pu lire au moins un tuple avec le curseur, on passe a 1 i_lecture */
			i_lecture = 1;
			
			/* test de la date d'install inconnue */
			if(i_dateinstall==-1)
				strcpy(dateinstall.arr, "inconnue");
				
			do
			{
				/* vidage du tampon */
   				fflush(stdin);	
				printf("\nVoulez-vous re-installer le logiciel %6s", numl.arr);
				printf("\n installe le %10s sur le poste %6s ? \nVotre choix (1=Oui/0=Non) : ",dateinstall.arr,nump.arr);
				scanf("%d",&reponse);
			}
			while((reponse != 1) && (reponse != 0));
		
			if(reponse)
			{

				/* vidage du tampon */
   				fflush(stdin);	
   				
   				/* saisie des donnees */
   				probleme.len=asks("\nEntrer le libelle du probleme: ",probleme.arr);
				date_re_install.len=asks("\nEntrer la date de re-installation: ",date_re_install.arr);
				/* verification de la date saisie */
				verif_date_re_inst();
				
				/* re-installation du logiciel sur le poste courant */
				/* EXEC SQL UPDATE INSTALLER
				SET PROBLEME = :probleme, DATE_RE_INS = :date_re_install
				WHERE N_POSTE = :nump; */ 

{
    struct sqlexd sqlstm;

    sqlstm.sqlvsn = 10;
    sqlstm.arrsiz = 5;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "update INSTALLER  set PROBLEME=:b0,DATE_RE_INS=:b1 where \
N_POSTE=:b2";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )384;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (         void  *)&probleme;
    sqlstm.sqhstl[0] = (unsigned int  )17;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         void  *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqhstv[1] = (         void  *)&date_re_install;
    sqlstm.sqhstl[1] = (unsigned int  )22;
    sqlstm.sqhsts[1] = (         int  )0;
    sqlstm.sqindv[1] = (         void  *)0;
    sqlstm.sqinds[1] = (         int  )0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqadto[1] = (unsigned short )0;
    sqlstm.sqtdso[1] = (unsigned short )0;
    sqlstm.sqhstv[2] = (         void  *)&nump;
    sqlstm.sqhstl[2] = (unsigned int  )9;
    sqlstm.sqhsts[2] = (         int  )0;
    sqlstm.sqindv[2] = (         void  *)0;
    sqlstm.sqinds[2] = (         int  )0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqadto[2] = (unsigned short )0;
    sqlstm.sqtdso[2] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto non_trouve;
    if (sqlca.sqlcode < 0) goto erreur_sql;
}


				
			};		
			
			
		};
		
non_trouve :
		if(!i_lecture)
		{	
			printf("\nPas de poste installe dans la salle %6s.",nump.arr,nums.arr);
			printf("\n --------------------- ");
			attendre();
		}; 		
		/* EXEC SQL CLOSE c2; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )411;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		
		/* vidage du tampon */
   		fflush(stdin);
		/* nouvelle lecture */
		nums.len=asks("\nEntrer le numero de salle (f/F pour quitter): ",nums.arr);
		continue;
		
erreur_sql :
		/* pour les autres cas d'erreur, la fonction se termine */
		errpt();
		arret();
		attendre();
		return;			
			
	}; /* fin while */
	
	/* validation de la transaction et sortie de la fonction */
	/* EXEC SQL COMMIT; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )426;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto erreur_sql;
}


	printf("\nTraitement realise.");
	attendre();
	
	/* retour a l'appelant */
	return;						
	

}

/* verification du numero de salle */
verif_nums()
{
	/* EXEC SQL WHENEVER SQLERROR CONTINUE; */ 

	/* EXEC SQL WHENEVER NOTFOUND CONTINUE; */ 

	
	/* EXEC SQL SELECT COUNT(*) INTO :nb
	FROM SALLE
	WHERE N_SALLE = :nums; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = "select count(*)  into :b0  from SALLE where N_SALLE=:b1";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )441;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&nb;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (         void  *)&nums;
 sqlstm.sqhstl[1] = (unsigned int  )12;
 sqlstm.sqhsts[1] = (         int  )0;
 sqlstm.sqindv[1] = (         void  *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


	
	while(nb!=1)
	{	
	
		system("clear");
		printf("\nLe numero de salle %6s est inconnu !",nums.arr);
		/* vidage du tampon */
   		fflush(stdin);	
		nums.len=asks("\nEntrer le numero du salle :",nums.arr);
		
		/* EXEC SQL SELECT COUNT(*) INTO :nb
		FROM SALLE
		WHERE N_SALLE = :nums; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "select count(*)  into :b0  from SALLE where N_SALLE=:b1";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )464;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nb;
  sqlstm.sqhstl[0] = (unsigned int  )4;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&nums;
  sqlstm.sqhstl[1] = (unsigned int  )12;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}




	};
}

/* verification de la date saisie */
verif_date_re_inst()
{
	/* si la longueur de la date saisie est nulle, on affecte inconnue */
	if(date_re_install.len==0)
		strcpy(date_re_install.arr, "inconnue");
}

/************************************************/
/* TP12-3 : fonction de l'affichage par segment */
/************************************************/
affichage_segment()
{
   int test; /*vaut 0 si la table vide,1 si il y a au moins un tuple*/

   while(numsegment.len!=3)
   {
        /* vidage du tampon */
   	fflush(stdin);	
   	test=0;
   	
  	system("clear"); /* effacement de l'�cran */
  	
   	numsegment.len=asks("Entrer le numero de segment:",numsegment.arr);
   	verif_numsegment();
	 
	/* EXEC SQL WHENEVER SQLERROR GOTO erreur_sql; */ 

	/* EXEC SQL WHENEVER NOTFOUND GOTO non_trouve; */ 

	/* EXEC SQL OPEN c3; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = sq0003;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )487;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&numsegment;
 sqlstm.sqhstl[0] = (unsigned int  )17;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto erreur_sql;
}


	
	printf("\nN_POSTE\t\tN_LOG\t\tDATE_INS\tPROBLEME\tDATE_RE_INS\n");
	
	/* on sort du while grace au NOTFOUND*/
	while (1)
	{
		/* EXEC SQL FETCH c3 INTO :nump, :numl, :dateinstall :i_dateinstall,:probleme :i_probl,:date_re_install :i_datereins; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )506;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nump;
  sqlstm.sqhstl[0] = (unsigned int  )9;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&numl;
  sqlstm.sqhstl[1] = (unsigned int  )8;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (         void  *)&dateinstall;
  sqlstm.sqhstl[2] = (unsigned int  )22;
  sqlstm.sqhsts[2] = (         int  )0;
  sqlstm.sqindv[2] = (         void  *)&i_dateinstall;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned int  )0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (         void  *)&probleme;
  sqlstm.sqhstl[3] = (unsigned int  )17;
  sqlstm.sqhsts[3] = (         int  )0;
  sqlstm.sqindv[3] = (         void  *)&i_probl;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned int  )0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqhstv[4] = (         void  *)&date_re_install;
  sqlstm.sqhstl[4] = (unsigned int  )22;
  sqlstm.sqhsts[4] = (         int  )0;
  sqlstm.sqindv[4] = (         void  *)&i_datereins;
  sqlstm.sqinds[4] = (         int  )0;
  sqlstm.sqharm[4] = (unsigned int  )0;
  sqlstm.sqadto[4] = (unsigned short )0;
  sqlstm.sqtdso[4] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode == 1403) goto non_trouve;
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		/*positionnement du marqueur de fin de chaine*/
		
		nump.arr[nump.len]='\0';
		numl.arr[numl.len]='\0';
		dateinstall.arr[dateinstall.len]='\0';
		probleme.arr[probleme.len]='\0';
		date_re_install.arr[date_re_install.len]='\0';
		/*on a au moins un tuple donc la variable de test est positionnee a 1*/
		test=1;
		/*test de la date d'installation inconnue*/
		if(i_dateinstall == -1)
			strcpy(dateinstall.arr, "inconnue");
		
		
		/*test du probleme inconnue*/
		 if(i_probl == -1)
			strcpy(probleme.arr, "inconnue");
			
		/*test de la date de la reinstallation inconnue*/
		 if(i_datereins == -1)
			strcpy(date_re_install.arr, "inconnue");	
				
		/*affichage des donnees*/
		printf("\n%7s\t\t%7s\t%15s\t%15s\t%15s\n",nump.arr,numl.arr,dateinstall.arr,probleme.arr,date_re_install.arr);	
	 
	};
	return;
non_trouve :
	if (!test)
	{
		printf("\nPas de logiciel sur ce segment");
		printf("\n --------------------- \n");
	}; 		
	/* EXEC SQL CLOSE c3; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )541;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto erreur_sql;
}


	return;
		

erreur_sql :
	errpt();
	arret();
	exit();	
  };
}  


/*********************************************/
/* TP12-3 : fonction de l'affichage par salle*/
/*********************************************/
affichage_salle()
{
 int test; /*vaut 0 si la table vide,1 si il y a au moins un tuple*/

   while(nums.len!=12)
   {
      /* vidage du tampon */
   	fflush(stdin);	
   	test=0;
   	
   	system("clear"); /* effacement de l'�cran */
   	
   	nums.len=asks("Entrer le numero de la salle:",nums.arr);
   	verif_nums();
	 
	/* EXEC SQL WHENEVER SQLERROR GOTO erreur_sql; */ 

	/* EXEC SQL WHENEVER NOTFOUND GOTO non_trouve; */ 

	/* EXEC SQL OPEN c4; */ 

{
 struct sqlexd sqlstm;

 sqlstm.sqlvsn = 10;
 sqlstm.arrsiz = 5;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = sq0004;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )556;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (         void  *)&nums;
 sqlstm.sqhstl[0] = (unsigned int  )12;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         void  *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto erreur_sql;
}


	
	printf("\nN_POSTE\t\tN_LOG\t\tDATE_INS\tPROBLEME\tDATE_RE_INS\n");
	
	/* on sort du while grace au NOTFOUND*/
	while (1)
	{
		/* EXEC SQL FETCH c4 INTO :nump, :numl, :dateinstall :i_dateinstall,:probleme :i_probl,:date_re_install :i_datereins; */ 

{
  struct sqlexd sqlstm;

  sqlstm.sqlvsn = 10;
  sqlstm.arrsiz = 5;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )575;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)0;
  sqlstm.sqhstv[0] = (         void  *)&nump;
  sqlstm.sqhstl[0] = (unsigned int  )9;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)&numl;
  sqlstm.sqhstl[1] = (unsigned int  )8;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (         void  *)&dateinstall;
  sqlstm.sqhstl[2] = (unsigned int  )22;
  sqlstm.sqhsts[2] = (         int  )0;
  sqlstm.sqindv[2] = (         void  *)&i_dateinstall;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned int  )0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (         void  *)&probleme;
  sqlstm.sqhstl[3] = (unsigned int  )17;
  sqlstm.sqhsts[3] = (         int  )0;
  sqlstm.sqindv[3] = (         void  *)&i_probl;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned int  )0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqhstv[4] = (         void  *)&date_re_install;
  sqlstm.sqhstl[4] = (unsigned int  )22;
  sqlstm.sqhsts[4] = (         int  )0;
  sqlstm.sqindv[4] = (         void  *)&i_datereins;
  sqlstm.sqinds[4] = (         int  )0;
  sqlstm.sqharm[4] = (unsigned int  )0;
  sqlstm.sqadto[4] = (unsigned short )0;
  sqlstm.sqtdso[4] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode == 1403) goto non_trouve;
  if (sqlca.sqlcode < 0) goto erreur_sql;
}


		
		/*positionnement du marqueur de fin de chaine*/
		
		nump.arr[nump.len]='\0';
		numl.arr[numl.len]='\0';
		dateinstall.arr[dateinstall.len]='\0';
		probleme.arr[probleme.len]='\0';
		date_re_install.arr[date_re_install.len]='\0';
		/*on a au moins un tuple donc la variable de test est positionnee a 1*/
		test=1;
		/*test de la date d'installation inconnue*/
		if(i_dateinstall == -1)
			strcpy(dateinstall.arr, "inconnue");
		
		
		/*test du probleme inconnue*/
		 if(i_probl == -1)
			strcpy(probleme.arr, "inconnue");
			
		/*test de la date de la reinstallation inconnue*/
		 if(i_datereins == -1)
			strcpy(date_re_install.arr, "inconnue");	
				
		/*affichage des donnees*/
		printf("\n%7s\t\t%7s\t%15s\t%15s\t%15s\n",nump.arr,numl.arr,dateinstall.arr,probleme.arr,date_re_install.arr);	
	 
	};
	return;
non_trouve :
	if (!test)
	{
		printf("\nPas de logiciel dans cette salle");
		printf("\n --------------------- \n");
	}; 		
/* EXEC SQL CLOSE c4; */ 

{
struct sqlexd sqlstm;

sqlstm.sqlvsn = 10;
sqlstm.arrsiz = 5;
sqlstm.sqladtp = &sqladt;
sqlstm.sqltdsp = &sqltds;
sqlstm.iters = (unsigned int  )1;
sqlstm.offset = (unsigned int  )610;
sqlstm.cud = sqlcud0;
sqlstm.sqlest = (unsigned char  *)&sqlca;
sqlstm.sqlety = (unsigned short)0;
sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
if (sqlca.sqlcode < 0) goto erreur_sql;
}


	return;
	


erreur_sql :
	errpt();
	arret();
	exit();	
  };
}

/* fonction qui permet de faire une pause et d'attendre la saisie */
attendre()
{
   printf("\n Appuyez sur ENTREE pour continuer ...");
   fflush(stdin);
   while(getchar()!='\n');

}
