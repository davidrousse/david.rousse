/* TP12 - Modification de la table INSTALLER */
ALTER TABLE INSTALLER ADD(probleme VARCHAR(15),date_re_ins DATE); 
