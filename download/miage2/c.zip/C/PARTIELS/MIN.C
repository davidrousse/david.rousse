/**************************************************************************
*
* Nom du projet     : Partiel MIAGe langage C
* Objet 				  : conversion en minuscules
*
***************************************************************************
*
* R�pertoire                : C\partiels
* Nom du fichier            : min.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 04 / 11 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAXCAR 100

int M(int);

void main(void)
{
	int c, min;

   /* saisie */
   printf("Entrez un caractere:");
   c = getchar();

	/* conversion en minuscule */
   min = M(c);

   /* resultat */
  	printf("\n%c en minuscule: %c", c, min);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();
   getchar();
}

/*
************************************************************
* NOM : M
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : convertit en minuscule
*
* SYNTAXE : min = M(c);
************************************************************
*/
int M(int c)
{
	if((c>='A') && (c<='Z'))
   	return (c-'A'+'a');
   else
   	return c;
}


