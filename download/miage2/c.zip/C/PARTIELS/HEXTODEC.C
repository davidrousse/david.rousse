/**************************************************************************
*
* Nom du projet     : Partiel MIAGe langage C
* Objet 				  : convertit un nombre en hexa en un decimal
*
***************************************************************************
*
* R�pertoire                : C\partiels
* Nom du fichier            : hextodec.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 23 / 09 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAXCAR 8

int htoi(char *);

void main(void)
{
   int valeur;
	char *s;

   /* allocation */
   s = (char *)malloc(MAXCAR * sizeof(char));
   if(s==NULL)
   	puts("\nMemoire insuffisante !"), exit(1);

   /* saisie */
   printf("Entrez un nombre en hexadecimal:");
   scanf("%s", s);

	/* conversion */
   valeur = htoi(s);

   /* resultat */
  	printf("\nLe nombre en base 10 vaut: %d", valeur);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();
   getchar();
}

/*
************************************************************
* NOM : htoi
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : convertit un hexadecimal en un nombre en base 10
*
* SYNTAXE : valeur = htoi(nombre);
************************************************************
*/
int htoi(char *s)
{
	int retour=0, exp, i, valeur;

   exp = strlen(s)-1; /* on recupere la longueur du nombre hexadecimal */

   for(i=0;i<strlen(s);i++)
   {
   	switch(s[i])
      {
       	case '0': valeur=0; break;
         case '1': valeur=1; break;
      	case '2': valeur=2; break;
         case '3': valeur=3; break;
      	case '4': valeur=4; break;
      	case '5': valeur=5; break;
      	case '6': valeur=6; break;
      	case '7': valeur=7; break;
      	case '8': valeur=8; break;
      	case '9': valeur=9; break;
      	case 'a':
      	case 'A': valeur=10; break;
      	case 'b':
      	case 'B': valeur=11; break;
      	case 'c':
      	case 'C': valeur=12; break;
      	case 'd':
      	case 'D': valeur=13; break;
      	case 'e':
      	case 'E': valeur=14; break;
      	case 'f':
      	case 'F': valeur=15; break;
         default:
         {
         	retour=NULL;printf("\n!!!Erreur de conversion!!!");exit(1);
			   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   			getchar();getchar();
         }
      }

      /* conversion en decimal */
      retour+=valeur*pow(16,exp--);
   }

   return retour;
}


