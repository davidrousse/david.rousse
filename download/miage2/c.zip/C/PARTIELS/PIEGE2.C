/**************************************************************************
*
* Nom du projet     : Partiel MIAGe langage C
* Objet 				  : piege a eviter en C
*
***************************************************************************
*
* R�pertoire                : C\partiels
* Nom du fichier            : piege1.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 04 / 11 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h> /* utile dans ce programme pour exit() */
#include <alloc.h>  /* utile dans ce programme pour malloc() */

#define message "Entrez votre chaine:"

void main(void)
{
	char *lecture;

   lecture = (char *)malloc(100*sizeof(char));
   if(lecture==NULL)
   	puts("\Memoire insuffisante !"), exit(1);

	puts(message);

   scanf("%s", lecture);

   fflush(stdin);

   printf("\nVotre chaine: %s", lecture);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();

}
