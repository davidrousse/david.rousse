/**************************************************************************
*
* Nom du projet     : Partiel MIAGe langage C
* Objet 				  : piege a eviter en C
*
***************************************************************************
*
* R�pertoire                : C\partiels
* Nom du fichier            : piege1.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 04 / 11 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>

float f(float,float);

void main(void)
{
	float i=8., j=4., r, s;

   r = f(i,j);
   s = f(i,j);

   /* resultat */
  	printf("\nValeurs:%f %f\nResultats: %2.2f %2.2f", i, j, r, s);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();
}

/*
************************************************************
* NOM : f
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION : pieges en C...
*
* SYNTAXE : nb = f(i,j);
************************************************************
*/
float f(float a, float b)
{
	static int c=3;

   switch(c)
   {
   	case 3: c=(b++)*a+(c++);
      default: c=(b++)*(--a)-c;
   }
   return c;
}


