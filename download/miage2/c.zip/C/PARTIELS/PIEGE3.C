/**************************************************************************
*
* Nom du projet     : Partiel MIAGe langage C
* Objet 				  : piege a eviter en C
*
***************************************************************************
*
* R�pertoire                : C\partiels
* Nom du fichier            : piege3.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 04 / 11 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>

void f(char *);
void g(char **);

void main(void)
{
	char texte[]="liste", *mot="arbre";

	f(texte);
   printf("\n %s", texte); /* imprime: l */

	g(&mot);
   printf("\n %s", mot); /* imprime: file */

/* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();

}

void f(char *c)
{
	c++;    /* on incremente l'adresse du parametre c et non le pointeur */
   		  /* constant texte de main()												*/

   *c = 0; /* attention ici, 0 entier sera convertit en 0 caractere 		*/
   	     /* cad en \0 qui represente le marqueur de fin de chaine 		*/
}

void g(char **p)
{
	*p = "file"; /* l'element point� par p, cad le pointeur mot est modifie */
   				 /* en d'autres termes, on chaine la valeur du pointeur		*/
                /* mot de main()															*/
}
