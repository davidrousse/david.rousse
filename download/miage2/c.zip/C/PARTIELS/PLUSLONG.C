/**************************************************************************
*
* Nom du projet     : Partiel MIAGe langage C
* Objet 				  : recherche le mot le plus long d'un texte tap� au clavier
*
***************************************************************************
*
* R�pertoire                : C\partiels
* Nom du fichier            : motlong.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 04 / 11 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXCAR 25 /* longueur maxi d'un mot */
#define MAXMOT 50 /* nombre maxi de mot du texte */

void main(void)
{
	char **s, tampon[MAXCAR];
   int nbmot=0, pluslong, max=0, i;

   /* allocation */
   s = (char **)malloc(MAXMOT * sizeof(char *));
   if(s==NULL)
   	puts("\nMemoire insuffisante !"), exit(1);

   /* saisie */
   printf("Entrez le texte (les separateurs sont ' ', tab et entree):\n");
   scanf("%s", tampon);
   while(strcmp(tampon, "FIN") && (nbmot<MAXMOT))
   {
	   /* allocation */
   	s[nbmot] = (char *)malloc((strlen(tampon)+1) * sizeof(char));
   	if(s[nbmot]==NULL)
   		puts("\nMemoire insuffisante !"), exit(1);

      strcpy(s[nbmot++], tampon); /* stockage du mot tap� */

   	scanf("%s", tampon); /* nouvelle lecture */
   }

	/* recherche du mot le plus long */
   pluslong = strlen(s[0]);
	for(i=1;i<nbmot;i++)
   	if(strlen(s[i])>pluslong)
      {
      	max = i; /* on recupere l'indice du mot le plus long */
         pluslong = strlen(s[i]); /* longueur du mot le plus long */
      }

   /* resultat */
  	printf("\nLe mot le plus long est : %s", s[max]);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();
   getchar();
}
