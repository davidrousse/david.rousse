/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Tri de chaine de caracteres.
*
***************************************************************************
*
* R�pertoire                : rousse\ptrchar
* Nom du fichier            : ptrchar.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE - Dimitri NESTY
* Date de creation          : 02 / 11 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <alloc.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define LMAX 50 /* longueur maximale d'un chaine */
#define NBLIGNEMAX 20 /* nombre maximum de lignes */

/* prototypes */
void tri(char **, int);
void minuscule(char *);

main()
{
	char *p_mots[NBLIGNEMAX], motcourant[LMAX];
   int compteur=0, i; /* compte le nombre de chaines saisies */

   /* lecture et stockage de l'ensemble des mots */
   printf("\nSaisir des chaines. Fin de la saisie par FIN ...\n");
   printf("\nEntrez la chaine numero %d (maximum", compteur+1);
   printf("%d chaines): ", NBLIGNEMAX);
   scanf("%s", motcourant);
   while(strcmp(motcourant, "FIN") && (compteur<NBLIGNEMAX))
   {
		/* allocation memoire et stockage */
		p_mots[compteur]=(char *)malloc(strlen(motcourant)+1 * sizeof(char));

      minuscule(motcourant);
      strcpy(p_mots[compteur], motcourant);

  		compteur++;

      /* nouvelle lecture */
   	printf("\nEntrez la chaine numero %d (maximum", compteur+1);
   	printf("%d chaines): ", NBLIGNEMAX);
   	scanf("%s", motcourant);

   }

   /* tri des chaines par ordre alphabetiques */
   tri(p_mots, compteur);

   /* affichage des donnees */
	printf("\nDonnees triees:");
   for(i=0;i<compteur;i++)
   	printf("\nChaine %d :%s", i+1, p_mots[i]);

}

/************************************************************
* NOM : tri
* INDICE : 0
* AUTEUR : David Rousse - Dimitri NESTY
* DESCRIPTION : tri de chaines de caracteres en appliquant le tri shaker
*
* SYNTAXE : tri(p_mots, compteur);
************************************************************
*/
void tri(char *p_mot[], int nbvaleurs)
{
	int i, j;
   char *min, tmp[LMAX];
   for (i=0; i<nbvaleurs-1; i++)
   {	min=p_mot[i];

      for(j=i+1; j<nbvaleurs; j++)
      {
      	if (strcmp(p_mot[j],min)<0)
             min=p_mot[j];
      }
      strcpy(tmp, min);
      strcpy(min, p_mot[i]);
      strcpy(p_mot[i], tmp);
    }
}

/************************************************************
* NOM : minuscule
* INDICE : 0
* AUTEUR : David Rousse - Dimitri NESTY
* DESCRIPTION : convertit un tableau en minuscules
*
* SYNTAXE : minuscule(tab);
************************************************************
*/
void minuscule(char motcourant[])
{
	int i;

   for(i=0; i<=strlen(motcourant); i++)
   	motcourant[i]=tolower(motcourant[i]);
}

