/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : affiche ts les nb 1� compris entre 2 bornes entieres
***************************************************************************
*
* R�pertoire                : miage\nbpremier
* Nom du fichier            : nbpremier.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE - Dimitri NESTY
* Date de creation          : 05 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void main(void)
{
	unsigned int liminf, limsup, Q, R, D=3, crlf=0, i;

   printf("Entrez les bornes...");
	/* limite inferieure */
   printf("\nBorne inferieur:");
 	scanf("%d", &liminf);

	/* limite superieure */
   do
   {
      printf("\nBorne superieure:");
   	scanf("%d", &limsup);
   }
   while(limsup<=liminf);

   /* calcul et affichage */
   printf("\nNombres premiers dans [%d; %d]:\n", liminf, limsup);

   /* premier pair */
   if(liminf <= 2)
   {
   	printf("\n  2 "); /* 2 est le seul nombre premier pair */
      crlf++;
      liminf = 3;
   }
   else
   {
   	if(liminf%2 == 0) /* premier impair suivant liminf */
      	liminf++;
   }

   /* premiers impairs */
	for(i=liminf; i<=limsup; i+=2)
   {
	   Q = i / D;
   	R = i % D;
   	while((Q!=D) && (R!=0))
      {
			D+=2; /* divideur impair suivant */
         Q = i / D;
		   R = i % D;
      }

   	if((R==0) && (Q<D)) /* R=0 */
   	{
   		printf("%3d ", i);
      	if(++crlf%10 == 0) /* retour a la ligne tous les 10 chiffres */
      		printf("\n");
   	}

      D = 3;
   }

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar(); /* vide le tampon */
   getchar();

}







