/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : convertit un nb fractionnaire en binaire.
*							 !!! Le point est le separateur decimal !!!
***************************************************************************
*
* R�pertoire                : miage\fractobin
* Nom du fichier            : fractobin.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE - Dimitri NESTY
* Date de creation          : 05 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAXENT 20 /* constante partie entiere */
#define MAXFRAC 20 /* constante partie decimale */

int dimension;

int *tobin(int nb)
{
	int *reste, i, taille, Q;
   extern dimension;

   Q = nb;

   /* allocation de memoire */
   taille = sizeof(int) * MAXENT;
   reste = (int *)malloc(taille);
   if(reste == NULL)
   	puts("\nMemoire insuffisante !"), exit(1);

   for(i=0; (i<taille) && (Q>0) ; i++)
   {
   	reste[i] = Q % 2;
      Q = Q / 2;
   }

   dimension = i-1;

   return reste;
}

int *todec(double nombre)
{
	int *tab, i, taille;

   /* allocation de memoire */
   taille = sizeof(int) * MAXFRAC;
   tab = (int *)malloc(taille);
   if(tab == NULL)
   	puts("\nMemoire insuffisante !"), exit(1);

   /* conversion de decimal vers binaire */
   for(i=0; i<MAXFRAC; i++)
	{
      nombre = nombre*2;

      if(nombre<1.0)
      	tab[i] = 0;
      else
      {
      	tab[i] = 1;
         nombre = nombre-1.0;
      }
   }

   return tab;
}


main(void)
{
   char signe; /* + si nombre positif, - si nombre negatif */
	int partent, *resent, *resdec, i;
   double nombre, partdec;
   extern dimension;

	printf("Entrez le nombre a convertir en binaire: ");
   scanf("%lf", &nombre);

   /* r�cuperation du signe */
   if(nombre<0)
   	signe = '-';
   else
   	signe = '+' ;

   nombre = fabs(nombre);

   /* recuperation partie entiere et decimale */
   partent = nombre; /* partie entiere */
   partdec = nombre - partent; /* partie decimale */

   /* conversion en binaire de la partie entiere */
   resent = tobin(partent); /* la fonction tobin ne travaille que */
   									/* sur des nombres >= 0					*/

   /* conversion en binaire de la partie decimale*/
	resdec = todec(partdec);

   /* affichage du resultat */
   printf("\n\Le nombre fractionnaire en base 2 vaut:\n\n");
   printf(" %c ",signe);

	/* impression partie entiere */
   if(!partent)
   	printf("0"); /* partie entiere nulle */
   else
   	for(i=dimension; i>=0; i--)
   		printf("%d", resent[i]);

   printf(" , ");

	/* impression partie decimale */
   for(i=0;i<MAXFRAC;i++)
   	printf("%d", resdec[i]);

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar(); /* vide le tampon */
   getchar();

}







