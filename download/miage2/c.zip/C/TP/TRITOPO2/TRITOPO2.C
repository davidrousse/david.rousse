/**************************************************************************
*
* Nom du projet     : Tri topologique d'un graphe G
* Objet 				  : Utilise la propri�t� "G est sans circuit =>il existe
*							 un sommet sans pr�c�dent".
*							 On essaie donc de vider le graphe � partir de la
*							 liste d'adjacence (ensemble des successeurs
*							 de chaque sommets).
*							 Pour vider le graphe, on cherche un sommet qui ne
*							 figure pas dans la liste des successeurs (cad qui
*							 n'a pas de predecesseur dans le graphe), on le
*							 supprime de la liste d'adjacence et on l'ajoute
*							 a l'ordre topologique, etc..., jusqu'a ne plus avoir
*							 de successeurs.
*							 Si on arrive � le vider, on sait qu'il n'y avait pas
*							 de circuit et on obtient un ordre topologique des
*							 sommets
*							 On attend en entr�e un nom de fichiers du type:
*							  2	 1
*							  3	 1
*							  5	 3
*							  etc...
*							  ou (2;1) est un arc du sommet 2 au sommet 1
*							  On accepte des noms de sommets num�riques
*							  entiers seulement
*
***************************************************************************
*
* R�pertoire                : C\tritopo2
* Nom du fichier            : tritopo2.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 28 / 09 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define VIDE (-1) /* sommet sans predecesseur */
#define NONPRESENT (-2) /* sommet non present dans le graphe G */

/* d�finition des structures pour la representation de G */
typedef struct Arc
		  {
        		int num; /* numero du sommet */
            struct Arc *suiv; /* adresse d'un autre sommet */
        } arc;

typedef struct Sommet
		  {
        		int degre; /* nombre de predecesseur du sommet */
            arc *allsuiv; /* liste des successeurs du sommet */
        } sommet;

/* variable globale */
int *liste; /* contiendra la liste des sommets par ordre topologique */

/*
************************************************************
* NOM : creerliste
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    cree la liste d'adjacence directe d'un graphe
*
* SYNTAXE : creerliste(nombresommet, graphe);
************************************************************
*/
void creerliste(FILE *fp, sommet *s, int min)
{
   /* variables du bloc */
   int S1, S2, i, j;
   arc *a;

   /* on lit le fichier en entier pour construire la liste d'adjacence */
   while(fscanf(fp, "%d %d", &S1, &S2) == 2)
   {
   	i = S1 - min; /* evite de stocker des numeros de sommets eleves */
      j = S2 - min;

      /* on marque la presence des sommets      */
      /* quand on les rencontre pour la 1� fois */
      if(s[i].degre == NONPRESENT)
      	s[i].degre = 0;
		if(s[j].degre == NONPRESENT)
      	s[j].degre = 0;

      /* on alloue la memoire pour prendre en compte l'arc (i;j) lu */
      a = (arc *)malloc(sizeof(arc));
      if(a == NULL) /* arret du programme */
      	puts("\nMemoire insuffisante !"), exit(1);

      a->num = j; /* j est l'extremite finale de l'arc */
      a->suiv = s[i].allsuiv; /* on insere en tete l'adresse du sommet j */
      s[i].allsuiv = a;       /* par ces 2 lignes								 */
      s[j].degre++; /* j possede i comme predecesseur */

   }
}

/*
************************************************************
* NOM : affichedico
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    affiche la liste d'adjacence directe d'un graphe
*
* SYNTAXE : affichedico(nombresommet, minimum, graphe);
************************************************************
*/
void affichedico(int nb, int min, sommet *s)
{
	char touche;
   int i;
   arc *p;

	printf("\nListe d'adjacence directe du graphe:\n");

   for(i=0;i<nb;i++)
   {
   	if(s[i].degre != NONPRESENT)
      {
      	printf("\nSommet: %d, nb de precedent(s): %d", i+min, s[i].degre);

         p = s[i].allsuiv;
        	while(p != NULL)
         {
          	printf("\n\t---> %d", p->num+min);
            p = p->suiv;
         }
      }
   }
   printf("\n\nAppuyer sur la touche ENTREE pour continuer...");
   getchar();
   while((touche = getchar()) != '\n');
}

void main(void)
{
	FILE *fp;
   char nomfic[51];
   int S1, S2, min, max, nbsommet, sommettraite, sommetsuivant;
   int i, k, cherche, courant=0;
   sommet *s;
   arc *p;

   /* demande du nom de fichier en entr�e */
   printf("Entrez le nom du fichier (nom.extension): ");
   scanf("%50s", nomfic);

   /* ouverture du fichier */
   fp = fopen(nomfic, "r");
   if(fp == NULL) /* arret du programme */
   	puts("\nImpossible d'ouvrir le fichier !!!"),exit(1);

   /* recherche des num�ros de sommets les plus �l�v�s */
   fscanf(fp, "%d %d", &S1, &S2);
   if(S1<S2)
   {
      min = S1;
      max = S2;
   }
   else
   {
      min = S2;
      max = S1;
   }
   while(fscanf(fp, "%d %d", &S1, &S2) == 2)
   {
   	/* on r�cup�re le plus petit et le plus grand */
      if(S1<S2)
      {
         if(S1<min)
         	min = S1;
         if(S2>max)
         	max = S2;
      }
      else
      {
         if(S2<min)
         	min = S2;
         if(S1>max)
         	max = S1;
      }
   }
   fclose(fp);

   /* on cr�e la liste d'ajacence directe du graphe */
   /* cad que pour chaque sommet, on cherche ses    */
   /* successeurs											 */
   nbsommet = max - min + 1;

   /* allocation de la memoire pour le graphe */
   s = (sommet *)malloc(nbsommet * sizeof(sommet));
   if(s == NULL) /*arret du programme */
   	puts("\nMemoire insuffisante !"),exit(1);

   /* allocation de la memoire pour la liste des sommets a afficher*/
   liste = (int *)malloc(nbsommet * sizeof(int));
	if(liste == NULL) /*arret du programme */
   	puts("\nMemoire insuffisante !"),exit(1);

   /* initialisation */
   for(i=0;i<nbsommet;i++)
   {
   	s[i].degre = NONPRESENT;
      s[i].allsuiv = NULL;
      liste[i] = VIDE;
   }


   /* creation de la liste */
   fp = fopen(nomfic, "r");
   creerliste(fp, s, min);
   fclose(fp);

	/* affichage de la liste d'adjacence directe de G */
   affichedico(nbsommet, min, s);

   /*************************************************************************/
   /* noyau reel du traitement 													  		 */
   /*************************************************************************/
   /* recherche des sommets qui n'ont pas de predecesseurs */
   /* cad des sommets dont le degre vaut 0					  */
   for(i=0; i<nbsommet; i++)
   {
   	if(s[i].degre == 0) /* le sommet n'a pas de predecesseur */
      {
      	s[i].degre = VIDE; /* on indique que le sommet a ete compte */
         liste[courant++] = i; /* on recupere le sommet */
         cherche = i; /* on commencera a eliminer les sommets depuis cherche */
      }
   }
   /* a la sortie, on sait par ou commencer la suppression    */
   /* on va parcourir G en partant du sommet d'indice cherche */

	/* on parcours le graphe en entier */
   for(i=0; i<nbsommet; i++)
   {

      /* on commence au 1� sommet existant */
      while(s[i].degre == NONPRESENT)
      	i++;

		/* si il n'existe pas de sommet sans predecesseur alors            */
      /* que le graphe n'est pas vide, il y a un cycle et donc           */
      /* on interrompt le programme en indiquant la presence de ce cycle */
      if(cherche == VIDE)
      	puts("\n!!! Le graphe comporte un CYCLE !!!\n"), exit(1);

      /* on reduit le dregre d'attachement des suivants immediats du sommet */
      /* d'indice cherche et si ce dregre devient nul, on ajoute le sommet  */
      /* en question a la liste contenant l'ordre topologique. Enfin, on    */
      /* supprime les arcs correspondants												 */

      sommettraite = cherche;

 	   p = s[sommettraite].allsuiv;

      sommetsuivant = courant;

      while(p != NULL)
      {
         k = p->num;
      	s[k].degre--; /* reduction du degre du sommet k */
         if(s[k].degre == 0)
         {
            liste[courant++] = k; /* on ajoute le sommet a l'ordre topo */
         }
         s[sommettraite].allsuiv = p->suiv;
         free(p);
         p = s[sommettraite].allsuiv;
      }

      /* mise a jour de la liste des sommets classes par ordre topo */
      if(sommetsuivant!=courant)
      	cherche = liste[sommetsuivant];
      else
      	cherche = liste[courant-1];

   }
   /*************************************************************************/
   /* fin reelle du traitement 																	 */
   /*************************************************************************/

   /* affichage du resultat */
  	i = 0;
   clrscr(); /* effacement de l'ecran */
   printf("\nSommets du graphe affiches par ordre topologique:\n");
  	while(i != nbsommet)
   {
      if(liste[i] != VIDE)
	     	printf("\n Niveau %d :\t%5d", i, liste[i]+min);

      i++;
   }

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();

}

