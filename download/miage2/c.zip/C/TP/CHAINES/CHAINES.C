#include <stdio.h>
#include <string.h>

main()
{
	char c, d;
   int i = 2;

   char string[5], *str;

   char nom[8]="Isabelle", pc[7]={'I','B','M'};

   c = "J'aime le C" [i++]; // c recoit a puis on incremente i
   d = "J'aime le C" [++i]; // on incremente i et d recoit m

   printf("%c %c \n", c, d); // affiche a m

   c = 'A';
   str = "12345";

   strcpy(string, str);

   i = c;

   printf("%s %s %d\n", str, string, i); // imprime 12345 65
   pc[0]='G';
   printf("\n%s", nom);
}
