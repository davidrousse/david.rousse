/**************************************************************************
*
* Nom du projet     : Tri d'un fichier
* Objet 				  : Tri du fichier en utilisant la m�thode de tri
*							 par fusion simple.
*							 Les fichiers en entr�e et en sortie seront de type
*							 texte et leurs noms seront donn�s avec l'extension
*
***************************************************************************
*
* R�pertoire                : C\Fusion
* Nom du fichier            : trifus.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 20 / 09 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>

#define LNTMP 100

/* variables globales */
int nbmono;
FILE *f, *fa, *fb;
char fictmp[LNTMP], fictmpa[LNTMP], fictmpb[LNTMP]; /* fichiers binaires  */
																	 /* et temporaires     */


/*
************************************************************
* NOM : copiemono
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    copie une monotonie de ficent vers ficsort
*
* SYNTAXE : copiemono(fichent, fichsort, valeur);
* N.B. :  On rappelle les param�tres des fonctions utilis�es
*
*	size_t fread(void *ptr, size_t size, size_t n, FILE *stream);
*	o� la fonction lit sur l'entr�e stream n caract�res de taille
*  respective size et stocke dans la zone m�moire point� par ptr
*
*	size_t fwrite(const void *ptr, size_t size, size_t n, FILE *stream);
*
************************************************************
*/
void copiemono(FILE *ficent, FILE *ficsort, int *psuiv)
{
	int prec; /* r�cup�re le dernier entier �crit */

   do
   {
      fwrite(psuiv, sizeof(int), 1, ficsort);
      prec = *psuiv;
      fread(psuiv, sizeof(int), 1, ficent);
   }
   while( !(feof(ficent) || *psuiv < prec)); /* tant que on n'est pas  */
   /* � la fin du fichier et que le suivant est sup�rieur au pr�cedent */

   nbmono++;
}

/*
************************************************************
* NOM : divise
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    �crit dans fa et fb les monotonies de f
*
* SYNTAXE : divise();
************************************************************
*/
void divise(void)
{
   int x;

   freopen(fictmp, "rb", f); /* on redirige le flux de lecture sur f vers */
   /* fictmp cad que l'on on �crira dans f, les donn�es seront �crites    */
   /* dans fictmp																			  */
	freopen(fictmpa, "wb", fa);
   freopen(fictmpb, "wb", fb);

   fread(&x, sizeof(int), 1, f);
   while(!feof(f))
   {
   	copiemono(f, fa, &x);

      /* si on atteind la fin du fichier � r�partir */
      /* la r�partition est termin�e ! 				 */
      if(feof(f)) break;

      copiemono(f, fb, &x);
   }
}

/*
************************************************************
* NOM : fusionne
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    fusionne les fichiers fa et fb dans f
*
* SYNTAXE : fusionne();
************************************************************
*/
void fusionne(void)
{
	int a, b, prec;

   nbmono = 0;

  	freopen(fictmp, "wb", f);
	freopen(fictmpa, "rb", fa);
   freopen(fictmpb, "rb", fb);

   fread(&a, sizeof(int), 1, fa);
   fread(&b, sizeof(int), 1, fb);

   while(!feof(fa) &&!feof(fb))
   {
   	if (a<b)
      {
         fwrite(&a, sizeof(int), 1, f);
         prec = a;
         fread(&a, sizeof(int), 1, fa);
         if (feof(fa) || a<prec)
         	copiemono(fb, f, &b);
      }
      else
      {
         fwrite(&b, sizeof(int), 1, f);
         prec = b;
         fread(&b, sizeof(int), 1, fb);
         if (feof(fb) || b<prec)
         	copiemono(fa, f, &a);
      }
   } /* fin tant que */

   /* copie des monotonies restants le cas �ch�ans */
	while(!feof(fa)) copiemono(fa, f, &a);
	while(!feof(fb)) copiemono(fb, f, &b);

}

/*
************************************************************
* NOM : trifus
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    coeur r�el du tri par fusion
*
* SYNTAXE : trifus();
************************************************************
*/
void trifus(void)
{
	do
   {
   	divise();
      fusionne();
   }
   while (nbmono>1);
}

/*
************************************************************
* NOM : copyright
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    affiche un message de copyright...
*
* SYNTAXE :  copyright();
************************************************************
*/
void copyright(void)
{
	printf("\n --- Copyright David Rousse 1999 --- \n");
}

/*
************************************************************
* NOM : main
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    d�monstration du tri par fusion simple
*
************************************************************
*/
main()
{
	/* d�clarations */
   char ficsource[41], ficsortie[41]; /* noms des fichiers � demander */
   											  /* � l'utilisateur					 */
   FILE *pfsource, *pfsortie;
   int x, i=0;

   /* message initial */
   printf("---------------------------------------\n\n");
   printf("Tri par fusion simple d'un fichier.\n");
	printf("Donner les noms de fichiers texte avec l'extension et\n");
   printf("le chemin d'acces s'ils ne sont pas dans le repertoire courant.\n");
	printf("\n---------------------------------------\n\n");

   /* saisie des noms de fichiers */
   printf("Fichier source: ");
   scanf("%40s",ficsource);
   printf("\nFichier sortie: ");
   scanf("%40s",ficsortie);

	/* cr�ation des noms des fichiers temporaires */
   tmpnam(fictmp);
   tmpnam(fictmpa);
   tmpnam(fictmpb);

   /* ouverture du fichier source */
   pfsource = fopen(ficsource, "r");
   if (pfsource == NULL) /* arr�t du programme */
   	puts ("Erreur lors de l'ouverture du fichier source !!!"), exit (1);

   /* ouverture des fichiers temporaires */
   f = fopen(fictmp, "wb");
   fa = fopen(fictmpa, "wb");
   fb = fopen(fictmpb, "wb");
   if (f == NULL || fa == NULL || f == NULL) /* arr�t du programme */
   	puts ("Erreur lors de l'ouverture des fichiers temporaires !"), exit (1);

   /* conversion fichier texte vers fichier binaire */
   while( fscanf(pfsource, "%d", &x) > 0)
   	fwrite(&x, sizeof(int), 1, f);

   /* fermeture fichier source */
   fclose(pfsource);

   /*************************/
   /* TRI PAR FUSION SIMPLE */
   trifus();

	/* fermeture et destruction des fichiers */
   fclose(fa);
   remove(fictmpa);
   fclose(fb);
   remove(fictmpb);

   /* ouverture du fichier de sortie */
   pfsortie = fopen(ficsortie, "w");
   if (pfsortie == NULL) /* arr�t du programme */
   	puts ("Erreur lors de l'ouverture du fichier de sortie !!!"), exit (1);

   /* conversion fichier binaire vers fichier texte */
   freopen(fictmp, "rb", f);

   while(fread(&x, sizeof(int), 1, f) > 0 )
   {
      fprintf(pfsortie, "%d ", x);
      i++;
      if (i == 10)
      {
      	fprintf(pfsortie, "\n");  /* 10 nombres par lignes */
         i = 0;
      }
   }

	/* fermeture et destruction du fichier temporaire restant */
   fclose(f);
   remove(fictmp);

   /* message de fin */
   copyright();

   return 0;
}

