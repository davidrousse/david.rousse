/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Compte le nombre de caract�res, de lignes
*							 et de colonnes dans un fichier texte donn� en entr�e.
*							 Les s�parateurs de mots sont la tabulation,
*							 le retour chariot et l'espace.
***************************************************************************
*
* R�pertoire                : C\cpttxt
* Nom du fichier            : cpttxt.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 22 / 09 /1997
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>

#define VRAI 1
#define FAUX 0

void main(void)
{
	long nc=0L; /* nombre de caract�res */
   int nl=0, nm=0, mot=FAUX; /* nombre de lignes, mots   */
   						        /* et indicateur pour 1 mot */
   char car='\o', nomfic[51];
   FILE *fp;

   /* lecture du fichier source */
   printf("Entrez le nom du fichier texte (chemin+nom.extension): ");
   scanf("%50s", nomfic);
   /* ouverture du fichier */
   fp = fopen(nomfic, "r");
   if(fp == NULL) /* arret du programme */
   	puts("Impossible d'ouvrir le fichier source !!!"),exit(1);

   /* lecture compl�te du fichier jusqu'� EOF */
   while(fscanf(fp, "%c", &car)==1)
   {
   	nc++; /* on a lu un nouveau caract�re */

      if( car != '\n' && car != ' ' && car != '\t' && !mot)
      {
      	mot = VRAI; /* on est dans un mot */
         nm++; /* on a un mot de plus */
      }

      if( car == '\n' || car == ' ' || car == '\t' && mot)
        	mot = FAUX; /* on sort d'un mot */

      if (car == '\n')
         nl++; /* on a une nouvelle ligne */

   }

   /* on doit incrementer le nombre de lignes 							  */
   /* car on sort du while lorsqu'on rencontre le dernier caractere */
   nl++;

   /* r�sultat du traitement */
   printf("\nLe texte contenait:");
   printf("\n\t-nombre de caracteres: %ld", nc);
   printf("\n\t-nombre de lignes: %d", nl);
   printf("\n\t-nombre de mots: %d", nm);

   /* pause pour la lecture du r�sultat */
   printf("\n\n--- Copyright David Rousse 1999 ---");
   printf("\nAppuyez sur une touche pour quitter...");
   car = getchar();
   scanf("%c",&car);

}







