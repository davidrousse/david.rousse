/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Palindrome ou pas ?
***************************************************************************
*
* R�pertoire                : miage\palindrome
* Nom du fichier            : palindrome.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE -Dimitri NESTY
* Date de creation          : 12 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>

#define TAILLE 100

main()
{
	char c, *tab;
   int nbcar=0, i=0, i_min, i_max, egal=1;

   /* allocation de memoire pour TAILLE char */
   tab = (char *)malloc(TAILLE * sizeof(char));
	if(tab == NULL) /* arret du programme si memoire insuffisante */
		puts("\nMemoire insuffisante !!!\n"), exit(1);

   /* lecture de la phrase, on s'arrete a $ */
   printf("\nEntrer une phrase terminee par un $:\n");
	/* on reste dans la boucle tant qu'on ne saisie par un $ */
   while((c = getche()) != '$')
   {
      /* stockage des majuscules tapees */
      if(((toascii(c))>=65) && ((toascii(c))<=90)) /* on ne prend en compte */
      	tab[i++] = c;  								   /* que les majuscules    */


      /* reallocation de memoire si la phrase est trop longue */
      if((i-nbcar)>TAILLE-1)
      {
      	nbcar = i;
         /* reallocation par tranche de TAILLE char */
         tab = (char *)realloc(tab, TAILLE * sizeof(char));
         if(tab == NULL) /* arret du programme si la memoire insuffisante */
				puts("\nMemoire insuffisante !!!\n"), exit(1);

      }

      /* materialisation d'un CRLF si appuie sur ENTREE */
      if(c == '\r')
      	printf("\n");
   }

   
   /* verification de la presence d'un palindrome */
   i_min=0;
   i_max=i-1;

   /* si le tableau est vide, par ex. si on a tape que des minuscules      */
   /* on indique que la phrase n'est pas un palindrome en mettant egal a 0 */
   if(i_max<0)
   	egal = 0;

   while((i_min<=i_max) && (egal))
   {
      if(tab[i_min]!=tab[i_max])
      	egal = 0;
      else
      {
        	i_min++;
      	i_max--;
      }
   }

	/* affichage du resultat */
   if(egal)
   	printf("\nLa phrase est un palyndrome !");
   else
   	printf("\nLa phrase n'est pas un palyndrome.");

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getch(); /* vide le tampon */
   getchar();
}
