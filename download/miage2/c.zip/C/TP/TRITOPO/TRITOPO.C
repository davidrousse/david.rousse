/**************************************************************************
*
* Nom du projet     : Tri topologique d'un graphe G
* Objet 				  : Utilise la propri�t� "G est sans circuit =>il existe
*							 un sommet sans pr�c�dent".
*							 On essaie donc de vider le graphe � partir de la
*							 liste d'adjacence inverse (ensemble des pr�decesseurs
*							 de chaque sommets).
*							 Si on arrive � le vider, on sait qu'il n'y avait pas
*							 de circuit et on obtient un ordre topologique des
*							 sommets
*							 On attend en entr�e un nom de fichiers du type:
*							  2	 1
*							  3	 1
*							  5	 3
*							  etc...
*							  ou (2;1) est un arc du sommet 2 au sommet 1
*							  On accepte des noms de sommets num�riques
*							  entiers seulement
*
***************************************************************************
*
* R�pertoire                : C\tritopo
* Nom du fichier            : tritopo.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 23 / 09 /1998
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define VIDE (-1) /* sommet sans predecesseur */
#define NONPRESENT (-2) /* sommet non present dans le graphe G */

/* d�finition des structures pour la representation de G */
typedef struct Arc
		  {
        		int num;
            struct Arc *suiv;
        } arc;

typedef struct Sommet
		  {
        		int degre;
            arc *prec;
        } sommet;

/* variable globale */
int *liste; /* contiendra la liste des sommets par ordre topologique */


/*
************************************************************
* NOM : affichedico
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    affiche la liste d'adjacence inverse d'un graphe
*
* SYNTAXE : affichedico(nombresommet, graphe);
************************************************************
*/
void affichedico(int nb, sommet *s)
{
	char touche;
   int i;
   arc *p;

	printf("\nListe d'adjacence inverse du graphe:\n");

   for(i=0;i<nb;i++)
   {
   	if(s[i].degre != NONPRESENT)
      {
      	printf("\nSommet: %d, degre: %d", i, s[i].degre);

         p = s[i].prec;
         if( p != NULL)
         {
         	while(p != NULL)
            {
            	printf("\n\t%d", p->num);
               p = p->suiv;
            }
         }
      }
   }
   printf("\n\nAppuyer sur la touche ENTREE pour continuer...");
   getchar();
   while((touche = getchar()) != '\n');
}

void main(void)
{
	FILE *fp;
   char nomfic[51];
   int S1, S2, min, max, nbsommet, sommetsuivant, i, j, cherche=1, G, courant=0;
   sommet *s;
   arc *a, *p;

   /* demande du nom de fichier en entr�e */
   printf("Entrez le nom du fichier (nom.extension): ");
   scanf("%50s", nomfic);

   /* ouverture du fichier */
   fp = fopen(nomfic, "r");
   if(fp == NULL) /* arret du programme */
   	puts("\nImpossible d'ouvrir le fichier !!!"),exit(1);

   /* recherche des num�ros de sommets les plus �l�v�s */
   fscanf(fp, "%d %d", &S1, &S2);
   if(S1<S2)
   {
      min = S1;
      max = S2;
   }
   else
   {
      min = S2;
      max = S1;
   }
   while(fscanf(fp, "%d %d", &S1, &S2) == 2)
   {
   	/* on r�cup�re le plus petit et le plus grand */
      if(S1<S2)
      {
         if(S1<min)
         	min = S1;
         if(S2>max)
         	max = S2;
      }
      else
      {
         if(S2<min)
         	min = S2;
         if(S1>max)
         	max = S1;
      }
   }
   fclose(fp);

   /* on cr�e la liste d'ajacence inverse du graphe */
   /* cad que pour chaque sommet, on cherche ses    */
   /* pr�decesseurs											 */
   nbsommet = max - min + 1;

   /* allocation de la memoire pour le graphe */
   s = (sommet *)malloc(nbsommet * sizeof(sommet));
   if(s == NULL) /*arret du programme */
   	puts("\nMemoire insuffisante !"),exit(1);

   /* allocation de la memoire pour la liste des sommets a afficher*/
   liste = (int *)malloc(nbsommet * sizeof(int));
	if(liste == NULL) /*arret du programme */
   	puts("\nMemoire insuffisante !"),exit(1);

   /* initialisation */
   for(i=0;i<nbsommet;i++)
   {
   	s[i].degre = NONPRESENT;
      s[i].prec = NULL;
      liste[i] = VIDE;
   }

   fp = fopen(nomfic, "r");

   /* on lit le fichier en entier pour construire la liste d'adjacence */
   while(fscanf(fp, "%d %d", &S1, &S2) == 2)
   {
   	i = S1 - min; /* evite de stocker des numeros de sommets eleves */
      j = S2 - min;

      /* on marque la presence des sommets */
      if(s[i].degre == NONPRESENT)
      	s[i].degre = 0;
		if(s[j].degre == NONPRESENT)
      	s[j].degre = 0;

      /* on alloue la memoire pour prendre en compte l'arc lu */
      a = (arc *)malloc(sizeof(arc));
      if(a == NULL) /* arret du programme */
      	puts("\nMemoire insuffisante !"), exit(1);

      a->num = i;
      a->suiv = s[j].prec;
      s[j].prec = a;
      s[j].degre++;

   }
   fclose(fp);

	/* affichage de la liste d'adjacence inverse de G */
   affichedico(nbsommet, s);

   /*************************************************************************/
   /* noyau reel du traitement 																	 */
   /*************************************************************************/

   /* recherche d'un sommet sans predecesseurs */
   while(i<nbsommet && cherche)
   {
   	if(s[i].degre == 0)
      {
      	s[i].degre = VIDE; /* le sommet n'a pas de predecesseur */
         liste[courant++] = i; /* on recupere le sommet */
         cherche = i; /* on commencera a eliminer les sommets depuis cherche */
      }
      i++;
   }

   /* on doit avoir necessairement cherche a 0 pour commencer la recherche */
   /* donc si G != de 0, on a trouve un sommet sans predecesseur				*/
   G = !cherche;

	/* on parcours le graphe en entier tant qu'il n'est pas vide */
   while(G != VIDE)
   {
   	/* on elimine le sommet d'indice cherche dans G */

      int debut = 0;
      arc *k;
      /* on commence au 1� sommet existant */
      while(s[debut].degre == NONPRESENT)
      	debut++;

      /* suppression du sommet cherche */
      for(i=debut;i<nbsommet;i++)
      {
      	p = s[i].prec;
         k = p; /* on sauve le pointeur precedent */

         while(p != NULL)
         {

         	if((p->num) == cherche) /* on doit supprimer l'element */
            {
            	/* modification du chainage */
               if((p->suiv) == NULL)
               	s[i].prec = NULL;
               else
               	(*k).suiv = (*p).suiv;

            	s[i].degre--; /* on a un predecesseur de moins poour s[i] */
               p = NULL;
            	free(p); /* on libere la memoire */
            }
            else /* element suivant */
            {
               k = p;
               p = p->suiv;
            }
         }
      }
      /* on cherche un nouveau sommet vide */
      i = 0;
      while(i<nbsommet && s[i].degre != 0)
      	i++;

      sommetsuivant = courant; /* on recupere la position de la pile */

      if(s[i].degre == 0)
      {
      	s[i].degre = VIDE; /* le sommet n'a pas de predecesseur */
         liste[courant++] = i; /* on recupere le sommet */
      }
      else
      	G = VIDE; /* on a reussi a vider G */

      /* mise a jour de la liste des sommets classes par ordre topo */
      if(sommetsuivant!=courant)
      	cherche = liste[sommetsuivant];
      else
      	cherche = liste[courant-1];

   }
   /*************************************************************************/
   /* fin reelle du traitement 																	 */
   /*************************************************************************/

   /* affichage du resultat */
   if(G != VIDE)
   	printf("\n\n Le graphe comportait un cycle !");
   else
	{
   	i = 0;

      clrscr(); /* effacement de l'ecran */
      printf("\nSommets du graphe affiches par ordre topologique:\n");
   	while(liste[i] != VIDE)
      {
      	printf("\n\t%5d", liste[i]+min);
         i++;
      }
   }

   /* message de fin */
   printf("\n\nAppuyer sur la touche ENTREE pour quitter...");
   getchar();

}

