/*
*	Exemple d'�criture sur dans un fichier
*/

#include <stdio.h>
#include <stdlib.h>

struct mystruct
{
  int i;
  char nom;
} *s;

int main(void)
{
   FILE *f;
   //struct mystruct *s;
   s = (mystruct*)malloc(sizeof(mystruct));

   /* test d'ouverture */
   if ((f = fopen("TEST.txt", "wb")) == NULL) /* open file TEST.$$$ */
   {
      fprintf(stderr, "Cannot open output file.\n");
      return 1;
   }

   s->i = 11;
   s->nom = 'A';

   fwrite(s, sizeof(s), 1, f); /* write struct s to file */
   fclose(f); /* close file */
   return 0;
}

