#include <stdio.h>
#include <string.h>

void main(void)
{

	char *s, *t;

   /* saisie des 2 chaines de caracteres */
   printf("Entrez 2 chaines de caracteres, separes par ENTREE.\n");
   printf("Chaine 1: ");
   scanf("%s", s);
   while(getchar() != '\n'); /* on vide le tampon */
   printf("\nChaine 2: ");
   scanf("%s", t);
   while(getchar() != '\n');
   printf("%s, %s", s,t);
	/* on cherche si t inclus dans s */

}
