#define DEBUG /* ligne a supprimer quand le projet sera termine */

/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Jeu de la vie
***************************************************************************
*
* R�pertoire                : miage\rousse\vie\vie.c
* Nom du fichier            : vie.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 07 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include "vie.h"

/* message pour le mode debug */
#ifdef DEBUG
#define message "\n*** !WARNING! VERSION DEBUG ***\n\n"
#endif

main()
{
	int N, **matrice, i, j, nbsituation=0;

   /* message pour la vzerion de debogage */
   puts(message);

   /* saisie de la taille */
   printf("\nEntrez la taille de la matrice:");
   scanf("%d", &N);
   fflush(stdin);

   /* allocation memoire */
   matrice = (char **)malloc(N*sizeof(int*));
   if(matrice==NULL)
   	puts("\memoire insuffisante !!!"),exit(1);
   for(i=0;i<N;i++)
	{
   	matrice[i]=(int *)malloc(N*sizeof(int));
      if(matrice[i]==NULL)
	   	puts("\memoire insuffisante !!!"),exit(1);
   }

   /* sasie de la situation initiale */
   for(i=0;i<N;i++)
   	for(j=0;j<N;j++)
      {
      	printf("Entrez la valeur de la case (%d,%d):",i, j);
         scanf("%d", &matrice[i][j]);
      }

   /* saise du nombre de situation a observer */
   printf("\nEntrez le nombre de situation a observer:");
   scanf("%d", &nbsituation);

   /* affichage des situation */
   printf("\nSituation initiale:\n");
   afficher(matrice,N);
   attendre('S');
   while(--nbsituation)
   {
   	/* evolution de la matrice */
      vivre(matrice,N);

      /* affichager la matrice */
      printf("\nSituation a l'etape %d:\n", nbsituation);
      afficher(matrice,N);

   	/* arret pour la visualisation */
      attendre('S');
   }

   /* message de fin */
   printf("\n\nLe jeu est fini ...");

}