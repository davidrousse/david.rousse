/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Jeux de la vie
***************************************************************************
*
* R�pertoire                : miage\rousse\vie\vieutils.c
* Nom du fichier            : vieutils.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 07 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/


#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

/************************************************************
* NOM : vivre
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    fait evoluer une matrice selon "les regles de la vie"
*
* SYNTAXE : vivre(mat,taille);
************************************************************
*/
void vivre(int **matrice, int taille)
{
	int i, j;

   /* evolution de la matrice */
   for(i=0; i<taille; i++)
	   for(j=0; j<taille; j++)
   	{
      	if((i>0)&&(j>0)&&(i<(taille-1))&&(j<(taille-1)))
         	/* le point a 4 voisins */
            if((matrice[i-1][j]==1)&&(matrice[i][j-1]==1)&&(matrice[i][j+1]==1)
	            &&(matrice[i+1][j]==1))
               matrice[i][j]=0; /* le point est borde de 1 donc il passe a 0 */
            else
					matrice[i][j]=1; /* le point passe a 1 */

      }
}

/************************************************************
* NOM : attendre
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    attend que le user appuie sur touche pour continuer
*
* SYNTAXE : attendre(car);
*************************************************************
*/
void attendre(char car)
{
   char touche=car;

   if(touche=='\0')
   	touche='\n'; /* touche ENTREE par defaut */

   fflush(stdin); /* vide le tampon d'entree standart */

   printf("\n\nAppuyez sur %c pour continuer ...\n", touche);
   while(getch()!=touche);

}

/************************************************************
* NOM : afficher
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    affiche une matrice de taille T
*
* SYNTAXE : afficher(mat,t);
************************************************************
*/
void afficher(int **mat, int taille)
{
	int i, j;

   printf("\t");

   for(i=0;i<taille;i++)
   	for(j=0;j<taille;j++)
      {
   		printf("%2d ", mat[i][j]);
      	if(j==(taille-1)) /* retour a la ligne */
      		printf("\n\t");
	   }
}
