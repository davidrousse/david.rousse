#include <stdio.h>
#include <string.h>

main()
{
	char c, d;
   int i = 2, *p2=NULL;
   char string[5], *str;
   static char *p3;
   char *p;

   c = "J'aime le C" [i++]; // c recoit a puis on incremente i
   d = "J'aime le C" [++i]; // on incremente i et d recoit m

   printf("%c %c \n", c, d); // affiche a m

   c = 'A';
   str = "12345";

   strcpy(string, str);

   i = c;

   printf("%s %s %d\n", str, string, i); // imprime 12345 65

   printf("\nTaille p = %d, taille *p = %d, element 1 = %c", sizeof(p2), sizeof(*p), *p);

   p="ABCD";
   p3 = "AB";

  	printf("\nTaille p = %d, taille *p = %d, element 1 = %c", sizeof(p3), sizeof(*p), *p3);
	printf("\nAdresse p = %d, adresse chaine pointee p = %d", &p, p);


}
