/* Fichier liste.c */
/* D�veloppement des fonctions de manipulation du type Liste */


#include <stdlib.h>
#include "liste.h"
#include <stdio.h>

Liste creation()        /* Cree une liste vide */
{ return(NULL);}

Liste destruction(Liste l) /* Detruit une liste donnee */
{ if (l) destruction(l->suivant);
  free(l);
  return(NULL);
}

int valeur(Liste l, int i) /* Retourne la valeur du ieme element d'une liste */
{ int j;
  Cellule * p = l;

  for (j = 0; j < i; j++)  p = p->suivant; /* Recherche de la ieme cellule */
  return(p->valeur);
 } 
 

/* Longueur d'une liste donnee l*/
int longueur(Liste l) 
{ Cellule * p = l;      /* Pointeur de parcours */
  int i;                /* Compteur de cellules */
  for (i = 0 ; p ; i++) p = p->suivant; /* Parcours de la liste */
  return(i);
}

/* Ajoute une valeur val au rang i dans une liste donnee l */
Liste insertion(Liste l, int i, int val)
{ Cellule * pcree ; /* Pointeur sur la nouvelle cellule */
  Cellule * p ; /* Pointeur de parcours de la liste */
  Cellule * prec; /*cellule precedant la cellule courante */
  int j; /* Indice de parcours de la liste */

 
  /* Cr�ation de la nouvelle cellule */
  pcree = (Cellule *)malloc(sizeof(Cellule));
  pcree->valeur = val;
  pcree->suivant=NULL;
  
  /* Insertion ... */
  if (i==0) /* ... en d�but de liste */
  { pcree->suivant = l;
    l = pcree ;
  }
  else /* ... en milieu ou en fin de liste */
  { /* Se positionner au rang i */
    for (j = 0, p = l; (p != NULL) && (j < i) ;  j++)
           {prec=p ;
            p=p->suivant;}
    /* Mise � jour des liens */ 
    pcree->suivant=p;
    prec->suivant=pcree;
  }
  return(l);
}


/* Supprime l'element de rang i dans la liste donn�e l */
Liste retrait(Liste l, int i)
{ Cellule * p; /* Pointeur de parcours de la liste qui pointera sur la cellule � liberer */
  Cellule * prec; /* adresse de la cellule precedant celle � lib�rer */
  int j ; /* Indice de parcours de la liste */


  if (i==0) /* suppression en d�but */
  { p = l;
    l = l->suivant;
  }
  else
  {  /* Se positionner au rang i */
     for (p = l, j = 0; (p != NULL) && (j < i); j++)
     		{prec=p;
          p=p->suivant;
          }
     /* mise � jour des liens */
     prec->suivant=p->suivant;
  }
  /* liberation de la cellule */
  free(p);
  return(l); /* Mise � jour de la t�te de la liste si besoin */
}

/* Retourne 1 si la liste est vide, 0 sinon */
int listeVide(Liste l) 

{ return (l==NULL); 
}

void edition(Liste l)  /* Edition de la liste */
{ if (l)
  {     printf("%d \t", l->valeur) ;
        edition(l->suivant) ;
  }
}

