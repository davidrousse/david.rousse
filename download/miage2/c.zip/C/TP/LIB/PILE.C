/* Fichier pile.c */
/* D�veloppement des fonctions de manipulation du type Pile */
#include "liste.h"
#include "pile.h"
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
Pile creationPile()        /* Cree une pile vide */
{ return(NULL);}

Pile destructionPile(Pile p) /* Detruit une pile donnee */
{
	if(p)
		destructionPile(p->suivant);

  	free(p);
  	return(NULL);
}

int valeurPile(Pile p) /* Retourne la valeur du haut de la pile */
{
	return(valeur(p, 0));
}


/* Longueur d'une pile donnee p*/
int longueurPile(Pile p)
{
	return(longueur(p));
}

/* Ajoute une valeur val en tete d'une pile donnee p */
Pile insertionPile(Pile p, int val)
{
	return((Pile)insertion(p,0,val));
}


/* Supprime l'element en tete d'une pile */
Pile retraitPile(Pile p)
{
	return((Pile)retrait(p,0)); /* Mise � jour de la t�te de la pile */
}

/* Retourne 1 si la pile est vide, 0 sinon */
int pileVide(Pile p)
{ return (p==NULL);
}

void editionPile(Pile p)  /* Edition de la pile */
{ if (p)
  {     printf("%d\n", p->valeur) ;
        editionPile(p->suivant) ;
  }
}

