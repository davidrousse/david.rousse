/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Fonctions manipulant des tableaux
***************************************************************************
*
* R�pertoire                : miage\lib\tabutils.c
* Nom du fichier            : tabutils.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE
* Date de creation          : 07 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/


#include <alloc.h>
#include <stdlib.h>
#include <stdio.h>

/************************************************************
* NOM : chargetab
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    charge un tableau d'entiers de nbvaleur
*
* SYNTAXE : tab = chargetab(taille);
************************************************************
*/
int *chargetab(int nbvaleur)
{
	int i, *tab;

   /* allocation de memoire */
   tab = (int *)malloc(nbvaleur * sizeof(int));
   if(tab == NULL) /* arret du programme */
   	puts("\nMemoire insuffisante !!!"), exit(1);

   /* chargement du tableau */
   for(i=0; i<nbvaleur; i++)
   {
   	printf("\nEntrez la valeur numero %d : ", i+1);
      scanf("%d", &tab[i]);
   }

   return tab;
}

/************************************************************
* NOM : tribulle
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    tri un tableau d'entiers en utilisant
*                  la methode du tri bulle
* SYNTAXE : tribulle(tab, nbvaleur);
************************************************************
*/
void tribulle(int *tab, int nbvaleur)
{
	int fin, swap, i;

   do
   {
   	fin = 0; /* si on ne fait aucune permutation lors du parcours */
               /* on sort de la boucle et le tableau est alors trie */

      /* parcours de tout le tableau */
      for(i=0;i<nbvaleur;i++)
      {
      	if(tab[i+1]<tab[i])
         {
         	/* permutation */
            swap = tab[i];
            tab[i] = tab[i+1];
            tab[i+1] = swap;
            fin = 1; /* on indique qu'une permutation a eu lieu */
         }
      }
   }
   while(fin);
}

/************************************************************
* NOM : dicho
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    recherche d'une valeur dans un tableau
*						 trie par ordre croissant en utilisant
*						 la dichotomie. Retourne l'indice de l'element
*						 si la recherche aboutie, (-1) sinon
*
* SYNTAXE : valeur = dicho(tab, nbvaleur, valeurcherchee);
*************************************************************
*/
int dicho(int *tab, int nbvaleur, int x)
{
	int imin, imax, imilieu;

   /* initialisation */
   imin = 0;
   imax = nbvaleur-1;
   imilieu = (imin+imax)/2;

   /* recherche dichotomique */
   while((imin<=imax) && (tab[imilieu]!=x))
   {
   	/* x dans partie basse du tableau */
      if(tab[imilieu]>x)
      	imax = --imilieu;

   	/* x dans partie haute du tableau */
      if(tab[imilieu]<x)
      	imin = ++imilieu;

      /* mise a jour de l'indice median */
      imilieu = (imin+imax)/2;

   }

   /* retourne indice de l'element dans le tableau si trouve, (-1) sinon */
   return (tab[imilieu]==x)?imilieu+1:(-1);
}

/************************************************************
* NOM : affichetab
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    affiche un tableau d'entiers de nbvaleur
*
* SYNTAXE : affichetab(tab,taille);
************************************************************
*/
void affichetab(int *tab, int nbvaleur)
{
	int i;

   printf("\n\nLe tableau contient les valeurs suivantes:\n\t");

   for(i=0;i<nbvaleur;i++)
   {
   	printf("%2d ", *(tab+i));
      if((i+1)%10==0) /* retour a la ligne tous les 10 chiffres */
      	printf("\n\t");
   }
}
