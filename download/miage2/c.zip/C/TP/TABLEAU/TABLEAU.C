/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Manipulation de tableaux
***************************************************************************
*
* R�pertoire                : miage\tableau
* Nom du fichier            : tableau.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE - Dimitri NESTY
* Date de creation          : 07 / 10 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <stdio.h>
#include <conio.h>
#include "perso.h"

main()
{
	int x, *tab, taille, iresultat;
   char rep='o';

   /* demande de la taille du tableau */
   printf("\nEntrez la taille du tableau : ");
   scanf("%d", &taille);

   /* creation et chargement du tableau */
   tab = chargetab(taille);

   /* tri du tableau */
   tribulle(tab,taille);

   do
   {

   	/* effacement de l'ecran */
      clrscr();

      /* affichage du tableau */
      affichetab(tab, taille);

      /* lecture de la valeur � chercher */
   	printf("\n\nEntrez la valeur a chercher: ");
      scanf("%d", &x);

      /* recherche da la valeur dans la tableau */
      iresultat = dicho(tab,taille,x);

      /* affichage du resultat de la recherche */
      if(iresultat!=(-1))
      	printf("\n\nLa valeur %d est a l'emplacement %d.",x,iresultat);
      else
      	printf("\n\nLa valeur %d n'est pas dans la tableau.",x);

      /* demande de continuation */
      getchar(); /* on vide le tampon */
      printf("\n\nVoulez-vous faire une nouvelle recherche (O/N) ?");
      scanf("%c", &rep);
   }
   while((rep!='N') && (rep!='n'));
}

