/**************************************************************************
*
* Nom du projet     : Application cours langage C
* Objet 				  : Gestion d'une pile d'entiers (LIFO).
*
***************************************************************************
*
* R�pertoire                : rousse\liste
* Nom du fichier            : lifo.c
* Nom du fichier d'analyse  :
* Auteur                    : David ROUSSE - Dimitri NESTY
* Date de creation          : 02 / 11 /1999
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/


#include <stdio.h>
#include <ctype.h>
#include "pile.h"

main()
{
 	Pile A,B; /*Declaration de deux piles*/
 	int PID,cpteurA=1,cpteurB=1;  /*Declaration d'un PID*/
   char ress;

   A=creationPile();
	B=creationPile();

   printf("\nEntrez les numeros de PID et la ressource separes par un espace.");
   printf("\nTapez -1 $ pour arreter. \n");
   while((scanf("%d %c",&PID,&ress)==2)&& (PID!=(-1))&& (ress!='$'))
   {
   	if (toupper(ress)=='A')
      	A=insertionPile(A,PID);
      else if (toupper(ress)=='B')
      		B=insertionPile(B,PID);
    }

   while (!pileVide(A)||!pileVide(B))/* pileVide(A)==0 si la pile A non vide */
   {
   	if (!pileVide(A))
      {
      	printf("\nEtat de la pile A apres le tour %d:\n",cpteurA);
   		editionPile(A);
      	A=retraitPile(A);
        	cpteurA++;
      }
      else printf("\nLa pile A est vide.\n");

      if (!pileVide(B))
      {
    		printf("\nEtat de la pile B apres le tour %d:\n",cpteurB);
   		editionPile(B);
      	B=retraitPile(B);
         cpteurB++;
      }
      else printf("\nLa pile B est vide.\n");

      printf("\nAppuyez sur S pour continuer.\n");
   	while(getch()!='S');
    }

    printf("\nLes deux piles sont vides !");

}


