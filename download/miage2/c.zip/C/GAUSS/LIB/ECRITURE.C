/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues. Module d'affichage de matrices et
*							 de tableaux � l'�cran et dans des fichiers.
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : ecriture.c
* Nom du fichier d'analyse  : suivi/suivi.doc
* Auteur                    : Igor APARICI - David ROUSSE
* Date de creation          : 13 / 12 /1999
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
*/

#include <stdio.h>

/* prototype de la fonction erreur() de utils.c */
void erreur(char*);

/************************************************************
* NOM : affichervect
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    affiche un tableau de double de nbvaleur
*
* SYNTAXE : affichervect(tab,taille);
************************************************************
*/
void affichervect(double *tab, int nbvaleur)
{
	int i;

   printf("\n\t");

   for(i=0;i<nbvaleur;i++)
   {
   	printf("%lf ", *(tab+i));
      if((i+1)%10==0) /* retour a la ligne tous les 10 chiffres */
      	printf("\n\t");
   }
}

/************************************************************
* NOM : affichermat
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    affiche une matrice de taille t
*
* SYNTAXE : affichermat(mat,t);
************************************************************
*/
void affichermat(double **mat, int taille)
{
	int i, j;

   printf("\t");

   for(i=0;i<taille;i++)
   	for(j=0;j<taille;j++)
      {
   		printf("%lf ", mat[i][j]);
      	if(j==(taille-1)) /* retour a la ligne */
      		printf("\n\t");
	   }
}

/************************************************************
* NOM : ecriremat
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    ecrit une matrice de taille t dans un fichier
*
* SYNTAXE : ecriremat(mat,t,fp);
************************************************************
*/
void ecriremat(double **mat, int taille, FILE *fp)
{
	int i, j;

   fprintf(fp,"\n");

   for(i=0;i<taille;i++)
   	for(j=0;j<taille;j++)
      {
   		fprintf(fp,"%lf ", mat[i][j]);
      	if(j==(taille-1)) /* retour a la ligne */
      		fprintf(fp,"\n");
	   }
}

/************************************************************
* NOM : ecrirevect
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    ecrit un tableau de double de nbvaleur dans un fichier
*
* SYNTAXE : ecrirevect(tab,taille,fp);
************************************************************
*/
void ecrirevect(double *tab, int nbvaleur, FILE *fp)
{
	int i;

   fprintf(fp,"\n");

   for(i=0;i<nbvaleur;i++)
   {
   	fprintf(fp,"%lf ", *(tab+i));
      fprintf(fp,"\n");
   }
}

/************************************************************
* NOM : ecrireentier
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    ecrit un entier dans un fichier
*
* SYNTAXE : ecrireentier(nb,fp);
************************************************************
*/
void ecrireentier(const int nb, FILE *fp)
{
	fprintf(fp,"\n");
   fprintf(fp,"%d",nb);
}

/************************************************************
* NOM : ecrirereel
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    ecrit un r�el dans un fichier
*
* SYNTAXE : ecrirereel(nb,fp);
************************************************************
*/
void ecrirereel(const float nb, FILE *fp)
{
	fprintf(fp,"\n");
   fprintf(fp,"%8.6f",nb);
}

/************************************************************
* NOM : ecriremessage
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    ecrit un message dans un fichier
*
* SYNTAXE : ecriremessage(msg,fp);
************************************************************
*/
void ecriremessage(const char *msg, FILE *fp)
{
  	fputs(msg,fp);
}

/************************************************************
* NOM : recuperernomfic
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    recupere un identifiant de fichier dans lequel ecrire
*
* SYNTAXE : recuperernomfic(nomdefaut);
************************************************************
*/
FILE *recuperernomfic(char *defaut)
{
	char nomfic[51];
	FILE *fp;

   /* vide le tampon */
   fflush(stdin);

   /* demande du nom de fichier */
   printf("\n Entrez le nom du fichier (nom et extension).");
   printf("\n Note: si aucun nom de fichier entre, le programme essaiera");
   printf("\n d'ecrire dans %s dans le repertoire courant.", defaut);
   printf("\n\t Nom fichier: ");
   gets(nomfic);

   /* ouverture du fichier */
   fp = fopen(nomfic, "w");
   if(fp == NULL) /* nom de fichier de donn�es par d�faut */
   	fp = fopen(defaut, "w");
   	if(fp == NULL) /* arret du programme */
      	erreur("\nImpossible d'ouvrir le fichier !!!");

   return fp;
}