/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues. Module d'acquisition des donn�es sur
*							 disque dur.
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : lecture.c
* Nom du fichier d'analyse  : suivi/suivi.doc
* Auteur                    : David ROUSSE
* Date de creation          : 13 / 12 /1999
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
*/

#include "perso.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>

/************************************************************
* NOM : lecturetaille
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    lit la taille du systeme lineaire � r�soudre
*
* SYNTAXE : int taille = lecturetaille(nomfichier);
************************************************************
*/
int lecturetaille(char *nomfic)
{
	FILE *fp;
   char ch, tampon[201];
   int taille=0, retour;

   /* demande du nom de fichier en entr�e */
   printf("\n Entrez le nom du fichier (nom et extension).");
   printf("\n Note: si aucun nom de fichier entre, le programme essaiera");
   printf("\n de lire donnees.txt dans le repertoire courant.");
   printf("\n\t Nom fichier: ");
   gets(nomfic);

   /* ouverture du fichier */
   fp = fopen(nomfic, "r");
   if(fp == NULL) /* nom de fichier de donn�es par d�faut */
   	fp = fopen("donnees.txt", "r");
   	if(fp == NULL) /* arret du programme */
      	erreur("\nImpossible d'ouvrir le fichier !!!");

   /* �limination des commentairtes dans le fichier */
   do
   {
      ch = (char)getc(fp);
      if(ch==EOF)
      	erreur("\nFicher en entr�e vide !!!");
   }
   while(!isdigit(ch));
   ungetc(ch,fp); /* repositionnement sur le chiffre pr�c�dent */

   /* compter le nombre de ligne pour d�terminer la taille */
   /* du syst�me lin�aire � traiter								  */
   while(fgets(tampon, 200, fp))
   	if(*tampon!='\n') taille++;

   /* v�rification que la matrice du syst�me est carr�e */
   retour = taille/2;
   if((2*retour)!=taille)
   	erreur("\nLe syst�me entr�e n'est pas � n �quations � n inconnues.");

   /* fermeture fichier de donn�es */
   fclose(fp);

   return retour;

}

/************************************************************
* NOM : lecturedonnees
* INDICE : 0
* AUTEUR : David Rousse
* DESCRIPTION :    lit le systeme lineaire � r�soudre
*
* SYNTAXE : lecturedonnees(matrice,secondmembre,taille,nomfichier);
************************************************************
*/
void lecturedonnees(double **matrice, double *secondmembre, int taille, char *nomfic)
{

	FILE *fp;
   int i, j;
   char ch;

   /* ouverture du fichier */
   fp = fopen(nomfic, "r");
   if(fp == NULL) /* nom de fichier de donn�es par d�faut */
   	fp = fopen("donnees.txt", "r");
		   if(fp == NULL) /* arret du programme */
   			erreur("\nImpossible d'ouvrir le fichier !!!");

   /* �limination des commentairtes dans le fichier */
   do
   {
      ch = (char)getc(fp);
      if(ch==EOF)
      	erreur("\nFicher en entr�e vide !!!");
   }
   while(!isdigit(ch));
   ungetc(ch,fp); /* repositionnement sur le chiffre pr�c�dent */

   /* lecture du 1� membre */
	for(i=0;i<taille;i++)
   	/* lecture d'une ligne */
      for(j=0;j<taille;j++)
      	fscanf(fp, "%lf", &matrice[i][j]);


   /* lecture du 2� membre */
   for(i=0;i<taille;i++)
	  	fscanf(fp, "%lf", &secondmembre[i]);

   /* fermeture fichier de donn�es */
   fclose(fp);

}

/************************************************************
* NOM : modifierdonnee
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    modifie un coefficient du systeme
*
* SYNTAXE : modifierdonnee(matrice,secondmembre,taille);
************************************************************
*/
void modifierdonnee(double **mat, double *vect, int taille)
{
   int lig, col;
   double donnee;

   /* lecture des indices du coefficient */
   fflush(stdin); /* vide le tampon */
  	printf("\n Coordonnees du coefficient a modifier...");
   printf("\n Entrer la ligne et la colonne separes par un espace: ");
   scanf("%d %d", &lig, &col);

   fflush(stdin); /* vide le tampon */
	if(col>taille) /* modification du second membre */
   {
   	printf("\n Modification du second membre...");
      printf("\n Entrer la nouvelle donnee: ");
		scanf("%lf", &donnee);
      /* stockage dans second membre */
      if(lig<=taille) /* coordonnee correcte */
      	vect[lig-1] = donnee;
   }
   else
   	/* modification de la matrice */
      if(lig<=taille) /* coordonnee correcte */
      {
	   	printf("\n Modification du premier membre...");
   	   printf("\n Entrer la nouvelle donnee: ");
			scanf("%lf", &donnee);
      	/* stockage dans second membre */
      	mat[lig-1][col-1] = donnee;
      }
}
