/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : pivotpart.c
* Nom du fichier d'analyse  : gauss\suivi.doc
* Auteur                    : David ROUSSE - Igor APARICI
* Date de creation          : 04 / 01 / 2000
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 1
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le :07 / 01 / 2000              Indice : 1
* Origine et Descriptif de la modification :
*
*  - Optimisation pour la reduction en remarquant que lorsque on a le pivot
*	en col-col, les coefficients du systeme A[i,j] tels que col<=i<=taille
*	et 1<=j<=col-1 sont deja nuls. Donc pour faire une op�ration de reduction
*	sur des lignes d'indices appartenant � [col,taille], il suffit de r�aliser
*	le traitement sur les indices de colonnes appartenant � [col,taille]
*
*	- Ajout de commentaires
*
* 	- Liberation de la memoire
*
***************************************************************************
*/

#include "perso.h"

/************************************************************
* NOM : pivotpartiel
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION : R�solution d'un syst�me lin�aire carr�
*               par la m�thode du pivot partiel c'est � dire
*					 recherche du premier pivot non nul et r�duction sous le piv�t.
*					 Les param�tres d'appel de cette fonction sont :
*						a : un tableau carr� (la matrice du syst�me)
*						b : un tableau unidimensionnel (le second membre du syst�me)
*						solution : un tableau unidimensionnel pour le vecteur solution
*						n : l'ordre de la matrice
*
*					 Elle renvoie la valeur 1 si la matrice est num�riquement
*					 inversible et la valeur 0 sinon; quand la valeur renvoy�e est 1,
*					 la solution du syst�me se trouve dans le tableau solution.
*
*
* SYNTAXE : r=pivotpartiel(double **A, double *B, double *solution, int taille);
************************************************************
*/
int pivotpartiel(double **A,double *B, double *solution, int taille)
{

	int i, j, col=0, pivotnultrouve=true, pivotnul, ligne;
 	double pivot, coeffareduire, **systeme; /* systeme contient tout */
   													 /* le syst�me lin�aire   */


 	/* allocation memoire */
 	systeme = allouer(taille,taille+1);


 	/* copie des premier et second membres dans systeme */
 	for(i=0;i<taille;i++)
 	{
 		for(j=0;j<taille;j++)
   	  	systeme[i][j]=A[i][j];

  		systeme[i][taille]=B[i];
 	}

   /* debut du traitement */

 	while(pivotnultrouve && col<taille) /* Traitement de la col-i�me colonne */
 	{

      /* recherche du premier pivot non nul parmi */
      /* systeme[col][col]...systeme[taille][col] */
      pivotnul=true;
  		ligne=col;

  		while (ligne<taille && pivotnul)
      {
         if(systeme[ligne][col]==0)
         	ligne++;
         else
         	pivotnul=false;
      } /* fin de la recherche du pivot */

      if(pivotnul) /* systeme[ligne][col]=0, pour ligne=col,...,taille */
        	pivotnultrouve=false;  /* Le syst�me n'a pas de solution */
      else   /* systeme[ligne][col] contient le premier pivot non nul */
      {
         /* on ramene le pivot sur la diagonale */
      	if(ligne>col) /* On �change les lignes ligne et col */
         {
           	for(j=col;j<taille;j++)
            {
             	/* On �change systeme[ligne][j] et systeme[col][j] */
               pivot=systeme[ligne][j];
               systeme[ligne][j]=systeme[col][j];
            	systeme[col][j]=pivot;
            }

            /* On �change systeme[ligne][taille] et systeme[col][taille+1] */
            pivot=systeme[ligne][taille];
            systeme[ligne][taille]=systeme[col][taille];
            systeme[col][taille]=pivot;
         }

      	/* Le pivot est sur la diagonale systeme[col][col]                 */
      	/* et les coefficients systeme[col+1][col],...,systeme[ligne][col] */
      	/* sont d�j� nuls                                                  */
      	/* On r�duit les lignes de ligne+1 � taille-1                      */
      	pivot=systeme[col][col];
      	for (i=ligne+1;i<taille;i++)
      	{
            /* pour reduire, on realise l'operation
				/* ligne i<-ligne i - systeme[i][col]/systeme[col][col]*ligne col */
            /* ce qui revient � faire
      		/* ligne i<-systeme[col][col]*ligne i - systeme[i][col]*ligne col */
            /* et on �vite ainsi de diviser par un pivot proche de 0          */

      		/* Premier membre                                                 */
         	coeffareduire=systeme[i][col];
         	for(j=col;j<taille;j++)
         		systeme[i][j]=pivot*systeme[i][j]-coeffareduire*systeme[col][j];

         	/* Second membre */
         	systeme[i][taille]=pivot*systeme[i][taille]-
         												coeffareduire*systeme[col][taille];
      	}

      	/* On passe � la colonne suivante */
      	col++;
 		}
	} /* On continue tant que le syst�me n'est pas singulier */

	/* Calcul du vecteur solution du syst�me */
	if(pivotnultrouve)
	{
		for (i=taille-1;i>=0;i--)
   	{
   		pivot=0;
      	for(j=i+1;j<taille;j++)
      		pivot+=systeme[i][j]*solution[j];
         /* Si i=taille, on sort de suite avec pivot=0 */
      	solution[i]=(systeme[i][taille]-pivot)/systeme[i][i];
   	}
	}

	/* liberation memoire */
	liberermat(systeme,taille);

	return pivotnultrouve; /* Retourne 1 si la solution existe, 0 sinon */
}

