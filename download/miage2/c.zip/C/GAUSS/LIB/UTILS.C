/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues. Modules de fonctions utilitaires
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : utils.c
* Nom du fichier d'analyse  : suivi\suivi.doc
* Auteur                    : Igor APARICI - David ROUSSE
* Date de creation          : 06 / 12 /1999
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
*/

#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include "perso.h"

/************************************************************
* NOM : menu
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    affiche un menu de choix pour l'utilisateur
*
* SYNTAXE : menu();
************************************************************
*/
void menu()
{
   clrscr(); /* effacement de l'�cran */

	/* Menu de choix */
	printf("\n        MENU DES FONCTIONS DE TRAITEMENT DU SYSTEME\n\n");
	printf("  ***********************************************************\n");
	printf("  *  0. Quitter                                             *\n");
   printf("  *  1. Methode du pivot total                              *\n");
	printf("  *  2. Methode du pivot de Gauss-Jordan                    *\n");
	printf("  *  3. Methode du pivot partiel                            *\n");
   printf("  *  4. Comparaison des resultats                           *\n");
	printf("  *  5. Calcul du determinant et du rang                    *\n");
	printf("  *  6. Calcul de la matrice inverse                        *\n");
   printf("  *  7. Affichage des donnees                               *\n");
   printf("  *  8. Modifier un coefficient du systeme                  *\n");
   printf("  *  9. Ecriture des resultats dans un fichier              *\n");
   printf("  * 10. Activation de l'ecriture sur disque                 *\n");
   printf("  * 11. Nouvelle lecture des donnees dans un fichier        *\n");
   printf("  ***********************************************************\n\n");
   printf(" \n \n Votre choix: ");

}

/************************************************************
* NOM : attendre
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    attend que l'utilisateur appuie sur
*						 la touche et affiche le message
*						 "Appuyez sur ENTREE pour continuer ..."
*
* SYNTAXE : attendre();
************************************************************
*/
void attendre()
{
   printf("\n Appuyez sur ENTREE pour continuer ...");
   fflush(stdin);
   while(getchar()!='\n');

}

/************************************************************
* NOM : messagedebut
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    affiche un meessage du debut de programme
*
* SYNTAXE : messagedebut();
************************************************************
*/
void messagedebut()
{
   printf(" \n\n Bienvenue dans le programme Gauss ...\n");
   printf(" Cet utilitaire vous permet de realiser diverses operations \n");
   printf(" sur des systemes lineaires a n equations a n inconnues.\n");
   attendre(); /* marque une pause et attend l'appui sur ENTREE */
}

/************************************************************
* NOM : messagefin
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    affiche un meessage du fin de programme
*
* SYNTAXE : messagefin();
************************************************************
*/
void messagefin()
{
   printf(" \n\n Programme realise par Igor APARICI et David ROUSSE ...\n");
   printf(" IUP MIAGe, Universite Paul Sabatier.\n");
   fflush(stdin); /* vide le tampon */
   printf("\n\n Appuyez sur n'importe quelle touche pour quitter.");
   getch();
}

/************************************************************
* NOM : erreur
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    affiche un meessage d'erreur et arrete
*						 l'ex�cution du programme
*
* SYNTAXE : erreur();
************************************************************
*/
void erreur(char *message)
{
   puts("\n**********            ERREUR FATALE         **********\n");
	perror(message);
   puts("\n********** LE PROGRAMME NE PEUT PAS CONTINUER **********");
   messagefin();
   exit(1);
}

