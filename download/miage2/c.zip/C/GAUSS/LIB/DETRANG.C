/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : detrang.c
* Nom du fichier d'analyse  : suivi\suivi.doc
* Auteur                    : David ROUSSE - Igor APARICI
* Date de creation          : 09 / 01 / 2000
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
*/

#include "perso.h"

/************************************************************
* NOM : detrang
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION : D�termination du rang et du d�terminant
*					 d'un syst�me lin�aire carr�
*               par la m�thode du pivot partiel c'est � dire
*					 recherche du premier pivot non nul et r�duction sous le piv�t.
*					 On r�alise � chaque �tape que des op�rations de type addition
*					 sur les lignes du syst�me donc, au final, le d�terminant du
*					 syst�me obtenu est le m�me que celui de la matrice initiale
*					 (Ainsi, il devient inutile de compte le nombre de permutations
*					 de lignes).
*					 De plus, le rang du syst�me est �gal au nombre de piv�ts non
*					 nuls trouv�s.
*					 Les param�tres d'appel de cette fonction sont :
*						a : un tableau carr� (la matrice du syst�me)
*						d : d�terminant du syst�me (param�tre r�sultat)
*						n : l'ordre de la matrice
*
*					 Elle renvoie la valeur du rang et, quand la valeur renvoy�e est
*					 �gale � la taille du syst�me, la valeur du d�terminant
*					 du syst�me se trouve dans determinant
*
*
* SYNTAXE : int detrang(double **A, double *B, int *determinant, int taille);
************************************************************
*/
int detrang(double **A, int *determinant, int taille)
{

	int i, j, col=0, pivotnultrouve=true, pivotnul, ligne, rang=0;
 	double coeffareduire, **systeme; /* systeme contient tout */
   													 /* le syst�me lin�aire   */


 	/* allocation memoire */
 	systeme = allouer(taille,taille+1);


 	/* copie du premier membre dans systeme */
 	for(i=0;i<taille;i++)
 	{
 		for(j=0;j<taille;j++)
   	  	systeme[i][j]=A[i][j];
 	}

   /* debut du traitement */

 	while(pivotnultrouve && col<taille) /* Traitement de la col-i�me colonne */
 	{

      /* recherche du premier pivot non nul parmi */
      /* systeme[col][col]...systeme[taille][col] */
      pivotnul=true;
  		ligne=col;

  		while (ligne<taille && pivotnul)
      {
         if(systeme[ligne][col]==0)
         	ligne++;
         else
         	pivotnul=false;
      } /* fin de la recherche du pivot */

      if(pivotnul) /* systeme[ligne][col]=0, pour ligne=col,...,taille */
        	pivotnultrouve=false;  /* Le syst�me n'a pas de solution */
      else   /* systeme[ligne][col] contient le premier pivot non nul */
      {
         /* un pivot non nul a �t� trouv� donc on incremente le rang */
         rang++;

         /* on ramene le pivot sur la diagonale */
      	if(ligne>col) /* On am�ne le pivot dans systeme[col][col] */
         {
           	for(j=col;j<taille;j++)
               systeme[col][j]+=systeme[ligne][j];

      		/* Le pivot est sur la diagonale systeme[col][col]              */
         	/* et dans systeme[ligne][col]											 */
      		/* Les coefficients systeme[col+1][col],...,systeme[ligne][col] */
      		/* sont d�j� nuls                                               */
      		/* On r�duit les lignes de ligne � taille-1                   */
      		for (i=ligne;i<taille;i++)
      		{
            	/* pour reduire, on realise l'operation
					   ligne i<-ligne i - systeme[i][col]/systeme[col][col]*ligne col
                                                                              */
         		coeffareduire=systeme[i][col]/systeme[col][col];
         		for(j=col;j<taille;j++)
         			systeme[i][j]-=(coeffareduire*systeme[col][j]);

      		}
         }
         else /* ligne=col donc le piv�t est d�j� sur la doagonale */
         {    /* on �limine sous le pivot en partant de col+1      */
           	for(i=col+1;i<taille;i++)
            {
               /* on r�alise ligne i<-ligne i -                               */
               /*                 systeme[i][col]/systeme[col][col]*ligne col */
            	coeffareduire = systeme[i][col]/systeme[col][col];
               for(j=col;j<taille;j++)
               	systeme[i][j]-=(coeffareduire*systeme[col][j]);
         	}
         }

      	/* On passe � la colonne suivante */
      	col++;
 		}
	} /* On continue tant que le syst�me n'est pas singulier */

	/* Calcul du vecteur solution du syst�me */
	if(pivotnultrouve)
	{
      /* systeme contient une matrice triangulaire sup�rieure de m�me */
      /* d�terminant que le syst�me initial.									 */
      /* Ce d�terminant est le produit des piv�ts c'est � dire des    */
      /* coefficients diagonaux de systeme 									 */
      *determinant = 1;
      for (i=0;i<taille;i++)
      	(*determinant)*=systeme[i][i]; /* on forme le produit des termes */
         										 /* diagonaux                      */
	}
   else
   	*determinant = 0; /* le syt�me est singulier et son d�terminant est nul */

	/* liberation memoire */
	liberermat(systeme,taille);

	return rang; /* retourne la valeur du rang du syst�me */
}

