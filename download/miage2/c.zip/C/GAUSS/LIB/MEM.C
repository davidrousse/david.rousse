/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues. Module d'allocation dynamique de m�moire
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : mem.c
* Nom du fichier d'analyse  : suivi\suivi.doc
* Auteur                    : Igor APARICI - David ROUSSE
* Date de creation          : 13 / 12 /1999
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
*/


#include "perso.h"
#include <stdlib.h>
#include <stdio.h>


/************************************************************
* NOM : allouervect
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    alloue un tableau de double de nbvaleur
*
* SYNTAXE : tab = allouervect(taille);
************************************************************
*/
double *allouervect(int nbvaleur)
{
   double *tab;

   /* allocation de memoire */
   tab = (double *)malloc(nbvaleur * sizeof(double));
   if(tab == NULL) /* arret du programme */
   	erreur("\nMemoire insuffisante !!!");

   return tab;
}

/************************************************************
* NOM : allouermat
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    alloue une matrice de double de nbvaleur
*
* SYNTAXE : mat = allouermat(taille);
************************************************************
*/
double **allouermat(int nbvaleur)
{
	int i;
   double **matrice;

   /* allocation memoire */
   matrice = (double **)malloc(nbvaleur*sizeof(double*));
   if(matrice==NULL)
   	erreur("\nMemoire insuffisante !!!");
   for(i=0;i<nbvaleur;i++)
	{
   	matrice[i]=(double *)malloc(nbvaleur*sizeof(double));
      if(matrice[i]==NULL)
	   	erreur("\nMemoire insuffisante !!!");
   }

   return matrice;
}

/************************************************************
* NOM : allouer
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    alloue une matrice de double
*
* SYNTAXE : mat = allouer(nbligne,nbcolonne);
************************************************************
*/
double **allouer(int nbligne,int nbcolonne)
{
	int i;
   double **matrice;

   /* allocation memoire */
   matrice = (double **)malloc(nbligne*sizeof(double*));
   if(matrice==NULL)
   	erreur("\nMemoire insuffisante !!!");
   for(i=0;i<nbligne;i++)
	{
   	matrice[i]=(double *)malloc(nbcolonne*sizeof(double));
      if(matrice[i]==NULL)
	   	erreur("\nMemoire insuffisante !!!");
   }

   return matrice;
}

/************************************************************
* NOM : liberermat
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    libere la memoire allou�e dynamiquement
*						 pour une matrice
*
* SYNTAXE : libererermat(matrice,taille);
************************************************************
*/
void liberermat(double **matrice, int nbligne)
{
	int i;

   /* liberation memoire */
   for(i=0;i<nbligne;i++)
   	free(matrice[i]);

   free(matrice);
}

/************************************************************
* NOM : liberervect
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    libere la memoire allou�e dynamiquement
*						 pour un vecteur
*
* SYNTAXE : liberervect(vect);
************************************************************
*/
void liberervect(double *tab)
{
	free(tab);
}

/************************************************************
* NOM : occupmemmat
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    renvoie la taille en octets occup� par une matrice
*						 en RAM
*
* SYNTAXE : int occupmemmat(taille);
************************************************************
*/
int occupmemmat(int taille)
{
	return taille*taille*sizeof(double);
}

/************************************************************
* NOM : occupmemvect
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION :    renvoie la taille en octets occup� par un vecteur
*						 en RAM
*
* SYNTAXE : int occupmemvect(taille);
************************************************************
*/
int occupmemvect(int taille)
{
	return taille*sizeof(double);
}
