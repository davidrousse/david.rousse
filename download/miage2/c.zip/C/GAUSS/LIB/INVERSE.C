/**************************************************************************
*
* Nom du projet     : Gauss
* Objet 				  : R�solution d'un syst�me lin�aire � n �quations
*							 � n inconnues. Module de calcul de la matrice inverse
*							 via ma m�thode du piv�t total
*
***************************************************************************
*
* R�pertoire                : gauss\lib
* Nom du fichier            : pivottot.c
* Nom du fichier d'analyse  : suivi\suivi.doc
* Auteur                    : David ROUSSE - Igor APARICI
* Date de creation          : 19 / 10 /1999
* Date de mise a jour       :
* Valide par                : David ROUSSE
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
*/

#include <math.h>
#include "perso.h"

#define LIBRE 1
#define NONLIBRE 0

/************************************************************
* NOM : pivottot
* INDICE : 0
* AUTEUR : Igor APARICI - David Rousse
* DESCRIPTION : Calcul de la matrice inverse
*               par la m�thode du pivot total
*					 Les param�tres d'appel de cette fonction sont :
*						a : un tableau carr� (la matrice du syst�me)
*						inverse : la matrice inverse calcul�e (param�tre r�sultat)
*						taille : l'ordre de la matrice
*
*					 Elle renvoie la valeur 1 si la matrice est num�riquement
*					 inversible et la valeur 0 sinon; quand la valeur renvoy�e est 1,
*					 la matrice inverse se trouve dans inverse.
*
*
* SYNTAXE : int pivottot(double **A, double **inverse, int taille);
************************************************************
*/
int inverse(double **A, double **inverse, int taille)
{

  int ligpiv, colpiv, i, j, k, retour=true, nbiteration=0;
  double pivotmax=0, swap;
  double **systeme;           /* systeme contient tout le syst�me lin�aire   */
  double **systemeindicateur; /* matrice indicatrice des colonnes barr�es    */

  /* allocation memoire */
  systeme = allouer(taille,2*taille);
  systemeindicateur = allouermat(taille);

  /* copie du membre et de la matrice unit� dans systeme */
  for(i=0;i<taille;i++)
  {
      /* matrice du syt�me */
  		for(j=0;j<taille;j++)
   		systeme[i][j]=A[i][j];

      /* matrice identit� en second membre */
      for(j=taille;j<2*taille;j++)
      {
      	if((i+taille)==j) /* coefficient diagonal de la matrice identit� */
         	systeme[i][j]=1.0;
         else
         	systeme[i][j]=0.0;
      }
  }

  /* remplissage de la matrice systemeindicateur avec des 1 (LIBRE) */
  for(i=0;i<taille;i++)
       for(j=0;j<taille;j++)
            systemeindicateur[i][j]=LIBRE;


 	/* recherche d'une premi�re valeur non nulle pour pivotmax   */
  	for(i=0; i<taille; i++)
  		for(j=0; j<taille; j++)
			if(systeme[i][j])
            pivotmax=systeme[i][j];

 while((nbiteration<taille) && pivotmax)
 {
       /* recherche d'un premier pivot dans les colonnes et lignes  */
       /* disponibles 															  */
       for(i=0; i<taille; i++)
            for(j=0; j<taille; j++)
                 if(systemeindicateur[i][j]!=NONLIBRE)
                 		pivotmax=systeme[i][j];

       /* recherche du pivot maximum en valeur absolue */
       for(i=0; i<taille; i++)
       	for(j=0; j<taille; j++)
         {
         	if(systemeindicateur[i][j] &&
                 					(fabs(systeme[i][j])>=fabs(pivotmax)))
            {
            	pivotmax=systeme[i][j];
               ligpiv=i;
               colpiv=j;
            }
         }


       if(pivotmax) /* si le pivot n'est pas nul, on continue le traitement */
       {
            /* mise � jour de la matrice systemeindicateur */

            /* remplissage de la ligne */
            for(j=0;j<taille;j++)
               systemeindicateur[ligpiv][j]=NONLIBRE;

            /* remplissage de la colonne */
            for(i=0;i<taille;i++)
               systemeindicateur[i][colpiv]=NONLIBRE;


				/* normalisation de la ligne du pivot */
            for(j=0; j<2*taille; j++)
                systeme[ligpiv][j]= systeme[ligpiv][j]/pivotmax;


            /* r�duction de la colonne du pivot */
            for(i=0;i<taille;i++)
            	if(i!=ligpiv)       /* on exclut la ligne du pivot */
               {
               	for(j=0;j<2*taille;j++) /* traitement des colonnes */
                  {
                  	if(j!=colpiv) /* on exclut la colonne du pivot */
                     systeme[i][j]=systeme[i][j]-
                     				systeme[i][colpiv]*systeme[ligpiv][j];

                  }
               }

				/* r�duction de la colonne du pivot */
            for(i=0;i<taille;i++)
            	if(i!=ligpiv) /* on exclut la ligne du pivot */
               	systeme[i][colpiv]=0.0;

       }

       nbiteration++; /* on passe � l'�tape suivante */
 }

 /* calcul des solutions si elles existent c'est � dire si on a trouv� */
 /* aucun pivot nul																	  */
 if(pivotmax==0)
 	retour = false; /* syste�me singulier */
 else
 {
	/* cr�ation d'une matrice identit� dans le premier membre */
   for(j=0;j<taille;j++)
   	for(i=0;i<taille;i++)
      {
      	if(systeme[i][j]!=0)
         {
         	if(i!=j)
            {
               /* �change des lignes i et j */
            	for(k=0;k<2*taille;k++)
               {
               	swap = systeme[i][k];
                  systeme[i][k] = systeme[j][k];
                  systeme[j][k] = swap;
               }
            }
         }
      }


   /* copie de la matrice inverse dans le param�tre r�sultat inverse */
   for(i=0;i<taille;i++)
   	for(j=taille;j<2*taille;j++)
      	inverse[i][j-taille]=systeme[i][j];

 }

 /* liberation memoire */
 liberermat(systeme,taille);
 liberermat(systemeindicateur,taille);

 return retour; /* renvoie 1 si le syst�me a une solution unique, 0 sinon */
}

