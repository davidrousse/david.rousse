/**************************************************************************
*
* Nom du projet     : Editeur de texte
* Objet 				  : editeur de texte utlisant l'allocation dynamique
*							 de memoire (donc plus performant qu'Edit de Windows)
*
*
***************************************************************************
*
* R�pertoire                : C\editeur
* Nom du fichier            : ed.c
* Nom du fichier d'analyse  :
* Auteur                    : Jacques THIBON, mise a jour par David ROUSSE
* Date de creation          : 03 / 09 /1997
* Date de mise a jour       :
* Valide par                :
* Date de validation        :
* Indice du module          : 0
*
***************************************************************************
*
***************************************************************************
************************ MODIFICATIONS APPORTEES **************************
*
* Le ://              Indice :
* Origine et Descriptif de la modification :
*
***************************************************************************
*/

#include <alloc.h>
#include <stdio.h>
#include <conio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>

struct sligne
   {
      char car[81];
      int longueur;
      struct sligne *suivant;
      struct sligne *precedent;
   } *pligne,*Pligne,*ptete,*pdebaff,*pfin,*paffi,*ptrav;

char  uncar, puncar, nomfich[40];
int lig=1, col=1, fich, i, k, l, c, pos, etat;
unsigned int touche;

void affligne()
{
   c=0;
   while(c<(*pligne).longueur-1)
   {
      c++;
      gotoxy(c,lig);
      fputchar((*pligne).car[c]);
   }
   c++;
}

void effinligne()
{
   if (col!=80)
   {
      k=col;
      while (k!=80)
      {
         gotoxy(k,lig);
         fputchar(' ');
         k++;
      }
   }
}

void affcolig()
{
   gotoxy(02,24);
   printf("col:%2d  lig:%4d",col,lig);
   gotoxy(col,lig);
}

void affetat()
{
   affcolig();
   gotoxy(30,24);
   printf("%s",nomfich);
   gotoxy(70,24);
   if (bioskey(2) >=80)
      printf("INS ");
   else
      printf("REMP");
   gotoxy(1,25);
   printf("F1=aide   F2=sauv.   F3=quitte   F4=sauv.+quitte  ");
   printf("alt+suppr=suppr.ligne");
   gotoxy(col,lig);

}

void affecran()
{
   clrscr();
   paffi=pdebaff;
   l=0;
   do
   {
      l++;
      c=0;
      while(c<(*paffi).longueur-1)
      {
         c++;
         gotoxy(c,l);
         fputchar((*paffi).car[c]);
      }
      c++;
      paffi=(*paffi).suivant;
   }
   while (paffi!=0 && l<22);
   affetat();
}

void allocligne()
{
   Pligne=malloc(87);
   (*Pligne).suivant=0;
   (*Pligne).precedent=0;
   (*Pligne).longueur=1;
   (*Pligne).car[1]='\x0a';
   for (k=2;k!=80;k++)
     (*Pligne).car[k]='\x20';
 }

 void decdroit()
 {
       k=80;
       while (k!=col)
       {
          (*pligne).car[k]=(*pligne).car[k-1];
          k--;
       }
 }

 void supcar()
 {
    if (col<(*pligne).longueur)
    {
       k=col;
       while (k!=80)
       {
          (*pligne).car[k]=(*pligne).car[k+1];
          k++;
       }
    }
    (*pligne).longueur--;
 }

 void up22()
 {
    ptrav=pdebaff;
    k=0;
    while (k!=21 && (*ptrav).precedent!=0)
    {
       ptrav=(*ptrav).precedent;
       k++;
       pligne=(*pligne).precedent;
    }
    pdebaff=ptrav;
 }

 void sauv()
 {
    /* ouverture du fichier en ecriture */
    fich=open(nomfich,0x104,0x80);

    /* ecriture dans le fichier */
    ptrav=ptete;
    while (ptrav != 0)
    {
       col=0;
       while(col!=(*ptrav).longueur)
       {
          col++;
          write(fich,&(*ptrav).car[col],1);
       }
       ptrav=(*ptrav).suivant;
    }
    puncar='\x1a';
    write(fich,&puncar,1);
    close(fich);
 }
void  ajustecol()
{
   if (col > (*pligne).longueur)
      col=(*pligne).longueur;
}


main()
{
   /* allocation d'une ligne */
   allocligne();
   ptete=Pligne;
   pdebaff=Pligne;
   pligne=Pligne;
   pfin=Pligne;

   /* demande du nom de fichier */
   clrscr();
   printf("nom du fichier ?:");
   scanf("%s",nomfich);

   /* ouverture du fichier */
   fich=open(nomfich,0x1);

   /* si le fichier existe */
   if (fich>0)
   {
      read(fich,&puncar,1);
      while (puncar!='\x1a')
      {
         col=0;
         while (puncar!='\x0a' && puncar!='\x1a')
         {
            col++;
            (*pligne).car[col]=puncar;
            read(fich,&puncar,1);
         }
         col++;
         (*pligne).car[col]=puncar;
         (*pligne).longueur=col;
         if (puncar!='\x1a')
            read(fich,&puncar,1);
         if (puncar!='\x1a')
         {
            /* allocation d'une ligne et MAJ pointeurs */
            allocligne();
            (*Pligne).precedent=pligne;
            (*pligne).suivant=Pligne;
            pfin=Pligne;
            pligne=Pligne;
         }
      }
      close(fich);
      col=1;
      lig=1;
      pligne=ptete;
      affecran();
   }
   else
   {
      clrscr();
      affetat();
   }

   /* intro des caracteres en mode remplacement ou insertion */
   touche = bioskey(0);
   while (touche!=0x3d00 && touche!=0x3e00)
   {
      uncar=touche;
      switch (touche)
      {
         /* touche F2 */
         case 0x3c00:
            sauv();
            break;


         /* touche entree */
         case 0x1c0d:
            allocligne();

	    if (col==1)
            {
	       if ((*pligne).precedent==0)
               {
                  /* insertion ligne en tete */
                  (*Pligne).suivant=ptete;
                  (*ptete).precedent=Pligne;
                  ptete=Pligne;
                  (*Pligne).precedent=0;
                  pdebaff=ptete;
               }
               else
               {
                  /* insertion ligne en milieu avant */
                  (*Pligne).suivant=pligne;
                  (*Pligne).precedent=(*pligne).precedent;
                  ptrav=(*pligne).precedent;
                  (*ptrav).suivant=Pligne;
                  (*pligne).precedent=Pligne;
               }
               lig++;
               affcolig();
            }
            else
            {
               /* insertion ligne en milieu apres */
               if ((*pligne).suivant==0)
                   pfin=Pligne;
               (*Pligne).precedent=pligne;
               (*Pligne).suivant=(*pligne).suivant;
               (*(*pligne).suivant).precedent=Pligne;
               (*pligne).suivant=Pligne;

               /* changement de ligne pour les caracteres de fin de ligne */
               k=1;
               pos=col;
               while (pos!=(*pligne).longueur)
               {
                  (*Pligne).car[k]=(*pligne).car[pos];
                  (*Pligne).longueur++;
                  k++;
                  pos++;
               }
               (*pligne).longueur=col;
               (*Pligne).car[k]='\x0a';
               (*pligne).car[col]='\x0a';
               pligne=Pligne;
               col=1;
               lig++;
            }
            if (lig==22)
            {
               lig--;
               pdebaff=(*pdebaff).suivant;
            }
            affecran();
            break;

         /* touche insertion */
         case 0x5200:
            gotoxy(70,24);
            if (bioskey(2) >=80)
               printf("INS ");
            else
               printf("REMP");
            break;

         /* touche suppression */
         case 0x5300:
	 /* shift+suppr  (shift ajoute decimal 2 a l'etat) */
            etat=bioskey(2);
	    etat=etat/2; /* decalage a droite de 1 bit */
	    if (etat%2 !=0) /* suppression de ligne */
	    {
               if ((*pligne).precedent==0)
               {
                  /* suppression en tete */
                  if ((*pligne).suivant==0)
                  {
                     /* une seule ligne */
                     col=1;
                     (*pligne).car[1]='\x0a';
                     (*pligne).longueur=1;
                  }
                  else
                  {
                     ptrav=(*pligne).suivant;
                     free(pligne);
                     ptete=ptrav;
                     pligne=ptrav;
                     (*pligne).precedent=0;
                     pdebaff=ptrav;
                  }
               }
               else
               {
                  if ((*pligne).suivant==0)
                  {
                     /* suppression en queue */
                     ptrav=pligne;
                     pligne=(*pligne).precedent;
                     pfin=pligne;
                     free(ptrav);
                     (*pligne).suivant=0;
                     lig--;
                     affcolig();
                  }
                  else
                  {
                    /* suppression en milieu */
                     (*(*pligne).precedent).suivant=(*pligne).suivant;
                     (*(*pligne).suivant).precedent=(*pligne).precedent;
                     ptrav=pligne;
                     pligne=(*pligne).suivant;
                     free(ptrav);
		     ajustecol();
		  }
	       }
	       affecran();
	    }
	    else
	    {
	       if (col<(*pligne).longueur)
	       {
		  supcar();
		  affligne();
		  gotoxy(c,lig);
		  fputchar(' ');
	       }
	    }
	    break;

         /* touche curseur droite */
         case 0x4d00:
            if (col!=80 && col<(*pligne).longueur)
            {
               col++;
               gotoxy(col,lig);
               affcolig();
            }
            break;

         /* touche curseur gauche  ou back space*/
         case 0x4b00:
         case 0x0e08:
            if (col!=1)
            {
               col--;
               gotoxy(col,lig);
               affcolig();
            }
            break;

         /* touche curseur haut */
         case 0x4800:
            if ((*pligne).precedent != 0)
            {
               pligne=(*pligne).precedent;
               if (col > (*pligne).longueur)
                  col=(*pligne).longueur;
	       if (lig!=1)
	       {
                  lig--;
		  affcolig();
	       }
               else
               {
                  pdebaff=pligne;
                  affecran();
               }
            }
            break;

         /* touche curseur bas */
         case 0x5000:
            if ((*pligne).suivant != 0)
            {
               pligne=(*pligne).suivant;
               if (col > (*pligne).longueur)
                  col=(*pligne).longueur;
	       if (lig<22)
	       {
                  lig++;
		  affcolig();
	       }
               else
               {
                  pdebaff=(*pdebaff).suivant;
                  affecran();
               }
            }
            break;

         /* touche fin */
         case 0x4f00:
            pdebaff=pfin;
            up22();
            affecran();
            pligne=pfin;
            lig=22;
            if (col > (*pligne).longueur)
               col=(*pligne).longueur;
            affcolig();
            break;

         /* touche home */
         case 0x4700:
            pdebaff=ptete;
            affecran();
            lig=1;
            col=1;
            pligne=ptete;
            affcolig();
            break;

         /* touche page up */
         case 0x04900:
            up22();
            affecran();
            if (col > (*pligne).longueur)
               col=(*pligne).longueur;
            break;

         /* touche page down */
         case 0x5100:
            ptrav=pdebaff;
            k=0;
            while (k!=21 && (*pligne).suivant!=0)
            {
               ptrav=(*ptrav).suivant;
               k++;
               pligne=(*pligne).suivant;
            }
            pdebaff=ptrav;
            affecran();
            if (col > (*pligne).longueur)
               col=(*pligne).longueur;
            break;

         /* caracteres ordinaires */
         default:
            if (bioskey(2) >=0x80 || col==(*pligne).longueur)
            {
               /* on est en insertion ou en remplacement en fin de ligne */
               if ((*pligne).longueur!=80)
               {
                  /* insertion d'un caractere en memoire */
                  decdroit();
                  (*pligne).longueur++;
                  (*pligne).car[col]=uncar;
                  affligne();
                  col++;
                  affcolig();
               }
             }
             else
             {     /* on est en remplacement */
                if (col!=80)
                {
                   (*pligne).car[col]=uncar;
                   fputchar(uncar);
                   col++;
                   affcolig();
                }
             }
       }
       gotoxy(col,lig);
       touche=bioskey(0);
   }
   if (touche==0x3e00)
      sauv();
   clrscr();
}
