#ifndef _VOL_H
#define _VOL_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe Vol
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : Vol.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Dateheur.h"
#include "Avion.h"
class Sejour;

class Vol: public Base
{
	protected:
   	string numVol;
      Avion * ptrAvion;
      DateHeure heure;
      string ville;
      Sejour * ptrSejourAssocie;

   public:
      static Liste toutesLesInstances;
      
   	Vol(string, string, DateHeure, string); //constructeur � partir
      			//d'un numero de Vol, d'un nom d'Avion, d'une Dateheure et d'un
       			//nom de ville
      ~Vol(); //destructeur d'une instance de Vol

      //accesseurs
      inline string getNumVol()const; //renvoie le nom du Vol
      inline Avion* getPtrAvion()const; //renvoie l'adresse de l'Avion associ�
      inline DateHeure getHeure()const; //renvoie le nom du Vol
      inline string getVille()const; //renvoie le nom de la ville
      virtual inline string getLigneVol() const { return("0");}; //m�thode
      	//virtuelle affichant le numero du vol, sa ville, son heure, sa porte,
         //son hall

      inline void setPtrAvion(Avion*); //affecte l'Avion associ� au Vol this
      inline void setPtrAvionNull(); //affecte l'Avion associ� au Vol � NULL
      inline void setPtrSejour(Sejour*);
      inline void setPtrSejourNull();

      //surcharges op�rateurs
      friend ostream& operator<<(ostream &, const Vol &); //surcharge
      						//de cout pour l'affichage d'un Vol
     	int operator>(Base *);
    	int operator<=(Base *);

		//m�thodes statiques
      static void initToutesLesInstances(); //initialise toutes les Vols
      						//� partir du fichier ../Donnees/Sejours.txt
      static void afficherToutesLesInstances(); //affiche toutes les instances
      						//pr�sentes en m�moire de Vol
      static int nombreInstances(); //renvoie le nombre d'instances
      						//pr�sentes en m�moire de Vol
      static Vol* adresseInstance(string); //renvoie l'adresse d'une instance
      						//de Vol dont on passe le nom en param�tre
};
#endif
