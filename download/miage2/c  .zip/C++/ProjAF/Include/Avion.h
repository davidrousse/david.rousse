#ifndef _AVION_H
#define _AVION_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe Avion
*
***************************************************************************
*
* R�pertoire                : prjaf/include
* Nom du fichier            : Avion.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <cstring.h>
#include <iostream.h>
#include "Liste.h"

class Vol;

class Avion : public Base
{
	private:
  		string numAvion;
  		string typeAvion;
      Liste tousLesVols;
  		static Liste toutesLesInstances;
  	public:
  		inline Avion(string,string); //constructeur, prend en 1� param�tre
      									  //le numero de l'avion et en 2� parametre
                                   //son type
  		inline ~Avion(); //destructeur

      //accesseurs
  		inline string getNumAvion()const;
  		inline string getTypeAvion()const;

      //surcharge op�rateur de sortie
      friend ostream & operator<<(ostream &, const Avion&);//cout

      void majTousLesVols(Vol *); // met � jour la liste de tous les
      						//vols associ�s � this avec l'adresse d'une instance
                        //de Vol appartenant � l'Avion en param�tre
   	void oterVol(Vol *); //enl�ve le Vol pass� en param�tre de la
      						//liste de vols associ�e � l'avion this

      void afficherTousLesVols();//affiche la liste des vols
      									//associ�es � l'avion

      //m�thodes statiques
  		static void initToutesLesInstances(); //initialise la liste des avions
      												  //� partir du fichier Appareil.txt
                                            //plac� dans le r�pertoire
                                            // ../Donnees
  		static void afficherToutesLesInstances(); //affiche toutes les instances
      														//pr�sntes en m�moire
      static int nombreInstances(); //renvoie le nombre d'instances
      										 //pr�sntes en m�moire
      static Avion* adresseInstance(string); //renvoie l'adresse d'un instance
      						//de Avion dont on passe le nom en param�tre
};
#endif
