#ifndef _PARKINGCONTACT_H
#define _PARKINGCONTACT_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe ParkingContact
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : parkingContact.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BAB NGOM - David ROUSSE
* Date de creation          : 27 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Parking.h"

class ParkingContact : public Parking
{
	protected:
      static Liste toutesLesInstances;

   public:
   	ParkingContact(string, string, string); //constructeur � partir
      			//d'un nom de parking,d'un nom de Porte et d'un
       			//nom de Zone

      //Parking(const Parking&); //constructeur de copie
      ~ParkingContact(); //destructeur d'une instance de Parking

      friend ostream& operator<<(ostream &, const ParkingContact &);
      						//surcharge de cout pour l'affichage d'un Parking

      //methodes statiques
      static void afficherToutesLesInstances(); //affiche toutes les instances
      			//presentes en m�moire de Parking
      static int nombreInstances(); //renvoie le nombre d'instances
      			//presentes en m�moire de Parking
      static ParkingContact* adresseInstance(string);//renvoie l'adresse d'une instance
      			//de Parking dont on passe le nom en param�tre

};
#endif
