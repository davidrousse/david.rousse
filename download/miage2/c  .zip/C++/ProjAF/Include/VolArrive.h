#ifndef _VOLARRIVE_H
#define _VOLARRIVE_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe VolArrive
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : VolArrive.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Vol.h"

class VolArrive: public Vol
{
   public:
      static Liste toutesLesInstances;

   	VolArrive(string, string, DateHeure, string); //constructeur � partir
      			//d'un numero de Vol, d'un nom d'Avion, d'une Dateheure et d'un
       			//nom de vone
      ~VolArrive(); //destructeur d'une instance de Vol

      virtual inline string getLigneVol() const; //m�thode
      	//virtuelle affichant le numero du vol, sa ville, son heure, sa porte,
         //son hall

      //surcharge op�rateurs
      friend ostream& operator<<(ostream &, const VolArrive &); //surcharge
      						//de cout pour l'affichage d'un Vol

		//m�thodes statiques
      static void afficherToutesLesInstances(); //affiche toutes les instances
      						//pr�sentes en m�moire de VolArrive
      static int nombreInstances(); //renvoie le nombre d'instances
      						//pr�sentes en m�moire de Vol
      static VolArrive* adresseInstance(string); //renvoie l'adresse d'une instance
      						//de Vol dont on passe le nom en param�tre
};
#endif
