#ifndef _LISTEITERATOR_H
#define _LISTEITERATOR_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Manipulation de listes d'instances
*							 Sp�cification de la classe ListeIterator
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : listeite.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BAB NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Liste.h"

class ListeIterator
{
	private:
    	Liste * liste;
    	cons courant;

 	public:
    	ListeIterator(Liste * l) // constructeur � partir de l'adresse de la liste li�e
    	{
      	liste=l;
     		courant=liste->car();
      }

    	void reinit()          // repositionne l'it�rateur en d�but de liste
    	{
      	courant=liste->car();
      }

    	Base * operator++(int)  // renvoie le Base * courant et se positionne sur le suivant
    	{
      	cons pcell=courant;
     		if(pcell!=NULL)
	  		{
         	courant=pcell->suivant;
	    		return(pcell->info);
         }
     		else return NULL;
      }

      Base * objetCourant()    // renvoie le Base * courant  rep�r� par l'it�rateur
	  	{
      	if(courant)
         	return (courant->info);
       	else return NULL;
      }
};
#endif