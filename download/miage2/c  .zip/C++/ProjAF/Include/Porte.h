#ifndef _PORTE_H
#define _PORTE_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe Porte
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : Porte.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Parking.h"

class Hall;

class Porte : public Base
{
	private:
   	string nomPorte;
      Hall *ptrHall;
      Liste tousLesParkings;
      static Liste toutesLesInstances;
   public:
   	Porte(string,string); //constructeur � partir d'un nom de Porte
      			//et du Hall associ� pass� en param�tres
      ~Porte(); //destructeur d'une instance de Porte

      //accesseurs
      inline string getNomPorte()const; //renvoie le nom de la Porte
      inline Hall* getPtrHall()const; //renvoie l'adresse du Hall associ�
      inline Liste* getTousLesParkings();//renvoie l'adresse de la liste
      													//des parking associes
		inline void setPtrHall(Hall*); //affecte la Porte � un Hall
		inline void setPtrHallNull(); //affecte NULL � ptrHall             
      int operator>(Base *);
      int operator<=(Base *);

      friend ostream& operator<<(ostream &, const Porte &); //surcharge de cout
      						//pour l'affichage d'une Porte
      void majTousLesParkings(Parking*); //met � jour la liste de toutes
      						//les parkings associ�s � this avec l'adresse d'une instance
                        //de Parking appartenant � la Porte en param�tre
      void oterParking(Parking*); //enleve le Parking pass�e en param�tre
      						//de la liste de parking associ�e � la Porte this
      void afficherTousLesParkings(); //affiche la listes des parkings
      										    //associ�es � la Porte

		//m�thodes statiques
      static void initToutesLesInstances(); //initialise toutes les Portes
      						//� partir du fichier ../Donnees/porte.txt
      static void afficherToutesLesInstances(); //affiche toutes les instances
      						//pr�sentes en m�moire de Porte
      static int nombreInstances(); //renvoie le nombre d'instances
      						//pr�sentes en m�moire de Porte
      static Porte* adresseInstance(string); //renvoie l'adresse d'une instance
      						//de Porte dont on passe le nom en param�tre

};
#endif 
