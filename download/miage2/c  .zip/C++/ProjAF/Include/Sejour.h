#ifndef _SEJOUR_H
#define _SEJOUR_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe Sejour
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : Sejour.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <fstream.h>
#include "Liste.h"
#include "VolArrive.h"
#include "VolDepart.h"
#include "Parking.h"
#include "Porte.h"
#include "Hall.h"
#include "ListeIte.h" 

class Sejour : public Base
{
	private:
   	VolArrive * ptrVolArrive;
      VolDepart * ptrVolDepart;
      Parking * ptrParking;

      Sejour(); //constructeur priv� cr�ant un Sejour vide

   public:
   	static Liste toutesLesInstances;
      
   	Sejour(VolArrive*, VolDepart*, Parking*); //constructeur � partir
      			//d'un *VolArrive, d'un *Voldepart, d'un *Parking
      ~Sejour(); //destructeur d'une instance de Sejour

      //accesseurs
      inline VolArrive* getPtrVolArrive()const; //renvoie l'adresse du VolArrive
      inline VolDepart* getPtrVolDepart()const; //renvoie l'adresse du VolDepart
      inline Parking* getPtrParking()const; //renvoie l'adresse du Parking
      inline string getNumVolArrive()const; //renvoie le num du VolArrive associe
      inline string getNumVolDepart()const; //renvoie le num du VolDepart associe
      inline string getProvenance()const; //renvoie la provenance
      inline string getDestination()const; //renvoie la destination
      inline string getNomParking()const; //renvoie le nom du Parking associe      
      inline string getNomPorte()const; //renvoie le nom du Porte associe
		inline string getNomHall()const; //renvoie le nom du Hall associe
      inline DateHeure getHeureArrive()const; //renvoie l'heure du Vol Arrive
      inline DateHeure getHeureDepart()const; //renvoie l'heure du Vol Depart
      inline string getLigneSejourArrive() const; //renvoie les info. du
      																 //Sejour Arrive
      inline string getLigneSejourDepart() const; //renvoie les info. du
      																 //Sejour Depart

      //affectation d'un Parking au Sejour courant this
      inline void setPtrParking(Parking *);
      //suppression du Parking allou�
      inline void setPtrParkingNull();

      //surcharges op�rateurs
      friend ostream& operator<<(ostream &, const Sejour &); //surcharge
      						//de cout pour l'affichage d'un Sejour
      friend ifstream& operator>>(ifstream &, Sejour &); //surcharge
      						//de >> entre instance de ifstream et une instance de
                        //Sejour pour cr�e un Sejour depuis les donn�es du
                        //fichier ifstream
      friend ofstream& operator<<(ofstream &, const Sejour &); //surcharge
      						//de << entre instance de ofstream et une instance de
                        //Sejour pour �crire un Sejour dans un fichier

     	int operator>(Base *);
    	int operator<=(Base *);

		//m�thodes statiques
      static void initToutesLesInstances(); //initialise toutes les Sejour

      static void afficherToutesLesInstances(); //affiche toutes les instances
      						//pr�sentes en m�moire de Sejour
      static int nombreInstances(); //renvoie le nombre d'instances
      						//pr�sentes en m�moire de Sejour
      static void sauverToutesLesInstances(char*); //ecrit dans le fichier
      						//Resultat.txt toutes les instances
      						//pr�sentes en m�moire de Sejour
      static Sejour* adresseInstance(Sejour*);
};
#endif
