#ifndef _PARKINGHORSCONTACT_H
#define _PARKINGHORSCONTACT_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe ParkingHorsContact
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : parkingHorsContact.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BAB NGOM - David ROUSSE
* Date de creation          : 27 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Parking.h"

class ParkingHorsContact : public Parking
{
	protected:
      static Liste toutesLesInstances;

   public:
   	ParkingHorsContact(string, string, string); //constructeur � partir
      			//d'un nom de parking,d'un nom de Porte et d'un
       			//nom de Zone

      //Parking(const Parking&); //constructeur de copie
      ~ParkingHorsContact(); //destructeur d'une instance de Parking

      friend ostream& operator<<(ostream &, const ParkingHorsContact &);
      						//surcharge de cout pour l'affichage d'un Parking

      //methodes statiques
      static void afficherToutesLesInstances(); //affiche toutes les instances
      			//presentes en m�moire de Parking
      static int nombreInstances(); //renvoie le nombre d'instances
      			//presentes en m�moire de Parking
      static ParkingHorsContact* adresseInstance(string);//renvoie l'adresse d'une instance
      			//de Parking dont on passe le nom en param�tre

};
#endif
