#ifndef _HALL_H
#define _HALL_H

/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe Hall
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : hall.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BAB NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

//#include <cstring.h>
//#include <iostream.h>
//#include "Liste.h"
#include "Porte.h"


class Hall : public Base
{
	private:
   	string nomHall;
      Liste toutesLesPortes;
      static Liste toutesLesInstances;
   public:
   	Hall(string); //constructeur � partir d'un nom de Hall en param�tre
      ~Hall(); //destructeur d'une instance de Hall

      //accesseurs
      inline string getNomHall()const; //renvoie le nom du Hall
      string getLigneHall();//renvoie pour this
      //le point de parking, l'immatriculation de l'appareil, le type
      //et les horaires de sejours
      inline Liste* getToutesLesPortes();//renvoi l'adresse de la liste
      											  //toutesLesPortes
      friend ostream& operator<<(ostream &, const Hall &); //surcharge de cout
      						//pour l'affichage d'un Hall
      void majToutesLesPortes(Porte*); //met � jour la liste de toutes les portes
      						//associ�e � this avec l'adresse d'une instance de Porte
                        //appartenant au Hall en param�tre
      void oterPorte(Porte*); //enleve la Porte pass�e en param�tre de la liste
      						//de portes associ�e au Hall this
      void afficherToutesLesPortes(); //affiche les listes des portes
      										  //associ�es au Hall
                                      	
		//m�thodes statiques
      static void initToutesLesInstances(); //initialise tous les Halls
      						//� partir du fichier ../Donnees/hall.txt
      static void afficherToutesLesInstances(); //affiche toutes les instances
      						//pr�sentes en m�moire de Hall
      static int nombreInstances(); //renvoie le nombre d'instances
      						//pr�sentes en m�moire de Hall
      static Hall* adresseInstance(string); //renvoie l'adresse d'une instance
      						//de Hall dont on passe le nom en param�tre

};
#endif
