#ifndef _PARKING_H
#define _PARKING_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe Parking
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : parking.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BAB NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <cstring.h>
#include <iostream.h>
#include "Liste.h"

class Sejour;
class Porte;
class Zone;

class Parking : public Base
{
	protected:
   	string nomParking;
      Porte *ptrPorte;
      Zone *ptrZone;
     	Liste tousLesSejours;
   public:
   	static Liste toutesLesInstances;
   	Parking(string, string, string); //constructeur � partir
      			//d'un nom de parking,d'un nom de Porte et d'un
       			//nom de Zone

      //Parking(const Parking&); //constructeur de copie
      ~Parking(); //destructeur d'une instance de Parking

      //accesseurs
      inline string getNomParking()const; //renvoie le nom du parking
      inline Porte* getPtrPorte()const; //renvoie l'adresse de la Porte associ�e
      inline Zone* getPtrZone()const; //renvoie l'adresse de la zone associ�e
      inline Liste* getTousLesSejours();//renvoie l'adresse de la liste
      													//des sejours associes
      inline void setPtrPorte(Porte*); //affecte la porte associ�e au parking this
      inline void setPtrZone(Zone*); //affecte la zone associ�e au parking this
      inline void setPtrPorteNull(); //affecte la porte associ�e au parking � NULL
      inline void setPtrZoneNull(); //affecte la zone associ�e au parking � NULL

      int operator>(Base *);
      int operator<=(Base *);

      friend ostream& operator<<(ostream &, const Parking &); //surcharge
      						//de cout pour l'affichage d'un Parking

      void majTousLesSejours(Sejour*); //met � jour la liste de toutes les
      						//sejours
      						//associ�e � this avec l'adresse d'une instance de
                        //Sejour li� au Parking en param�tre
      void oterSejour(Sejour*); //enleve le Sejour pass�e en param�tre de la liste
      						//de sejours associ�e au Parking this
      void afficherTousLesSejours(); //affiche les sejours
      													 //associ�s au Parking

      //methodes statiques
      static void initToutesLesInstances(); //initialise tous les parkings
      			//� partir du fichier ../Donnees/parking.txt
      static void afficherToutesLesInstances(); //affiche toutes les instances
      			//presentes en m�moire de Parking
      static int nombreInstances(); //renvoie le nombre d'instances
      			//presentes en m�moire de Parking
      static Parking* adresseInstance(string);//renvoie l'adresse d'une instance
      			//de Parking dont on passe le nom en param�tre

};
#endif
