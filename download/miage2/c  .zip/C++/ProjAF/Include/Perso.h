#ifndef _PERSO_H
#define IDD_ABOUT	3
#define Projet	3
#define PlaneImg	2
#define PlaneIco	01
#define _PERSO_H
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Fichier personnel de protoypes et noms de menus
*
***************************************************************************
*
* R�pertoire                : projaf/include
* Nom du fichier            : Perso.h
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 07 / 03 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        :  /  /
* Indice du module          : 0
*
***************************************************************************
*/

//fichier de ressources pour utiliser une InputBox
#include <owl\inputdia.rc>

// mn�moniques utilis�s dans le fichier de ressources pour identifier les menus
#define ID_APropos 10
#define ID_Quitter 20
#define ID_AfficherControle 30
#define ID_AfficherSejour 40
#define ID_SauverSejour 50
#define ID_AfficherHall1 60
#define ID_AfficherHall2 70
#define ID_AfficherHall3 80
#define ID_AfficherHall4 90
#define ID_Acceuil 100

#define ID_FenAcceuil 3
#define IDC_STATICBITMAP1	101

#endif
