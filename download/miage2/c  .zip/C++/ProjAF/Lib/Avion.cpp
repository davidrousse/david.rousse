/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe Avion
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : Avion.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/


//#include <iostream.h>
//#include <cstring.h>
#include <fstream.h>
#include "ListeIte.h"
#include "Avion.h"
#include "Vol.h"

//constructeur
Avion::Avion(string pnum,string ptype):numAvion(pnum),typeAvion(ptype)
{
  	//mise � jour de la liste des instances de avion
   toutesLesInstances.ajouter(this);
}

//destructeur
Avion::~Avion()
{
   for(int i=0;tousLesVols.longueur();i++)
 		((Vol*)tousLesVols.nieme(i))->setPtrAvionNull();

	//mise � jour de la liste des instances Avion
   toutesLesInstances.oter(this);
}

//accesseur
string Avion::getNumAvion()const
{
	//retourne le numero de l'avion
   return numAvion;
}

//accesseur
string Avion::getTypeAvion()const
{
	//retourne le type de l'avion
   return typeAvion;
}

//affichage d'un avion
ostream & operator<<(ostream & pcout,const Avion& pavion)
{
	pcout<<"Numero de l'avion :"<<pavion.numAvion<<endl;
   pcout<<"Type d'avion :"<<pavion.typeAvion<<endl;

   return pcout;
}

//mise � jour de la liste de toutes les vols
void Avion::majTousLesVols(Vol * pNouveauVol)
{
	if(pNouveauVol)
   	tousLesVols.ajouter(pNouveauVol);
}

//enl�ve un vol de la liste de tous les vols
void Avion::oterVol(Vol * ptrVol)
{
 	if(ptrVol)
 		tousLesVols.oter(ptrVol);
}


//affiche les vols associ�es � l'avion
void Avion::afficherTousLesVols()
{
	cout<<"Avion::afficherTousLesVols"<<endl;

   if(tousLesVols.listeVide())
	 	cout<<"Il n'y a aucune vol associ� � l'avion"<<endl;
   else
   {
   	ListeIterator lstVols(&tousLesVols);
   	Vol *precVol = (Vol*)lstVols++;

   	cout<<"Liste des vols associ�es :"<<endl;
   	while(precVol)
   	{
   		cout<<precVol->getNumVol()<<endl;
			precVol = (Vol*)lstVols++;
   	}
   }
}



//initialisation donn�e statique
Liste Avion::toutesLesInstances;

//cr�e des instaces d'avions � partir du fichier Avion.txt
//plac� dans le r�pertoire ..\Donnees
void Avion::initToutesLesInstances()
{
	string tampon, pNumAvion, pTypeAvion;
   int nombreEnregistrement;
   ifstream fichierEntre("../Donnees/Avion.txt"); //cr�ation d'une instance
   																//de istream

	//on teste si le fichier peut �tre lu
   if(fichierEntre.good())
   {
   	//lecture du nombre d'enregistrements
      fichierEntre>>nombreEnregistrement;

      for(int i=0;i<nombreEnregistrement;i++)
      {
      	fichierEntre>>pNumAvion;
         fichierEntre>>pTypeAvion;
         //instanciation d'un avion
         new Avion(pNumAvion,pTypeAvion);
      }
   }

   //fermeture du fichier
   fichierEntre.close();
}

//fonction qui affiche la liste
//des instances de Avion
void Avion::afficherToutesLesInstances()
{
	Avion *precAvi;
	if(toutesLesInstances.listeVide())
     	cout<<"Il n'y a aucun avion enregistr�"<<endl;
	else
	{
      //parcours de la liste cha�n�e et affichage
		ListeIterator avionIterateur(&toutesLesInstances);
      
      precAvi=(Avion*)avionIterateur++;

      while(precAvi)
      {
         cout<<*precAvi;
         precAvi->afficherTousLesVols();
         precAvi=(Avion*)avionIterateur++;
      }
   }
}

//nombre d'instances de Avion enregistr�es
int Avion::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'une instance de Avion
Avion* Avion::adresseInstance(string pNomAvion)
{
	if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator listToutesLesInstances(&toutesLesInstances);
      Avion* ptrAvion=(Avion*)listToutesLesInstances++;

      //parcours de la liste des instances via un listeIterator
      while(ptrAvion && (ptrAvion->numAvion != pNomAvion))
      	ptrAvion=(Avion*)listToutesLesInstances++;
      if(ptrAvion && (ptrAvion->numAvion==pNomAvion))
      	return ptrAvion;
      else
      	return NULL;
   }
}
