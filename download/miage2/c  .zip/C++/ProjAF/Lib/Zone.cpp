/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe Zone
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : Zone.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <fstream.h>
#include "ListeIte.h"
#include "Zone.h"

//constructeur
Zone::Zone(string pNomZone,string pTypeZone)
{
	nomZone=pNomZone;
   typeZone=pTypeZone;
   //mise � jour de la liste des instances de Zone
   toutesLesInstances.ajouter(this);
}

//destructeur
Zone::~Zone()
{
	for(int i=0;tousLesParkings.longueur();i++)
		((Parking*)tousLesParkings.nieme(i))->setPtrZoneNull();

  	//mise � jour de la liste des instances Zone
	toutesLesInstances.oter(this);
}

//accesseur
string Zone::getNomZone()const
{
	//retourne le nom de la Zone
	return (nomZone);
}

string Zone::getTypeZone()const
{
	//retourne le type de la Zone
	return (typeZone);
}

//affichage d'une Zone
ostream & operator<<(ostream & pcout,const Zone& pzone)
{
	pcout<<"Nom de la zone :"<<pzone.nomZone<<endl;
   pcout<<"Type de la zone :"<<pzone.typeZone<<endl;
   return pcout;
}

//mise � jour de la liste de toutes les parkings
void Zone::majTousLesParkings(Parking * pNouveauParking)
{
	if(pNouveauParking)
   	tousLesParkings.ajouter(pNouveauParking);
}

//enl�ve un parking de la liste de tous les parkings
void Zone::oterParking(Parking * ptrParking)
{
 if(ptrParking)
 	tousLesParkings.oter(ptrParking);
}

//affiche les portes associ�es au Hall
void Zone::afficherTousLesParkings()
{
	cout<<"Zone::afficherToutesLesParkings"<<endl;

   if(tousLesParkings.listeVide())
	 	cout<<"Il n'y a aucun parking associ� a la zone"<<endl;
   else
   {
   	ListeIterator lstParkings(&tousLesParkings);
   	Parking *precParking = (Parking*)lstParkings++;

   	cout<<"Liste des parkings associes :"<<endl;
   	while(precParking)
   	{
   		cout<<precParking->getNomParking()<<endl;
			precParking = (Parking*)lstParkings++;
   	}
   }
}

//initialisation donn�e statique
Liste Zone::toutesLesInstances; // c'est la vraie d�claration

//cr�e des instances de zone � partir du fichier Zone.txt
//plac� dans le r�pertoire ../Donnees
void Zone::initToutesLesInstances()
{
	string pNomZone,pTypeZone;
   int nombreEnregistrement;
   ifstream fichierEntre("../Donnees/Zone.txt"); //cr�ation d'un instance
   															 //de istream

   //on teste si le fichier peut �tre lu
   if(fichierEntre.good())
   {
   	//lecture du nombre d'enregistrements
      fichierEntre>>nombreEnregistrement;

      for(int i=0;i<nombreEnregistrement;i++)
      {
      	fichierEntre>>pNomZone;
         fichierEntre>>pTypeZone;
         //instanciation d'une Zone
         new Zone(pNomZone,pTypeZone);
      }
   }

   //fermeture du fichier
   fichierEntre.close();
}

//fonction qui affiche la liste des instances de Zone
void Zone::afficherToutesLesInstances()
{
	Zone *precZone;
   if(toutesLesInstances.listeVide())
   	cout<<"Il n'y a aucune zone enregistr�e";
   else
   {
   	//parcours de la liste cha�n�e et affichage
      ListeIterator zoneIterateur(&toutesLesInstances);
      precZone=(Zone*)zoneIterateur++;
      while(precZone)
      {
      	cout<<*precZone;
         precZone=(Zone*)zoneIterateur++;
      }
   }
}

//nombre d'instances de Zone enregistr�es
int Zone::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'une instance de Zone
Zone* Zone::adresseInstance(string pNomZone)
{
	if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator listToutesLesInstances(&toutesLesInstances);
      Zone* ptrZone=(Zone*)listToutesLesInstances++;

      //parcours de la liste des instances via un listeIterator
      while(ptrZone && (ptrZone->nomZone != pNomZone))
      	ptrZone=(Zone*)listToutesLesInstances++;
      if(ptrZone && (ptrZone->nomZone == pNomZone))
      	return ptrZone;
      else
      	return NULL;
   }
}
