/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe VolDepart
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : VolDepart.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include "Sejour.h"
#include "Hall.h"
#include "ListeIte.h"
#include "VolDepart.h"

//initialisation donn�e statique
Liste VolDepart::toutesLesInstances;

//constructeur
VolDepart::VolDepart(string pNumVol,string pNumAvionAssocie,DateHeure pHeure,
						string pVille):Vol(pNumVol,pNumAvionAssocie,pHeure,pVille)
{
   toutesLesInstances.ajouter(this);
}

//destructeur
VolDepart::~VolDepart()
{
	//mise � jour de la liste des instances Vol
   toutesLesInstances.oter(this);
}

//m�thode virtuelle affichant le numero du vol, sa ville, son heure, sa porte,
//son hall
string VolDepart::getLigneVol() const
{
	string retour("D\t");
   Porte * ptrPorteAssociee=((ptrSejourAssocie->getPtrParking())->getPtrPorte());

   retour = retour + getNumVol() + "\t" + getVille() + "\t" + getHeure() + "\t"
		+ ptrPorteAssociee->getNomPorte() + "\t" + (ptrPorteAssociee->getPtrHall())->getNomHall();   ;

   return retour; 
}

//surcharge de cout pour l'affichage d'un Vol
ostream& operator<<(ostream & pcout, const VolDepart & pRefVol)
{
	pcout<<endl<<"Numero du Vol :"<<pRefVol.numVol<<endl;
   if(pRefVol.ptrAvion)
   	pcout<<"Avion associ� :"<<(pRefVol.ptrAvion)->getNumAvion()<<endl;
   pcout<<pRefVol.getHeure();
   pcout<<"Destination :"<<pRefVol.ville<<endl;

   return(pcout);
}

//affiche toutes les instances pr�sentes en m�moire de Vol
void VolDepart::afficherToutesLesInstances()
{
	VolDepart *precVol;
	if(toutesLesInstances.listeVide())
     	cout<<"Il n'y a aucun vol enregistre"<<endl;
	else
	{
      //parcours de la liste cha�n�e et affichage
		ListeIterator volIterateur(&toutesLesInstances);

      precVol=(VolDepart*)volIterateur++;

      while(precVol)
      {
         cout<<*precVol;
         precVol=(VolDepart*)volIterateur++;
      }
   }
}

//renvoie le nombre d'instances pr�sentes en m�moire de Vol
int VolDepart::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//renvoie l'adresse d'une instance de Vol dont on passe le nom en param�tre
VolDepart* VolDepart::adresseInstance(string pNumVol)
{
	//recherche dans la liste des instances de Vol celle dont le nom
   //correspond au param�tre et renvoie l'adresse de l'instance si la
   //recherche aboutit, NULL sinon
   if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator lstToutesLesInstances(&toutesLesInstances);
      VolDepart* ptrVol = (VolDepart*)lstToutesLesInstances++;

      //parcours de la liste des instances en recherchant celle dont
      //le nom est pNumVol
      while(ptrVol && (ptrVol->getNumVol()!=pNumVol))
			ptrVol = (VolDepart*)lstToutesLesInstances++;

      //on v�rifie si on est sortie de la boucle en ayant trouv� l'instance
      if(ptrVol && (ptrVol->getNumVol() == pNumVol))
      	return ptrVol;
      else
      	return NULL;
   }
}


