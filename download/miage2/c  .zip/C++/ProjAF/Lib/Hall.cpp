//#define DEBUG
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe Hall
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : Hall.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/


#include <fstream.h>
#include "ListeIte.h"
#include "Hall.h"
#include "Liste.h"
#include "Avion.h"
#include "Sejour.h" 
class Porte;

//constructeur
Hall::Hall(string n)
{
	nomHall=n;
   //mise � jour de la liste des instances de Hall
   toutesLesInstances.ajouter(this);
}

//destructeur
Hall::~Hall()
{
	//mise � jour des liens pour les Portes li�es � this
	for(int i=0;toutesLesPortes.longueur();i++)
		((Porte*)toutesLesPortes.nieme(i))->setPtrHallNull();

	//mise � jour de la liste des instances Hall
	toutesLesInstances.oter(this);

	//toutesLesPortes.~Liste();
}

//accesseur
string Hall::getNomHall()const
{
	//retourne le nom du Hall
	return (nomHall);
}

//renvoie pour this le point de parking
//l'immatriculation de l'appareil, le type
//et les horaires de sejours
string Hall::getLigneHall()
{
   string retour;
	Porte* precPorte;
   Parking* precParking;
   Sejour* precSejour;
   ListeIterator PorteIte(&toutesLesPortes);
	precPorte=(Porte*)PorteIte++;

   while(precPorte)
   {
   	ListeIterator ParkingIte(precPorte->getTousLesParkings());
      precParking=(Parking*)ParkingIte++;
      while(precParking)
      {
        string nomParking;
        nomParking=precParking->getNomParking();

        ListeIterator SejourIte(precParking->getTousLesSejours());
        precSejour=(Sejour*)SejourIte++;
        while(precSejour)
        {
        	 	Avion* ptrAvionAssocie=((precSejour->getPtrVolArrive())->getPtrAvion());
            retour=retour+nomParking+"\t"+ptrAvionAssocie->getNumAvion()+"\t"+
            		ptrAvionAssocie->getTypeAvion()+"\t"+(char*)precSejour->getHeureArrive()+"/"+
                  (char*)precSejour->getHeureDepart()+ "\n";
            precSejour=(Sejour*)SejourIte++;
        }
        precParking=(Parking*)ParkingIte++;
      }
      precPorte=(Porte*)PorteIte++;
   }
  	return retour;
}

//Renvoi l'adresse de la liste toutesLesPortes
Liste* Hall::getToutesLesPortes()
{
	return &toutesLesPortes;
}

//affichage d'un Hall
ostream & operator<<(ostream & pcout,const Hall& phall)
{
	pcout<<"Nom du hall :"<<phall.nomHall<<endl;
   return pcout;
}

//mise � jour de la liste de toutes les portes
void Hall::majToutesLesPortes(Porte * pNouvellePorte)
{
	if(pNouvellePorte)
   	toutesLesPortes.ajouterEnOrdre(pNouvellePorte);
}

//enl�ve une porte de la liste de toutes les portes
void Hall::oterPorte(Porte * ptrPorte)
{
 if(ptrPorte)
 	toutesLesPortes.oter(ptrPorte);
}

//affiche les portes associ�es au Hall
void Hall::afficherToutesLesPortes()
{
	cout<<"Hall::afficherToutesLesPortes"<<endl;

   if(toutesLesPortes.listeVide())
	 	cout<<"Il n'y a aucune porte associ� au hall";
   else
   {
   	ListeIterator lstPortes(&toutesLesPortes);
   	Porte *precPorte = (Porte*)lstPortes++;

   	cout<<"Liste des portes associ�es :"<<endl;
   	while(precPorte)
   	{
   		cout<<precPorte->getNomPorte()<<endl;
			precPorte = (Porte*)lstPortes++;
   	}
   }
}

//initialisation donn�e statique
Liste Hall::toutesLesInstances; // c'est la vraie d�claration

//cr�e des instances de hall � partir du fichier Hall.txt
//plac dans le r�pertoire ../Donnees
void Hall::initToutesLesInstances()
{
	string pNomHall;
   int nombreEnregistrement;
   ifstream fichierEntre("../Donnees/Hall.txt"); //cr�ation d'un instance
   															 //de istream

   //on teste si le fichier peut �tre lu
   if(fichierEntre.good())
   {
   	//lecture du nombre d'enregistrements
      fichierEntre>>nombreEnregistrement;

      for(int i=0;i<nombreEnregistrement;i++)
      {
      	fichierEntre>>pNomHall;
         //instanciation d'un Hall
         new Hall(pNomHall);
      }
   }

   //fermeture du fichier
   fichierEntre.close();
}

//fonction qui affiche la liste des instances de Hall
void Hall::afficherToutesLesInstances()
{

	Hall *precHall;

   if(toutesLesInstances.listeVide())
   	cout<<"Il n'y a aucun hall enregistr�";
   else
   {
   	//parcours de la liste cha�n�e et affichage
      ListeIterator hallIterateur(&toutesLesInstances);
      precHall=(Hall*)hallIterateur++;
      while(precHall)
      {
      	cout<<*precHall;
      	precHall->afficherToutesLesPortes();
         cout<<precHall->getLigneHall();
#ifdef DEBUG
			string tampon;
			cout<<endl<<"Appuyer sur une touche pour continuer...";
   		cin>>tampon;
#endif
         precHall=(Hall*)hallIterateur++;
      }
   }
}

//nombre d'instances de Hall enregistr�es
int Hall::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'une instance de Hall
Hall* Hall::adresseInstance(string pNomHall)
{
	if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator listToutesLesInstances(&toutesLesInstances);
      Hall* ptrHall=(Hall*)listToutesLesInstances++;

      //parcours de la liste des instances via un listeIterator
      while(ptrHall && (ptrHall->nomHall != pNomHall))
      	ptrHall=(Hall*)listToutesLesInstances++;
      if(ptrHall && (ptrHall->nomHall==pNomHall))
      	return ptrHall;
      else
      	return NULL;
   }
}
