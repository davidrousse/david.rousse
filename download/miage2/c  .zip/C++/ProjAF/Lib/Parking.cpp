/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Impl�mentation de la classe Parking
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : parking.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <cstring.h>
#include <fstream.h>
#include "ListeIte.h"
#include "Parking.h"
#include "ParkingContact.h"
#include "ParkingHorsContact.h"
#include "Hall.h"
#include "Porte.h"
#include "Zone.h"
#include "Sejour.h"

//constructeur
Parking::Parking(string pNomParking, string pPorteAssocie, string pZoneAssocie)
																		  :nomParking(pNomParking)
{
   //liaison avec la porte dont le nom est passe en param�tre
   ptrPorte = Porte::adresseInstance(pPorteAssocie);

   //mise � jour de la liste de parking de la porte dont d�pend this
   if(ptrPorte)
		ptrPorte->majTousLesParkings(this);

   //liaison avec la Zone dont le nom est passe en param�tre
   ptrZone = Zone::adresseInstance(pZoneAssocie);

   //mise � jour de la liste de parking de la zone dont d�pend this
   if(ptrZone)
		ptrZone->majTousLesParkings(this);

	//mise � jour de la liste des instances de Parking
   toutesLesInstances.ajouter(this);
}

//destructeur
Parking::~Parking()
{
   //mise � jour de la liste des parkings dont d�pend this
   if(ptrPorte)
	   ptrPorte->oterParking(this);

   //mise � jour de la liste des zones dont d�pend this
   if(ptrZone)
	   ptrZone->oterParking(this);

   //suppresion des liens correspant entre Sejour et Parking li�s
   for(int i=0;i<tousLesSejours.longueur();i++)
   	((Sejour*)tousLesSejours.nieme(i))->setPtrParkingNull();


	//mise � jour de la liste des instances Parking
	toutesLesInstances.oter(this);
}

//accesseurs
string Parking:: getNomParking()const
{
	 //renvoie le nom du parking
    return nomParking;
}


Porte* Parking::getPtrPorte()const
{
	//renvoie l'adresse de la Porte associ�e
    return ptrPorte;
}


Zone* Parking::getPtrZone()const
{
	 //renvoie l'adresse de la zone associ�e
    return ptrZone;
}


Liste* Parking::getTousLesSejours()
{
	//renvoie l'adresse de la liste des sejours associes
   return &tousLesSejours;
}

//affectation d'une nouvelle porte
void Parking::setPtrPorte(Porte* pPorteAssociee)
{
	 //affecte la porte associ�e au parking this
    ptrPorte = pPorteAssociee;
}

//affectation d'une nouvelle porte
void Parking::setPtrZone(Zone* pZoneAssociee)
{
	 //affecte la porte associ�e au parking this
    ptrZone = pZoneAssociee;
}

//affectation � NULL ptrPorte
void Parking::setPtrPorteNull()
{
    ptrPorte = NULL;
}

//affectation � NULL ptrZone
void Parking::setPtrZoneNull()
{
    ptrZone = NULL;
}

//surcharge op�rateur de comparaison > entre this et un Parking
//renvoie 1 si le parking de this est  alphabetiquement
//sup�rieure � celui de pPtrParking
int Parking::operator>(Base *pPtrParking)
{
   if(pPtrParking)
		return (nomParking>(((Parking*)pPtrParking)->getNomParking()));
   else
   	return 0;
}

//surcharge op�rateur de comparaison < entre this et un Parking
//renvoie 1 si le parking de this est  alphabetiquement
//inf�rieur � celui de pPtrParking
int Parking::operator<=(Base *pPtrParking)
{
 	if(pPtrParking)
		return (nomParking<=(((Parking*)pPtrParking)->getNomParking()));
   else
   	return 0;
}

//affichage d'un Parking
ostream& operator<<(ostream & pcout,const Parking& pRefParking)
{
	pcout<<"Nom du parking :"<<pRefParking.nomParking<<endl;
   if(pRefParking.ptrPorte)
   	pcout<<"Porte associ�e :"<<(pRefParking.ptrPorte)->getNomPorte()<<endl;
   if(pRefParking.ptrZone)
   	pcout<<"Zone associ�e :"<<(pRefParking.ptrZone)->getNomZone()<<endl;
   return pcout;
}

//mise � jour de la liste des Sejours associ�s au Parking this
void Parking::majTousLesSejours(Sejour * pPtrSejour)
{
	if(pPtrSejour)
   	tousLesSejours.ajouterEnOrdre(pPtrSejour);
}

//suppression d'un Sejour de la liste de Sejour associ� � la parking
void Parking::oterSejour(Sejour * pPtrSejour)
{
	if(pPtrSejour)
   	tousLesSejours.oter(pPtrSejour);
}

//affiche les sejours associ�s au Parking
void Parking::afficherTousLesSejours()
{
	cout<<"Parking::afficherTousLesSejours"<<endl;

   if(tousLesSejours.listeVide())
	 	cout<<"Il n'y a aucun sejour associe au parking"<<endl;
   else
   {
   	ListeIterator lstSejours(&tousLesSejours);
   	Sejour *precSejour = (Sejour*)lstSejours++;

   	cout<<"Liste des sejours associ�s :"<<endl;
   	while(precSejour)
   	{
   		cout<<*precSejour<<endl;
			precSejour = (Sejour*)lstSejours++;
   	}
   }
}

//methodes statiques

//initialisation donn�e statique
Liste Parking::toutesLesInstances;

//initialise tous les parkings
//� partir du fichier ../Donnees/parking.txt
void Parking::initToutesLesInstances()
{
	string tempNomParking,tempNomPorteAssocie,tempNomZoneAssocie;
   int nombreEnregistrement=0;
   Zone *ptrTempZone; //pr�mettra de cecuperer le type de la zone associ�e
   ifstream fichierEntre("../Donnees/parking.txt"); //creation d'une instance
   																//de istream

   //on teste si le fichier peut �tre lu
   if(fichierEntre.good())
   {
   	//lecture du nombre d'enregistrements
      fichierEntre>>nombreEnregistrement;

      for(int i=0;i<nombreEnregistrement;i++)
      {
      	fichierEntre>>tempNomParking;
         fichierEntre>>tempNomZoneAssocie;
         fichierEntre>>tempNomPorteAssocie;
         //instanciation d'un Parking, du'un parkingContact
         //ou d'un ParkingHorscontact
         ptrTempZone = Zone::adresseInstance(tempNomZoneAssocie); //on r�cup�re
         								//l'adresse du pointeur Zone associ� au Parking
         if(ptrTempZone && (ptrTempZone->getTypeZone()=="CONTACT"))
				new ParkingContact(tempNomParking,tempNomPorteAssocie,
               															tempNomZoneAssocie);
         else
         {
         	if(ptrTempZone && (ptrTempZone->getTypeZone()=="HORS_CONTACT"))
            	new ParkingHorsContact(tempNomParking,tempNomPorteAssocie,
               															tempNomZoneAssocie);
            else
            	new Parking(tempNomParking,tempNomPorteAssocie,
               															tempNomZoneAssocie);
         }
      }
   }

   //fermeture du fichier
   fichierEntre.close();
}

//fonction qui affiche la liste
//des instances de Parking

void Parking::afficherToutesLesInstances()
{
	Parking *precParking;
   if(toutesLesInstances.listeVide())
   	cout<<"Il n'y a aucun parking enregistr�"<<endl;
   else
   {
   	//parcours de la liste cha�nee et affichage
      ListeIterator parkingIterateur(&toutesLesInstances);

      precParking=(Parking*)parkingIterateur++;

      while (precParking)
      {
      	cout<<*precParking<<endl;
         precParking->afficherTousLesSejours();

#ifdef DEBUG
//********************DEBUG*****************************
         string tampon;
         cout<<"TAPEZ TOUCHE....."<<endl;
         cin>>tampon;
#endif
         precParking=(Parking*)parkingIterateur++;
      }

   }

}



//nombre d'instances de parking enregistres
int Parking::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'un Parking dont le nom est passe en param�tre
Parking* Parking::adresseInstance(string pNomParking)
{
	//recherche dans la liste des instances de Parking celle dont le nom
   //correspond au param�tre et renvoie l'adresse de l'instance si la
   //recherche aboutit, NULL sinon
   if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator lstToutesLesInstances(&toutesLesInstances);
      Parking* ptrParking = (Parking*)lstToutesLesInstances++;

      //parcours de la liste des instances en recherchant celle dont
      //le nom est pNomParking
      while(ptrParking && ((ptrParking->getNomParking())!=pNomParking))
			ptrParking = (Parking*)lstToutesLesInstances++;

      //on v�rifie si on est sortie de la boucle en ayant trouv� l'instance
      if(ptrParking && (ptrParking->getNomParking() == pNomParking))
      	return ptrParking;
      else
      	return NULL;
   }
}
