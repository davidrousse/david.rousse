//#define DEBUG
/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe Sejour
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : Sejour.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 / 2000
* Date de mise a jour       : 06 / 03 / 2000
* Valide par                :
* Date de validation        :   /   /  
* Indice du module          : 1
*
***************************************************************************
*/

#include <fstream.h>
#include "ListeIte.h"
#include "Sejour.h"
#include "VolArrive.h"

//initialisation donn�e statique
Liste Sejour::toutesLesInstances;

//constructeur priv� cr�ant un Sejour vide
Sejour::Sejour()
{
   //initialisation des donn�es membres � NULL
	ptrVolArrive = NULL;
   ptrVolDepart = NULL;
   ptrParking = NULL;
}

//constructeur
Sejour::Sejour(VolArrive *pPtrVolArrive,VolDepart* pPtrVolDepart,
Parking *pPtrParking):ptrVolArrive(pPtrVolArrive),ptrVolDepart(pPtrVolDepart),
ptrParking(pPtrParking)
{
   toutesLesInstances.ajouterEnOrdre(this);
}

//destructeur
Sejour::~Sejour()
{
   //mise � jour de la liste des sejours dont d�pend this
   if(ptrParking)
	   ptrParking->oterSejour(this);

   if(ptrVolArrive)
   	ptrVolArrive->setPtrSejourNull();

	if(ptrVolDepart)
   	ptrVolDepart->setPtrSejourNull();

	//mise � jour de la liste des instances Sejour
   toutesLesInstances.oter(this);
}

//Accesseurs
VolArrive* Sejour::getPtrVolArrive()const
{
	//retourne l'adresse du VolArrive
	return(ptrVolArrive);
}

VolDepart* Sejour::getPtrVolDepart()const
{
	//retourne l'adresse du VolDepart
	return(ptrVolDepart);
}

Parking* Sejour::getPtrParking()const
{
	//retourne l'adresse du Parking
	return(ptrParking);
}

string Sejour::getNumVolArrive()const
{
	//renvoie le numero du VolArrive
   if(ptrVolArrive)
	   return(ptrVolArrive->getNumVol());
   else
   	return "-";
}

string Sejour::getNumVolDepart()const
{
	//renvoie le numero du VolDepart
   if(ptrVolDepart)
	   return(ptrVolDepart->getNumVol());
   else
   	return "-";
}

string Sejour::getNomParking()const
{
	//renvoie le nom du Parking
   if(ptrParking)
	   return(ptrParking->getNomParking());
   else
   	return "-";
}

string Sejour::getNomPorte()const
{
	//renvoie le nom de la Porte
   if(ptrParking)
   {
   	Porte *ptrPorte=(ptrParking->getPtrPorte());
	   if(ptrPorte)
      	return(ptrPorte->getNomPorte());
      else
   		return "-";
   }
   else
   	return "-";
}

string Sejour::getNomHall()const
{
	//renvoie le nom du Hall
   if(ptrParking)
   {
   	Porte *ptrPorte=(ptrParking->getPtrPorte());
	   if(ptrPorte)
      {
      	Hall *ptrHall=(ptrPorte->getPtrHall());
         if(ptrHall)
	      	return(ptrHall->getNomHall());
         else
   			return "-";
      }
      else
      	return "-";
   }
   else
   	return "-";
}

string Sejour::getProvenance()const
{
	//renvoie la provenance du Sejour
   if(ptrVolArrive)
	   return(ptrVolArrive->getVille());
   else
   	return "-";
}

string Sejour::getDestination()const
{
	//renvoie la destination du Sejour
   if(ptrVolDepart)
	   return(ptrVolDepart->getVille());
   else
   	return "-";
}

DateHeure Sejour::getHeureArrive()const
{
	//renvoie l'heure d'arrivee d'un VolArrive
   if(ptrVolArrive)
	   return(ptrVolArrive->getHeure());
   else
   	return DateHeure(0,0);
}

DateHeure Sejour::getHeureDepart()const
{
	//renvoie l'heure de depart d'un VolDepart
   if(ptrVolDepart)
	   return(ptrVolDepart->getHeure());
   else
   	return DateHeure(0,0);
}

//affiche une ligne correspondant au info. du sejour arrive
string Sejour::getLigneSejourArrive()const
{
	string retour("A\t");
   string tempDateHeure((char*)getHeureArrive());

   retour = retour + getNumVolArrive() + "\t" + getProvenance() +"\t"+
   													getNomHall() + "\t" + tempDateHeure;

   //la m�thode c_str() convertit un string en un const char*
	return retour;
}

//affiche une ligne correspondant au info. du sejour depart
string Sejour::getLigneSejourDepart()const
{
	string retour("D\t");
   string tempDateHeure((char*)getHeureDepart());

   retour = retour + getNumVolDepart() + "\t" + getDestination() +"\t"+
   													getNomHall() + "\t" + tempDateHeure;

   //la m�thode c_str() convertit un string en un const char*
	return retour;
}

//affectation d'un Parking au Sejour courant this
void Sejour::setPtrParking(Parking *ptrParkingAssocie)
{
	ptrParking = ptrParkingAssocie;
   //mise � jour de la liste de sejours du parking dont d�pend this
   if(ptrParking)
		ptrParking->majTousLesSejours(this);
}

//affecte NULL � ptrParking
void Sejour::setPtrParkingNull()
{
	ptrParking = NULL;
}

//surcharge de cout pour l'affichage d'un Sejour
ostream& operator<<(ostream & pcout, const Sejour & pRefSejour)
{  string tampon;
	pcout<<endl<<"Vol arrive :"<<pRefSejour.getNumVolArrive();
   pcout<<endl<<"Arrivee, "<<pRefSejour.getHeureArrive();
	pcout<<endl<<"Vol depart :"<<pRefSejour.getNumVolDepart();
   pcout<<endl<<"Depart, "<<pRefSejour.getHeureDepart();
   pcout<<endl<<"Parking alloue :"<<pRefSejour.getNomParking();
	pcout<<endl<<"Hall :"<<pRefSejour.getNomHall()<<endl;
   pcout<<endl<<"Appuyer une touche pour continuer...";
   cin>>tampon;
   return(pcout);
}

//surcharge de >> entre instance de ifstream et une instance de
//Sejour pour cr�e un Sejour depuis les donn�es du fichier ifstream
//!!! Les avions doivent d�j� �tre cr�er pour que le lien entre
//Avion et Vol soit mat�rialis�
ifstream& operator>>(ifstream & fichierEntre, Sejour & pSejour)
{
	string tempNumVol, tempNumAvionAssocie,tempVille;
   string tempNumAvion, tempTypeAvion;
   DateHeure *tempHeure;
   int tempH, tempM;
	VolArrive * ptrVolArriveAssocie;
	VolDepart * ptrVolDepartAssocie;

   //lecture d'un enregistrement dans le fichier
   fichierEntre>>tempNumVol;
   fichierEntre>>tempH;
   fichierEntre>>tempM;
   fichierEntre>>tempVille;
   fichierEntre>>tempNumAvionAssocie;
   //manipulation de l'heure d'un Vol
   tempHeure = new DateHeure(tempH,tempM);

   //instanciation alternativement d'un VolArrive et d'un VolDepart

   //instanciation d'un vol arrive
   ptrVolArriveAssocie = new VolArrive(tempNumVol,tempNumAvionAssocie,*tempHeure,tempVille);

   //lecture d'un enregistrement dans le fichier
   fichierEntre>>tempNumVol;
   fichierEntre>>tempH;
   fichierEntre>>tempM;
   fichierEntre>>tempVille;
   fichierEntre>>tempNumAvionAssocie;
   //manipulation de l'heure d'un Vol
   delete tempHeure;
   tempHeure = new DateHeure(tempH,tempM);

   //instanciation d'un vol depart
   ptrVolDepartAssocie = new VolDepart(tempNumVol,tempNumAvionAssocie,*tempHeure,tempVille);

   //mise � jour des attributs de Sejour, sans Parking associ�
 	pSejour.ptrVolArrive = ptrVolArriveAssocie;
   pSejour.ptrVolDepart = ptrVolDepartAssocie;
   Sejour::toutesLesInstances.ajouterEnOrdre(&pSejour);

   //cr�ation du lien entre Vol et Sejour
   pSejour.ptrVolArrive->setPtrSejour(&pSejour);
   pSejour.ptrVolDepart->setPtrSejour(&pSejour);

   //lib�ration m�moire allou�e dynamiquement
   delete tempHeure;

	return fichierEntre;
}

//surcharge de << entre instance de ifstream et une instance de
//Sejour pour �crire un Sejour dans un fichier
ofstream& operator<<(ofstream & fichierSortie, const Sejour & pRefSejour)
{
   fichierSortie<<endl<<"*************************************";
	fichierSortie<<endl<<"Vol arrive :"<<pRefSejour.getNumVolArrive();
   fichierSortie<<endl<<"Arrivee, "<<pRefSejour.getHeureArrive();
	fichierSortie<<endl<<"Vol depart :"<<pRefSejour.getNumVolDepart();
   fichierSortie<<endl<<"Depart, "<<pRefSejour.getHeureDepart();
   fichierSortie<<endl<<"Parking alloue :"<<pRefSejour.getNomParking();
	fichierSortie<<endl<<"Hall :"<<pRefSejour.getNomHall()<<endl;
   fichierSortie<<endl<<"*************************************";
   return(fichierSortie);
}

//surcharge op�rateur de comparaison > entre this et un Sejour
//renvoie 1 si l'heure d'arrive de this est > � l'heure d'arrive de pPtrSejour
int Sejour::operator>(Base *pPtrSejour)
{
   if(ptrVolArrive && &pPtrSejour)
		return ( *ptrVolArrive> ((Sejour*)pPtrSejour)->getPtrVolArrive());
   else
   	return 0;
}

//surcharge op�rateur de comparaison > entre this et un Sejour
//renvoie 1 si l'heure d'arrive de this est <= � l'heure d'arrive de pPtrSejour
int Sejour::operator<=(Base *pPtrSejour)
{
   if(ptrVolArrive && &pPtrSejour)
		return ( *ptrVolArrive<= ((Sejour*)pPtrSejour)->getPtrVolArrive());
   else
   	return 0;
}

//Creation des sejours par affectation des vols dans les parkings
//il faut que "l'aeroport" et les vols+avions soient deja crees
void Sejour::initToutesLesInstances()
{
   Parking::initToutesLesInstances();
   Avion::initToutesLesInstances();

   //variables pour le chargement des donn�es depuis le fichier sejours.txt
   int nbEnregistrement;
   ifstream fichierEntre("../donnees/sejours.txt");

   if(fichierEntre.good())
   {
   	fichierEntre>>nbEnregistrement;

      //parcours du fichier sejours.txt et cr�ation de Sejour
      //sans lien avec Parking
      for(int i=0;i<nbEnregistrement;i+=2)
      	fichierEntre>>(*(new Sejour())); //cr�ation d'un Sejour vide puis
                                        //utilisation des >> entre un
                                        //ifstream et un Sejour
      //les Sejours sont maintenant cr�es et class�s par heure de VolArrive

      //fermeture fichier
      fichierEntre.close();
   }
#ifdef DEBUG
   //******************DEBUG**********************
   //ecriture dans un fichier de la liste des Sejour
   //tri�s par heure de VolArrive
	sauverToutesLesInstances("SejoursOrd.txt");
#endif

   //on cr�e un liste de Sejour calqu�e sur toutesLesInstances
   Liste tousLesSejoursDejaAlloues = toutesLesInstances;

   //variables pour parcourir les donnees
   ListeIterator parkingIterator(&Parking::toutesLesInstances);
   ListeIterator sejourIterator(&toutesLesInstances);
   ListeIterator sejourIteratorDejaAlloue(&tousLesSejoursDejaAlloues);

   Sejour * ptrSejourDejaAlloue;
   Sejour * ptrSejourAallouer = (Sejour*)sejourIterator++;;
   Parking * ptrParkingVide = (Parking*)parkingIterator++;

   int nbAllocation;
   Duree delai(0,5); //on pr�voit un d�lai de battement de 5 minutes
   						//entre chaque vol

   //***************************************
   // affectation des parkings aux sejours *
   //***************************************

   //nombre d'allocation de Parking � effectuer
   nbAllocation = Sejour::nombreInstances();

   //creation du premier sejour
   ptrSejourAallouer->setPtrParking(ptrParkingVide);

#ifdef DEBUG
   //******************DEBUG**********************
   cout<<"Premier sejour � allouer :";
	cout<<ptrSejourAallouer->getNomParking()<<endl;
#endif

   //mise � jour des parkings utilis�s
   ptrParkingVide = (Parking*)parkingIterator++;

   //mise � jour de nombre d'allocation restants � faire
   nbAllocation--;

#ifdef DEBUG
   //******************DEBUG**********************
   cout<<"Premier sejour alloue :";
	cout<<*ptrSejourDejaAlloue<<endl;
#endif

   //allocation des nbEnregistrement-1 Sejours restants
   for(int i=0;i<nbAllocation;i++)
   {
	   //mise � jour des Sejour restants � allouer
   	ptrSejourAallouer = (Sejour*)sejourIterator++;

      //retour en d�but de liste de Sejour deja allou�s
      sejourIteratorDejaAlloue.reinit();

	   //on se place sur le premier Sejour � prendre en compte
   	ptrSejourDejaAlloue = (Sejour*)sejourIteratorDejaAlloue++;

#ifdef DEBUG
	   //******************DEBUG**********************
   	cout<<"Sejour alloue :";
		cout<<*ptrSejourDejaAlloue<<endl;
#endif

      //parcours des Sejours deja allou�s en recherchant un Sejour
      //dont l'heure de Depart soit <= � l'heure d'arriv�e du Sejour � allouer
      while(ptrSejourDejaAlloue &&
      		(((ptrSejourDejaAlloue->getHeureDepart())+delai)>
                                         (ptrSejourAallouer->getHeureArrive())))
      	ptrSejourDejaAlloue = (Sejour*)sejourIteratorDejaAlloue++;

      if(ptrSejourDejaAlloue)
      {
      	//on a trouv� un Sejour dont l'heure de Depart est
         //<= � l'heure d'arriv�e du Sejour � allouer
         //on affecte donc un sejour � un parking deja utilise
			ptrSejourAallouer->setPtrParking(ptrSejourDejaAlloue->getPtrParking());

         //on met � jour l'indice des sejours d�ja allou�s
	      tousLesSejoursDejaAlloues.oter(ptrSejourDejaAlloue);

      }
      else
      {
      	//on affecte un parking non alloue
			ptrSejourAallouer->setPtrParking(ptrParkingVide);

		   //mise � jour des parkings utilis�s
   		ptrParkingVide = (Parking*)parkingIterator++;
      }
      //on met � jour la  liste de tous les sejours
      //dans parking
      //(ptrSejourAallouer->ptrParking)->majTousLesSejours(ptrSejourAallouer);

#ifdef DEBUG
   	//******************DEBUG**********************
      string tampon;
		cout<<ptrSejourAallouer->getNomParking()<<endl;
   	cout<<endl<<"Appuyer une touche pour continuer...";
   	cin>>tampon;
#endif

   }
}


//affiche toutes les instances pr�sentes en m�moire de Sejour
void Sejour::afficherToutesLesInstances()
{
	Sejour *precSejour;
	if(toutesLesInstances.listeVide())
     	cout<<"Il n'y a aucun sejour enregistre"<<endl;
	else
	{
      //parcours de la liste cha�n�e et affichage
		ListeIterator sejourIterateur(&toutesLesInstances);

      precSejour=(Sejour*)sejourIterateur++;

      while(precSejour)
      {
         cout<<*precSejour;
         precSejour=(Sejour*)sejourIterateur++;
      }
   }
}

//renvoie le nombre d'instances pr�sentes en m�moire de Sejour
int Sejour::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//ecrit dans le fichier Resultat.txt toutes les instances
//pr�sentes en m�moire de Sejour
void Sejour::sauverToutesLesInstances(char *nomFich)
{
	Sejour *precSejour;
	ofstream ofs;
   ofs.open(nomFich);

   ofs<<"*************** Liste des Sejours ***************";
   if(toutesLesInstances.listeVide())
    	ofs<<"Il n'y a aucun sejour enregistre";
   else
   {
     	//parcours de la liste cha�n�e et affichage
		ListeIterator sejourIterateur(&toutesLesInstances);

     	precSejour=(Sejour*)sejourIterateur++;

     	while(precSejour)
     	{
        	ofs<<*precSejour;
        	precSejour=(Sejour*)sejourIterateur++;
     	}
   }
   //dernier ligne du fichier
   ofs<<"\n*************** Fin de la liste des Sejours ***************";

   //fermeture du fichier
   ofs.close();
}

//retourne l'adresse d'une instance de Sejour
Sejour* Sejour::adresseInstance(Sejour* pPtrSejourAssocie)
{
	if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator listToutesLesInstances(&toutesLesInstances);
      Sejour* ptrSejour=(Sejour*)listToutesLesInstances++;

      //parcours de la liste des instances via un listeIterator
      while(ptrSejour && (pPtrSejourAssocie != ptrSejour))
      	ptrSejour=(Sejour*)listToutesLesInstances++;
      if(ptrSejour && (pPtrSejourAssocie == ptrSejour))
      	return ptrSejour;
      else
      	return NULL;
   }
}

