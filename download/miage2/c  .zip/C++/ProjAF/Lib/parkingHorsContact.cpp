/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe ParkingHorsContact
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : parkingHorsContact.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 27 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <fstream.h>
#include "ListeIte.h"
#include "Porte.h"
#include "Zone.h"
#include "ParkingHorsContact.h"

//constructeur
ParkingHorsContact::ParkingHorsContact(string pNomParking, string pPorteAssocie,
			string pZoneAssocie):Parking(pNomParking,pPorteAssocie,pZoneAssocie)
{
	//mise � jour de la liste des instances de Parking
   toutesLesInstances.ajouter(this);
}

//destructeur
ParkingHorsContact::~ParkingHorsContact()
{
	//mise � jour de la liste des instances Parking
	toutesLesInstances.oter(this);
}

//affichage d'un Parking
ostream& operator<<(ostream & pcout,const ParkingHorsContact& pRefParking)
{
	pcout<<"Nom du parking (hors contact):"<<pRefParking.nomParking<<endl;
   if(pRefParking.ptrPorte)
   	pcout<<"Porte associ�e :"<<(pRefParking.ptrPorte)->getNomPorte()<<endl;
   if(pRefParking.ptrZone)
   	pcout<<"Zone associ�e :"<<(pRefParking.ptrZone)->getNomZone()<<endl;
   return pcout;
}


//methodes statiques

//initialisation donn�e statique
Liste ParkingHorsContact::toutesLesInstances;

//fonction qui affiche la liste
//des instances de Parking
void ParkingHorsContact::afficherToutesLesInstances()
{
	ParkingHorsContact *precParking;
   if(toutesLesInstances.listeVide())
   	cout<<"Il n'y a aucun parking hors contact enregistr�"<<endl;
   else
   {
   	//parcours de la liste cha�nee et affichage
      ListeIterator parkingIterateur(&toutesLesInstances);

      precParking=(ParkingHorsContact*)parkingIterateur++;

      while (precParking)
      {
      	cout<<*precParking;
         precParking=(ParkingHorsContact*)parkingIterateur++;
      }

   }

}

//nombre d'instances de parking enregistres
int ParkingHorsContact::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'un Parking dont le nom est passe en param�tre
ParkingHorsContact* ParkingHorsContact::adresseInstance(string pNomParking)
{
	//recherche dans la liste des instances de Parking celle dont le nom
   //correspond au param�tre et renvoie l'adresse de l'instance si la
   //recherche aboutit, NULL sinon
   if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator lstToutesLesInstances(&toutesLesInstances);
      ParkingHorsContact* ptrParking = (ParkingHorsContact*)lstToutesLesInstances++;

      //parcours de la liste des instances en recherchant celle dont
      //le nom est pNomParking
      while(ptrParking && ((ptrParking->getNomParking())!=pNomParking))
			ptrParking = (ParkingHorsContact*)lstToutesLesInstances++;

      //on v�rifie si on est sortie de la boucle en ayant trouv� l'instance
      if(ptrParking && (ptrParking->getNomParking() == pNomParking))
      	return ptrParking;
      else
      	return NULL;
   }
}
