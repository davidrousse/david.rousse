/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe Porte
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : Porte.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <fstream.h>
#include "ListeIte.h"
#include "Porte.h"
#include "Hall.h"

//initialisation donn�e statique
Liste Porte::toutesLesInstances;

//constructeur
Porte::Porte(string pNomPorte, string pNomHallAssocie):nomPorte(pNomPorte)
{
   //liaison avec le Hall dont le nom est pass� en param�tre
   ptrHall = Hall::adresseInstance(pNomHallAssocie);

   //mise � jour de la liste de porte du Hall dont d�pend this
   if(ptrHall)
   	ptrHall->majToutesLesPortes(this);

  	//mise � jour de la liste des instances
   toutesLesInstances.ajouter(this);
}

//destructeur
Porte::~Porte()
{
   //mise � jour de la liste des portes dont d�pend this
   if(ptrHall)
	   ptrHall->oterPorte(this);

   //suppresion des liens correspant entre Porte et Parking li� � la porte this
   for(int i=0;i<tousLesParkings.longueur();i++)
   	((Parking*)tousLesParkings.nieme(i))->setPtrPorteNull();

	//mise � jour de la liste des instances Avion
   toutesLesInstances.oter(this);
}

//accesseur
string Porte::getNomPorte()const
{
	//retourne le nom de la porte
   return nomPorte;
}

//accesseur
Hall* Porte::getPtrHall()const
{
	//retourne l'adresse du Hall associ� � la Porte
   return ptrHall;
}

//accesseur sur l'adresse de liste de parking
Liste* Porte::getTousLesParkings()
{
	//returne l'adresse de la liste des parkings associes
   return &tousLesParkings;
}


//association d'un Hall � la Porte this
void Porte::setPtrHall(Hall* pPtrHallAssocie)
{
	//on v�rifie que le Hall que l'on veut associ� � la Porte this existe
	if(Hall::adresseInstance(pPtrHallAssocie->getNomHall()))
   	ptrHall = pPtrHallAssocie;
}

//affecte NULL � ptrHall
void Porte::setPtrHallNull()
{
	ptrHall = NULL;
}

//surcharge op�rateur de comparaison > entre this et un Porte
//renvoie 1 si la porte de this est  alphabetiquement
//sup�rieure � celui de pPtrPorte
int Porte::operator>(Base *pPtrPorte)
{
   if(pPtrPorte)
		return (nomPorte>(((Porte*)pPtrPorte)->getNomPorte()));
   else
   	return 0;
}

//surcharge op�rateur de comparaison < entre this et un Porte
//renvoie 1 si la Porte de this est  alphabetiquement
//inf�rieur � celui de pPtrPorte
int Porte::operator<=(Base *pPtrPorte)
{
 	if(pPtrPorte)
		return (nomPorte<=(((Porte*)pPtrPorte)->getNomPorte()));
   else
   	return 0;
}
//affichage d'une porte
ostream & operator<<(ostream & pcout,const Porte& pRefPorte)
{
	pcout<<"Nom de la porte :"<<pRefPorte.nomPorte<<endl;
   if(pRefPorte.ptrHall)
	   pcout<<"Hall associ� :"<<(pRefPorte.ptrHall)->getNomHall()<<endl;

   return pcout;
}

//mise � jour de la liste des parking associ�s � la porte this
void Porte::majTousLesParkings(Parking * pPtrParking)
{
	if(pPtrParking)
   	tousLesParkings.ajouterEnOrdre(pPtrParking);
}

//suppression d'un parking de la liste de parking associ� � la porte
void Porte::oterParking(Parking * pPtrParking)
{
	if(pPtrParking)
   	tousLesParkings.oter(pPtrParking);
}

//affiche les portes associ�es au Hall
void Porte::afficherTousLesParkings()
{
	cout<<"Porte::afficherToutesLesParkings"<<endl;

   if(tousLesParkings.listeVide())
	 	cout<<"Il n'y a aucun parking associ� a la porte";
   else
   {
   	ListeIterator lstParkings(&tousLesParkings);
   	Parking *precParking = (Parking*)lstParkings++;

   	cout<<"Liste des parkings associ�s :"<<endl;
   	while(precParking)
   	{
   		cout<<precParking->getNomParking()<<endl;
			precParking = (Parking*)lstParkings++;
   	}
   }
}

//cr�e des instaces de portes � partir du fichier porte.txt
//plac� dans le r�pertoire ../Donnees
void Porte::initToutesLesInstances()
{
	string tempNomPorte, tempNomHallAssocie;
   int nombreEnregistrement;
   ifstream fichierEntre("../Donnees/porte.txt"); //cr�ation d'une instance
   																//de istream

	//on teste si le fichier peut �tre lu
   if(fichierEntre.good())
   {
   	//lecture du nombre d'enregistrements
      fichierEntre>>nombreEnregistrement;

      for(int i=0;i<nombreEnregistrement;i++)
      {
      	fichierEntre>>tempNomPorte;
         fichierEntre>>tempNomHallAssocie;
         //instanciation d'une porte
         new Porte(tempNomPorte,tempNomHallAssocie);
      }
   }

   //fermeture du fichier
   fichierEntre.close();
}

//fonction qui affiche la liste
//des instances de Porte
void Porte::afficherToutesLesInstances()
{
	Porte *precPorte;
	if(toutesLesInstances.listeVide())
     	cout<<"Il n'y a aucune porte enregistr�e"<<endl;
	else
	{
      //parcours de la liste cha�n�e et affichage
		ListeIterator porteIterateur(&toutesLesInstances);
      
      precPorte=(Porte*)porteIterateur++;

      while(precPorte)
      {
         cout<<*precPorte;
         precPorte->afficherTousLesParkings();
         precPorte=(Porte*)porteIterateur++;
      }
   }
}

//nombre d'instances de Porte enregistr�es
int Porte::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'une porte dont le nom est pass�e en param�tre
Porte* Porte::adresseInstance(string pNomPorte)
{
	//recherche dans la liste des instances de Porte celle dont le nom
   //correspond au param�tre et renvoie l'adresse de l'instance si la
   //recherche aboutit, NULL sinon
   if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator lstToutesLesInstances(&toutesLesInstances);
      Porte* ptrPorte = (Porte*)lstToutesLesInstances++;

      //parcours de la liste des instances en recherchant celle dont
      //le nom est pNomPorte
      while(ptrPorte && (ptrPorte->getNomPorte()!=pNomPorte))
			ptrPorte = (Porte*)lstToutesLesInstances++;

      //on v�rifie si on est sortie de la boucle en ayant trouv� l'instance
      if(ptrPorte && (ptrPorte->getNomPorte() == pNomPorte))
      	return ptrPorte;
      else
      	return NULL;
   }
}
