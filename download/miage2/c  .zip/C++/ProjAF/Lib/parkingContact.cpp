/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Sp�cification de la classe ParkingContact
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : parkingContact.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 27 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/


#include <fstream.h>
#include "ListeIte.h"
#include "Porte.h"
#include "Zone.h"
#include "ParkingContact.h"

//constructeur
ParkingContact::ParkingContact(string pNomParking, string pPorteAssocie,
				string pZoneAssocie):Parking(pNomParking,pPorteAssocie,pZoneAssocie)
{
	//mise � jour de la liste des instances de ParkingContact
   toutesLesInstances.ajouter(this);
}

//destructeur
ParkingContact::~ParkingContact()
{
	//mise � jour de la liste des instances ParkingContact
	toutesLesInstances.oter(this);
}

//affichage d'un Parking
ostream& operator<<(ostream & pcout,const ParkingContact& pRefParking)
{
	pcout<<"Nom du parking (au contact):"<<pRefParking.nomParking<<endl;
   if(pRefParking.ptrPorte)
   	pcout<<"Porte associ�e :"<<(pRefParking.ptrPorte)->getNomPorte()<<endl;
   if(pRefParking.ptrZone)
   	pcout<<"Zone associ�e :"<<(pRefParking.ptrZone)->getNomZone()<<endl;
   return pcout;
}


//methodes statiques

//initialisation donn�e statique
Liste ParkingContact::toutesLesInstances;

//fonction qui affiche la liste
//des instances de Parking
void ParkingContact::afficherToutesLesInstances()
{
	ParkingContact *precParking;
   if(toutesLesInstances.listeVide())
   	cout<<"Il n'y a aucun parking au contact enregistr�"<<endl;
   else
   {
   	//parcours de la liste cha�nee et affichage
      ListeIterator parkingIterateur(&toutesLesInstances);

      precParking=(ParkingContact*)parkingIterateur++;

      while (precParking)
      {
      	cout<<*precParking;
         precParking=(ParkingContact*)parkingIterateur++;
      }

   }

}

//nombre d'instances de parking enregistres
int ParkingContact::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//retourne l'adresse d'un Parking dont le nom est passe en param�tre
ParkingContact* ParkingContact::adresseInstance(string pNomParking)
{
	//recherche dans la liste des instances de Parking celle dont le nom
   //correspond au param�tre et renvoie l'adresse de l'instance si la
   //recherche aboutit, NULL sinon
   if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator lstToutesLesInstances(&toutesLesInstances);
      ParkingContact* ptrParking = (ParkingContact*)lstToutesLesInstances++;

      //parcours de la liste des instances en recherchant celle dont
      //le nom est pNomParking
      while(ptrParking && ((ptrParking->getNomParking())!=pNomParking))
			ptrParking = (ParkingContact*)lstToutesLesInstances++;

      //on v�rifie si on est sortie de la boucle en ayant trouv� l'instance
      if(ptrParking && (ptrParking->getNomParking() == pNomParking))
      	return ptrParking;
      else
      	return NULL;
   }
}
