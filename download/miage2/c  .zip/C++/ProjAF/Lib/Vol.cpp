/**************************************************************************
*
* Nom du projet     : Automatisation du Poste de Coordination Centrale
* Objet 				  : Implementation de la classe Vol
*
*
***************************************************************************
*
* R�pertoire                : projaf/lib
* Nom du fichier            : Vol.cpp
* Nom du fichier d'analyse  :
* Auteur                    : Maya DARRIEULAT - BABA NGOM - David ROUSSE
* Date de creation          : 10 / 02 /2000
* Date de mise a jour       :
* Valide par                :
* Date de validation        : 11 / 01 / 2000
* Indice du module          : 0
*
***************************************************************************
*/

#include <fstream.h>
#include "ListeIte.h"
#include "Vol.h"
#include "VolArrive.h"
#include "VolDepart.h"
#include "Sejour.h"

//initialisation donn�e statique
Liste Vol::toutesLesInstances;

//constructeur
Vol::Vol(string pNumVol,string pNumAvionAssocie,DateHeure pHeure,string pVille)
{
	numVol = pNumVol;

   //liaison avec l'Avion dont le num�ro est pass� en param�tre
   ptrAvion = Avion::adresseInstance(pNumAvionAssocie);

   //mise � jour de la liste de porte du Hall dont d�pend this
   if(ptrAvion)
   	ptrAvion->majTousLesVols(this);

   heure = pHeure;

   ville = pVille;

   toutesLesInstances.ajouterEnOrdre(this);
}

//destructeur
Vol::~Vol()
{
   //mise � jour de la liste des vols dont d�pend this
   if(ptrAvion)
	   ptrAvion->oterVol(this);

	//mise � jour de la liste des instances Vol
   toutesLesInstances.oter(this);
}

//Accesseurs
string Vol::getNumVol()const
{
	//retourne le num�ro de vol
	return(numVol);
}

Avion* Vol::getPtrAvion()const
{
	//retourne l'adresse de l'Avion associ� � vol
	return(ptrAvion);
}

DateHeure Vol::getHeure()const
{
	//renvoie le nom du Vol
   return(heure);
}

string Vol::getVille()const
{
	//renvoie le nom de la ville
   return(ville);
}

//affecte l'Avion associ� au Vol this
void Vol::setPtrAvion(Avion * pPtrAvionAssocie)
{
	//on verifie que l'avion que l'on veut associ� au Vol this existe
   if(Avion::adresseInstance(pPtrAvionAssocie->getNumAvion()))
   	ptrAvion = pPtrAvionAssocie;
}

//affecte l'Avion associ� au Vol � NULL
void Vol::setPtrAvionNull()
{
	ptrAvion = NULL;
}

//affecte le Sejour associ� au Vol this
void Vol::setPtrSejour(Sejour * pPtrSejourAssocie)
{
	//on verifie que le sejour que l'on veut associ� au Vol this existe
   if(Sejour::adresseInstance(pPtrSejourAssocie))
   	ptrSejourAssocie = pPtrSejourAssocie;
}

//affecte le Sejour associ� au Vol � NULL
void Vol::setPtrSejourNull()
{
	ptrSejourAssocie = NULL;
}

//surcharge de cout pour l'affichage d'un Vol
ostream& operator<<(ostream & pcout, const Vol & pRefVol)
{
	pcout<<endl<<"Numero du Vol :"<<pRefVol.numVol<<endl;
   if(pRefVol.ptrAvion)
   	pcout<<"Avion associe :"<<(pRefVol.ptrAvion)->getNumAvion()<<endl;
   pcout<<pRefVol.getHeure();
   pcout<<"Ville :"<<pRefVol.ville<<endl;

   return(pcout);
}

//surcharge op�rateur de comparaison > entre this et un VolArrive
//renvoie 1 si l'heure de this est sup�rieure � celle de pPtrVolArrive
int Vol::operator>(Base *pPtrVol)
{
   //cout<<"> dans Vol "<<endl;
   if(pPtrVol)
		return (heure>(((Vol*)pPtrVol)->getHeure()));
   else
   	return 0;
}

//surcharge op�rateur de comparaison > entre this et un Vol
//renvoie 1 si l'heure de this est sup�rieure � celle de pPtrVol
int Vol::operator<=(Base *pPtrVol)
{
   //cout<<"<= dans Vol "<<endl;
   if(pPtrVol)
		return (heure<=(((Vol*)pPtrVol)->getHeure()));
   else
   	return 0;
}

//cr�e des instances de vols � partir du fichier sejours.txt
//plac� dans le r�pertoire ../Donnees
void Vol::initToutesLesInstances()
{
	string tempNumVol, tempNumAvionAssocie,tempVille;
   string tempNumAvion, tempTypeAvion;
   int tempH, tempM, nombreEnregistrement, nombreAppareil, cpt;
   ifstream fichierEntre("../Donnees/Sejours.txt"); //cr�ation d'une instance
   																//de istream pour la lecture
                                                   //des sejours
   //ifstream fichierAvion("../Donnees/Avion.txt");

	//on teste si le fichier peut �tre lu
   if(fichierEntre.good())
   {
   	//lecture du nombre d'enregistrements
      fichierEntre>>nombreEnregistrement;

      for(int i=0;i<nombreEnregistrement;i++)
      {
         //lecture d'un enregistrement dans le fichier
      	fichierEntre>>tempNumVol;
         fichierEntre>>tempH;
         fichierEntre>>tempM;
		   fichierEntre>>tempVille;
         fichierEntre>>tempNumAvionAssocie;

         //recherche du type de l'avion correspondant �
         //tempNumAvionAssocie dans le fichier Avion.txt
         //si l'avion en question n'est pas encore instanci�
         if(!Avion::adresseInstance(tempNumAvionAssocie))
         {
         	ifstream fichierAvion("../Donnees/Avion.txt");

         	if(fichierAvion.good())
		   	{
            	//lecture du nombre d'enregistrements dans Appareil.txt
      			fichierAvion>>nombreAppareil;

            	//on lit le premier article
            	fichierAvion>>tempNumAvion;
            	fichierAvion>>tempTypeAvion;

            	//on met � jour le compteur de lecture
            	cpt=1;

            	//tant que l'on est pas � la fin du fichier Appareil.txt
            	//et que l'on a pas trouv� le type d'appareil de tempNumAvionAssocie
            	//on reste dans le while
            	while((cpt<nombreAppareil) && (tempNumAvionAssocie!=tempNumAvion))
            	{
            		//on passe � l'enregistrement suivant
               	fichierAvion>>tempNumAvion;
               	fichierAvion>>tempTypeAvion;
               	//on incr�mente le compteur de lecture
               	cpt++;
            	}
            	//on v�rifie que l"'on a trouv� le type de l'avion
            	if(tempNumAvionAssocie==tempNumAvion)
					{	//cr�ation d'un nouvel Avion
               	new Avion(tempNumAvion,tempTypeAvion);
               	cout<<"Cr�ation d'un avion dans Vol::initToutesLesInstances"<<endl;
            	}
            	//repositionnemnt en d�but de fichier Avion.txt en fermant
            	//-reouvrant le fichier
            	fichierAvion.close();
            	//fichierAvion.setbuf("",0);
            	//ifstream fichierAvion("../Donnees/Appareil.txt");
         	}
         }

         //objet local pour la manipulation de l'heure d'un Vol
         DateHeure tempHeure(tempH,tempM);

         //instanciation alternativement d'un VolArrive et d'un VolDepart
         if(i%2)
         	//instanciation d'un vol depart
            new VolDepart(tempNumVol,tempNumAvionAssocie,tempHeure,tempVille);
         else
	         //instanciation d'un vol arrive
   	      new VolArrive(tempNumVol,tempNumAvionAssocie,tempHeure,tempVille);
      }
   }

   //fermeture fichier
   fichierEntre.close();
   //fichierAvion.close();
}

//affiche toutes les instances pr�sentes en m�moire de Vol
void Vol::afficherToutesLesInstances()
{
	Vol *precVol;
	if(toutesLesInstances.listeVide())
     	cout<<"Il n'y a aucun vol enregistr�"<<endl;
	else
	{
      //parcours de la liste cha�n�e et affichage
		ListeIterator volIterateur(&toutesLesInstances);

      precVol=(Vol*)volIterateur++;

      while(precVol)
      {
         cout<<*precVol;
         precVol=(Vol*)volIterateur++;
      }
   }
}

//renvoie le nombre d'instances pr�sentes en m�moire de Vol
int Vol::nombreInstances()
{
	return toutesLesInstances.longueur();
}

//renvoie l'adresse d'une instance de Vol dont on passe le nom en param�tre
Vol* Vol::adresseInstance(string pNumVol)
{
	//recherche dans la liste des instances de Vol celle dont le nom
   //correspond au param�tre et renvoie l'adresse de l'instance si la
   //recherche aboutit, NULL sinon
   if(toutesLesInstances.listeVide())
   	return NULL;
   else
   {
   	ListeIterator lstToutesLesInstances(&toutesLesInstances);
      Vol* ptrVol = (Vol*)lstToutesLesInstances++;

      //parcours de la liste des instances en recherchant celle dont
      //le nom est pNumVol
      while(ptrVol && (ptrVol->getNumVol()!=pNumVol))
			ptrVol = (Vol*)lstToutesLesInstances++;

      //on v�rifie si on est sortie de la boucle en ayant trouv� l'instance
      if(ptrVol && (ptrVol->getNumVol() == pNumVol))
      	return ptrVol;
      else
      	return NULL;
   }
}


