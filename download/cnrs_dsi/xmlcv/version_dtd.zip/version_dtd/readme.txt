*********************************************
************       Contenu       ************
************    David ROUSSE     ************
*********************************************

readme.txt : ce fichier

cv.xml : CV en XML � valider via dtd/cv.dtd

dr_copyright.xml : copyright inclus dans cv.xml

cv.htm : CV en HTML g�n�r� via cv.xml 

\dtd : DTD pour la validation d'un CV

\img : images utilis�es dans un CV

\xsl : feuilles de style pour la pr�sentation d'un CV

Utilitaires XML en ligne de commande :

- Parseur XML Xerces
java dom.Counter [-n] -v [-s] cv.xml 
java sax.Counter [-n] -v [-s] cv.xml

- Processeur XSLT Xalan 
java org.apache.xalan.xslt.Process -IN cv.xml -XSL xsl/cv.xsl -OUT cv.html

***********************************************
* Date de cr�ation : 15/02/2003		      *
* Derni�re mise � jour : 15/02/2003           *
***********************************************
*         Ing�nieur d'�tudes CNRS             *
***********************************************
