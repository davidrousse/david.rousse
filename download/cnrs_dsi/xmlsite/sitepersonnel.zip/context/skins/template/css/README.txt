CSS files traditionally go here.  They are referenced in site2xhtml.xsl with
(for example):

<link rel="stylesheet" href="{$root}skin/page.css" type="text/css"/>
