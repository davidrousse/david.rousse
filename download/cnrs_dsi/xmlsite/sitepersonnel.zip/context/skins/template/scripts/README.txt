Javascript files traditionally go here.  They are referenced in site2xhtml.xsl
with (for example):

<script type="text/javascript" language="JavaScript" src="{$root}skin/breadcrumbs.js"/>
