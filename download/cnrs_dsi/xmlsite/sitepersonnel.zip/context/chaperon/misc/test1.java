/*
 *  Copyright (C) Chaperon. All rights reserved.                               
 *  ------------------------------------------------------------------------- 
 *  This software is published under the terms of the Apache Software License 
 *  version 1.1, a copy of which has been included  with this distribution in 
 *  the LICENSE file.                                                         
 */

package example;

public class Example
{
  public String concat(String param1, String param2) 
  {
    return param1 + param2;
  }
}
