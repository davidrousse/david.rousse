#include <conio.h>
#include <stdio.h>
#include <process.h>
#include <stdlib.h>

					/* Jeu de demineur, version 2            */
               /* Taille du tableau g�r�e dynamiquement */

/* variables globales */
int **champs;
char **Situation;
int NbLignes, NbColonnes, NbMines, perdu, NbMinesDec;

/* fonction qui place des mines */
void PlacerMines(int NbM)
{
	int x, y, i, j;

   for(i=0;i<=(NbLignes-1);i++)
   {
   	for(j=0;j<=(NbColonnes-1);j++)
        	champs[i][j]=0;
   }
   i=0;
   while(i!=NbM)
   {
   	x=rand()%NbLignes;
      y=rand()%NbColonnes;
      if(champs[x][y]!=(-1)) /* on s'assure que la case     */
      {			   			  /* ne contient pas deja 1 mine */
        	champs[x][y]=(-1); /* -1 symbolise une mine */
      	i++; /* on comptabilise le nombre de mines placees */
      }
   }
}

/* fonction qui calcule les valeurs dans la table champs */
void CalculerValeursCases()
{
	int Nbl, Nbc;
	for(Nbl=0; Nbl <= NbLignes-1; Nbl++)
	{
		for(Nbc=0; Nbc <= NbColonnes-1; Nbc++)
		{
			if(champs[Nbl][Nbc] == (-1))  /* -1 symbolise 1 mine */
			{
            if(Nbc < NbColonnes-1 && Nbl > 0)
					if(champs[Nbl-1][Nbc+1] != (-1))
						champs[Nbl-1][Nbc+1]++;
            if(Nbc < NbColonnes-1)
					if(champs[Nbl][Nbc+1] != (-1))
						champs[Nbl][Nbc+1]++;
				if(Nbc < NbColonnes-1 && Nbl < NbLignes-1)
					if(champs[Nbl+1][Nbc+1] != (-1))
						champs[Nbl+1][Nbc+1]++;
				if(Nbl < NbLignes-1)
					if(champs[Nbl+1][Nbc] != (-1))
						champs[Nbl+1][Nbc]++;
            if(Nbc > 0 && Nbl < NbLignes-1)
					if(champs[Nbl+1][Nbc-1] != (-1))
						champs[Nbl+1][Nbc-1]++;
				if(Nbc > 0)
					if(champs[Nbl][Nbc-1] != (-1))
						champs[Nbl][Nbc-1]++;
				if(Nbc > 0 && Nbl > 0)
					if(champs[Nbl-1][Nbc-1] != (-1))
						champs[Nbl-1][Nbc-1]++;
				if(Nbl > 0)
					if(champs[Nbl-1][Nbc] != (-1))
						champs[Nbl-1][Nbc]++;

			}
		}
	}
}

/* fonction qui initalise la table Situation affich�e pour jouer */
void CreerSituation(char **T)
{
	int i,j;
   for(i=0;i<=(NbLignes-1);i++)
   {
   	for(j=0;j<=(NbColonnes-1);j++)
      	T[i][j]='?';
   }
}

/* fonction qui affiche rectangulairement le contenu de Situation */
void AfficherSituation(char **T)
{
	int i,j,l=3;
   gotoxy(20,l);
   for(i=0;i<=(NbLignes-1);i++)
   {
   	for(j=0;j<=(NbColonnes-1);j++)
      	printf("%c ",T[i][j]);

      l++;
      gotoxy(20,l); /* on replace le curseur */
   }
   gotoxy(5,l);
   printf("M/m pour deminer	Q/q pour decouvrir	F/f pour quitter");
}

/* fonction qui decouvre les cases quand on clique sur une case vide */
void propage(int l, int c)
{
   char convert[]="12345678";  /* sert a la convertion entre     */
   									 /* les tables champs et Situation */

	// on d�couvre la situation
	Situation[l][c] = ' ';

	// en haut
	// si on n'est pas en haut du tableau
	if(l > 0)
	{
		// si la case est vide
		if(champs[l-1][c] == 0)
		{
			// Si la case n'a pas d�ja �t� d�couverte
			// Si on ne fait pas ce test, le programme ne sort jamais
			if(Situation[l-1][c] != ' ')
			{
				// on continue dans cette direction
				propage(l-1, c);
			}
		}
		else
		{
			//On est forcemment sur un chiffre
			//Il faut le d�couvrir et arr�ter dans cette direction
			Situation[l-1][c] = convert[champs[l-1][c]-1];
		}
	}
   // en bas
	if(l < NbLignes-1)
	{
		// si la case est vide
		if(champs[l+1][c] == 0)
		{
			// Si la case n'a pas d�ja �t� d�couverte
			// Si on ne fait pas ce test, le prog ne sort jamais
			if(Situation[l+1][c] != ' ')
			{
				// on continue dans cette direction
				propage(l+1, c);
			}
		}
		else
		{
			//On est forc�mment sur un chiffre
			//Il faut le d�couvrir et arr�ter dans cette direction
			Situation[l+1][c] = convert[champs[l+1][c]-1];
		}
	}

   // � gauche
	if(c > 0)
	{
		// si la case est vide
		if(champs[l][c-1] == 0)
		{
			// Si la case n'a pas d�ja �t� d�couverte
			// Si on ne fait pas ce test, le programme ne sort jamais
			if(Situation[l][c-1] != ' ')
			{
				// on continue dans cette direction
				propage(l, c-1);
			}
		}
		else
		{
			//On est forc�mment sur un chiffre
			//Il faut le d�couvrir et arr�ter dans cette direction
			Situation[l][c-1] = convert[champs[l][c-1]-1];
		}
	}

   // � droite
	if(c < NbColonnes-1)
	{
		// si la case est vide
		if(champs[l][c+1] == 0)
		{
			// Si la case n'a pas d�ja �t� d�couverte
			// Si on ne fait pas ce test, le programme ne sort jamais
			if(Situation[l][c+1] != ' ')
			{
				// on continue dans cette direction
				propage(l, c+1);
			}
		}
		else
		{
			//On est forcmement sur un chiffre
			//Il faut le d�couvrir et arr�ter dans cette direction
			Situation[l][c+1] = convert[champs[l][c+1]-1];
		}
	}
}

/* fonction qui met a jour la table Situation apres l'action du joueur */
void MAJSituation(char **Sit, int **Ch, int Nl, int Nc, char Act)
{
   char convert[]="12345678";  /* sert a la convertion entre     */
   									 /* les tables champs et Situation */

   if(Sit[Nl][Nc]=='?')
   {
   	if((Act=='M') || (Act=='m'))
      {
   		if(Ch[Nl][Nc]==(-1))
				NbMinesDec++; /* le joueur a decouvert 1 mine */
         else
         	perdu=0; /* le joueur a perdu */

      	Sit[Nl][Nc]='M';
   	}
   	else
      {
   		if((Act=='Q') || (Act=='q'))
      	{
      		if(Ch[Nl][Nc]==(-1))
         		perdu=0; /* le joueur a perdu */
         	else
         	{
            	if(Ch[Nl][Nc]!= 0)
               	Sit[Nl][Nc] = convert[Ch[Nl][Nc]-1];/*on affiche le chiffre*/
               else
               	propage(Nl,Nc); /* decouverte des cases vides */
         	};
      	}
   	};
	}
}

/* fonction qui met a jour la table Situation         */
/* quand le joueur a perdu: affiche toutres les mines */
void MAJPerdu()
{
	int i, j;
   for(i=0;i<=(NbLignes-1);i++)
   {
   	for(j=0;j<=(NbColonnes-1);j++)
      {
      	if(champs[i][j]==(-1))
         	Situation[i][j]='*';
      }
   }
}

/* fonction qui affiche les regles */
void AffRegles()
{
	printf("\n Bienvenue dans l'aide du jeu.\n Le but du jeu est de trouver ");
   printf("les mines dans la grille affich�e a l'ecran.\n");
   printf(" Apres avoir entre la taille de la grille dans laquelle vous ");
   printf(" voulez jouer,\n vous avez le choix entre 3 actions:\n\t");
   printf("- marquer une case en tapant M ou m\n\t- decouvrir une case");
   printf(" en tapant Q ou q\n\t- quitter le jeu avec F ou f\n Bonne chance!");
}

/*  fonction qui alloue la m�moire dynamiquement */
void *allocmem(int n)
{
	void *p=malloc(n);
   if(p==NULL)
   	puts("Pas assez de m�moire"),
      exit(1);
   return p;
}

/* fonction principale */
void main(void)
{
   char Action, Rep1, Rep2;
   int i, MaxMines, NumLigne, NumColonne;

   clrscr();
   printf(" Bienvenue dans le jeu de demineur.\n Voulez-vous lire les regles?");
   printf("(O=Oui/N=Non) : ");
   scanf("%c",&Rep1);
   if(Rep1=='O' || Rep1=='o')
   {
   	AffRegles();
      printf("\n Voulez-vous toujours jouer? (O=Oui/N=Non): ");
      getchar();
      scanf("%c",&Rep1);
   }
   else
   	Rep1='O';

   while(Rep1!='N' && Rep1!='n')
   {
      NbMinesDec=0; /* pr�partion d'une partie */
   	perdu=1;
      do
      {
      	clrscr();
      	printf("\n Entrez la taille du champs en lignes ");
      	printf("par colonnes,\n et separes d'un espace: ");
      	scanf("%d %d",&NbLignes,&NbColonnes);
      }
      while(NbLignes<2 || NbColonnes<2);
      MaxMines=(NbLignes*NbColonnes)-1;

      /* Allocation de la m�moire n�cessaire pour g�rer les 2 tables */
      /* pour la matrice champs */
      champs= (int **)allocmem(NbLignes * sizeof(int *));
      for(i=0;i<NbLignes;i++)
      	champs[i]=(int *)allocmem(NbColonnes * sizeof(int *));
      /* pour la matrice Situation */
		Situation= (char **)allocmem(NbLignes * sizeof(char *));
      for(i=0;i<NbLignes;i++)
      	Situation[i]=(char *)allocmem(NbColonnes * sizeof(char *));

      do
      {
      	printf("\n Entrez le nombre de mines (<= %d): ",MaxMines);
         scanf("%d",&NbMines);
      }
      while(NbMines>MaxMines);

      /* generation de la table champs */
      srand(getpid());
      PlacerMines(NbMines);
      CalculerValeursCases();
      clrscr();
      /* generation de la table Situation */
      CreerSituation(Situation);
      AfficherSituation(Situation);

      /* demande de l'action */
      do
      {
      	printf("\n\n\t Quelle action voulez-vous faire? : ");
         getchar();
         scanf("%c",&Action);
      }
      while(Action!='Q' && Action!='q' && Action!='M' && Action!='m'
      												&& Action!='F' && Action!='f');

      while(Action!='F' && Action!='f' && NbMinesDec!=NbMines &&	perdu!=0)
      {
      	/* demande des coordonnees */
         do
         {
         	printf("\n\t Donnez les coordonnees (<= %d *",NbLignes);
            printf(" %d), separees d'un espace: ",NbColonnes);
            scanf("%d %d",&NumLigne,&NumColonne);
         }
         while(NumLigne>NbLignes || NumColonne>NbColonnes);

         /* modification de Situation */
         MAJSituation(Situation,champs,NumLigne-1,NumColonne-1,Action);
         clrscr();
         AfficherSituation(Situation);

         /* demande d'une nouvelle action */
         if(NbMinesDec!=NbMines && perdu!=0)
         {
         	do
	      	{
   	   		printf("\n\t Quelle action voulez-vous faire? : ");
      	   	getchar();
        			scanf("%c",&Action);
      		}
      		while(Action!='Q' && Action!='q' && Action!='M' && Action!='m'
      													&& Action!='F' && Action!='f');

      	}
      }


      /* la partie est finie */
      /* partie perdue */
      if(perdu==0)
      {
      	MAJPerdu(); /* on montre l'emplacemlent des mines au joueur */
         clrscr();
         AfficherSituation(Situation);
         printf("\n\n\t\a Dommage, c'est perdu.");
      }
      /* partie gagn�e */
      if(NbMinesDec==NbMines)
      	printf("\n\n\t Bravo, c'est gagne!!!");

      /* la partie est interrompue par le joueur */
      if(Action=='F' || Action=='f')
      {
      	printf("\n\t Voulez-vous vraiment quitter? (O=Oui/N=Non) : ");
         getchar();
         scanf("%c",&Rep2);
         if(Rep2=='O' || Rep2=='o')
         	Rep1='N';
      }
      else
      {
      	printf("\n\t Voulez-vous rejouer? (O=Oui/N=Non) : ");
         getchar();
         scanf("%c",&Rep1);
      };
   }
}
